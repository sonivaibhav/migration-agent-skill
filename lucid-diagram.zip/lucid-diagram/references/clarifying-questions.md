# Clarifying questions — when and what to ask

The goal is a diagram the user only has to review. Questions cost the user a round-trip, a wrong
diagram costs them more. Ask when an answer would change the picture; don't ask when you can find
out yourself or when a default is obviously fine.

## Decide first: can I draw without asking?

Draw immediately when ALL of these are true:

- The diagram type is clear from the wording ("sequence diagram", "swimlane", "ERD", "org chart"), or
  only one type makes sense for the subject.
- The subject is defined: the user described the nodes/steps, or it is code/config in the repo you can read.
- Nothing in the request hints at a specific audience or level ("for the exec review" → high level; "for the runbook" → detailed).

If the subject is in the repo, explore it before deciding. Typical sources: entry points and routers
(architecture), ORM models / migrations (ERD), class hierarchies (class), state enums and transition
tables (state), CI/CD YAML (flowchart), handlers that call other services (sequence).

Otherwise ask — once, up to 3 questions, using **AskUserQuestion** with 2–4 short options each.
Always put the most likely answer first. Include "Something else" only when the options aren't exhaustive.

## Question templates (pick the ones that matter)

**Type** (only when ambiguous)
> "Which view of the checkout process do you want?"
> - Flowchart — the steps and decisions
> - Swimlane — steps by team/system
> - Sequence — the calls between services over time

**Scope**
> "How detailed should this be?"
> - Overview — ~10 boxes, fits on a slide
> - Detailed — ~25 boxes, every step
> - Full set — overview + one detail diagram per area

**Layers**
> "Which overlays should be toggleable layers?" (multi-select)
> - Exception / error handling
> - Security boundaries
> - Future state / proposed changes
> - Review notes and assumptions

**Audience / style** (rarely needed)
> "Who is this for?"
> - Engineers — technical labels, protocols on edges
> - Leadership — plain-language labels, no internals
> - Mixed — technical diagram with an annotations layer

**Orientation** — don't ask; default from `diagram-types.md`. Change only if the preview is awkward or the user objects.

**Missing facts about the subject** — ask in plain language, not multiple choice, when the answer is
free-form ("Which services does the orchestrator call besides the vector store?"). Batch these into
one message.

## After the answers

State your assumptions in one line when you deliver ("Assumed the payment service is external; put
it outside the platform boundary"). That is cheaper than another question and easy for the reviewer
to correct.

Don't re-ask after a re-render. If a revision request is ambiguous ("make it cleaner"), do the most
plausible fix (switch direction, add containers, hide an overlay) and say what you changed.
