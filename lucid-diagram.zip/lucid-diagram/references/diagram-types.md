# Diagram types — conventions, shape vocabulary, layer presets, quality bar

Read only the section you need. Each ends with the reviewer checklist that "professional" means
for that type. `examples/<type>.json` is a worked spec for every section.

Contents: Flowchart · Swimlane · Architecture · Network · Sequence · ERD · Class · State · Org chart · Mind map · Use case · Freeform

---

## Flowchart (`type: flowchart`)

**Use for:** a single process with decisions. **Direction:** `TB` (or `LR` for wide, shallow flows).

Shapes: `terminator` start/end (green start, green/red end) · `process` steps · `decision`
questions phrased as yes/no, colour `yellow` · `data` inputs/outputs · `document` · `database` ·
`subroutine` for a step detailed elsewhere · `note` for SLAs/assumptions.

Layers: `Process` (base) · `Exception handling` (error branches, retries — dashed edges back to the step) · `Future state` · `Review notes`.

Quality bar:
- Exactly one start; every path reaches an end.
- Every decision has ≥2 outgoing edges, all labelled (`yes`/`no`, or the value tested).
- Verbs in steps ("Validate payment"), questions in decisions ("Payment OK?").
- ≤ 20 steps; extract sub-processes into `subroutine` nodes and separate diagrams.

## Swimlane (`type: swimlane`)

**Use for:** a process across roles/teams/systems — who does what. Needs `lanes`.

- `lane_orientation: horizontal` (roles as rows, flow left→right) is the norm for ≤ 6 lanes; use
  `vertical` when there are many short steps.
- Same shape vocabulary as flowchart; every node needs a `lane`.
- Hand-offs between lanes are the point of the diagram — make the edge label the artefact handed over when it isn't obvious ("signed contract").

Layers: `Process` · `Future state (automation)` (purple, dashed) · `Pain points` (red notes).

Quality bar: no lane empty; lanes ordered by first participation; ≤ 25 nodes total.

## Architecture / cloud (`type: architecture`)

**Use for:** systems, services, cloud deployments. **Direction:** `LR` (clients left, data stores right).

- Containers are the structure: region → VPC → subnet; or "Clients" / "Platform" / "Third parties".
  Nest with `parent`. Security boundaries get `style.dashed: true` and go on the `Security boundaries` layer.
- Shapes: `user`/`actor`, `device` (apps), `service` (compute/API/function), `database`, `storage`
  (object storage), `queue` (Kafka/SQS), `cloud`/`internet`, `loadbalancer`, `firewall`.
  Put the vendor product in the label ("Bedrock LLM", "Cloud Run"). See SKILL.md on icons.
- Edge labels: protocol/payload ("HTTPS", "gRPC", "S3 event", "embeddings"). Dashed for auth / control plane.
- Colour semantics (pick one scheme, add a legend note): purple = AI/ML, red = security/auth,
  orange = async/ingestion, blue = default.

Layers: `Infrastructure` (base) · `Data flow` (all edges) · `Security boundaries` · `Scaling/HA` · `Annotations`.
Putting all edges on `Data flow` lets a reviewer see topology alone by hiding that layer.

Quality bar: one request path can be traced end-to-end; every store has an owner service;
external systems visibly outside the platform boundary; ≤ 20 nodes per page.

## Network (`type: network`)

**Direction:** `TB` (internet at top). Containers = zones (DMZ, LAN, VLANs) with CIDR in the label,
dashed on the `Security zones` layer. Shapes: `internet`, `firewall`, `loadbalancer`, `device`
(switch/router), `server`, `database`. Edge labels: ports/protocols where they matter.

Layers: `Physical` · `Security zones` · `Logical/VLANs` · `Monitoring`.

## Sequence (`type: sequence`)

**Use for:** ordered interactions between participants. Spec lives in `sequence.actors` / `sequence.messages`.

- Actors left→right in order of first involvement; the human/initiator first with `shape: actor`,
  stores last with `shape: database`.
- Messages: imperative or endpoint form ("POST /orders", "authorize(card)"). Returns are `kind: return`.
- Error/alternative flows on their own layer (`Error handling`), coloured red — Lucid has no
  native `alt` frame in import, so the layer toggle *is* the alt frame.
- `note` on a message for constraints (timeouts, retries, idempotency).

Quality bar: ≤ 15 messages per diagram; every request has a visible response or is marked `async`;
no participant without messages.

## ERD (`type: erd`)

Entities are `shape: entity` with `attributes` rows: `PK id: uuid`, `FK order_id: uuid`, `name: varchar(255)`.
Relationships are edges with crow's-foot arrows: `one`, `many`, `zero-or-many`, `one-or-many`,
plus `start_arrow` for the other end. Label the edge with the verb phrase ("places", "contains").
**Direction:** `LR`, parents left.

Layers: `Model` · `Indexes/constraints` (notes) · `Planned changes` (dashed entities).

Quality bar: every FK has a relationship edge; cardinality on both ends; ≤ 15 entities per page (split by bounded context).

## Class (`type: class`)

`shape: class` with `attributes` and `methods` using UML visibility (`+ - #`). Stereotypes in the label
(`«interface» Tool`). Edges: `inherit` (generalisation, dashed for interface realisation), `diamond`
(aggregation/composition), `open` (association, label with multiplicity "1..*").
Layout puts parents above children automatically. **Direction:** `TB`.

Quality bar: no god-class with > 8 methods listed (summarise); associations labelled with multiplicity.

## State machine (`type: state`)

`start` and `end` pseudo-states (empty labels), `state` shapes, transitions labelled with the event
(and `[guard]` / `/ action` when relevant). **Direction:** `LR` for linear lifecycles, `TB` for branching.
Highlight active/happy-path states in `blue`, terminal success in `green`, failure in `red`.

Layers: `States` · `Error transitions` · `Timeouts`.

Quality bar: every state reachable from start; every non-terminal state has an exit; transitions labelled.

## Org chart (`type: orgchart`)

`shape: person`, label `"Title\nName"`. Edges parent → report. **Direction:** `TB`. Tree layout centres
reports under their manager. Colour by function sparingly.

Layers: `Current` · `Open roles` (dashed, gray) · `Proposed changes`.

## Mind map (`type: mindmap`)

One `root`, `topic` children, edges root → branch → leaf. **Direction:** `LR`. Colour the first-level
branches; leaves inherit the theme. Keep leaf labels ≤ 4 words.

## Use case (`type: usecase`)

`actor` shapes outside a container that represents the system; `usecase` ellipses inside; edges
`open` arrows from actor to use case; `inherit`-style dashed edges labelled "«include»"/"«extend»".
**Direction:** `LR`.

## Freeform (`type: freeform`)

Layered layout with no type-specific rules or orphan warnings. Use when nothing above fits (e.g. a
timeline or a concept map) or when the user supplies `x`/`y` for everything.

---

## Universal quality rules

- Title on the page (`title`) and, for multi-diagram sets, a numbered prefix ("01 Overview", "02 Ingestion").
- One idea per diagram. Overview first, then detail diagrams that each zoom into one container.
- Labels are nouns for things and verbs for actions; no abbreviations the audience wouldn't know.
- Colour means something and is explained by a legend note on the `Annotations`/`Review notes` layer.
- Layers: base picture stands on its own with every overlay hidden.
- Straight, mostly non-crossing flow. If the preview looks tangled, change `direction`, add containers, or split.
