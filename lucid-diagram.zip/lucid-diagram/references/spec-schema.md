# Diagram spec (JSON) reference

One JSON file per diagram. Everything except `nodes` is optional. Run
`python3 scripts/lucid_diagram.py schema` for the compact version.

## Top level

| Field | Values | Notes |
|---|---|---|
| `title` | string | Page name in Lucid and default file name (slugified). |
| `type` | `flowchart` `swimlane` `architecture` `network` `sequence` `erd` `class` `state` `orgchart` `mindmap` `usecase` `freeform` | Picks the layout algorithm and defaults. |
| `direction` | `TB` `BT` `LR` `RL` | Main flow direction. Default `TB`. Ignored by `sequence`. |
| `theme` | `neutral` `blue` `slate` `green` | Default fill/stroke/font colours. |
| `layers` | list of `{id, name, visible?, locked?}` | First layer is the base. Referenced by `id` or `name`. |
| `containers` | list of Container | Boundaries / groups. Nest with `parent`. |
| `nodes` | list of Node | Required. |
| `edges` | list of Edge | Connectors. |
| `lanes` | list of `{id, label}` | `swimlane` only. |
| `lane_orientation` | `horizontal` (lanes are rows, flow L→R) or `vertical` (columns, flow T→B) | `swimlane` only. Default `horizontal`. |
| `sequence` | `{actors, messages}` | `sequence` only, see below. |
| `spacing` | `{rank, node, container_padding, message, lifeline}` | Pixels. Increase `rank` when edge labels collide; `node` when shapes crowd. |

## Node

```json
{"id": "api", "label": "Orders API", "shape": "service", "container": "vpc", "layer": "infra",
 "color": "blue", "style": {"bold": true, "dashed": false, "fontSize": 12},
 "attributes": ["PK id: uuid"], "methods": ["+ run()"], "note": "reviewer hint", "link": "https://…",
 "x": 100, "y": 40, "w": 160, "h": 60}
```

- `label` — use `\n` for manual line breaks (e.g. `"CTO\nJane Park"`). Empty is fine for `start` / `end`.
- `shape` — see catalogue below. Unknown shapes fall back to `process` with a warning.
- `container` — id of a Container. Node is laid out inside it.
- `lane` — lane id (swimlane diagrams).
- `layer` — layer id or name. Default: first layer.
- `color` — `blue` `green` `orange` `red` `purple` `yellow` `gray` `white` `teal` or `#RRGGBB`. Omit for the theme default.
- `attributes` / `methods` — rows for `class` and `entity` shapes. Prefix `PK`/`FK`, or UML `+ - #`.
- `note` — not drawn; emitted as an XML comment for reviewers.
- `link` — URL attached to the shape (draw.io only).
- `x`,`y` (+ `w`,`h`) — pin the node at absolute pixels; it is excluded from auto-layout.

### Shape catalogue

| Family | Shapes |
|---|---|
| Flowchart | `process` `rounded` `terminator` `decision` `data` `document` `database` `subroutine` `hexagon` `delay` `manual` `note` `text` `ellipse` `circle` |
| Architecture / network | `service` `server` `queue` `cloud` `internet` `storage` `firewall` `loadbalancer` `device` `user` `actor` |
| UML | `class` `entity` `state` `start` `end` `usecase` `component` |
| Org / mind map | `person` `root` `topic` |

## Edge

```json
{"id": "e1", "from": "web", "to": "api", "label": "HTTPS", "layer": "data",
 "style": {"arrow": "block", "dashed": true, "dotted": false, "color": "#B85450", "width": 2, "start_arrow": "one"}}
```

- `from` / `to` — node or container ids.
- `arrow` — `block` (default) `open` `none` `both` `diamond` (aggregation) `inherit` (generalisation; laid out parent-above-child) `one` `many` `zero-or-many` `one-or-many` (crow's foot; `start_arrow` sets the other end, default `one`).
- `dashed` — dependencies, async, optional, future-state.
- `layer` — overlays like "Error handling" or "Future state".

## Container

```json
{"id": "vpc", "label": "VPC (private)", "parent": "aws", "layer": "security", "color": "#FDF5E6", "style": {"dashed": true}}
```

Containers size themselves to their children plus padding. Edges may target a container.

A container on the **base layer** is a real group in Lucid (drag it and the children follow). A container on an
**overlay layer** (e.g. a security boundary) is drawn as an outline only, so hiding the overlay never hides the
nodes inside it; its children are grouped with the nearest base-layer ancestor instead.

## Layer

```json
{"id": "future", "name": "Future state", "visible": true, "locked": false}
```

`visible:false` still exports the content; it is hidden by default when opened. Lucid shows layers in the right-hand **Layers** panel.

## Sequence diagrams

```json
"sequence": {
  "actors": [{"id": "u", "label": "Shopper", "shape": "actor"}, {"id": "api", "label": "Orders API"}],
  "messages": [
    {"from": "u", "to": "api", "label": "POST /orders", "kind": "sync"},
    {"from": "api", "to": "u", "label": "201", "kind": "return", "layer": "base", "note": "idempotent"}
  ]}
```

- Actors are drawn left→right in list order; put the initiator first.
- `kind`: `sync` (solid, filled arrow), `async` (solid, open arrow), `return` (dashed, open arrow).
- `from == to` draws a self-message.
- `note` adds a sticky note to the right of the message.
- There is no native alt/loop frame on the import path; put alternative flows on their own layer (e.g. "Error handling") so the layer toggle plays that role.
- `nodes`/`edges` are ignored for this type (generated from `sequence`).

## Layout knobs that fix most problems

| Symptom | Fix |
|---|---|
| Edge labels overlap shapes | `"spacing": {"rank": 100}` |
| Shapes crowded side by side | `"spacing": {"node": 70}` |
| Diagram too tall | `"direction": "LR"` |
| Long edge crosses a box | Usually solved automatically (channels are reserved); otherwise move the target into the same container, or split the node |
| Label wraps badly | Add `\n` in the label or give the node `w` |
| Wrong node above another | Add an edge that expresses the dependency, or pin one node with `x`/`y` |
