---
name: lucid-diagram
description: Generate professional, review-ready Lucidchart diagrams as importable files (.drawio primary, .vsdx fallback, plus a .png preview) from a JSON spec, with auto-layout and Lucid layers — no Lucid API token or connector needed, the user uploads through the Lucid UI. Use this whenever the user asks for any diagram, flowchart, swimlane, architecture/cloud diagram, sequence diagram, ERD, class diagram, state machine, org chart, network diagram, mind map, or says "draw", "visualize", "map out", "chart the flow", or mentions Lucid/Lucidchart/Lucidspark, Visio, or draw.io — even if they don't name a diagram type. Also use it to diagram code, systems, or processes found in the repo.
---

# /lucid-diagram

Turn a request (or a codebase) into a diagram file the user can drop into Lucidchart's
**Import documents** dialog. The user's job should be *validate and review*, not *draw*.

Outputs per diagram, all from one spec:
- `<name>.drawio` — primary. Lucid imports draw.io files as editable native shapes and reads layers.
- `<name>.vsdx` — Visio fallback for tenants that block draw.io import.
- `<name>.png` — preview rendered from the same layout, so you and the user can eyeball it before delivering.
- `<name>.json` — the spec. It is the source of truth; commit it so diagrams can be regenerated and diffed.

## Workflow

### 1. Understand the request — ask before you draw

Read `references/clarifying-questions.md`. Decide within one pass whether you can draw without asking.

You can skip questions when the request already pins down: the diagram type, the subject
(what nodes/edges exist), the audience, and whether layers are wanted. If the subject is code
in the repo ("diagram our auth flow"), explore the code first — the answers usually live there,
and questions you could have answered yourself are the most annoying kind.

Otherwise use **AskUserQuestion** (multiple choice, at most 3 questions, 2–4 options each).
Ask the things that change the picture, in this priority:

1. **Diagram type** — only if genuinely ambiguous (e.g. "show me the checkout process" could be flowchart, swimlane, or sequence).
2. **Scope / level of detail** — high-level (≤12 nodes) vs detailed (≤25) vs exhaustive (multi-page).
3. **Layers** — which overlays they want toggleable (see layer presets below).
4. **Orientation and style** — TB/LR, theme, colour semantics. Usually skippable; default to the conventions in `references/diagram-types.md`.

Never ask about things the spec has sensible defaults for (spacing, shape sizes, file names).
Never ask more than once per diagram unless the answers opened a new ambiguity.

### 2. Pick the type and read its conventions

Open `references/diagram-types.md` and read **only** the section for the chosen type. It gives
the shape vocabulary, layout direction, the layer preset, and the professional-quality rules
reviewers expect (e.g. every decision has labelled yes/no edges; lifelines ordered by first use).

### 3. Write the spec

Write `diagrams/<slug>.json` following `references/spec-schema.md` (run
`python3 scripts/lucid_diagram.py schema` for the compact cheat-sheet). Rules that matter:

- Stable, meaningful ids (`api_gateway`, not `n7`). They become Lucid shape names and survive re-renders.
- Put every node, edge and container on a **layer**. Layer 1 is the base picture; overlays
  (exceptions, security, future-state, annotations) go on their own layers so reviewers can toggle them.
- Use `containers` for boundaries (VPC, region, team, subsystem). Nest them with `parent`.
- Use `color` only with meaning (one colour = one concept) and add a `note`-shaped legend node
  on an *Annotations* layer when you use more than two colours.
- Label decision edges. Label data-flow edges with the protocol or payload when known.
- Keep ≤ 25 nodes per diagram. If the subject is bigger, split into one overview plus detail diagrams,
  each its own spec.
- Leave positions out — the layout engine places everything. Only pin `x`/`y` when the user
  insists on a specific arrangement.

### 4. Render

```bash
python3 scripts/lucid_diagram.py render diagrams/<slug>.json --out diagrams/out
```

The script validates the spec first (dangling ids, undefined layers/lanes/containers, orphan nodes,
empty labels) and stops on errors. Fix the spec — don't hand-edit the outputs. Add `--strict` when
warnings should also block.

### 5. Review before handing over

Open the PNG with the Read tool and check it like a reviewer would:

- Flow reads in one direction; no edge passes through an unrelated node; no overlapping shapes.
- Labels fit (long labels → shorten or add `\n`); no orphan nodes unless they are notes.
- Every layer in the printed report has the content you intended (a layer with 0 shapes / 0 lines is a spec bug).
- The picture answers the user's question at the level they asked for.

If something is off, change the spec (direction, spacing, splitting a node, moving to a
container, adding `\n` to labels) and re-render. Two or three passes is normal.

### 6. Deliver

Give the user the file paths, the one-line report from the script, and the upload steps from
`references/lucid-upload.md` (the short version: **+ New → Import documents → drop the .drawio**).
Tell them what to validate in Lucid — layer toggles, any colour semantics, and anything you were
unsure about. Keep it brief; the diagram is the deliverable.

## Layer presets (use these unless the user asks otherwise)

| Diagram type | Base layer | Typical overlays |
|---|---|---|
| flowchart / swimlane | Process | Exception handling · Future state · Review notes |
| architecture / network | Infrastructure | Data flow · Security boundaries · Scaling/HA · Annotations |
| sequence | Happy path | Error handling · Async/background |
| erd / class | Model | Indexes/constraints · Planned changes |
| state | States | Error transitions · Timeouts |
| orgchart | Current | Open roles · Proposed changes |
| mindmap | Topics | Owners · Risks |

One layer is fine for simple diagrams. Don't manufacture overlays with nothing on them.

## Choosing the file format

- **.drawio (default).** Editable shapes, layers, containers, glued connectors. If Lucid rejects the extension, rename to `.xml` — same content.
- **.vsdx.** Same layout, simpler geometry (rect/rounded/ellipse/diamond/parallelogram/hexagon/document); fancier shapes fall back to a rectangle with the label. Use when draw.io import is disabled on the tenant.
- Both are produced by default; it costs nothing.
- Mermaid pasted into Lucid's *Diagram as code* panel is not a target: no layers, and on most tenants it renders as one uneditable object.

## Cloud icons and vendor shapes

Lucid's draw.io importer does not reliably map draw.io's AWS/Azure/GCP icon styles, so the generator uses
generic labelled shapes (`service`, `database`, `storage`, `queue`, `firewall`, `loadbalancer`, `cloud`).
Put the vendor product in the label ("API Gateway", "Cloud Run"). Reviewers swap in Lucid's AWS/Azure/GCP
shape libraries with *Replace shape* in seconds, and connectors stay attached. Say this in the hand-off when
the diagram is cloud architecture.

## Files in this skill

- `scripts/lucid_diagram.py` — spec → layout → .drawio / .vsdx / .png. Stdlib only (Pillow optional for PNG). `render`, `validate`, `schema` subcommands.
- `references/spec-schema.md` — every field of the spec, shapes, arrows, colours, themes.
- `references/diagram-types.md` — per-type conventions, shape vocabulary, layer presets, quality rules.
- `references/clarifying-questions.md` — when and what to ask with AskUserQuestion; question templates.
- `references/lucid-upload.md` — UI import steps, post-import checklist, troubleshooting.
- `examples/*.json` — one worked spec per diagram type. Copy the closest one as a starting point.
- `evals/evals.json` — test prompts for iterating on this skill.
