# lucid-diagram — a Claude Code skill

`/lucid-diagram` turns a request (or your codebase) into a professional diagram file that imports
straight into Lucidchart through the UI — no API token required.

- Output from one spec: `.drawio` (primary, editable shapes + layers), `.vsdx` (Visio fallback), `.png` preview, and the `.json` spec (source of truth, commit it).
- Delivery is always UI upload — no Lucid API token, REST access, or connector required.
- Types: flowchart, swimlane, architecture/cloud, network, sequence, ERD, class, state, org chart, mind map, use case, freeform.
- Layers: every node/edge/container can sit on a Lucid layer (base picture + toggleable overlays).
- Clarification: Claude uses `AskUserQuestion` when the request is ambiguous, otherwise it just draws.
- Auto-layout: layered (Sugiyama-style) with reserved channels for long edges, tidy trees for org/mind maps, lane grids for swimlanes, lifeline columns for sequences.

## Install

Copy this folder into your repo (project skill) or your home directory (personal skill):

```
.claude/skills/lucid-diagram/      # project — commit it, everyone on the repo gets /lucid-diagram
~/.claude/skills/lucid-diagram/    # personal
```

Requirements: Python 3.9+. `pip install pillow` for the PNG preview (optional).

## Use

```
/lucid-diagram sequence diagram of the checkout flow in src/checkout, with an error-handling layer
/lucid-diagram architecture of this repo for the platform review — overview only
/lucid-diagram swimlane for our customer onboarding: customer, sales, ops, IT
```

Claude writes `diagrams/<slug>.json`, renders to `diagrams/out/`, reviews the PNG, then tells you what to
upload and what to check. In Lucid: **+ New → Import documents → drop the .drawio**.

Regenerate any diagram yourself:

```
python3 .claude/skills/lucid-diagram/scripts/lucid_diagram.py render diagrams/order-flow.json --out diagrams/out
python3 .claude/skills/lucid-diagram/scripts/lucid_diagram.py validate diagrams/order-flow.json
python3 .claude/skills/lucid-diagram/scripts/lucid_diagram.py schema
```

## Layout of this skill

```
SKILL.md                      workflow Claude follows
scripts/lucid_diagram.py      spec -> layout -> drawio / vsdx / png (stdlib only)
references/spec-schema.md     the JSON spec
references/diagram-types.md   conventions + quality bar per type
references/clarifying-questions.md   AskUserQuestion playbook
references/lucid-upload.md    Lucid UI import steps, checklist, troubleshooting
examples/*.json               one spec per diagram type
evals/evals.json              test prompts
```

## Known limits

- `.vsdx` uses simplified geometry (rect/rounded/ellipse/diamond/parallelogram/hexagon/document); fancier shapes fall back to a rectangle with the label. Prefer `.drawio`.
- Cloud vendor icons are not embedded (Lucid's draw.io importer doesn't map them reliably); generic shapes are used with the product name in the label — swap via *Replace shape* in Lucid.
- Lucid's own JSON import format is REST-only and intentionally not targeted.
