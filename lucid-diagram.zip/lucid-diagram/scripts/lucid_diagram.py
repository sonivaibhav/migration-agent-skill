#!/usr/bin/env python3
"""
lucid_diagram.py — render a diagram spec (JSON) into files Lucidchart can import
through its UI (no API token needed):

  * .drawio  (draw.io / diagrams.net XML)   — primary; imports as editable shapes, keeps layers
  * .vsdx    (Microsoft Visio)              — secondary; OOXML package, keeps layers
  * .png     (preview)                      — for review before upload, needs Pillow

Usage:
  python3 lucid_diagram.py render spec.json --out ./out [--formats drawio,vsdx,png]
  python3 lucid_diagram.py validate spec.json
  python3 lucid_diagram.py schema            # print a compact spec reference

Only the Python standard library is required; Pillow is optional (preview only).
See references/spec-schema.md for the spec format.
"""
from __future__ import annotations

import argparse
import html
import json
import math
import os
import sys
import zipfile
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from xml.sax.saxutils import escape as xesc

# ----------------------------------------------------------------------------
# Shape catalog
# ----------------------------------------------------------------------------
# key -> (drawio style, vsdx geometry kind, default (w, h))
SHAPES: Dict[str, Tuple[str, str, Tuple[int, int]]] = {
    # flowchart
    "process":    ("rounded=0;whiteSpace=wrap;html=1;", "rect", (140, 60)),
    "rounded":    ("rounded=1;whiteSpace=wrap;html=1;arcSize=20;", "rounded", (140, 60)),
    "terminator": ("rounded=1;whiteSpace=wrap;html=1;arcSize=50;", "pill", (120, 50)),
    "decision":   ("rhombus;whiteSpace=wrap;html=1;", "diamond", (140, 90)),
    "data":       ("shape=parallelogram;perimeter=parallelogramPerimeter;whiteSpace=wrap;html=1;fixedSize=1;", "parallelogram", (140, 60)),
    "document":   ("shape=document;whiteSpace=wrap;html=1;boundedLbl=1;", "document", (140, 70)),
    "database":   ("shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;", "cylinder", (100, 80)),
    "subroutine": ("shape=process;whiteSpace=wrap;html=1;backgroundOutline=1;", "rect", (140, 60)),
    "hexagon":    ("shape=hexagon;perimeter=hexagonPerimeter2;whiteSpace=wrap;html=1;fixedSize=1;", "hexagon", (140, 70)),
    "delay":      ("shape=delay;whiteSpace=wrap;html=1;", "rounded", (140, 60)),
    "manual":     ("shape=manualInput;whiteSpace=wrap;html=1;", "parallelogram", (140, 60)),
    "note":       ("shape=note;whiteSpace=wrap;html=1;backgroundOutline=1;darkOpacity=0.05;size=14;", "rect", (160, 70)),
    "ellipse":    ("ellipse;whiteSpace=wrap;html=1;", "ellipse", (120, 70)),
    "circle":     ("ellipse;whiteSpace=wrap;html=1;aspect=fixed;", "ellipse", (60, 60)),
    "text":       ("text;html=1;strokeColor=none;fillColor=none;align=center;verticalAlign=middle;whiteSpace=wrap;", "text", (160, 40)),
    # architecture / network (generic, labeled — importer-safe)
    "service":    ("rounded=1;whiteSpace=wrap;html=1;arcSize=10;", "rounded", (150, 64)),
    "server":     ("rounded=0;whiteSpace=wrap;html=1;", "rect", (130, 64)),
    "queue":      ("shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;rotation=90;", "cylinder", (110, 60)),
    "cloud":      ("ellipse;shape=cloud;whiteSpace=wrap;html=1;", "cloud", (150, 90)),
    "internet":   ("ellipse;shape=cloud;whiteSpace=wrap;html=1;", "cloud", (150, 90)),
    "storage":    ("shape=cylinder3;whiteSpace=wrap;html=1;boundedLbl=1;backgroundOutline=1;size=15;", "cylinder", (100, 80)),
    "firewall":   ("rounded=0;whiteSpace=wrap;html=1;fillColor=#FDE2E2;strokeColor=#B03A2E;", "rect", (130, 60)),
    "loadbalancer": ("rhombus;whiteSpace=wrap;html=1;", "diamond", (140, 80)),
    "user":       ("shape=umlActor;verticalLabelPosition=bottom;verticalAlign=top;html=1;outlineConnect=0;", "actor", (40, 70)),
    "actor":      ("shape=umlActor;verticalLabelPosition=bottom;verticalAlign=top;html=1;outlineConnect=0;", "actor", (40, 70)),
    "device":     ("rounded=1;whiteSpace=wrap;html=1;arcSize=15;", "rounded", (120, 60)),
    # UML
    "class":      ("swimlane;fontStyle=1;align=center;verticalAlign=top;childLayout=stackLayout;horizontal=1;startSize=30;horizontalStack=0;resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=0;marginBottom=0;html=1;whiteSpace=wrap;", "table", (180, 120)),
    "entity":     ("swimlane;fontStyle=1;align=center;verticalAlign=top;childLayout=stackLayout;horizontal=1;startSize=30;horizontalStack=0;resizeParent=1;resizeParentMax=0;resizeLast=0;collapsible=0;marginBottom=0;html=1;whiteSpace=wrap;", "table", (180, 120)),
    "state":      ("rounded=1;whiteSpace=wrap;html=1;arcSize=30;", "rounded", (140, 60)),
    "start":      ("ellipse;html=1;fillColor=#000000;strokeColor=#000000;", "ellipse", (30, 30)),
    "end":        ("ellipse;html=1;shape=endState;fillColor=#000000;strokeColor=#000000;", "ellipse", (30, 30)),
    "usecase":    ("ellipse;whiteSpace=wrap;html=1;", "ellipse", (140, 70)),
    "component":  ("shape=component;align=left;spacingLeft=36;html=1;whiteSpace=wrap;", "rect", (160, 60)),
    # org / mind map
    "person":     ("rounded=1;whiteSpace=wrap;html=1;arcSize=10;", "rounded", (160, 64)),
    "topic":      ("rounded=1;whiteSpace=wrap;html=1;arcSize=40;", "pill", (140, 46)),
    "root":       ("rounded=1;whiteSpace=wrap;html=1;arcSize=40;fontStyle=1;", "pill", (170, 60)),
}
DEFAULT_SHAPE = "process"

CONTAINER_STYLE = "rounded=1;whiteSpace=wrap;html=1;arcSize=6;verticalAlign=top;align=left;spacingLeft=8;spacingTop=2;fontStyle=1;container=1;collapsible=0;"
LANE_STYLE_H = "swimlane;horizontal=0;startSize=36;html=1;whiteSpace=wrap;collapsible=0;fontStyle=1;"
LANE_STYLE_V = "swimlane;horizontal=1;startSize=36;html=1;whiteSpace=wrap;collapsible=0;fontStyle=1;"
POOL_STYLE_H = "swimlane;horizontal=0;startSize=0;html=1;whiteSpace=wrap;collapsible=0;fontStyle=1;strokeWidth=2;"

# Named palettes: (fill, stroke, font)
THEMES = {
    "neutral":  {"fill": "#FFFFFF", "stroke": "#333333", "font": "#1A1A1A", "container": "#F7F7F7", "lane": "#FAFAFA", "edge": "#4D4D4D"},
    "blue":     {"fill": "#DAE8FC", "stroke": "#6C8EBF", "font": "#1A1A1A", "container": "#F5F8FD", "lane": "#F5F8FD", "edge": "#4D4D4D"},
    "slate":    {"fill": "#E6EEF5", "stroke": "#3B5A7A", "font": "#152535", "container": "#F3F6F9", "lane": "#F8FAFC", "edge": "#3B5A7A"},
    "green":    {"fill": "#D5E8D4", "stroke": "#82B366", "font": "#1A1A1A", "container": "#F4FAF3", "lane": "#F4FAF3", "edge": "#4D4D4D"},
}
SEMANTIC_COLORS = {  # node.color shortcuts
    "blue": ("#DAE8FC", "#6C8EBF"), "green": ("#D5E8D4", "#82B366"), "orange": ("#FFE6CC", "#D79B00"),
    "red": ("#F8CECC", "#B85450"), "purple": ("#E1D5E7", "#9673A6"), "yellow": ("#FFF2CC", "#D6B656"),
    "gray": ("#F5F5F5", "#666666"), "white": ("#FFFFFF", "#333333"), "teal": ("#D0F0EE", "#2E8B86"),
}


# ----------------------------------------------------------------------------
# Model
# ----------------------------------------------------------------------------
@dataclass
class Node:
    id: str
    label: str = ""
    shape: str = DEFAULT_SHAPE
    container: Optional[str] = None
    lane: Optional[str] = None
    layer: str = "Base"
    color: Optional[str] = None
    style: Dict = field(default_factory=dict)
    attributes: List[str] = field(default_factory=list)   # class / entity rows
    methods: List[str] = field(default_factory=list)
    note: str = ""
    x: float = 0; y: float = 0; w: float = 0; h: float = 0  # absolute, set by layout
    fixed: bool = False
    link: str = ""


@dataclass
class Edge:
    id: str
    src: str
    dst: str
    label: str = ""
    layer: str = "Base"
    style: Dict = field(default_factory=dict)
    points: List[Tuple[float, float]] = field(default_factory=list)  # explicit route (sequence msgs)
    waypoints: List[Tuple[float, float]] = field(default_factory=list)  # intermediate bends for connected edges


@dataclass
class Container:
    id: str
    label: str = ""
    parent: Optional[str] = None
    layer: str = "Base"
    color: Optional[str] = None
    style: Dict = field(default_factory=dict)
    x: float = 0; y: float = 0; w: float = 0; h: float = 0


@dataclass
class Layer:
    id: str
    name: str
    visible: bool = True
    locked: bool = False


@dataclass
class Diagram:
    title: str
    kind: str
    direction: str
    theme: str
    layers: List[Layer]
    containers: List[Container]
    nodes: List[Node]
    edges: List[Edge]
    lanes: List[Dict]
    lane_orientation: str
    sequence: Dict
    spacing: Dict
    extra_shapes: List[Dict] = field(default_factory=list)  # free vertices produced by layout (lifelines etc.)


VALID_KINDS = {"flowchart", "swimlane", "architecture", "network", "sequence", "erd", "class",
               "state", "orgchart", "mindmap", "usecase", "freeform"}


def load_spec(path: str) -> Diagram:
    with open(path, "r", encoding="utf-8") as fh:
        raw = json.load(fh)
    return parse_spec(raw)


def parse_spec(raw: Dict) -> Diagram:
    kind = raw.get("type", "flowchart")
    layers_raw = raw.get("layers") or [{"id": "base", "name": "Base"}]
    layers = [Layer(id=str(l.get("id") or l.get("name")), name=str(l.get("name") or l.get("id")),
                    visible=bool(l.get("visible", True)), locked=bool(l.get("locked", False))) for l in layers_raw]
    layer_default = layers[0].name

    def lname(v):  # accept layer id or name
        if v is None:
            return layer_default
        for l in layers:
            if v in (l.id, l.name):
                return l.name
        return str(v)

    containers = [Container(id=str(c["id"]), label=c.get("label", ""), parent=c.get("parent"),
                            layer=lname(c.get("layer")), color=c.get("color"), style=c.get("style", {}))
                  for c in raw.get("containers", [])]
    nodes = []
    for n in raw.get("nodes", []):
        node = Node(id=str(n["id"]), label=n.get("label", str(n["id"])), shape=n.get("shape", DEFAULT_SHAPE),
                    container=n.get("container"), lane=n.get("lane"), layer=lname(n.get("layer")),
                    color=n.get("color"), style=n.get("style", {}), attributes=n.get("attributes", []),
                    methods=n.get("methods", []), note=n.get("note", ""), link=n.get("link", ""))
        if "w" in n: node.w = float(n["w"])
        if "h" in n: node.h = float(n["h"])
        if "x" in n and "y" in n:
            node.x, node.y, node.fixed = float(n["x"]), float(n["y"]), True
        nodes.append(node)
    edges = []
    taken = {n.id for n in nodes} | {c.id for c in containers}
    for i, e in enumerate(raw.get("edges", [])):
        eid = str(e.get("id") or f"edge-{i+1}")
        while eid in taken:
            eid = f"edge-{i+1}-{e['from']}-{e['to']}"[:36] if eid == f"edge-{i+1}" else eid + "-x"
        taken.add(eid)
        edges.append(Edge(id=eid, src=str(e["from"]), dst=str(e["to"]),
                          label=e.get("label", ""), layer=lname(e.get("layer")), style=e.get("style", {})))
    return Diagram(
        title=raw.get("title", "Diagram"), kind=kind, direction=raw.get("direction", "TB"),
        theme=raw.get("theme", "neutral"), layers=layers, containers=containers, nodes=nodes, edges=edges,
        lanes=raw.get("lanes", []), lane_orientation=raw.get("lane_orientation", "horizontal"),
        sequence=raw.get("sequence", {}), spacing=raw.get("spacing", {}),
    )


# ----------------------------------------------------------------------------
# Validation
# ----------------------------------------------------------------------------
def validate(d: Diagram) -> Tuple[List[str], List[str]]:
    errors, warnings = [], []
    if d.kind not in VALID_KINDS:
        errors.append(f"unknown type '{d.kind}'; expected one of {sorted(VALID_KINDS)}")
    ids = [n.id for n in d.nodes]
    dup = {i for i in ids if ids.count(i) > 1}
    if dup:
        errors.append(f"duplicate node ids: {sorted(dup)}")
    cids = {c.id for c in d.containers}
    nid = set(ids)
    if cids & nid:
        errors.append(f"ids used for both a node and a container: {sorted(cids & nid)}")
    layer_names = {l.name for l in d.layers}
    lane_ids = {str(l.get("id") or l.get("label")) for l in d.lanes}
    for n in d.nodes:
        if n.shape not in SHAPES:
            warnings.append(f"node '{n.id}': unknown shape '{n.shape}', falling back to '{DEFAULT_SHAPE}'")
        if n.container and n.container not in cids:
            errors.append(f"node '{n.id}': container '{n.container}' not defined")
        if n.layer not in layer_names:
            errors.append(f"node '{n.id}': layer '{n.layer}' not defined")
        if d.kind == "swimlane" and not n.lane:
            warnings.append(f"node '{n.id}': swimlane diagram but no 'lane' set (placed in first lane)")
        if n.lane and d.lanes and n.lane not in lane_ids:
            errors.append(f"node '{n.id}': lane '{n.lane}' not defined")
        if not n.label.strip() and n.shape not in ("start", "end", "circle"):
            warnings.append(f"node '{n.id}' has an empty label")
    for c in d.containers:
        if c.parent and c.parent not in cids:
            errors.append(f"container '{c.id}': parent '{c.parent}' not defined")
        if c.layer not in layer_names:
            errors.append(f"container '{c.id}': layer '{c.layer}' not defined")
    seen_e = set()
    eids = [e.id for e in d.edges]
    dup_e = {i for i in eids if eids.count(i) > 1}
    if dup_e:
        errors.append(f"duplicate edge ids: {sorted(dup_e)}")
    for e in d.edges:
        if e.src not in nid and e.src not in cids:
            errors.append(f"edge '{e.id}': from '{e.src}' not defined")
        if e.dst not in nid and e.dst not in cids:
            errors.append(f"edge '{e.id}': to '{e.dst}' not defined")
        if e.layer not in layer_names:
            errors.append(f"edge '{e.id}': layer '{e.layer}' not defined")
        key = (e.src, e.dst, e.label)
        if key in seen_e:
            warnings.append(f"edge '{e.id}': duplicate of another edge {key}")
        seen_e.add(key)
    if d.kind not in ("sequence", "freeform", "erd", "class"):
        touched = {e.src for e in d.edges} | {e.dst for e in d.edges}
        for n in d.nodes:
            if n.id not in touched and n.shape not in ("note", "text"):
                warnings.append(f"node '{n.id}' ('{n.label}') has no connections")
    if d.kind == "sequence":
        acts = d.sequence.get("actors", [])
        if not acts:
            errors.append("sequence diagram needs sequence.actors")
        aids = {str(a["id"]) for a in acts}
        for i, m in enumerate(d.sequence.get("messages", [])):
            if m.get("from") not in aids or m.get("to") not in aids:
                errors.append(f"sequence message #{i+1}: from/to must reference actor ids {sorted(aids)}")
    if d.kind == "swimlane" and not d.lanes:
        errors.append("swimlane diagram needs 'lanes'")
    if len(d.nodes) > 250:
        warnings.append(f"{len(d.nodes)} nodes — consider splitting into pages/diagrams for readability")
    return errors, warnings


# ----------------------------------------------------------------------------
# Layout
# ----------------------------------------------------------------------------
def _size(n: Node, d: Diagram):
    base = SHAPES.get(n.shape, SHAPES[DEFAULT_SHAPE])[2]
    w = n.w or base[0]
    h = n.h or base[1]
    if n.shape in ("class", "entity"):
        rows = len(n.attributes) + len(n.methods)
        h = max(h, 30 + 26 * max(rows, 1) + (8 if n.methods and n.attributes else 0) + 8)
        longest = max([len(n.label)] + [len(a) for a in n.attributes + n.methods] + [10])
        w = max(w, min(360, 7.2 * longest + 30))
    elif n.shape not in ("start", "end", "circle", "actor", "user"):
        # grow with label length so text does not overflow
        words = n.label.replace("<br>", " ").split()
        longest = max([len(x) for x in words] + [0])
        est = max(longest * 8 + 24, min(320, len(n.label) * 7.5 * 0.6 + 40))
        w = max(w, est)
        lines = max(1, math.ceil(len(n.label) * 7.5 / max(w - 20, 1)))
        h = max(h, 22 + 18 * lines)
    n.w, n.h = float(w), float(h)


def _break_cycles(node_ids: List[str], adj: Dict[str, List[str]]) -> Dict[str, List[str]]:
    """Return a DAG adjacency by reversing back-edges found in DFS."""
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {v: WHITE for v in node_ids}
    dag = {v: [] for v in node_ids}
    sys.setrecursionlimit(10000)

    def visit(u):
        color[u] = GRAY
        for v in adj.get(u, []):
            if v not in color:
                continue
            if color[v] == GRAY:
                dag[v].append(u)  # reversed
            else:
                dag[u].append(v)
                if color[v] == WHITE:
                    visit(v)
        color[u] = BLACK

    for v in node_ids:
        if color[v] == WHITE:
            visit(v)
    return dag


def _layered(items: List[str], edges: List[Tuple[str, str]], sizes: Dict[str, Tuple[float, float]],
             direction: str, gap_main: float, gap_cross: float) -> Dict[str, Tuple[float, float]]:
    """Sugiyama-lite: longest-path layering + barycenter ordering + centered coordinates.
    Returns top-left positions relative to (0,0)."""
    if not items:
        return {}
    adj = defaultdict(list)
    for a, b in edges:
        if a in sizes and b in sizes and a != b:
            adj[a].append(b)
    dag = _break_cycles(items, adj)
    preds = defaultdict(list)
    for u, vs in dag.items():
        for v in vs:
            preds[v].append(u)
    # longest path layering
    rank: Dict[str, int] = {}
    order = list(items)
    # topological order
    indeg = {v: len(preds[v]) for v in items}
    queue = [v for v in items if indeg[v] == 0]
    topo = []
    while queue:
        u = queue.pop(0)
        topo.append(u)
        for v in dag[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                queue.append(v)
    for v in topo:
        rank[v] = max([rank[p] + 1 for p in preds[v]], default=0)
    for v in items:
        rank.setdefault(v, 0)
    # nodes with no predecessors but with successors: place them just above their earliest successor
    for v in items:
        if not preds[v] and dag[v]:
            rank[v] = max(0, min(rank[s] for s in dag[v]) - 1)
    # virtual nodes for edges that span more than one rank: they reserve a channel so the
    # long edge does not run through an unrelated node in an intermediate rank
    sizes = dict(sizes)
    virtual: List[str] = []
    long_edges = [(u, v) for u, vs in dag.items() for v in vs if rank[v] - rank[u] > 1]
    for u, v in long_edges:
        dag[u] = [x for x in dag[u] if x != v]
        preds[v] = [p for p in preds[v] if p != u]
        prev = u
        for k in range(1, rank[v] - rank[u]):
            vid = f"__v_{u}_{v}_{k}"
            virtual.append(vid)
            sizes[vid] = (16.0, 16.0)
            rank[vid] = rank[u] + k
            dag.setdefault(prev, []).append(vid)
            dag[vid] = []
            preds[vid].append(prev)
            prev = vid
        dag[prev].append(v)
        preds[v].append(prev)
    layers: Dict[int, List[str]] = defaultdict(list)
    for v in order + virtual:
        layers[rank[v]].append(v)
    ranks = sorted(layers)
    # barycenter ordering, a few sweeps
    pos = {v: i for r in ranks for i, v in enumerate(layers[r])}
    for _ in range(4):
        for r in ranks[1:]:
            def bary(v):
                ps = [pos[p] for p in preds[v] if p in pos]
                return sum(ps) / len(ps) if ps else pos[v]
            layers[r].sort(key=bary)
            pos.update({v: i for i, v in enumerate(layers[r])})
        for r in reversed(ranks[:-1]):
            def bary2(v):
                ss = [pos[s] for s in dag[v] if s in pos]
                return sum(ss) / len(ss) if ss else pos[v]
            layers[r].sort(key=bary2)
            pos.update({v: i for i, v in enumerate(layers[r])})
    # coordinates
    main_is_y = direction in ("TB", "BT")
    result = {}
    row_extents = []
    for r in ranks:
        vs = layers[r]
        cross_total = sum((sizes[v][0] if main_is_y else sizes[v][1]) for v in vs) + gap_cross * (len(vs) - 1)
        main_max = max((sizes[v][1] if main_is_y else sizes[v][0]) for v in vs)
        row_extents.append((r, cross_total, main_max))
    max_cross = max(c for _, c, _ in row_extents)
    main_cursor = 0.0
    for r, cross_total, main_max in row_extents:
        vs = layers[r]
        cross_cursor = (max_cross - cross_total) / 2
        for v in vs:
            w, h = sizes[v]
            if main_is_y:
                result[v] = (cross_cursor, main_cursor + (main_max - h) / 2)
                cross_cursor += w + gap_cross
            else:
                result[v] = (main_cursor + (main_max - w) / 2, cross_cursor)
                cross_cursor += h + gap_cross
        main_cursor += main_max + gap_main
    vpaths: Dict[Tuple[str, str], List[Tuple[float, float]]] = {}
    for u, v in long_edges:
        pts = []
        for k in range(1, rank[v] - rank[u]):
            vid = f"__v_{u}_{v}_{k}"
            if vid in result:
                pts.append((result[vid][0] + 8, result[vid][1] + 8))
        vpaths[(u, v)] = pts
    for vid in virtual:
        result.pop(vid, None)
    if direction == "BT":
        total = main_cursor - gap_main
        result = {v: (x, total - y - sizes[v][1]) for v, (x, y) in result.items()}
        vpaths = {k: [(x, total - y) for x, y in pts] for k, pts in vpaths.items()}
    if direction == "RL":
        total = main_cursor - gap_main
        result = {v: (total - x - sizes[v][0], y) for v, (x, y) in result.items()}
        vpaths = {k: [(total - x, y) for x, y in pts] for k, pts in vpaths.items()}
    _layered.last_vpaths = vpaths
    return result


def _tree(items: List[str], edges: List[Tuple[str, str]], sizes, direction, gap_main, gap_cross):
    """Tidy tree for org charts / mind maps (children centered under parent)."""
    children = defaultdict(list)
    has_parent = set()
    for a, b in edges:
        if a in sizes and b in sizes:
            children[a].append(b)
            has_parent.add(b)
    roots = [v for v in items if v not in has_parent] or items[:1]
    main_is_y = direction in ("TB", "BT")
    subtree: Dict[str, float] = {}

    def cross(v):
        return sizes[v][0] if main_is_y else sizes[v][1]

    def measure(v, seen):
        if v in seen:
            return cross(v)
        seen.add(v)
        kids = [k for k in children[v] if k not in seen]
        if not kids:
            subtree[v] = cross(v)
        else:
            subtree[v] = max(cross(v), sum(measure(k, seen) for k in kids) + gap_cross * (len(kids) - 1))
        return subtree[v]

    seen = set()
    for r in roots:
        measure(r, seen)
    result = {}
    placed = set()

    def place(v, cross_start, main_pos):
        if v in placed:
            return
        placed.add(v)
        w, h = sizes[v]
        width = subtree.get(v, cross(v))
        centre = cross_start + width / 2
        if main_is_y:
            result[v] = (centre - w / 2, main_pos)
        else:
            result[v] = (main_pos, centre - h / 2)
        kids = [k for k in children[v] if k not in placed]
        cur = cross_start + (width - (sum(subtree.get(k, cross(k)) for k in kids) + gap_cross * (len(kids) - 1))) / 2
        step = (h if main_is_y else w) + gap_main
        for k in kids:
            place(k, cur, main_pos + step)
            cur += subtree.get(k, cross(k)) + gap_cross

    cur = 0.0
    for r in roots:
        place(r, cur, 0.0)
        cur += subtree.get(r, cross(r)) + gap_cross * 2
    # any unreachable leftovers
    for v in items:
        if v not in result:
            result[v] = (cur, 0.0)
            cur += cross(v) + gap_cross
    return result


def _grid(items, sizes, cols, gap):
    result = {}
    x = y = 0.0
    row_h = 0.0
    for i, v in enumerate(items):
        w, h = sizes[v]
        if i and i % cols == 0:
            x, y, row_h = 0.0, y + row_h + gap, 0.0
        result[v] = (x, y)
        x += w + gap
        row_h = max(row_h, h)
    return result


def layout(d: Diagram) -> None:
    sp = d.spacing
    gap_main = float(sp.get("rank", 70 if d.kind in ("flowchart", "state") else 90))
    gap_cross = float(sp.get("node", 50))
    pad = float(sp.get("container_padding", 30))
    for n in d.nodes:
        _size(n, d)
    _edge_route.main_is_y = d.direction in ("TB", "BT")
    if d.kind == "sequence":
        _layout_sequence(d)
        return
    if d.kind == "swimlane":
        _layout_swimlane(d, gap_main, gap_cross)
        return
    _layout_compound(d, gap_main, gap_cross, pad)


def _layout_compound(d: Diagram, gap_main, gap_cross, pad):
    """Lay out nodes inside containers recursively; containers become nodes of their parent."""
    node_by = {n.id: n for n in d.nodes}
    cont_by = {c.id: c for c in d.containers}
    kids_nodes = defaultdict(list)
    kids_conts = defaultdict(list)
    for n in d.nodes:
        if not n.fixed:
            kids_nodes[n.container].append(n.id)
    for c in d.containers:
        kids_conts[c.parent].append(c.id)

    def top_container(x: Optional[str]) -> Optional[str]:
        return x

    def owner_chain(item_id):  # chain of containers from item up to root
        chain = []
        if item_id in node_by:
            cur = node_by[item_id].container
        else:
            cur = cont_by[item_id].parent
        while cur:
            chain.append(cur)
            cur = cont_by[cur].parent
        return chain

    def lift(item_id, scope):  # which direct child of `scope` contains item
        if item_id in node_by and node_by[item_id].container == scope:
            return item_id
        if item_id in cont_by and cont_by[item_id].parent == scope:
            return item_id
        for c in owner_chain(item_id):
            if (cont_by[c].parent == scope):
                return c
        return None

    rel: Dict[str, Tuple[float, float]] = {}   # position relative to parent container's content origin
    csize: Dict[str, Tuple[float, float]] = {}
    rel_wp: Dict[str, Dict[str, Tuple[Optional[str], List[Tuple[float, float]]]]] = defaultdict(dict)  # eid -> {exit|mid|entry: (scope, pts)}
    scope_origin: Dict[Optional[str], Tuple[float, float]] = {}

    def do_scope(scope: Optional[str]):
        for c in kids_conts[scope]:
            do_scope(c)
        items = kids_nodes[scope] + kids_conts[scope]
        sizes = {}
        for i in items:
            sizes[i] = (node_by[i].w, node_by[i].h) if i in node_by else csize[i]
        edges = []
        for e in d.edges:
            a, b = lift(e.src, scope), lift(e.dst, scope)
            if a and b and a != b:
                # generalisation arrows point child -> parent; lay the parent out above the child
                if e.style.get("arrow") == "inherit":
                    a, b = b, a
                edges.append((a, b))
        # edges crossing this container's boundary get a virtual entry/exit anchor so the layered
        # layout reserves a channel for them instead of letting them run through sibling shapes
        ENTRY, EXIT = "__entry__", "__exit__"
        cross_out, cross_in = set(), set()
        if scope is not None:
            for e in d.edges:
                a, b = lift(e.src, scope), lift(e.dst, scope)
                if a and not b and e.style.get("arrow") != "inherit":
                    cross_out.add(a)
                if b and not a and e.style.get("arrow") != "inherit":
                    cross_in.add(b)
        layout_items = list(items)
        if cross_out:
            layout_items.append(EXIT); sizes[EXIT] = (1.0, 1.0)
            edges += [(a, EXIT) for a in cross_out]
        if cross_in:
            layout_items.append(ENTRY); sizes[ENTRY] = (1.0, 1.0)
            edges += [(ENTRY, b) for b in cross_in]
        vp: Dict = {}
        if d.kind in ("orgchart", "mindmap"):
            pos = _tree(items, [ed for ed in edges if ENTRY not in ed and EXIT not in ed], sizes, d.direction, gap_main, gap_cross)
        elif d.kind in ("erd", "class", "usecase") and not edges:
            pos = _grid(items, sizes, max(1, int(math.ceil(math.sqrt(len(items))))), gap_cross)
        elif not edges and len(items) > 1:
            pos = _grid(items, sizes, max(1, min(4, len(items))), gap_cross)
        else:
            _layered.last_vpaths = {}
            pos = _layered(layout_items, edges, sizes, d.direction, gap_main, gap_cross)
            vp = _layered.last_vpaths
            # drop the anchor rank(s): shift real items so the layout starts at 0 again
            main_is_y = d.direction in ("TB", "BT")
            pos.pop(ENTRY, None); pos.pop(EXIT, None)
            minx = min((pos[i][0] for i in items), default=0)
            miny = min((pos[i][1] for i in items), default=0)
            pos = {i: (x - minx, y - miny) for i, (x, y) in pos.items()}
            vp = {k: [(x - minx, y - miny) for x, y in pts] for k, pts in vp.items()}
            for e in d.edges:
                a, b = lift(e.src, scope), lift(e.dst, scope)
                inherit = e.style.get("arrow") == "inherit"
                if a and b and a != b:
                    key = (b, a) if inherit else (a, b)
                    if key in vp and vp[key]:
                        pts = list(reversed(vp[key])) if inherit else vp[key]
                        rel_wp[e.id]["mid"] = (scope, pts)
                elif a and not b and (a, EXIT) in vp and vp[(a, EXIT)]:
                    rel_wp[e.id]["exit"] = (scope, vp[(a, EXIT)])
                elif b and not a and (ENTRY, b) in vp and vp[(ENTRY, b)]:
                    rel_wp[e.id]["entry"] = (scope, vp[(ENTRY, b)])
        maxx = max((pos[i][0] + sizes[i][0] for i in items), default=0)
        maxy = max((pos[i][1] + sizes[i][1] for i in items), default=0)
        for i in items:
            rel[i] = pos[i]
        if scope is not None:
            label_h = 28
            csize[scope] = (max(maxx + 2 * pad, 160), maxy + 2 * pad + label_h)

    do_scope(None)

    def absolutize(scope: Optional[str], ox: float, oy: float):
        scope_origin[scope] = (ox, oy)
        for i in kids_nodes[scope] + kids_conts[scope]:
            x, y = rel[i]
            if i in node_by:
                node_by[i].x, node_by[i].y = ox + x, oy + y
            else:
                c = cont_by[i]
                c.x, c.y, c.w, c.h = ox + x, oy + y, csize[i][0], csize[i][1]
                absolutize(i, c.x + pad, c.y + pad + 28)

    absolutize(None, 40, 40)
    edge_by = {e.id: e for e in d.edges}
    for eid, segs in rel_wp.items():
        wps = []
        for part in ("exit", "mid", "entry"):
            if part in segs:
                scope, pts = segs[part]
                ox, oy = scope_origin.get(scope, (40, 40))
                wps += [(ox + x, oy + y) for x, y in pts]
        edge_by[eid].waypoints = wps


def _layout_swimlane(d: Diagram, gap_main, gap_cross):
    lanes = [str(l.get("id") or l.get("label")) for l in d.lanes]
    lane_idx = {l: i for i, l in enumerate(lanes)}
    for n in d.nodes:
        if n.lane not in lane_idx:
            n.lane = lanes[0]
    ids = [n.id for n in d.nodes]
    sizes = {n.id: (n.w, n.h) for n in d.nodes}
    adj = defaultdict(list)
    for e in d.edges:
        if e.src in sizes and e.dst in sizes:
            adj[e.src].append(e.dst)
    dag = _break_cycles(ids, adj)
    preds = defaultdict(list)
    for u, vs in dag.items():
        for v in vs:
            preds[v].append(u)
    rank = {}
    indeg = {v: len(preds[v]) for v in ids}
    q = [v for v in ids if indeg[v] == 0]
    while q:
        u = q.pop(0)
        rank[u] = max([rank[p] + 1 for p in preds[u]], default=0)
        for v in dag[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    for v in ids:
        rank.setdefault(v, 0)
    horizontal = d.lane_orientation == "horizontal"  # lanes are rows, flow left->right
    header = 36
    # slot nodes: (lane, rank) -> list
    slot = defaultdict(list)
    for n in d.nodes:
        slot[(n.lane, rank[n.id])].append(n)
    nranks = max(rank.values(), default=0) + 1
    # column widths / row heights
    col_main = [0.0] * nranks
    lane_cross = [0.0] * len(lanes)
    for (lane, r), ns in slot.items():
        if horizontal:
            col_main[r] = max(col_main[r], max(n.w for n in ns))
            lane_cross[lane_idx[lane]] = max(lane_cross[lane_idx[lane]], sum(n.h for n in ns) + gap_cross * (len(ns) - 1))
        else:
            col_main[r] = max(col_main[r], max(n.h for n in ns))
            lane_cross[lane_idx[lane]] = max(lane_cross[lane_idx[lane]], sum(n.w for n in ns) + gap_cross * (len(ns) - 1))
    lane_cross = [max(c + 2 * 40, 120) for c in lane_cross]
    main_starts = []
    cur = header + 40
    for r in range(nranks):
        main_starts.append(cur)
        cur += col_main[r] + gap_main
    main_total = cur - gap_main + 40
    cross_starts = []
    ccur = 0.0
    for i in range(len(lanes)):
        cross_starts.append(ccur)
        ccur += lane_cross[i]
    ox, oy = 40, 40
    for (lane, r), ns in slot.items():
        li = lane_idx[lane]
        if horizontal:
            block = sum(n.h for n in ns) + gap_cross * (len(ns) - 1)
            y = oy + cross_starts[li] + (lane_cross[li] - block) / 2
            for n in ns:
                n.x = ox + main_starts[r] + (col_main[r] - n.w) / 2
                n.y = y
                y += n.h + gap_cross
        else:
            block = sum(n.w for n in ns) + gap_cross * (len(ns) - 1)
            x = ox + cross_starts[li] + (lane_cross[li] - block) / 2
            for n in ns:
                n.y = oy + main_starts[r] + (col_main[r] - n.h) / 2
                n.x = x
                x += n.w + gap_cross
    # lanes as containers (special style)
    d.containers = [c for c in d.containers if not c.style.get("_lane")]
    for i, l in enumerate(d.lanes):
        lid = str(l.get("id") or l.get("label"))
        c = Container(id=f"lane_{lid}", label=l.get("label", lid), layer=d.layers[0].name, style={"_lane": True})
        if horizontal:
            c.x, c.y, c.w, c.h = ox, oy + cross_starts[i], main_total, lane_cross[i]
        else:
            c.x, c.y, c.w, c.h = ox + cross_starts[i], oy, lane_cross[i], main_total
        d.containers.append(c)
    for n in d.nodes:
        n.container = f"lane_{n.lane}"


def _layout_sequence(d: Diagram):
    actors = d.sequence.get("actors", [])
    msgs = d.sequence.get("messages", [])
    step = float(d.spacing.get("message", 60))
    colw = float(d.spacing.get("lifeline", 200))
    head_w, head_h = 140, 50
    top = 40
    xs = {}
    d.nodes = []
    for i, a in enumerate(actors):
        aid = str(a["id"])
        cx = 60 + i * colw + head_w / 2
        xs[aid] = cx
        n = Node(id=f"actor_{aid}", label=a.get("label", aid), shape=a.get("shape", "process"),
                 layer=d.layers[0].name, color=a.get("color"))
        n.w, n.h = head_w, head_h
        if n.shape in ("actor", "user"):
            n.w, n.h = 40, 70
        n.x, n.y = cx - n.w / 2, top
        d.nodes.append(n)
    body_top = top + head_h + 10
    total_h = body_top + step * (len(msgs) + 1)
    d.extra_shapes = []
    for aid, cx in xs.items():
        d.extra_shapes.append({"kind": "lifeline", "x": cx, "y1": body_top, "y2": total_h,
                               "layer": d.layers[0].name})
    d.edges = []
    layer_names = {l.id: l.name for l in d.layers}
    for i, m in enumerate(msgs):
        y = body_top + step * (i + 1)
        x1, x2 = xs[str(m["from"])], xs[str(m["to"])]
        style = dict(m.get("style", {}))
        if m.get("kind") == "return":
            style.setdefault("dashed", True)
            style.setdefault("arrow", "open")
        if m.get("kind") == "async":
            style.setdefault("arrow", "open")
        e = Edge(id=f"m{i+1}", src="", dst="", label=m.get("label", ""),
                 layer=layer_names.get(m.get("layer"), m.get("layer") or d.layers[0].name), style=style)
        if x1 == x2:  # self message
            e.points = [(x1, y), (x1 + 60, y), (x1 + 60, y + step * 0.5), (x1, y + step * 0.5)]
        else:
            e.points = [(x1, y), (x2, y)]
        d.edges.append(e)
        if m.get("note"):
            n = Node(id=f"note_{i+1}", label=m["note"], shape="note", layer=d.layers[0].name)
            n.w, n.h = 160, 50
            n.x, n.y = max(x1, x2) + 30, y - 25
            d.nodes.append(n)


# ----------------------------------------------------------------------------
# draw.io emitter
# ----------------------------------------------------------------------------
def _fill_stroke(theme, color: Optional[str], default_fill=None):
    t = THEMES.get(theme, THEMES["neutral"])
    if color and color in SEMANTIC_COLORS:
        return SEMANTIC_COLORS[color]
    if color and color.startswith("#"):
        return color, t["stroke"]
    return (default_fill or t["fill"]), t["stroke"]


def _label_html(n: Node) -> str:
    if n.shape in ("class", "entity"):
        return html.escape(n.label)
    return html.escape(n.label).replace("\n", "<br>")


def _edge_style(e: Edge, theme: str, orth=True) -> str:
    t = THEMES.get(theme, THEMES["neutral"])
    s = e.style
    parts = []
    if orth and not e.points:
        parts.append("edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;")
    parts.append(f"html=1;strokeColor={s.get('color', t['edge'])};strokeWidth={s.get('width', 1.5)};")
    arrow = s.get("arrow", "block")
    if arrow == "none":
        parts.append("endArrow=none;")
    elif arrow == "open":
        parts.append("endArrow=open;endFill=0;")
    elif arrow == "both":
        parts.append("endArrow=block;startArrow=block;endFill=1;startFill=1;")
    elif arrow == "diamond":
        parts.append("endArrow=diamondThin;endFill=0;")
    elif arrow == "inherit":
        parts.append("endArrow=block;endFill=0;endSize=12;")
    elif arrow in ("one", "many", "zero-or-many", "one-or-many"):
        er = {"one": "ERone", "many": "ERmany", "zero-or-many": "ERzeroToMany", "one-or-many": "ERoneToMany"}
        parts.append(f"endArrow={er[arrow]};endFill=0;startArrow={er.get(s.get('start_arrow', 'one'), 'ERone')};startFill=0;")
    else:
        parts.append("endArrow=block;endFill=1;")
    if s.get("dashed"):
        parts.append("dashed=1;")
    if s.get("dotted"):
        parts.append("dashed=1;dashPattern=1 3;")
    parts.append("fontSize=11;labelBackgroundColor=#FFFFFF;")
    return "".join(parts)


def emit_drawio(d: Diagram) -> str:
    t = THEMES.get(d.theme, THEMES["neutral"])
    lines = []
    lines.append('<mxfile host="lucid-diagram" modified="2026-01-01T00:00:00.000Z" agent="lucid-diagram skill" version="24.7.0" type="device">')
    lines.append(f'  <diagram id="page1" name="{xesc(d.title)}">')
    lines.append('    <mxGraphModel dx="1400" dy="900" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="1169" pageHeight="827" math="0" shadow="0">')
    lines.append('      <root>')
    lines.append('        <mxCell id="0"/>')
    layer_ids = {}
    for i, l in enumerate(d.layers):
        lid = "1" if i == 0 else f"layer_{i}"
        layer_ids[l.name] = lid
        attrs = f'id="{lid}" parent="0"'
        if l.name != "Background" or i != 0:
            attrs += f' value="{xesc(l.name)}"'
        if not l.visible:
            attrs += ' visible="0"'
        if l.locked:
            attrs += ' locked="1"'
        lines.append(f'        <mxCell {attrs}/>')
    # note: draw.io renders layers in array order (first = bottom).
    cont_by = {c.id: c for c in d.containers}
    base_layer = d.layers[0].name

    def grouping_container(container: Optional[str]) -> Optional[str]:
        """Containers on overlay layers are drawn as outlines only: in draw.io a child inherits its
        parent's layer, so grouping nodes under an overlay container would hide them with the overlay."""
        cur = container
        while cur and cur in cont_by and cont_by[cur].layer != base_layer:
            cur = cont_by[cur].parent
        return cur

    def parent_of(item_container: Optional[str], layer: str) -> str:
        g = grouping_container(item_container)
        return g if g else layer_ids.get(layer, "1")

    def rel_xy(x, y, container: Optional[str]):
        g = grouping_container(container)
        if g and g in cont_by:
            c = cont_by[g]
            return x - c.x, y - c.y
        return x, y

    # containers first (they must precede children)
    def cont_depth(c):
        dpt, cur = 0, c.parent
        while cur:
            dpt, cur = dpt + 1, cont_by[cur].parent
        return dpt

    for c in sorted(d.containers, key=cont_depth):
        fill, stroke = _fill_stroke(d.theme, c.color, t["lane"] if c.style.get("_lane") else t["container"])
        if c.style.get("_lane"):
            style = (LANE_STYLE_H if d.lane_orientation == "horizontal" else LANE_STYLE_V)
        else:
            style = CONTAINER_STYLE
        if c.style.get("dashed"):
            style += "dashed=1;"
        if c.layer != base_layer:
            style = style.replace("container=1;", "container=0;")
        style += f"fillColor={fill};strokeColor={stroke};fontColor={t['font']};fontSize=12;"
        rx, ry = rel_xy(c.x, c.y, c.parent)
        parent = parent_of(c.parent, c.layer)
        lines.append(f'        <mxCell id="{xesc(c.id)}" value="{xesc(c.label)}" style="{xesc(style)}" vertex="1" parent="{xesc(parent)}">')
        lines.append(f'          <mxGeometry x="{rx:.0f}" y="{ry:.0f}" width="{c.w:.0f}" height="{c.h:.0f}" as="geometry"/>')
        lines.append('        </mxCell>')
    # free shapes (sequence lifelines)
    for i, s in enumerate(d.extra_shapes):
        if s["kind"] == "lifeline":
            style = f"endArrow=none;dashed=1;html=1;strokeColor={t['stroke']};strokeWidth=1;"
            lines.append(f'        <mxCell id="lifeline_{i}" style="{xesc(style)}" edge="1" parent="{layer_ids.get(s["layer"], "1")}">')
            lines.append('          <mxGeometry relative="1" as="geometry">')
            lines.append(f'            <mxPoint x="{s["x"]:.0f}" y="{s["y1"]:.0f}" as="sourcePoint"/>')
            lines.append(f'            <mxPoint x="{s["x"]:.0f}" y="{s["y2"]:.0f}" as="targetPoint"/>')
            lines.append('          </mxGeometry>')
            lines.append('        </mxCell>')
    # nodes
    for n in d.nodes:
        base_style = SHAPES.get(n.shape, SHAPES[DEFAULT_SHAPE])[0]
        fill, stroke = _fill_stroke(d.theme, n.color)
        if n.shape in ("start", "end"):
            fill, stroke = "#000000", "#000000"
        if n.shape == "note":
            fill = n.color and SEMANTIC_COLORS.get(n.color, (fill,))[0] or "#FFF2CC"
            stroke = "#D6B656"
        if n.shape == "text":
            fill, stroke = "none", "none"
        style = base_style + f"fillColor={fill};strokeColor={stroke};fontColor={t['font']};fontSize={n.style.get('fontSize', 12)};"
        if n.style.get("bold"):
            style += "fontStyle=1;"
        if n.style.get("dashed"):
            style += "dashed=1;"
        if n.style.get("extra"):
            style += n.style["extra"]
        rx, ry = rel_xy(n.x, n.y, n.container)
        parent = parent_of(n.container, n.layer)
        attrs = f'id="{xesc(n.id)}" value="{xesc(_label_html(n))}" style="{xesc(style)}" vertex="1" parent="{xesc(parent)}"'
        if n.link:
            # wrap in UserObject so link survives
            lines.append(f'        <UserObject label="{xesc(_label_html(n))}" link="{xesc(n.link)}" id="{xesc(n.id)}">')
            lines.append(f'          <mxCell style="{xesc(style)}" vertex="1" parent="{xesc(parent)}">')
            lines.append(f'            <mxGeometry x="{rx:.0f}" y="{ry:.0f}" width="{n.w:.0f}" height="{n.h:.0f}" as="geometry"/>')
            lines.append('          </mxCell>')
            lines.append('        </UserObject>')
        else:
            lines.append(f'        <mxCell {attrs}>')
            lines.append(f'          <mxGeometry x="{rx:.0f}" y="{ry:.0f}" width="{n.w:.0f}" height="{n.h:.0f}" as="geometry"/>')
            lines.append('        </mxCell>')
        if n.shape in ("class", "entity"):
            y = 30
            rows = list(n.attributes)
            if n.attributes and n.methods:
                rows.append("__sep__")
            rows += n.methods
            for j, row in enumerate(rows):
                if row == "__sep__":
                    lines.append(f'        <mxCell id="{xesc(n.id)}_sep" value="" style="line;strokeWidth=1;fillColor=none;align=left;verticalAlign=middle;spacingTop=-1;spacingLeft=3;spacingRight=3;rotatable=0;labelPosition=right;points=[];portConstraint=eastwest;strokeColor={stroke};" vertex="1" parent="{xesc(n.id)}">')
                    lines.append(f'          <mxGeometry y="{y}" width="{n.w:.0f}" height="8" as="geometry"/>')
                    lines.append('        </mxCell>')
                    y += 8
                    continue
                lines.append(f'        <mxCell id="{xesc(n.id)}_r{j}" value="{xesc(row)}" style="text;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=6;spacingRight=4;overflow=hidden;rotatable=0;points=[[0,0.5],[1,0.5]];portConstraint=eastwest;whiteSpace=wrap;html=1;fontSize=11;fontColor={t["font"]};" vertex="1" parent="{xesc(n.id)}">')
                lines.append(f'          <mxGeometry y="{y}" width="{n.w:.0f}" height="26" as="geometry"/>')
                lines.append('        </mxCell>')
                y += 26
        if n.note:
            lines.append(f'        <!-- note for {xesc(n.id)}: {xesc(n.note)} -->')
    # edges
    node_by_id = {n.id: n for n in d.nodes}
    for e in d.edges:
        style = _edge_style(e, d.theme)
        parent = layer_ids.get(e.layer, "1")
        if e.points:
            lines.append(f'        <mxCell id="{xesc(e.id)}" value="{xesc(e.label)}" style="{xesc(style)}" edge="1" parent="{parent}">')
            lines.append('          <mxGeometry relative="1" as="geometry">')
            (x1, y1), (x2, y2) = e.points[0], e.points[-1]
            lines.append(f'            <mxPoint x="{x1:.0f}" y="{y1:.0f}" as="sourcePoint"/>')
            lines.append(f'            <mxPoint x="{x2:.0f}" y="{y2:.0f}" as="targetPoint"/>')
            if len(e.points) > 2:
                lines.append('            <Array as="points">')
                for (px, py) in e.points[1:-1]:
                    lines.append(f'              <mxPoint x="{px:.0f}" y="{py:.0f}"/>')
                lines.append('            </Array>')
            lines.append('          </mxGeometry>')
            lines.append('        </mxCell>')
        else:
            lines.append(f'        <mxCell id="{xesc(e.id)}" value="{xesc(e.label)}" style="{xesc(style)}" edge="1" parent="{parent}" source="{xesc(e.src)}" target="{xesc(e.dst)}">')
            if e.waypoints:
                a = node_by_id.get(e.src) or cont_by.get(e.src)
                b = node_by_id.get(e.dst) or cont_by.get(e.dst)
                route = _edge_route(a, b, e.waypoints)[1:-1] if a and b else e.waypoints
                lines.append('          <mxGeometry relative="1" as="geometry">')
                lines.append('            <Array as="points">')
                for (px, py) in route:
                    lines.append(f'              <mxPoint x="{px:.0f}" y="{py:.0f}"/>')
                lines.append('            </Array>')
                lines.append('          </mxGeometry>')
            else:
                lines.append('          <mxGeometry relative="1" as="geometry"/>')
            lines.append('        </mxCell>')
    lines.append('      </root>')
    lines.append('    </mxGraphModel>')
    lines.append('  </diagram>')
    lines.append('</mxfile>')
    return "\n".join(lines)


# ----------------------------------------------------------------------------
# Visio (.vsdx) emitter
# ----------------------------------------------------------------------------
PX_PER_IN = 96.0
NS_MAIN = "http://schemas.microsoft.com/office/visio/2012/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _rgb(hexcol: str) -> str:
    return hexcol if hexcol and hexcol.startswith("#") else "#333333"


def _vsdx_geometry(kind: str, w: float, h: float) -> str:
    """Geometry section in inches; shape-local coords with origin bottom-left."""
    def row(ix, t, x, y):
        return f'<Row T="{t}" IX="{ix}"><Cell N="X" V="{x:.4f}"/><Cell N="Y" V="{y:.4f}"/></Row>'
    if kind in ("ellipse", "cloud", "pill"):
        if kind == "pill":
            return ('<Section N="Geometry" IX="0">'
                    f'{row(1, "MoveTo", 0, 0)}{row(2, "LineTo", w, 0)}{row(3, "LineTo", w, h)}{row(4, "LineTo", 0, h)}{row(5, "LineTo", 0, 0)}'
                    '</Section>')
        return ('<Section N="Geometry" IX="0">'
                f'<Row T="Ellipse" IX="1"><Cell N="X" V="{w/2:.4f}"/><Cell N="Y" V="{h/2:.4f}"/>'
                f'<Cell N="A" V="{w:.4f}"/><Cell N="B" V="{h/2:.4f}"/><Cell N="C" V="{w/2:.4f}"/><Cell N="D" V="{h:.4f}"/></Row>'
                '</Section>')
    if kind == "diamond":
        pts = [(w / 2, 0), (w, h / 2), (w / 2, h), (0, h / 2), (w / 2, 0)]
    elif kind == "parallelogram":
        k = min(w * 0.2, 0.3)
        pts = [(k, 0), (w, 0), (w - k, h), (0, h), (k, 0)]
    elif kind == "hexagon":
        k = min(w * 0.2, 0.3)
        pts = [(k, 0), (w - k, 0), (w, h / 2), (w - k, h), (k, h), (0, h / 2), (k, 0)]
    elif kind == "document":
        pts = [(0, h * 0.15), (w, h * 0.15), (w, h), (0, h), (0, h * 0.15)]
    elif kind == "actor":
        pts = [(w * 0.3, 0), (w * 0.7, 0), (w * 0.7, h), (w * 0.3, h), (w * 0.3, 0)]
    elif kind == "cylinder":
        pts = [(0, 0), (w, 0), (w, h), (0, h), (0, 0)]
    else:  # rect, rounded, table, text
        pts = [(0, 0), (w, 0), (w, h), (0, h), (0, 0)]
    rows = [row(1, "MoveTo", *pts[0])] + [row(i + 2, "LineTo", *p) for i, p in enumerate(pts[1:])]
    extra = ""
    if kind == "text":
        extra = '<Cell N="NoFill" V="1"/><Cell N="NoLine" V="1"/>'
    return f'<Section N="Geometry" IX="0">{extra}{"".join(rows)}</Section>'


def emit_vsdx(d: Diagram) -> Dict[str, bytes]:
    """Return {zip member path: bytes} for a minimal but valid .vsdx with layers."""
    t = THEMES.get(d.theme, THEMES["neutral"])
    # page size (inches)
    all_x = [n.x + n.w for n in d.nodes] + [c.x + c.w for c in d.containers] + [p[0] for e in d.edges for p in e.points]
    all_y = [n.y + n.h for n in d.nodes] + [c.y + c.h for c in d.containers] + [p[1] for e in d.edges for p in e.points]
    for s in d.extra_shapes:
        all_y.append(s.get("y2", 0)); all_x.append(s.get("x", 0))
    page_w_px = max(all_x, default=800) + 60
    page_h_px = max(all_y, default=600) + 60
    PW, PH = page_w_px / PX_PER_IN, page_h_px / PX_PER_IN

    def ix(px):  # x px -> in
        return px / PX_PER_IN

    def iy(py):  # y px (top-down) -> in (bottom-up)
        return PH - py / PX_PER_IN

    layer_index = {l.name: i for i, l in enumerate(d.layers)}
    shape_ids: Dict[str, int] = {}
    next_id = [1]

    def nid(key: str) -> int:
        shape_ids[key] = next_id[0]
        next_id[0] += 1
        return shape_ids[key]

    shapes_xml: List[str] = []
    connects_xml: List[str] = []

    def shape2d(key, label, x, y, w, h, kind, fill, stroke, layer, bold=False, dashed=False, font_size=10, align_top=False):
        sid = nid(key)
        wi, hi = w / PX_PER_IN, h / PX_PER_IN
        pinx = ix(x) + wi / 2
        piny = iy(y) - hi / 2
        cells = [
            f'<Cell N="PinX" V="{pinx:.4f}"/>', f'<Cell N="PinY" V="{piny:.4f}"/>',
            f'<Cell N="Width" V="{wi:.4f}"/>', f'<Cell N="Height" V="{hi:.4f}"/>',
            f'<Cell N="LocPinX" V="{wi/2:.4f}" F="Width*0.5"/>', f'<Cell N="LocPinY" V="{hi/2:.4f}" F="Height*0.5"/>',
            f'<Cell N="FillForegnd" V="{fill}"/>', f'<Cell N="LineColor" V="{stroke}"/>',
            '<Cell N="LineWeight" V="0.0139"/>',
        ]
        if kind == "rounded" or kind == "pill":
            cells.append(f'<Cell N="Rounding" V="{(0.35 if kind == "pill" else 0.12):.3f}"/>')
        if dashed:
            cells.append('<Cell N="LinePattern" V="2"/>')
        if align_top:
            cells.append('<Cell N="VerticalAlign" V="0"/>')
        char = (f'<Section N="Character"><Row IX="0"><Cell N="Color" V="{t["font"]}"/>'
                f'<Cell N="Size" V="{font_size/72:.4f}"/><Cell N="Style" V="{1 if bold else 0}"/></Row></Section>')
        para = '<Section N="Paragraph"><Row IX="0"><Cell N="HorzAlign" V="1"/></Row></Section>' if not align_top else \
               '<Section N="Paragraph"><Row IX="0"><Cell N="HorzAlign" V="0"/></Row></Section>'
        layer_sec = f'<Section N="LayerMem"><Row IX="0"><Cell N="LayerMember" V="{layer_index.get(layer, 0)}"/></Row></Section>'
        text = f'<Text><cp IX="0"/>{xesc(label)}</Text>' if label else ""
        shapes_xml.append(
            f'<Shape ID="{sid}" NameU="{xesc(key)}" Name="{xesc(key)}" Type="Shape">'
            + "".join(cells) + char + para + layer_sec + _vsdx_geometry(kind, wi, hi) + text + '</Shape>')
        return sid

    def connector(key, label, pts, layer, dashed=False, arrow="block", src_key=None, dst_key=None, color=None):
        sid = nid(key)
        (x1, y1), (x2, y2) = pts[0], pts[-1]
        bx, by, ex, ey = ix(x1), iy(y1), ix(x2), iy(y2)
        length = math.hypot(ex - bx, ey - by) or 0.01
        ang = math.atan2(ey - by, ex - bx)
        arrows = {"none": 0, "block": 4, "open": 1, "both": 4, "diamond": 6, "inherit": 5, "one": 0, "many": 0,
                  "zero-or-many": 0, "one-or-many": 0}
        cells = [
            f'<Cell N="BeginX" V="{bx:.4f}"/>', f'<Cell N="BeginY" V="{by:.4f}"/>',
            f'<Cell N="EndX" V="{ex:.4f}"/>', f'<Cell N="EndY" V="{ey:.4f}"/>',
            f'<Cell N="PinX" V="{(bx+ex)/2:.4f}" F="(BeginX+EndX)/2"/>', f'<Cell N="PinY" V="{(by+ey)/2:.4f}" F="(BeginY+EndY)/2"/>',
            f'<Cell N="Width" V="{length:.4f}" F="SQRT((EndX-BeginX)^2+(EndY-BeginY)^2)"/>',
            '<Cell N="Height" V="0"/>', '<Cell N="LocPinX" V="0" F="Width*0"/>', '<Cell N="LocPinY" V="0" F="Height*0"/>',
            f'<Cell N="Angle" V="{ang:.4f}" F="ATAN2(EndY-BeginY,EndX-BeginX)"/>',
            f'<Cell N="EndArrow" V="{arrows.get(arrow, 4)}"/>', '<Cell N="LineWeight" V="0.0139"/>',
            f'<Cell N="LineColor" V="{color or t["edge"]}"/>',
            '<Cell N="ObjType" V="2"/>', '<Cell N="GlueType" V="2"/>', '<Cell N="ConLineRouteExt" V="1"/>',
        ]
        if arrow == "both":
            cells.append('<Cell N="BeginArrow" V="4"/>')
        if dashed:
            cells.append('<Cell N="LinePattern" V="2"/>')
        # geometry: straight line in local coords + optional waypoints
        rows = ['<Row T="MoveTo" IX="1"><Cell N="X" V="0" F="Width*0"/><Cell N="Y" V="0" F="Height*0"/></Row>']
        if len(pts) > 2:
            # local coordinate transform for waypoints
            cos, sin = math.cos(ang), math.sin(ang)
            k = 2
            for (px, py) in pts[1:-1]:
                dx, dy = ix(px) - bx, iy(py) - by
                lx, ly = dx * cos + dy * sin, -dx * sin + dy * cos
                rows.append(f'<Row T="LineTo" IX="{k}"><Cell N="X" V="{lx:.4f}"/><Cell N="Y" V="{ly:.4f}"/></Row>')
                k += 1
            rows.append(f'<Row T="LineTo" IX="{k}"><Cell N="X" V="{length:.4f}" F="Width*1"/><Cell N="Y" V="0" F="Height*0"/></Row>')
        else:
            rows.append(f'<Row T="LineTo" IX="2"><Cell N="X" V="{length:.4f}" F="Width*1"/><Cell N="Y" V="0" F="Height*0"/></Row>')
        geom = f'<Section N="Geometry" IX="0"><Cell N="NoFill" V="1"/>{"".join(rows)}</Section>'
        layer_sec = f'<Section N="LayerMem"><Row IX="0"><Cell N="LayerMember" V="{layer_index.get(layer, 0)}"/></Row></Section>'
        char = f'<Section N="Character"><Row IX="0"><Cell N="Size" V="{9/72:.4f}"/></Row></Section>'
        text = f'<Text><cp IX="0"/>{xesc(label)}</Text>' if label else ""
        shapes_xml.append(f'<Shape ID="{sid}" NameU="{xesc(key)}" Name="{xesc(key)}" Type="Shape">'
                          + "".join(cells) + char + layer_sec + geom + text + '</Shape>')
        if src_key and src_key in shape_ids:
            connects_xml.append(f'<Connect FromSheet="{sid}" FromCell="BeginX" FromPart="9" ToSheet="{shape_ids[src_key]}" ToCell="PinX" ToPart="3"/>')
        if dst_key and dst_key in shape_ids:
            connects_xml.append(f'<Connect FromSheet="{sid}" FromCell="EndX" FromPart="12" ToSheet="{shape_ids[dst_key]}" ToCell="PinX" ToPart="3"/>')

    # containers first (z-order bottom)
    cont_by = {c.id: c for c in d.containers}

    def depth(c):
        dpt, cur = 0, c.parent
        while cur:
            dpt, cur = dpt + 1, cont_by[cur].parent
        return dpt
    for c in sorted(d.containers, key=depth):
        fill, stroke = _fill_stroke(d.theme, c.color, t["lane"] if c.style.get("_lane") else t["container"])
        shape2d(c.id, c.label, c.x, c.y, c.w, c.h, "rounded" if not c.style.get("_lane") else "rect", fill, stroke,
                c.layer, bold=True, dashed=bool(c.style.get("dashed")), font_size=11, align_top=True)
    for s in d.extra_shapes:
        if s["kind"] == "lifeline":
            connector(f"lifeline_{s['x']:.0f}", "", [(s["x"], s["y1"]), (s["x"], s["y2"])], s["layer"], dashed=True, arrow="none")
    for n in d.nodes:
        kind = SHAPES.get(n.shape, SHAPES[DEFAULT_SHAPE])[1]
        fill, stroke = _fill_stroke(d.theme, n.color)
        if n.shape in ("start", "end"):
            fill, stroke = "#000000", "#000000"
        if n.shape == "note":
            fill, stroke = "#FFF2CC", "#D6B656"
        label = n.label
        if n.shape in ("class", "entity"):
            parts = [n.label]
            if n.attributes:
                parts.append("\n".join(n.attributes))
            if n.methods:
                parts.append(("---\n" if n.attributes else "") + "\n".join(n.methods))
            label = "\n".join(parts)
        shape2d(n.id, label, n.x, n.y, n.w, n.h, kind, fill, stroke, n.layer, bold=bool(n.style.get("bold")),
                dashed=bool(n.style.get("dashed")), font_size=int(n.style.get("fontSize", 10)),
                align_top=n.shape in ("class", "entity"))
    node_by = {n.id: n for n in d.nodes}
    for e in d.edges:
        if e.points:
            pts = e.points
            src = dst = None
        else:
            a = node_by.get(e.src) or cont_by.get(e.src)
            b = node_by.get(e.dst) or cont_by.get(e.dst)
            if not a or not b:
                continue
            pts = _edge_route(a, b, e.waypoints)
            src, dst = e.src, e.dst
        connector(e.id, e.label, pts, e.layer, dashed=bool(e.style.get("dashed") or e.style.get("dotted")),
                  arrow=e.style.get("arrow", "block"), src_key=src, dst_key=dst, color=e.style.get("color"))

    # ---- package parts
    layers_xml = "".join(
        f'<Row IX="{i}"><Cell N="Name" V="{xesc(l.name)}"/><Cell N="Color" V="255"/><Cell N="Status" V="0"/>'
        f'<Cell N="Visible" V="{1 if l.visible else 0}"/><Cell N="Print" V="1"/><Cell N="Active" V="{1 if i == 0 else 0}"/>'
        f'<Cell N="Lock" V="{1 if l.locked else 0}"/><Cell N="Snap" V="1"/><Cell N="Glue" V="1"/>'
        f'<Cell N="NameUniv" V="{xesc(l.name)}"/><Cell N="ColorTrans" V="0"/></Row>'
        for i, l in enumerate(d.layers))
    page1 = (f'<?xml version="1.0" encoding="utf-8"?>'
             f'<PageContents xmlns="{NS_MAIN}" xmlns:r="{NS_REL}" xml:space="preserve">'
             f'<Shapes>{"".join(shapes_xml)}</Shapes>'
             + (f'<Connects>{"".join(connects_xml)}</Connects>' if connects_xml else "")
             + '</PageContents>')
    pages = (f'<?xml version="1.0" encoding="utf-8"?>'
             f'<Pages xmlns="{NS_MAIN}" xmlns:r="{NS_REL}" xml:space="preserve">'
             f'<Page ID="0" NameU="{xesc(d.title)}" Name="{xesc(d.title)}" ViewScale="1" ViewCenterX="{PW/2:.3f}" ViewCenterY="{PH/2:.3f}">'
             f'<PageSheet LineStyle="0" FillStyle="0" TextStyle="0">'
             f'<Cell N="PageWidth" V="{PW:.4f}"/><Cell N="PageHeight" V="{PH:.4f}"/>'
             f'<Cell N="PageScale" V="1" U="IN"/><Cell N="DrawingScale" V="1" U="IN"/><Cell N="DrawingSizeType" V="3"/><Cell N="DrawingScaleType" V="0"/>'
             f'<Section N="Layer">{layers_xml}</Section>'
             f'</PageSheet><Rel r:id="rId1"/></Page></Pages>')
    document = (f'<?xml version="1.0" encoding="utf-8"?>'
                f'<VisioDocument xmlns="{NS_MAIN}" xmlns:r="{NS_REL}" xml:space="preserve">'
                '<DocumentSettings TopPage="0" DefaultTextStyle="0" DefaultLineStyle="0" DefaultFillStyle="0" DefaultGuideStyle="0"/>'
                '<Colors/><FaceNames><FaceName NameU="Calibri"/></FaceNames>'
                '<StyleSheets><StyleSheet ID="0" NameU="No Style" Name="No Style">'
                '<Cell N="EnableLineProps" V="1"/><Cell N="EnableFillProps" V="1"/><Cell N="EnableTextProps" V="1"/>'
                '<Cell N="LineWeight" V="0.01"/><Cell N="LineColor" V="#000000"/><Cell N="LinePattern" V="1"/>'
                '<Cell N="FillForegnd" V="#FFFFFF"/><Cell N="FillBkgnd" V="#FFFFFF"/><Cell N="FillPattern" V="1"/>'
                '<Cell N="TextBkgnd" V="0"/><Cell N="VerticalAlign" V="1"/>'
                '<Section N="Character"><Row IX="0"><Cell N="Font" V="Calibri"/><Cell N="Color" V="#000000"/><Cell N="Size" V="0.1667"/></Row></Section>'
                '<Section N="Paragraph"><Row IX="0"><Cell N="HorzAlign" V="1"/></Row></Section>'
                '</StyleSheet></StyleSheets></VisioDocument>')
    content_types = ('<?xml version="1.0" encoding="utf-8"?>'
                     '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                     '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                     '<Default Extension="xml" ContentType="application/xml"/>'
                     '<Override PartName="/visio/document.xml" ContentType="application/vnd.ms-visio.drawing.main+xml"/>'
                     '<Override PartName="/visio/pages/pages.xml" ContentType="application/vnd.ms-visio.pages+xml"/>'
                     '<Override PartName="/visio/pages/page1.xml" ContentType="application/vnd.ms-visio.page+xml"/>'
                     '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
                     '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
                     '</Types>')
    root_rels = ('<?xml version="1.0" encoding="utf-8"?>'
                 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 '<Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/document" Target="visio/document.xml"/>'
                 '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
                 '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
                 '</Relationships>')
    doc_rels = ('<?xml version="1.0" encoding="utf-8"?>'
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/pages" Target="pages/pages.xml"/>'
                '</Relationships>')
    pages_rels = ('<?xml version="1.0" encoding="utf-8"?>'
                  '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                  '<Relationship Id="rId1" Type="http://schemas.microsoft.com/visio/2010/relationships/page" Target="page1.xml"/>'
                  '</Relationships>')
    core = ('<?xml version="1.0" encoding="utf-8"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f'<dc:title>{xesc(d.title)}</dc:title><dc:creator>lucid-diagram</dc:creator></cp:coreProperties>')
    app = ('<?xml version="1.0" encoding="utf-8"?>'
           '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
           '<Application>Microsoft Visio</Application></Properties>')
    return {
        "[Content_Types].xml": content_types.encode(), "_rels/.rels": root_rels.encode(),
        "docProps/core.xml": core.encode(), "docProps/app.xml": app.encode(),
        "visio/document.xml": document.encode(), "visio/_rels/document.xml.rels": doc_rels.encode(),
        "visio/pages/pages.xml": pages.encode(), "visio/pages/_rels/pages.xml.rels": pages_rels.encode(),
        "visio/pages/page1.xml": page1.encode(),
    }


def _edge_route(a, b, waypoints=None) -> List[Tuple[float, float]]:
    """Orthogonal route between boundary points (used by vsdx + preview)."""
    if waypoints:
        pts = []
        wx, wy = waypoints[0]
        ax, ay = a.x + a.w / 2, a.y + a.h / 2
        # exit on the axis along which the waypoint lies clear of the shape, and jog over to the
        # channel in the gap between ranks (never inside the waypoint's own rank)
        if wy > a.y + a.h or wy < a.y:
            edge_y = a.y + a.h if wy > ay else a.y
            gap_y = (edge_y + wy) / 2
            pts += [(ax, edge_y), (ax, gap_y), (wx, gap_y)]
        else:
            edge_x = a.x + a.w if wx > ax else a.x
            gap_x = (edge_x + wx) / 2
            pts += [(edge_x, ay), (gap_x, ay), (gap_x, wy)]
        # orthogonalise between consecutive waypoints: move along the main flow axis first
        main_is_y = getattr(_edge_route, "main_is_y", True)
        for (px, py), (qx, qy) in zip(waypoints, waypoints[1:]):
            pts.append((px, py))
            if abs(qx - px) > 1 and abs(qy - py) > 1:
                pts.append((px, qy) if main_is_y else (qx, py))
        pts.append(waypoints[-1])
        lx, ly = waypoints[-1]
        bx, by = b.x + b.w / 2, b.y + b.h / 2
        if ly < b.y or ly > b.y + b.h:
            edge_y = b.y if ly < b.y else b.y + b.h
            gap_y = (edge_y + ly) / 2
            pts += [(lx, gap_y), (bx, gap_y), (bx, edge_y)]
        else:
            edge_x = b.x if lx < bx else b.x + b.w
            gap_x = (edge_x + lx) / 2
            pts += [(gap_x, ly), (gap_x, by), (edge_x, by)]
        return pts
    ax, ay = a.x + a.w / 2, a.y + a.h / 2
    bx, by = b.x + b.w / 2, b.y + b.h / 2
    dx, dy = bx - ax, by - ay
    if abs(dx) > abs(dy):
        p1 = (a.x + a.w if dx > 0 else a.x, ay)
        p2 = (b.x if dx > 0 else b.x + b.w, by)
        mid = (p1[0] + p2[0]) / 2
        return [p1, (mid, p1[1]), (mid, p2[1]), p2] if abs(dy) > 2 else [p1, p2]
    p1 = (ax, a.y + a.h if dy > 0 else a.y)
    p2 = (bx, b.y if dy > 0 else b.y + b.h)
    mid = (p1[1] + p2[1]) / 2
    return [p1, (p1[0], mid), (p2[0], mid), p2] if abs(dx) > 2 else [p1, p2]


# ----------------------------------------------------------------------------
# PNG preview (optional, Pillow)
# ----------------------------------------------------------------------------
def emit_png(d: Diagram, path: str) -> bool:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception:
        return False
    t = THEMES.get(d.theme, THEMES["neutral"])
    all_x = [n.x + n.w for n in d.nodes] + [c.x + c.w for c in d.containers] + [p[0] for e in d.edges for p in e.points]
    all_y = [n.y + n.h for n in d.nodes] + [c.y + c.h for c in d.containers] + [p[1] for e in d.edges for p in e.points]
    for s in d.extra_shapes:
        all_x.append(s.get("x", 0)); all_y.append(s.get("y2", 0))
    W, H = int(max(all_x, default=600) + 60), int(max(all_y, default=400) + 60)
    scale = 2
    img = Image.new("RGB", (W * scale, H * scale), "white")
    dr = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 11 * scale)
        bold = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 12 * scale)
    except Exception:
        font = bold = ImageFont.load_default()
    S = lambda v: v * scale
    cont_by = {c.id: c for c in d.containers}

    def depth(c):
        dpt, cur = 0, c.parent
        while cur:
            dpt, cur = dpt + 1, cont_by[cur].parent
        return dpt
    hidden = {l.name for l in d.layers if not l.visible}
    for c in sorted(d.containers, key=depth):
        if c.layer in hidden:
            continue
        fill, stroke = _fill_stroke(d.theme, c.color, t["lane"] if c.style.get("_lane") else t["container"])
        dr.rounded_rectangle([S(c.x), S(c.y), S(c.x + c.w), S(c.y + c.h)], radius=S(6), fill=fill, outline=stroke, width=scale)
        dr.text((S(c.x + 8), S(c.y + 6)), c.label, fill=t["font"], font=bold)
    for s in d.extra_shapes:
        if s["kind"] == "lifeline":
            y = s["y1"]
            while y < s["y2"]:
                dr.line([S(s["x"]), S(y), S(s["x"]), S(min(y + 6, s["y2"]))], fill=t["stroke"], width=scale)
                y += 10

    def wrap(text, maxw, f):
        out = []
        for para in text.split("\n"):
            line = ""
            for word in para.split():
                trial = (line + " " + word).strip()
                if dr.textlength(trial, font=f) <= maxw or not line:
                    line = trial
                else:
                    out.append(line); line = word
            out.append(line)
        return out

    node_by = {n.id: n for n in d.nodes}
    for n in d.nodes:
        if n.layer in hidden:
            continue
        kind = SHAPES.get(n.shape, SHAPES[DEFAULT_SHAPE])[1]
        fill, stroke = _fill_stroke(d.theme, n.color)
        if n.shape in ("start", "end"):
            fill = stroke = "#000000"
        if n.shape == "note":
            fill, stroke = "#FFF2CC", "#D6B656"
        box = [S(n.x), S(n.y), S(n.x + n.w), S(n.y + n.h)]
        if kind in ("ellipse", "cloud"):
            dr.ellipse(box, fill=fill, outline=stroke, width=scale)
        elif kind == "diamond":
            cx, cy = S(n.x + n.w / 2), S(n.y + n.h / 2)
            dr.polygon([(cx, box[1]), (box[2], cy), (cx, box[3]), (box[0], cy)], fill=fill, outline=stroke, width=scale)
        elif kind == "parallelogram":
            k = S(min(n.w * 0.2, 25))
            dr.polygon([(box[0] + k, box[1]), (box[2], box[1]), (box[2] - k, box[3]), (box[0], box[3])], fill=fill, outline=stroke, width=scale)
        elif kind == "hexagon":
            k = S(min(n.w * 0.2, 25)); cy = S(n.y + n.h / 2)
            dr.polygon([(box[0] + k, box[1]), (box[2] - k, box[1]), (box[2], cy), (box[2] - k, box[3]), (box[0] + k, box[3]), (box[0], cy)], fill=fill, outline=stroke, width=scale)
        elif kind in ("rounded", "pill"):
            dr.rounded_rectangle(box, radius=S(n.h / 2 if kind == "pill" else 8), fill=fill, outline=stroke, width=scale)
        elif kind == "text":
            pass
        elif kind == "actor":
            cx = S(n.x + n.w / 2)
            dr.ellipse([cx - S(8), box[1], cx + S(8), box[1] + S(16)], outline=stroke, width=scale)
            dr.line([cx, box[1] + S(16), cx, box[1] + S(45)], fill=stroke, width=scale)
            dr.line([cx - S(15), box[1] + S(25), cx + S(15), box[1] + S(25)], fill=stroke, width=scale)
            dr.line([cx, box[1] + S(45), cx - S(14), box[3]], fill=stroke, width=scale)
            dr.line([cx, box[1] + S(45), cx + S(14), box[3]], fill=stroke, width=scale)
        elif kind == "cylinder":
            dr.rectangle([box[0], box[1] + S(8), box[2], box[3] - S(8)], fill=fill, outline=stroke, width=scale)
            dr.ellipse([box[0], box[3] - S(16), box[2], box[3]], fill=fill, outline=stroke, width=scale)
            dr.ellipse([box[0], box[1], box[2], box[1] + S(16)], fill=fill, outline=stroke, width=scale)
        else:
            dr.rectangle(box, fill=fill, outline=stroke, width=scale)
        # label
        label = n.label
        if n.shape in ("class", "entity"):
            dr.line([box[0], box[1] + S(30), box[2], box[1] + S(30)], fill=stroke, width=scale)
            dr.text((S(n.x + n.w / 2), S(n.y + 15)), n.label, fill=t["font"], font=bold, anchor="mm")
            y = n.y + 30 + 13
            for row in n.attributes + (["—"] if n.methods and n.attributes else []) + n.methods:
                dr.text((S(n.x + 8), S(y)), row, fill=t["font"], font=font, anchor="lm")
                y += 26
            continue
        if kind == "actor":
            dr.text((S(n.x + n.w / 2), S(n.y + n.h + 12)), label, fill=t["font"], font=font, anchor="mm")
            continue
        if n.shape in ("start", "end"):
            continue
        lines_ = wrap(label, S(n.w - 16), font)
        lh = 14 * scale
        y0 = S(n.y + n.h / 2) - lh * (len(lines_) - 1) / 2
        for i, ln in enumerate(lines_):
            dr.text((S(n.x + n.w / 2), y0 + i * lh), ln, fill=t["font"], font=font, anchor="mm")
    for e in d.edges:
        if e.layer in hidden:
            continue
        if e.points:
            pts = e.points
        else:
            a = node_by.get(e.src) or cont_by.get(e.src)
            b = node_by.get(e.dst) or cont_by.get(e.dst)
            if not a or not b:
                continue
            pts = _edge_route(a, b, e.waypoints)
        col = e.style.get("color", t["edge"])
        spts = [(S(x), S(y)) for x, y in pts]
        if e.style.get("dashed") or e.style.get("dotted"):
            for (x1, y1), (x2, y2) in zip(spts, spts[1:]):
                L = math.hypot(x2 - x1, y2 - y1)
                nseg = max(1, int(L / S(8)))
                for k in range(0, nseg, 2):
                    fx1 = x1 + (x2 - x1) * k / nseg; fy1 = y1 + (y2 - y1) * k / nseg
                    fx2 = x1 + (x2 - x1) * min(k + 1, nseg) / nseg; fy2 = y1 + (y2 - y1) * min(k + 1, nseg) / nseg
                    dr.line([fx1, fy1, fx2, fy2], fill=col, width=scale)
        else:
            dr.line(spts, fill=col, width=scale)
        if e.style.get("arrow", "block") != "none":
            (x1, y1), (x2, y2) = spts[-2], spts[-1]
            ang = math.atan2(y2 - y1, x2 - x1)
            L = S(9)
            p1 = (x2 - L * math.cos(ang - 0.4), y2 - L * math.sin(ang - 0.4))
            p2 = (x2 - L * math.cos(ang + 0.4), y2 - L * math.sin(ang + 0.4))
            dr.polygon([(x2, y2), p1, p2], fill=col)
        if e.label:
            # label at the midpoint of the longest segment (close to what draw.io/Lucid do)
            seg = max(zip(spts, spts[1:]), key=lambda q: math.hypot(q[1][0] - q[0][0], q[1][1] - q[0][1]))
            mx, my = (seg[0][0] + seg[1][0]) / 2, (seg[0][1] + seg[1][1]) / 2
            tw = dr.textlength(e.label, font=font)
            dr.rectangle([mx - tw / 2 - S(3), my - S(8), mx + tw / 2 + S(3), my + S(8)], fill="white")
            dr.text((mx, my), e.label, fill=t["font"], font=font, anchor="mm")
    img = img.resize((W, H), Image.LANCZOS) if scale != 1 else img
    img.save(path)
    return True


# ----------------------------------------------------------------------------
# Output checks
# ----------------------------------------------------------------------------
def check_outputs(paths: Dict[str, str]) -> List[str]:
    import xml.dom.minidom
    problems = []
    if "drawio" in paths:
        try:
            xml.dom.minidom.parse(paths["drawio"])
        except Exception as ex:
            problems.append(f"drawio XML not well-formed: {ex}")
    if "vsdx" in paths:
        try:
            with zipfile.ZipFile(paths["vsdx"]) as z:
                names = set(z.namelist())
                for req in ("[Content_Types].xml", "visio/document.xml", "visio/pages/pages.xml", "visio/pages/page1.xml"):
                    if req not in names:
                        problems.append(f"vsdx missing part {req}")
                for n in names:
                    if n.endswith(".xml") or n.endswith(".rels"):
                        xml.dom.minidom.parseString(z.read(n))
        except Exception as ex:
            problems.append(f"vsdx package problem: {ex}")
    return problems


def report(d: Diagram) -> str:
    hidden = [l.name for l in d.layers if not l.visible]
    per_layer = defaultdict(lambda: [0, 0])
    for n in d.nodes:
        per_layer[n.layer][0] += 1
    for e in d.edges:
        per_layer[e.layer][1] += 1
    lines = [f"Title: {d.title}", f"Type: {d.kind}   Direction: {d.direction}   Theme: {d.theme}",
             f"Nodes: {len(d.nodes)}   Edges: {len(d.edges)}   Containers: {len(d.containers)}   Lanes: {len(d.lanes)}",
             "Layers: " + ", ".join(f"{l.name} ({per_layer[l.name][0]} shapes / {per_layer[l.name][1]} lines"
                                   + (", hidden" if not l.visible else "") + (", locked" if l.locked else "") + ")"
                                   for l in d.layers)]
    if hidden:
        lines.append("Hidden layers are still exported; toggle them in Lucid's Layers panel.")
    return "\n".join(lines)


# ----------------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------------
SCHEMA_HELP = """
Spec (JSON) — minimal:
{
  "title": "Order pipeline", "type": "flowchart", "direction": "TB", "theme": "neutral",
  "layers": [{"id": "base", "name": "Base"}, {"id": "notes", "name": "Annotations", "visible": true}],
  "containers": [{"id": "aws", "label": "AWS us-east-1", "layer": "base"}],
  "nodes": [
    {"id": "start", "label": "Order received", "shape": "terminator"},
    {"id": "check", "label": "In stock?", "shape": "decision", "container": "aws", "color": "yellow", "layer": "base"}
  ],
  "edges": [{"from": "start", "to": "check", "label": "", "style": {"dashed": false, "arrow": "block"}}]
}
type: flowchart | swimlane | architecture | network | sequence | erd | class | state | orgchart | mindmap | usecase | freeform
swimlane: add "lanes": [{"id": "sales", "label": "Sales"}], "lane_orientation": "horizontal|vertical"; nodes get "lane".
sequence: "sequence": {"actors": [{"id": "u", "label": "User", "shape": "actor"}],
                       "messages": [{"from": "u", "to": "api", "label": "POST /orders", "kind": "sync|async|return", "note": "..."}]}
class/erd: node shape "class" / "entity" with "attributes": [...], "methods": [...]; edge arrow: inherit | diamond | one | many | one-or-many | zero-or-many
Shapes: """ + ", ".join(sorted(SHAPES)) + """
Colors: """ + ", ".join(SEMANTIC_COLORS) + """ or any #hex.   Themes: """ + ", ".join(THEMES) + """
Positions: give "x","y" (and "w","h") on a node to pin it; everything else is auto-laid-out.
"""


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("render", help="render spec to drawio/vsdx/png")
    r.add_argument("spec"); r.add_argument("--out", default="."); r.add_argument("--formats", default="drawio,vsdx,png",
                   help="comma list of drawio,vsdx,png")
    r.add_argument("--name", default=None, help="base filename (default: derived from title)")
    r.add_argument("--strict", action="store_true", help="fail on warnings too")
    v = sub.add_parser("validate", help="validate a spec without rendering"); v.add_argument("spec")
    sub.add_parser("schema", help="print the spec reference")
    args = ap.parse_args(argv)

    if args.cmd == "schema":
        print(SCHEMA_HELP)
        return 0
    d = load_spec(args.spec)
    errors, warnings = validate(d)
    for w in warnings:
        print(f"WARN  {w}")
    for e in errors:
        print(f"ERROR {e}")
    if errors or (args.strict and warnings):
        print("Spec invalid — fix the above and re-run.")
        return 2
    if args.cmd == "validate":
        print("Spec OK")
        return 0
    layout(d)
    os.makedirs(args.out, exist_ok=True)
    import re as _re
    base = args.name or _re.sub(r"-+", "-", "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in d.title.lower())).strip("-") or "diagram"
    fmts = {f.strip() for f in args.formats.split(",") if f.strip()}
    paths = {}
    if "drawio" in fmts:
        p = os.path.join(args.out, base + ".drawio")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(emit_drawio(d))
        paths["drawio"] = p
    if "vsdx" in fmts:
        p = os.path.join(args.out, base + ".vsdx")
        with zipfile.ZipFile(p, "w", zipfile.ZIP_DEFLATED) as z:
            for name, data in emit_vsdx(d).items():
                z.writestr(name, data)
        paths["vsdx"] = p
    if "png" in fmts:
        p = os.path.join(args.out, base + ".png")
        if emit_png(d, p):
            paths["png"] = p
        else:
            print("WARN  Pillow not installed — skipping PNG preview (pip install pillow)")
    probs = check_outputs(paths)
    for p in probs:
        print(f"ERROR {p}")
    print(report(d))
    for k, p in paths.items():
        print(f"{k:7s} -> {p}")
    return 1 if probs else 0


if __name__ == "__main__":
    sys.exit(main())
