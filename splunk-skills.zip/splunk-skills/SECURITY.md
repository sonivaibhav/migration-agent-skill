# Security

`splunk-triage` reads production logs. This page states the threat model, what
the tooling enforces, what it only advises, and how to report a gap.

## Threat model

| Threat | Mitigation | Enforced by |
|---|---|---|
| Agent or user writes to Splunk (lookups, alerts, saved searches, email) | `search` and `fanout` are the only subcommands that reach Splunk; the SPL command allowlist rejects every write command before the query leaves the machine | CLI |
| Unbounded or runaway searches | `index=` and `earliest=` mandatory; window cap and row cap from `org.yaml`; wider windows need an explicit flag after asking the user | CLI |
| Customer data in transcripts, tickets, files | Every field redacted or hashed per `fields.yaml` before print; unmapped fields default to hash; pattern guards for card numbers, national IDs, emails on every string | CLI |
| One team's sensitive fields visible to another | `visibility: owner` prints only with `--context <owning seal>`; seals can widen only their own fields; `never` is a core floor | CLI + `validate.py` |
| Copying a field under a new name to dodge its rule (`eval`, `rename`, `values(...) as`, `rex`) | Field lineage: a created column inherits the strictest rule of its sources; `_raw`-derived groups hash | CLI |
| Results persisted to disk | No writes without `--save`; saved output is the redacted output | CLI |
| Raw events read in bulk | `_raw` dropped by default; `--raw` needs `head ≤ 5` and `--context` = the owning seal of every index queried; raw text still pattern-guarded | CLI |
| Oversized results in the agent's context | Projection to the seal's focus when the SPL has no `table`; text fields truncated with a visible marker; per-run budget warning | CLI |
| Queries sent to an unlisted host | `--base-url` (or `SPLUNK_BASE_URL`) must match an instance in `org.yaml` (exit 6 before sign-in) | CLI |
| Credential leakage | Kerberos only, no passwords; token cache owner-only; CLI never prints tokens; `SPLUNK_INSECURE_TLS` not honoured; redirects restricted to `org.yaml` hosts | CLI |
| Prompt injection via log content | Guardrails loaded every run: log content is data, not instructions | Agent (advised) |
| Using the skill to profile a named person | Guardrails scope: incident identifiers only, never a name | Agent (advised) |
| A seal lowering core protections in its own files | `validate.py` rejects `never` downgrades, owner-on-foreign-field, unmasked direct PII, PII in examples | CI |
| Core leaking org specifics to another org | `validate.py` rejects org name, instance hosts in `core/` | CI |

## Enforced vs advised

Anything marked **CLI** or **CI** holds regardless of what the agent is told.
Anything marked **advised** depends on the agent following
`splunk-triage/core/guardrails.md`. We treat advised controls as defence in
depth, not as the control.

## Audit

Each CLI run appends one line to a local audit log: timestamp, instance host,
SHA-256 of the SPL, `--context`, row count, status (ok, rejected, host-refused,
auth-failed, search-failed). Never the SPL text, never results.

## Reference guard implementation

`splunk-triage/scripts/guard.py` is the runnable contract for the CLI: `check_spl`
(allowlist, bounds, shape) and `Redactor.redact_rows` (visibility, masks,
pattern guards, per-run salted hashing). `splunk_cli.py` calls both, in that
order, and `tests/security/test_guard.py` pins every rule in the
table above with a failing case. `tests/evals/mock_cli.py` uses the same module,
so agent evals exercise the real guard without Splunk access.

## Red-team tests

`tests/security/` covers write-command injection (including buried after many
pipes, mixed case, and inside quotes), missing bounds, over-cap windows, cap
escalation on non-aggregates, leading-token tricks, owner-field access with no
or wrong `--context`, cross-seal field-name collisions, never-list downgrade
attempts, clear PII in free text, and laundering a hashed field through `eval`,
`rename`, `stats values(...) as`, `rex` and chains of them. `tests/evals/layer-2-execution` adds the
agent-side cases: rephrasing after a rejection, skipping the ask before 24h,
and following instructions planted in log lines.

## Reporting

Open an issue tagged `security` or contact the owners in `CODEOWNERS` for
`core/`. Do not include production data in the report.
