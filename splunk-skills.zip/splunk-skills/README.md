# splunk-skills

`splunk-triage` is an agent skill that triages production incidents across downstream systems
without waiting on an SME. It finds the right application (seal) from a plain question, runs
short read-only Splunk searches that redact customer data, and reports in plain language with
the query that ran. Runs in GitHub Copilot (GPT or Claude models) and in Claude Code; nothing in
it assumes one model or one shell.

```
/splunk-triage Check UR prod logs for new errors
/splunk-triage UR Prod splunk alert triggered: UR Prod 5xx Rate
/splunk-triage users cannot sign in to Ultimate Rewards since 2pm
/splunk-triage trace frTraceId abc-7 from UR into ForgeRock
```

## How it works

```
 question ──► resolve.py ──► fast: one seal, standard question → first query printed
                 │           full: journey → hops with key + skew → seals to read
                 ▼
       build_query.py composes 5–7 line SPL from fields.yaml roles
                 ▼
       splunk_cli.py search | fanout  →  guard.py: read-only · bounded · redacted · projected  →  report
```

Each application is a folder: `seals/<seal-id>-<name>/` with `seal.yaml` (names, indexes,
sourcetypes), `fields.yaml` (what each field is, which are PII, which play the status / endpoint
/ id / trace roles), `links.yaml` (what it sends downstream and on which key), `alerts.yaml`
(your Splunk alerts), `notes.md` (traps), `queries.md` (recipes the builder cannot derive).
`journeys/` chain seals for a user action. `core/` holds the rules once and never names an org
or a seal, so another org copies the skill and replaces `org.yaml` and `seals/`.

## Setup

Python 3.9 or newer (3.14 works), git, Kerberos sign-in, Splunk read access.

```bash
git clone ssh://git@bitbucketdc-digital-ssh.jpmchase.net:7999/wcmrt/splunk-skills.git
python3 splunk-skills/splunk-triage/scripts/setup.py
```

One command (`python` instead of `python3` on Windows): checks Python and PyYAML, links the
skill into `~/.copilot/skills` or `~/.claude/skills` (copies on Windows), retires an old `rewards-splunk-cli` link, validates the
seal files, and runs the Splunk access check once `scripts/splunk_client.py` holds your
`login()` and `search()` (two functions; `first-run/CLI-INTEGRATION.md`). It ends with a
command to try. Kerberos, VPN and CA bundles stay with you; it tells you what is missing.
Then follow `first-run/README.md`.

## Add your application

```bash
python3 splunk-triage/scripts/onboard_seal.py          # a few questions; paste a field list when asked
python3 splunk-triage/scripts/validate.py --score 55555
```

Onboarding drafts every file with its guesses marked `check`, runs validation, and prints a
completeness score with what is missing (roles, links to confirm, alerts, journey membership).
Your seal is usable from the first run; standard questions need no hand-written SPL.
`onboard_seal.py --fieldsummary <index> <sourcetype>` prints the Splunk query that lists fields.

## Repository

| Path | What |
|---|---|
| `splunk-triage/SKILL.md` | the skill: resolve → fast or full path → report |
| `splunk-triage/core/` | guardrails and references; org-neutral by validation |
| `splunk-triage/seals/`, `journeys/`, `org.yaml` | the org's content |
| `splunk-triage/scripts/` | `resolve`, `build_query`, `guard`, `validate`, `onboard_seal`, `setup`, `build_registry`, `splunk_cli` (complete; needs your `splunk_client.py` with `login()` and `search()`, see `splunk_client_example.py`) |
| `first-run/` | the day-1 plan, CLI integration guide, facts to validate, sample prompts, live contract check |
| `splunk-triage/GRAPH.md` (generated) | how the seals connect: links, journeys, alerts |
| `tests/` | unit, security (the guard contract), agent evals with a mocked CLI |
| `SECURITY.md`, `CONTRIBUTING.md` | threat model and how to change things |

`rewards-splunk-cli` is the old name; a shim points to `splunk-triage` for one release.
