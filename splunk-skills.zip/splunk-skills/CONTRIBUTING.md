# Contributing

## Who changes what

| Path | Owner | Review |
|---|---|---|
| `splunk-triage/core/**`, `scripts/**`, `org.yaml` | Platform owners (see `CODEOWNERS`) | Required |
| `splunk-triage/seals/<id>-*/**` | That seal's team | Team review; platform review only if `validate.py` fails |
| `splunk-triage/journeys/<name>.yaml` | The `owner:` in the file | Owner review; any seal referenced may comment |
| `registry.yaml` | Nobody; generated | CI regenerates and fails the build if it is stale |

## Adding a seal

`python3 splunk-triage/scripts/onboard_seal.py` (or `--answers my.yaml`; `--print-template`
gives the file). It asks for the id, name, aliases, index, sourcetypes, owners, volume, a field
list, what you call downstream, and your alert names, then drafts every file with its guesses
marked `check`, validates, and prints a completeness score. Review the `check` lines in
`fields.yaml` (PII class, visibility, units), fill `roles` for every sourcetype, run each
`verify_query` in prod and flip the link to `confirmed`, fill `means` and `then` on each alert.
Commit your folder and the regenerated `registry.yaml`. `validate.py --score <id>` shows what
is still missing. Once the seal works, run `| tstats count where index=<i> sourcetype=<st>
earliest=-15m latest=now by <status field>` in prod; if it returns the same rows as the `stats`
version, add `indexed_in: [prod]` to that sourcetype in `fields.yaml` and volume checks stop
reading events.

## Routing knobs in seal.yaml

- `aliases`: every way people say the seal (names, acronyms, index, sourcetypes).
- `app_aliases`: app → phrases, so "WL 500s" queries the WL sourcetype and "balance service" the
  balance one. Keep them specific; a generic word here (gateway, challenge) hijacks other seals.
- `id_patterns`: name → regex for identifiers people paste; a match routes to you.
- Recipe titles in `queries.md` route too: a distinctive word in the title ("region", "platform")
  sends the question to that recipe instead of a generated query. Seal aliases and kind words
  (errors, traffic, latency) do not count; a title about one identifier ("for one profile") is
  offered only for trace questions or a pasted identifier, and an `id_patterns` name (`browser_token`)
  picks the recipe whose title has those words; a title naming two apps ("UR vs WL") wins when
  the question names both.

## Adding a recipe

Standard questions are generated (`build_query.py`); add a recipe to `queries.md` only for SPL
that encodes something the builder cannot derive (a filter string, a `rex`, a special key). Add a
row to the index table at the top, then a section: title, one line on when, SPL under 8 lines
ending in `| head 20 | table …` for an event list, one line of provenance. Every `spl` block needs
`index=` and `earliest=`, and no shipped block may be wider than 24 hours.

## Adding an alert

One entry in your seal's `alerts.yaml`: the exact Splunk alert name, `means` in one plain
sentence, `kind`, the `where` condition, and `then`. The resolver matches alert names first.

## Confirming a link

Run the edge's `verify_query` in prod. Set `status: confirmed`, fill
`skew_s` from what you observed, add `provenance:` with the date.

## Adding a journey

Create `journeys/<name>.yaml` with `owner`, `triggers` (what people say),
`entry` seal, and `hops` as `<seal>/<link id>`. Hops must resolve to existing
links; put the link in the calling seal's `links.yaml` first.

## Overriding a core reference for your seal

Copy `core/references/<file>.md` to `seals/<yours>/overrides/<file>.md` and
edit. It replaces the core file for your seal only. Keep it rare; prefer
`notes.md` for additions.

## Never

- Real identifiers, card numbers, emails, or names in any example.
- Lowering a `never` field or setting `owner` on another seal's field.
- Org names, instance hosts, or seal IDs inside `core/`.
- Hand-editing `registry.yaml`.
- A journey whose every trigger is also a seal alias (alias words never count toward a journey).
- `transaction`, a leading wildcard, or a hand-written `tstats` in any shipped SPL (the builder
  emits `tstats` itself, only for pure counts in the environments `indexed_in` lists).

## Tests

`tests/run-evals.sh` runs `validate.py`, checks `registry.yaml` is fresh, and
runs `pytest` over:

- `tests/unit/` — tree invariants, validator guards (each class of mistake has
  a failing fixture), resolver routing, content consistency (units, join keys,
  SPL hygiene, banned commands), and eval-suite well-formedness.
- `tests/security/` — the guard layer the CLI must call (`scripts/guard.py`):
  write-command allowlist, mandatory `index=`/`earliest=`, window and row caps,
  leading-token shape, and every redaction rule (never / owner / hash / last4 /
  pattern guards / per-run salt / cross-seal owner precedence).
- `tests/evals/` — three agent layers (routing, execution, output), each a
  `test-suite.yaml` of cases plus an `evaluator-prompt.md` for a grader model,
  run against `mock_cli.py` which applies the real guard and serves fixtures.

Adding a seal? Add a routing case to layer 1 with your aliases, and a fixture
for your Step-1 query.
