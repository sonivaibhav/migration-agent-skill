"""Red-team tests against the guard layer the CLI must call.

Each test is a thing a careless or malicious user could try. The guard, not
the prompt, has to stop it. The real splunk_cli.py routes through
scripts/guard.py; these tests pin that behaviour.
"""
import pytest

from guard import GuardError, Limits, Redactor, check_spl, pattern_guard, REDACTED

UR = "cfs_digital_ultimate_rewards_aws_89592"
FR = "cfs_digauthciam_81712"
RPEX = "rpex_111863"


@pytest.fixture
def lim():
    return Limits.from_org()


# ------------------------------------------------------------ read-only

@pytest.mark.parametrize("cmd", [
    "outputlookup evil.csv", "collect index=summary", "sendemail to=x@y.com",
    "delete", "outputcsv dump", "rest /services/saved/searches", "script foo",
    "runshellscript bar", "map search=\"search index=x\"", "savedsearch mine",
    "dbxquery query=\"drop table\"", "mcollect index=m", "sendalert webhook",
])
def test_write_commands_are_rejected(lim, cmd):
    with pytest.raises(GuardError, match="not allowed"):
        check_spl(f"index={UR} earliest=-1h | {cmd}", lim)


def test_write_command_buried_after_many_pipes(lim):
    spl = f"index={UR} earliest=-1h | fields a | eval b=1 | stats count by b | sort - count | outputlookup x.csv"
    with pytest.raises(GuardError):
        check_spl(spl, lim)


def test_write_command_in_mixed_case(lim):
    with pytest.raises(GuardError):
        check_spl(f"index={UR} earliest=-1h | OutputLookup x.csv", lim)


def test_write_command_inside_quotes_is_not_a_command(lim):
    """A literal string containing the word must not trip the guard."""
    check_spl(f'index={UR} earliest=-1h message="outputlookup failed" | stats count', lim)


def test_inputlookup_append_is_rejected(lim):
    with pytest.raises(GuardError):
        check_spl(f"index={UR} earliest=-1h | inputlookup append=true x.csv", lim)


def test_inputlookup_read_is_allowed(lim):
    check_spl(f"index={UR} earliest=-1h | inputlookup x.csv | stats count", lim)


# ------------------------------------------------------------ bounded

def test_missing_index_rejected(lim):
    with pytest.raises(GuardError, match="index="):
        check_spl("search sourcetype=x earliest=-1h | stats count", lim)


def test_missing_earliest_rejected(lim):
    with pytest.raises(GuardError, match="earliest="):
        check_spl(f"index={UR} | stats count", lim)


@pytest.mark.parametrize("win", ["-25h", "-2d", "-7d", "-30d", "-1500m"])
def test_window_over_cap_rejected(lim, win):
    with pytest.raises(GuardError, match="over the"):
        check_spl(f"index={UR} earliest={win} latest=now | stats count", lim)


@pytest.mark.parametrize("win", ["-15m", "-1h", "-4h", "-24h", "-1d", "-1440m"])
def test_window_at_or_under_cap_allowed(lim, win):
    check_spl(f"index={UR} earliest={win} latest=now | stats count", lim)


def test_wide_window_allowed_only_with_confirm_flag():
    lim = Limits.from_org(confirm_window=True)
    check_spl(f"index={UR} earliest=-7d | timechart span=1d count", lim)


def test_max_results_above_cap_needs_aggregate(lim):
    lim.max_results = 5000
    with pytest.raises(GuardError, match="aggregate"):
        check_spl(f"index={UR} earliest=-1h | head 5000 | table _time, uri", lim)
    out = check_spl(f"index={UR} earliest=-1h | stats count by uri | sort - count", lim)
    assert out["effective_max_rows"] == 5000


def test_default_cap_applies(lim, org):
    out = check_spl(f"index={UR} earliest=-1h | table uri", lim)
    assert out["effective_max_rows"] == org["limits"]["max_rows"]


# ------------------------------------------------------------ shape

@pytest.mark.parametrize("spl", [
    f"(index={UR}) earliest=-1h | stats count",
    f"index IN ({UR}, {FR}) earliest=-1h | stats count",
    f"TERM(abc) index={UR} earliest=-1h | stats count",
    f"| inputlookup x.csv",
    f"| rest /services/server/info",
])
def test_bad_leading_token_rejected(lim, spl):
    with pytest.raises(GuardError):
        check_spl(spl, lim)


def test_makeresults_smoke_allowed(lim):
    assert check_spl("| makeresults", lim)["effective_max_rows"] == 1


def test_search_prefix_allows_parens_and_in(lim):
    check_spl(f"search (index={UR} a=1) OR (index={FR} b=2) earliest=-1h | stats count", lim)
    check_spl(f"search index IN ({UR}, {FR}) earliest=-1h | stats count", lim)


# ------------------------------------------------------------ redaction

ALL = "| table *"      # keep every field: these tests check masking, not projection


def rows():
    return [{
        "_time": "2026-11-07T10:00:00", "_raw": "secret raw", "host": "h1", "index": UR,
        "uri": "/rewards", "status": "500", "responseTime": "1234567",
        "smCigProfileId": "987654321", "frTraceId": "uuid-1",
        "xForwardedFor": "10.0.0.9", "userAgent": "Mozilla/5.0",
        "message": "user john.doe@example.com card 4111111111111111 ssn 123-45-6789",
        "unmappedField": "clear-value",
    }]


def test_core_suppress_list_dropped():
    out = Redactor().redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]
    for k in ("_raw", "host", "index"):
        assert k not in out


def test_time_dropped_in_table_mode_kept_in_json():
    r = Redactor()
    assert "_time" not in r.redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]
    assert "_time" in r.redact_rows(rows(), f"index={UR} earliest=-1h", json_mode=True)[0]


def test_pii_none_fields_print_clear():
    out = Redactor().redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]
    assert out["uri"] == "/rewards" and out["status"] == "500 (server error)" and out["frTraceId"] == "uuid-1"


def test_profile_id_hashed_and_stable_within_run():
    r = Redactor()
    a = r.redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]["smCigProfileId"]
    b = r.redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]["smCigProfileId"]
    assert a == b and a != "987654321" and len(a) == 12


def test_hash_differs_across_runs():
    a = Redactor().redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]["smCigProfileId"]
    b = Redactor().redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]["smCigProfileId"]
    assert a != b, "per-run salt: a hash must not be reusable across runs"


def test_same_value_hashes_same_across_seals_in_one_run():
    """Joinability: the UR profile and the RPEX profile with the same clear value hash alike."""
    r = Redactor()
    ur = r.redact_rows([{"smCigProfileId": "42"}], f"index={UR} earliest=-1h {ALL}")[0]["smCigProfileId"]
    rp = r.redact_rows([{"online-profile-identifier": "42"}], f"index={RPEX} earliest=-1h {ALL}")[0]["online-profile-identifier"]
    assert ur == rp


def test_unmapped_field_is_hashed_not_shown():
    out = Redactor().redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]
    assert out["unmappedField"] != "clear-value"


def test_redact_mask_applied():
    out = Redactor().redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]
    assert out["userAgent"] == REDACTED


def test_pattern_guards_scrub_free_text():
    out = Redactor().redact_rows(rows(), f"index={UR} earliest=-1h {ALL}")[0]
    assert "4111111111111111" not in out["message"]
    assert "john.doe@example.com" not in out["message"]
    assert "123-45-6789" not in out["message"]
    assert out["message"].count(REDACTED) == 3


def test_pattern_guard_leaves_non_luhn_digits():
    assert "1234567890123" in pattern_guard("id 1234567890123 ok")  # fails Luhn, not a card


def test_never_field_cannot_be_unmasked_even_by_owner():
    r = Redactor(context="89592")
    out = r.redact_rows([{"ssn": "123-45-6789", "cardNumber": "4111111111111111"}], f"index={UR} earliest=-1h {ALL}")[0]
    assert out["ssn"] == REDACTED and out["cardNumber"] == REDACTED


def test_owner_field_redacted_without_context():
    out = Redactor().redact_rows([{"userId": "john.doe"}], f"index={FR} earliest=-1h {ALL}")[0]
    assert out["userId"] == REDACTED


def test_owner_field_redacted_with_wrong_context():
    out = Redactor(context="89592").redact_rows([{"userId": "john.doe"}], f"index={FR} earliest=-1h {ALL}")[0]
    assert out["userId"] == REDACTED


def test_owner_field_clear_with_owning_context():
    out = Redactor(context="81712").redact_rows([{"userId": "john.doe"}], f"index={FR} earliest=-1h {ALL}")[0]
    assert out["userId"] == "john.doe"


def test_owner_rule_wins_over_a_weaker_rule_for_the_same_field_name():
    """UR app log also has userId (indirect/hash). In a UR+FR query the FR owner rule must win."""
    spl = f"search (index={UR}) OR (index={FR}) earliest=-1h {ALL}"
    assert Redactor().redact_rows([{"userId": "john.doe"}], spl)[0]["userId"] == REDACTED
    assert Redactor(context="81712").redact_rows([{"userId": "john.doe"}], spl)[0]["userId"] == "john.doe"


def test_context_does_not_unlock_other_seals_owner_fields():
    """Running with --context 89592 on a ForgeRock index must not reveal FR owner fields."""
    out = Redactor(context="89592").redact_rows([{"userId": "john.doe"}], f"index={FR} earliest=-1h {ALL}")[0]
    assert out["userId"] == REDACTED


def test_multivalue_key_value_keeps_prefix():
    out = Redactor().redact_rows([{"trackingIds{}": ["userid=john", "profileid=123"]}], f"index={FR} earliest=-1h {ALL}")[0]
    assert out["trackingIds{}"][0].startswith("userid=") and out["trackingIds{}"][1].startswith("profileid=")
    assert "123" not in out["trackingIds{}"][1]


def test_seal_suppress_list_applied():
    out = Redactor().redact_rows([{"DataCenter": "", "msec_frac": "123", "uri": "/x"}], f"index={UR} earliest=-1h {ALL}")[0]
    assert "DataCenter" not in out and "msec_frac" not in out and out["uri"] == "/x"


def test_owner_clear_value_still_pattern_guarded():
    """Even the owning team does not get a card number back in clear."""
    out = Redactor(context="81712").redact_rows([{"userId": "4111111111111111"}], f"index={FR} earliest=-1h {ALL}")[0]
    assert out["userId"] == REDACTED


def test_validate_blocks_a_seal_lowering_never(tmp_seal):
    """Defence in depth: even if guard had a bug, CI rejects the file."""
    import subprocess, sys, yaml
    p = tmp_seal / "seals" / "89592-ur" / "fields.yaml"
    d = yaml.safe_load(p.read_text())
    d["sourcetypes"]["wcmur_cfs_ultimate_rewards_ecs_uraccess_st"]["fields"].append(
        {"raw": "accountNumber", "display": "Acct", "pii": "direct", "visibility": "owner", "mask": "none"})
    p.write_text(yaml.safe_dump(d, sort_keys=False))
    r = subprocess.run([sys.executable, str(tmp_seal / "scripts" / "validate.py")], capture_output=True, text=True, cwd=tmp_seal)
    assert "never-list" in r.stdout


# ------------------------------------------------------------ projection, truncation, decode, raw

from guard import format_table, truncate, Budget, owning_seals, has_projection


def test_auto_projection_when_spl_has_no_table():
    r = Redactor(focus="errors")
    out = r.redact_rows([{"uri": "/x", "status": "500", "bytes": "9", "userAgent": "UA", "smCigProfileId": "1"}], f"index={UR} earliest=-15m")[0]
    assert set(out) == {"uri", "status", "smCigProfileId"}, out


def test_no_projection_when_spl_has_table():
    r = Redactor(focus="errors")
    out = r.redact_rows([{"uri": "/x", "bytes": "9"}], f"index={UR} earliest=-15m | table uri, bytes")[0]
    assert "bytes" in out


def test_text_field_is_truncated_with_visible_marker():
    out = Redactor().redact_rows([{"message": "x" * 450}], f"index={UR} earliest=-15m | table message")[0]
    assert out["message"].endswith("…[+150 chars]") and len(out["message"]) < 330


def test_text_field_keeps_first_multivalue_entry_only():
    out = Redactor().redact_rows([{"message": ["first", "second"]}], f"index={UR} earliest=-15m | table message")[0]
    assert out["message"] == "first"


def test_decode_table_and_http_status():
    rows = [{"authInfo": "MON", "status": "504"}, {"authInfo": "-", "status": "200"}, {"authInfo": "ZZZ", "status": "999"}]
    out = Redactor().redact_rows(rows, f"index={UR} earliest=-15m | table authInfo, status")
    assert out[0]["authInfo"] == "MON (Chase Retail - iPhone)" and out[0]["status"] == "504 (gateway timeout)"
    assert out[1]["authInfo"] == "(missing)" and out[1]["status"] == "200 (ok)"
    assert out[2]["authInfo"] == "ZZZ (unknown)" and out[2]["status"] == "999"


def test_raw_requires_head_le_5_and_owner_context():
    lim = Limits.from_org(raw=True, context="89592")
    check_spl(f"index={UR} earliest=-15m | head 5 | table _time, _raw", lim)
    with pytest.raises(GuardError, match="head"):
        check_spl(f"index={UR} earliest=-15m | head 6 | table _raw", lim)
    with pytest.raises(GuardError, match="head"):
        check_spl(f"index={UR} earliest=-15m | table _raw", lim)
    with pytest.raises(GuardError, match="owning seal"):
        check_spl(f"index={UR} earliest=-15m | head 5 | table _raw", Limits.from_org(raw=True, context="81712"))
    with pytest.raises(GuardError, match="one seal"):
        check_spl(f"search (index={UR}) OR (index={FR}) earliest=-15m | head 5 | table _raw", lim)


def test_projection_keeps_fields_the_spl_created():
    spl = f'index={UR} earliest=-15m | rex field=message "code=(?<code>\\d+)" | eval ms=round(responseTime/1000,1) | rename uri as endpoint | sort - _time'
    out = Redactor(focus="errors").redact_rows([{"code": "500", "ms": "1.2", "endpoint": "/x", "bytes": "9"}], spl)[0]
    assert {"code", "ms", "endpoint"} <= set(out) and "bytes" not in out


def test_raw_rows_are_pattern_guarded_and_capped():
    out = Redactor(raw=True, context="89592").redact_rows([{"_raw": "card 4111111111111111 " + "y" * 3000}], f"index={UR} earliest=-15m | head 5 | table _raw")[0]
    assert "4111111111111111" not in out["_raw"] and "…[+" in out["_raw"]


def test_raw_dropped_without_flag():
    out = Redactor().redact_rows([{"_raw": "secret", "uri": "/x"}], f"index={UR} earliest=-15m | table uri")[0]
    assert "_raw" not in out


def test_format_table_header_once_and_collapses_repeats():
    txt = format_table([{"a": 1, "b": "x"}, {"a": 1, "b": "x"}, {"a": 2, "b": "y"}])
    assert txt.splitlines()[0] == "a | b"
    assert "×2" in txt and txt.strip().endswith("(3 rows)")
    assert format_table([]) == "(0 rows)"


def test_budget_warns_past_soft_limits(tmp_path):
    b = Budget(tmp_path / "run.json")
    assert b.status(b.add(100, 10_000)) == ""
    msg = b.status(b.add(250, 10_000))
    assert "350 rows" in msg and "Aggregate" in msg


def test_helpers():
    assert owning_seals(f"search (index={UR}) OR (index={FR}) earliest=-1h") == {"89592", "81712"}
    assert has_projection(f"index={UR} earliest=-1h | stats count") and not has_projection(f"index={UR} earliest=-1h | sort - _time")
    assert truncate("abc", 5) == "abc" and truncate("abcdef", 3) == "abc…[+3 chars]"


def test_aggregate_outputs_print_clear_but_unmapped_by_fields_still_hash():
    spl = f"index={UR} earliest=-15m | stats count, dc(smCigProfileId) as users, p99(responseTime) as p99 by status, mysteryField"
    out = Redactor().redact_rows([{"status": "500", "mysteryField": "secret", "count": 212, "users": 40, "p99": 1500}], spl)[0]
    assert out["count"] == "212" and out["users"] == "40" and out["p99"] == "1500"
    assert out["mysteryField"] != "secret", "an unmapped group-by field is still hashed"


def test_implicit_count_without_alias_prints_clear():
    out = Redactor().redact_rows([{"uri": "/x", "count": 7}], f"index={UR} earliest=-15m | stats count by uri")[0]
    assert out["count"] == "7"


def test_count_named_field_in_non_aggregate_query_is_still_hashed():
    """Outside an aggregate, a raw field that happens to be called 'count' is just an unmapped field."""
    out = Redactor().redact_rows([{"count": "4242"}], f"index={UR} earliest=-15m | table count")[0]
    assert out["count"] != "4242"



# ------------------------------------------------------------ window edge cases

@pytest.mark.parametrize("earliest", ["0", "1", "@d", "yesterday", "-1mon"])
def test_all_time_or_unparsed_window_is_rejected(lim, earliest):
    with pytest.raises(GuardError, match="cannot tell"):
        check_spl(f"index={UR} earliest={earliest} | stats count", lim)


def test_snap_adds_one_unit_conservatively(lim):
    with pytest.raises(GuardError, match="over the"):
        check_spl(f"index={UR} earliest=-1d@d | stats count", lim)       # up to 48h
    check_spl(f"index={UR} earliest=-12h@h | stats count", lim)          # up to 13h
    check_spl(f"index={UR} earliest=-0d@d | stats count", lim)           # start of today: up to 24h


def test_absolute_window_pair_is_measured(lim):
    check_spl(f'index={UR} earliest="11/07/2026:13:50:00" latest="11/07/2026:14:20:00" | stats count', lim)
    with pytest.raises(GuardError, match="48h"):
        check_spl(f'index={UR} earliest="11/01/2026:00:00:00" latest="11/03/2026:00:00:00" | stats count', lim)


def test_weeks_unit_is_understood(lim):
    with pytest.raises(GuardError, match="336h"):
        check_spl(f"index={UR} earliest=-2w | stats count", lim)


@pytest.mark.parametrize("spl", [f"index=* earliest=-1h | stats count", f"index=*rewards* earliest=-1h | stats count",
                                 f"search index IN (*) earliest=-1h | stats count"])
def test_wildcard_index_rejected(lim, spl):
    with pytest.raises(GuardError, match="every index"):
        check_spl(spl, lim)


def test_confirm_window_unlocks_unparsed_and_wide(lim):
    lim = Limits.from_org(confirm_window=True)
    check_spl(f"index={UR} earliest=-7d | timechart span=1d count", lim)
    check_spl(f"index={UR} earliest=@d | stats count", lim)


# ------------------------------------------------------------ laundering a hashed field under a new name

PROFILE = "1234567890"


def _one(spl, row, context=None):
    return Redactor(context=context, raw=False, focus=None).redact_rows([row], spl)[0]


def test_eval_copy_of_a_hashed_field_stays_hashed():
    out = _one(f"index={UR} earliest=-15m | eval x=smCigProfileId | head 5 | table x, smCigProfileId",
               {"x": PROFILE, "smCigProfileId": PROFILE})
    assert out["x"] != PROFILE and out["x"] == out["smCigProfileId"], "same value, same hash, never clear"


def test_rename_of_a_hashed_field_stays_hashed():
    out = _one(f"index={UR} earliest=-15m | rename smCigProfileId as who | head 5 | table who", {"who": PROFILE})
    assert out["who"] != PROFILE and len(out["who"]) == 12


def test_stats_values_alias_inherits_the_source_rule_but_counts_print_clear():
    spl = f"index={UR} earliest=-15m | stats values(smCigProfileId) as ids, count, dc(smCigProfileId) as people by status"
    out = _one(spl, {"ids": [PROFILE, "222"], "count": "7", "people": "2", "status": "500"})
    assert PROFILE not in out["ids"] and out["count"] == "7" and out["people"] == "2"


def test_unaliased_values_column_is_hashed_too():
    out = _one(f"index={UR} earliest=-15m | stats values(smCigProfileId) by status", {"values(smCigProfileId)": PROFILE, "status": "500"})
    assert out["values(smCigProfileId)"] != PROFILE


def test_rex_from_raw_is_hashed_rex_from_a_clear_text_field_is_clear():
    spl = (f'index={UR} earliest=-15m | rex "profileid=(?<pid>\\d+)" | rex field=message "code=(?<code>\\d+)" '
           f"| eval ms=round(responseTime/1000,1) | rename uri as endpoint | head 5 | table pid, code, ms, endpoint")
    out = _one(spl, {"pid": PROFILE, "code": "500", "ms": "12.5", "endpoint": "/x"})
    assert out["pid"] != PROFILE and out["code"] == "500" and out["ms"] == "12.5" and out["endpoint"] == "/x"


def test_lineage_follows_a_chain_of_renames_and_evals():
    out = _one(f"index={UR} earliest=-15m | eval a=smCigProfileId | eval b=a | rename b as c | head 5 | table c", {"c": PROFILE})
    assert out["c"] != PROFILE


def test_conditional_eval_inherits_the_strictest_branch():
    spl = f'index={UR} earliest=-15m | eval who=if(status>=500, smCigProfileId, "ok"), path=coalesce(uri, "none") | head 5 | table who, path'
    out = _one(spl, {"who": PROFILE, "path": "/x"})
    assert out["who"] != PROFILE and out["path"] == "/x"


def test_owner_field_copied_under_a_new_name_still_needs_the_owner_context():
    spl = f"index={FR} earliest=-15m | eval u=userId | head 5 | table u"
    assert _one(spl, {"u": "jsmith"})["u"] == REDACTED
    assert _one(spl, {"u": "jsmith"}, context="81712")["u"] == "jsmith"


def test_timechart_value_columns_print_clear():
    out = _one(f"index={UR} earliest=-15m | timechart span=5m count by status", {"_time": "t", "500": "3", "200": "9"})
    assert out == {"500": "3", "200": "9"}


def test_builder_text_cut_carries_the_marker_and_drops_the_helper_column():
    spl = (f"index={UR} earliest=-15m | fields message | eval message_len=len(mvindex(message, 0)), "
           f"message=substr(mvindex(message, 0), 1, 20) | head 5 | table _time, message")
    out = Redactor(context=None, raw=False, focus=None).redact_rows([{"message": "a" * 20, "message_len": "533"}, {"message": "short", "message_len": "5"}], spl)
    assert out[0] == {"message": "a" * 20 + "…[+513 chars]"} and out[1] == {"message": "short"}


# ------------------------------------------------------------ noise list vs columns the SPL asked for

def test_metadata_column_named_in_a_by_clause_is_kept_and_clear():
    """'stats count by sourcetype' is the zero-row check every team runs; the noise list must not eat it."""
    out = _one(f"index={UR} earliest=-15m | stats count by sourcetype", {"sourcetype": "wcmur_x", "count": "5"})
    assert out == {"sourcetype": "wcmur_x", "count": "5"}


def test_metadata_columns_not_asked_for_stay_suppressed():
    out = _one(f"index={UR} earliest=-15m | head 5 | table status, uri", {"status": "500", "uri": "/x", "host": "pod-1", "sourcetype": "st", "punct": "x"})
    assert set(out) == {"status", "uri"}


def test_fieldsummary_metadata_is_clear_but_sample_values_are_not():
    out = _one(f"index={UR} earliest=-1m | head 200 | fieldsummary maxvals=0 | where count>0 | table field, count, distinct_count",
               {"field": "smCigProfileId", "count": "200", "distinct_count": "4", "values": "1234567890"})
    assert out["field"] == "smCigProfileId" and out["count"] == "200" and out["values"] != "1234567890"


def test_raw_is_never_kept_by_naming_it_without_the_raw_flag():
    out = _one(f"index={UR} earliest=-15m | head 5 | table _time, _raw", {"_raw": "secret", "_time": "t"})
    assert "_raw" not in out
