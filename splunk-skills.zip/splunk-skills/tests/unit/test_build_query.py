"""build_query.py composes short, correct SPL from fields.yaml roles."""
import re

import pytest

from build_query import BuildError, Builder, around_window, baseline_window, norm_window

UR_ACCESS = "wcmur_cfs_ultimate_rewards_ecs_uraccess_st"
UR_APP = "wcmur_cfs_ultimate_rewards_ecs_ur_st"


def lines(spl):
    return spl.strip().splitlines()


def test_errors_step1_uses_access_log_and_status_role():
    spl, ex = Builder("89592").build(1, "errors")
    assert spl.startswith(f"index=cfs_digital_ultimate_rewards_aws_89592 sourcetype={UR_ACCESS} status>=500 earliest=-15m latest=now")
    assert "| fields - _raw" in spl and "| stats count by status, uri" in spl
    assert len(lines(spl)) <= 8 and len(ex) == 3


def test_high_volume_default_window_is_15m_and_overridable():
    assert "earliest=-15m" in Builder("89592").build(0)[0]
    assert "earliest=-4h" in Builder("89592").build(0, window="4h")[0]
    assert "earliest=-4h" in Builder("89592").build(0, window="-4h")[0]


def test_latency_converts_microseconds():
    spl, ex = Builder("89592").build(1, "latency")
    assert "p99(responseTime)" in spl and "round(p99/1000, 1)" in spl
    assert any("us" in e for e in ex)


def test_latency_ms_field_has_no_conversion():
    spl, _ = Builder("81712").build(1, "latency")
    assert "responseTimeMs" in spl and "/1000" not in spl


def test_step2_prefers_application_log_and_caps_message():
    spl, _ = Builder("89592", prefer="application").build(2)
    assert f"sourcetype={UR_APP}" in spl and "level=ERROR" in spl
    assert "substr(mvindex(message, 0), 1, 300)" in spl
    assert "| head 20" in spl


def test_step3_dedups_and_projects_focus():
    spl, _ = Builder("89592").build(3, "errors")
    assert "| dedup status, uri" in spl
    assert lines(spl)[-1].startswith("| table _time, uri, status")
    assert "| head 20" in spl


def test_step4_picks_sourcetype_that_declares_the_key_and_has_no_error_filter():
    spl, _ = Builder("89592", key="frTraceId").build(4, key="frTraceId", value="abc-7")
    assert f"sourcetype={UR_ACCESS}" in spl and 'frTraceId="abc-7"' in spl
    assert "status>=500" not in spl and "level=ERROR" not in spl
    assert "| sort 0 _time" in spl and "| head 50" in spl


def test_step4_collapse_is_one_row():
    spl, ex = Builder("89592", key="userId").build(4, key="userId", value="x", collapse=True)
    assert "| stats earliest(_time) as start" in spl and "by userId" in spl
    assert "mvindex(messages, 0, 4)" in spl
    assert "one row" in ex[1]


def test_step5_raw_caps_at_five():
    spl, _ = Builder("89592", key="frTraceId").build(5, key="frTraceId", value="a", head=50)
    assert "| head 5" in spl and "| table _time, _raw" in spl


def test_trend_is_sparse_stats_not_timechart():
    spl, _ = Builder("89592").build(1, trend="5m")
    assert "| bin _time span=5m" in spl and "| stats count by _time, status" in spl
    assert "timechart" not in spl


def test_dotted_field_quoting():
    spl, _ = Builder("81712").build(1, "errors")
    assert '"response.statusCode">=500' in spl                  # base search: double quotes
    assert '| stats count by "response.statusCode", uriPath' in spl


def test_missing_role_is_a_clear_error():
    with pytest.raises(BuildError, match="latency"):
        Builder("111863").build(1, "latency")


def test_unknown_seal_and_sourcetype():
    with pytest.raises(BuildError):
        Builder("00000")
    with pytest.raises(BuildError):
        Builder("89592", "nope_st")


def test_baseline_window_shifts_one_week():
    assert baseline_window("-1h") == "earliest=-10140m latest=-10080m"
    assert baseline_window("15m") == "earliest=-10095m latest=-10080m"


def test_around_window_is_centred_absolute():
    w = around_window("2026-11-07 14:05", "30m")
    assert w == 'earliest="11/07/2026:13:50:00" latest="11/07/2026:14:20:00"'
    assert ":13:50:00" in around_window("14:05", "30m")
    with pytest.raises(BuildError):
        around_window("yesterday", "30m")


def test_norm_window():
    assert norm_window("2h") == "-2h" and norm_window("-2h") == "-2h"


def test_every_seal_builds_a_step0():
    from _common import load_seals
    for sid in load_seals():
        spl, _ = Builder(sid).build(0, where="")
        assert spl.startswith(f"index=") and "| stats count" in spl


# ------------------------------------------------------------ funnel: fewer rows, fewer events read

def test_step1_breakdowns_end_at_the_top_rows():
    for kind in ("errors", "volume", "latency"):
        spl, ex = Builder("89592").build(1, kind)
        assert spl.rstrip().endswith("| head 20"), spl
        assert "20" in ex[2]
    spl, _ = Builder("89592").build(1, "errors", head=5)
    assert spl.rstrip().endswith("| head 5")


def test_trend_is_capped_at_60_buckets_with_a_suggested_span():
    with pytest.raises(BuildError, match="use --trend 30m"):
        Builder("89592").build(1, "errors", trend="5m", window="24h")
    spl, _ = Builder("89592").build(1, "errors", trend="30m", window="24h")
    assert "span=30m" in spl


def test_text_cut_ships_the_full_length_for_the_cli_marker():
    spl, _ = Builder("89592", prefer="application").build(2, "errors")
    assert re.search(r"\| eval message_len=len\(mvindex\(message, 0\)\), message=substr\(mvindex\(message, 0\), 1, \d+\)", spl), spl


def test_counts_read_events_unless_the_owner_confirmed_indexed_fields():
    """tstats on a field that is not indexed returns 0 and looks like 'no traffic'; so it is opt-in per environment."""
    spl, _ = Builder("89592", env="prod").build(0, "volume")
    assert spl.startswith("index=") and "| stats count" in spl


def test_confirmed_indexed_environment_counts_from_the_index_summary():
    b = Builder("89592", env="prod")
    b.tstats_ok = True                                   # what fields.yaml `indexed_in: [prod]` sets
    spl, ex = b.build(0, "volume")
    assert spl == f"| tstats count where index={b.index} sourcetype={b.sourcetype} earliest=-15m latest=now"
    assert "no events read" in ex[0]
    spl, _ = b.build(1, "volume")
    assert spl.startswith("| tstats count where") and spl.endswith("| head 20") and " by uri" in spl
    spl, _ = b.build(1, "volume", trend="5m")
    assert "by _time span=5m" in spl
    spl, _ = b.build(1, "errors")                       # a filter (status>=500) still reads events
    assert spl.startswith("index=")
    b2 = Builder("89592", env="test"); b2.tstats_ok = False
    assert Builder("89592", env="test").build(0, "volume")[0].startswith("index=")


def test_indexed_in_from_fields_yaml_switches_on_the_summary(tmp_seal):
    import yaml
    from _common import load_seal
    import build_query
    p = tmp_seal / "seals" / "89592-ur" / "fields.yaml"
    doc = yaml.safe_load(p.read_text())
    st = next(iter(doc["sourcetypes"]))
    doc["sourcetypes"][st]["indexed_in"] = ["prod"]
    p.write_text(yaml.safe_dump(doc, sort_keys=False))
    load_seal.cache_clear() if hasattr(load_seal, "cache_clear") else None
    b = build_query.Builder("89592", sourcetype=st, env="prod")
    assert b.tstats_ok and b.build(0, "volume")[0].startswith("| tstats")
    assert not build_query.Builder("89592", sourcetype=st, env="test").tstats_ok
