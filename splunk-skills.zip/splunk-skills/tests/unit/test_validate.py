"""validate.py must be clean on the shipped tree and must catch each class of mistake."""
import subprocess
import sys

import pytest
import yaml


def run_validate(skill_dir):
    return subprocess.run([sys.executable, str(skill_dir / "scripts" / "validate.py")],
                          capture_output=True, text=True, cwd=skill_dir)


def test_shipped_tree_is_clean(skill):
    r = run_validate(skill)
    assert r.returncode == 0, r.stdout
    assert "0 errors" in r.stdout


def _edit_yaml(path, fn):
    data = yaml.safe_load(path.read_text())
    fn(data)
    path.write_text(yaml.safe_dump(data, sort_keys=False))


@pytest.mark.parametrize("mutation,expected", [
    # fields.yaml protections
    (lambda d: d["sourcetypes"]["wcmur_cfs_ultimate_rewards_ecs_uraccess_st"]["fields"].append(
        {"raw": "ssn", "display": "SSN", "pii": "direct", "visibility": "public", "mask": "none"}),
     "never-list"),
    (lambda d: d["sourcetypes"]["wcmur_cfs_ultimate_rewards_ecs_uraccess_st"]["fields"].append(
        {"raw": "fullName", "display": "Name", "pii": "direct", "visibility": "public", "mask": "none"}),
     "pii: direct but public and unmasked"),
    (lambda d: d.__setitem__("seal", "99999"), "seal '99999' != 89592"),
])
def test_fields_yaml_guards(tmp_seal, mutation, expected):
    _edit_yaml(tmp_seal / "seals" / "89592-ur" / "fields.yaml", mutation)
    r = run_validate(tmp_seal)
    assert r.returncode == 1
    assert expected in r.stdout, r.stdout


def test_link_to_unknown_seal_is_error(tmp_seal):
    _edit_yaml(tmp_seal / "seals" / "89592-ur" / "links.yaml",
               lambda d: d["links"].append({"id": "bogus", "to": "424242", "kind": "user", "status": "confirmed"}))
    r = run_validate(tmp_seal)
    assert "unknown destination seal '424242'" in r.stdout


def test_placeholder_without_verify_query_warns(tmp_seal):
    _edit_yaml(tmp_seal / "seals" / "89592-ur" / "links.yaml",
               lambda d: d["links"].append({"id": "p", "to": "<X>", "kind": "user", "status": "placeholder"}))
    r = run_validate(tmp_seal)
    assert "placeholder without verify_query" in r.stdout


def test_placeholder_destination_requires_placeholder_status(tmp_seal):
    _edit_yaml(tmp_seal / "seals" / "89592-ur" / "links.yaml",
               lambda d: d["links"].append({"id": "p", "to": "<X>", "kind": "user", "status": "confirmed"}))
    r = run_validate(tmp_seal)
    assert "placeholder destination but status is not placeholder" in r.stdout


def test_journey_hop_must_resolve(tmp_seal):
    p = tmp_seal / "journeys" / "ur-sign-in.yaml"
    _edit_yaml(p, lambda d: d["hops"].append({"link": "89592/does-not-exist"}))
    r = run_validate(tmp_seal)
    assert "does not resolve" in r.stdout


def test_journey_name_must_match_filename(tmp_seal):
    p = tmp_seal / "journeys" / "ur-sign-in.yaml"
    _edit_yaml(p, lambda d: d.__setitem__("name", "renamed"))
    r = run_validate(tmp_seal)
    assert "!= filename" in r.stdout


def test_folder_name_must_match_seal_yaml(tmp_seal):
    (tmp_seal / "seals" / "89592-ur").rename(tmp_seal / "seals" / "89592-wrong")
    r = run_validate(tmp_seal)
    assert "folder should be '89592-ur'" in r.stdout


def test_override_must_match_a_core_reference(tmp_seal):
    (tmp_seal / "seals" / "89592-ur" / "overrides" / "not-a-core-file.md").write_text("# x\n")
    r = run_validate(tmp_seal)
    assert "no matching file in core/references/" in r.stdout


def test_override_with_matching_name_is_allowed(tmp_seal):
    (tmp_seal / "seals" / "89592-ur" / "overrides" / "output-format.md").write_text("# UR output\n")
    r = run_validate(tmp_seal)
    assert r.returncode == 0, r.stdout


def test_spl_block_without_time_bound_is_error(tmp_seal):
    q = tmp_seal / "seals" / "89592-ur" / "queries.md"
    q.write_text(q.read_text() + "\n## Bad\n\n```spl\nindex=x | stats count\n```\n")
    r = run_validate(tmp_seal)
    assert "spl block without earliest=" in r.stdout


def test_spl_block_without_index_is_error(tmp_seal):
    q = tmp_seal / "seals" / "89592-ur" / "queries.md"
    q.write_text(q.read_text() + "\n## Bad\n\n```spl\nsourcetype=x earliest=-1h | stats count\n```\n")
    r = run_validate(tmp_seal)
    assert "spl block without index=" in r.stdout


def test_card_number_in_example_is_error(tmp_seal):
    q = tmp_seal / "seals" / "89592-ur" / "notes.md"
    q.write_text(q.read_text() + "\nexample card 4111111111111111\n")
    r = run_validate(tmp_seal)
    assert "possible card number" in r.stdout


def test_org_name_in_core_is_error(tmp_seal):
    p = tmp_seal / "core" / "references" / "triage-ladder.md"
    p.write_text(p.read_text() + "\nThis applies to CCB only.\n")
    r = run_validate(tmp_seal)
    assert "core/ mentions the org name" in r.stdout


def test_instance_host_in_core_is_error(tmp_seal):
    p = tmp_seal / "core" / "references" / "triage-ladder.md"
    p.write_text(p.read_text() + "\nhttps://aws-ccb-prod.prod.aws.jpmchase.net\n")
    r = run_validate(tmp_seal)
    assert "core/ mentions instance host" in r.stdout


def test_new_seal_scaffold_then_validate(tmp_seal):
    r = subprocess.run([sys.executable, str(tmp_seal / "scripts" / "new_seal.py"), "55555", "cashback"],
                       capture_output=True, text=True, cwd=tmp_seal)
    assert r.returncode == 0, r.stdout + r.stderr
    seal_yaml = tmp_seal / "seals" / "55555-cashback" / "seal.yaml"
    assert "55555" in seal_yaml.read_text() and "<SEAL_ID>" not in seal_yaml.read_text()
    r = run_validate(tmp_seal)
    assert r.returncode == 0, "a bare scaffold must validate clean so a team can commit it and fill it in:\n" + r.stdout
