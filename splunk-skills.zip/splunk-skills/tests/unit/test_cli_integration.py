"""splunk_cli.py with a fake splunk_client.py: the integration contract your real module must meet.
Run the same assertions against the real client by pointing SPLUNK_BASE_URL at UAT and dropping
the fake (first-run/check_cli_contract.py does this)."""
import json
import os
import subprocess
import sys
import textwrap

import pytest

FAKE_CLIENT = textwrap.dedent('''
    class AuthError(Exception): ...
    class SearchError(Exception): ...
    CALLS = []
    def login(base_url):
        import os
        if os.environ.get("FAKE_AUTH_FAIL"): raise AuthError("kerberos: no ticket")
        return {"base": base_url}
    def search(session, base_url, spl, max_rows, timeout_s=120):
        import json, os
        log = os.environ.get("FAKE_CALLS")
        if log:
            open(log, "a").write(json.dumps({"spl": spl, "max_rows": max_rows}) + "\\n")
        if "makeresults" in spl: return [{"ok": "1"}]
        if "boom" in spl: raise SearchError("job failed")
        return [{"_time": "t", "_raw": "secret raw", "status": "500", "uri": "/x", "count": 7, "smCigProfileId": "123",
                 "message": "card 4111111111111111 " + "z" * 400}] * 3
''')
PROD = "https://aws-ccb-prod.prod.aws.jpmchase.net:443"
UR = "cfs_digital_ultimate_rewards_aws_89592"


@pytest.fixture
def cli(tmp_seal, tmp_path):
    (tmp_seal / "scripts" / "splunk_client.py").write_text(FAKE_CLIENT)
    calls = tmp_path / "calls.log"
    env = {**os.environ, "SPLUNK_BASE_URL": PROD, "SPLUNK_TRIAGE_DATA": str(tmp_path / "data"), "FAKE_CALLS": str(calls)}

    def run(*args, env_over=None):
        e = {**env, **(env_over or {})}
        return subprocess.run([sys.executable, str(tmp_seal / "scripts" / "splunk_cli.py"), *args],
                              capture_output=True, text=True, cwd=tmp_seal, env=e)
    run.calls = calls
    run.data = tmp_path / "data"
    return run


def test_search_goes_through_guard_client_and_redactor(cli):
    r = cli("search", f"index={UR} earliest=-15m latest=now | stats count by status, uri", "--context", "89592")
    assert r.returncode == 0, r.stderr
    out = r.stdout
    assert "500 (server error)" in out and "| 7" in out and "×3" in out      # decode, aggregate clear, collapse
    assert "secret raw" not in out and "4111111111111111" not in out
    sent = json.loads(cli.calls.read_text().splitlines()[0])
    assert sent["spl"].startswith("search index="), "CLI must prepend 'search' before index="
    assert sent["max_rows"] == 1000
    audit = (cli.data / "audit.log").read_text()
    rec = json.loads(audit.splitlines()[-1])
    assert rec["status"] == "ok" and rec["rows"] == 3 and "spl" not in rec and len(rec["spl_sha256"]) == 64


def test_guard_rejection_sends_nothing(cli):
    r = cli("search", f"index={UR} earliest=-15m | outputlookup x", "--context", "89592")
    assert r.returncode == 3 and "REJECTED" in r.stderr
    assert not cli.calls.exists(), "a rejected query must never reach the client"
    assert json.loads((cli.data / "audit.log").read_text())["status"] == "rejected"


def test_unknown_host_is_refused_before_login(cli):
    r = cli("search", f"index={UR} earliest=-15m | stats count", env_over={"SPLUNK_BASE_URL": "https://evil.example.com:443"})
    assert r.returncode == 6 and "not an instance in org.yaml" in r.stderr
    assert not cli.calls.exists()


def test_auth_failure_exit_4_and_search_failure_exit_5(cli):
    r = cli("search", f"index={UR} earliest=-15m | stats count", env_over={"FAKE_AUTH_FAIL": "1"})
    assert r.returncode == 4 and "sign-in failed" in r.stderr
    r = cli("search", f"index={UR} boom earliest=-15m | stats count")
    assert r.returncode == 5 and "search failed" in r.stderr


def test_json_keeps_time_and_truncates_text(cli):
    r = cli("search", f"index={UR} earliest=-15m | table _time, message", "--json")
    rows = json.loads(r.stdout)
    assert rows[0]["_time"] == "t" and rows[0]["message"].endswith("chars]") and "[redacted]" in rows[0]["message"]


def test_baseline_runs_twice(cli):
    r = cli("search", f"index={UR} earliest=-1h latest=now | stats count", "--baseline")
    assert r.returncode == 0 and "# now" in r.stdout and "# one week earlier" in r.stdout
    assert len(cli.calls.read_text().splitlines()) == 2
    assert "earliest=-10140m latest=-10080m" in cli.calls.read_text()


def test_save_writes_redacted_output_only(cli, tmp_path):
    out = tmp_path / "report.txt"
    cli("search", f"index={UR} earliest=-15m | table status, message", "--save", str(out))
    txt = out.read_text()
    assert "500" in txt and "4111111111111111" not in txt and "secret raw" not in txt


def test_raw_needs_owner_context_through_cli(cli):
    r = cli("search", f"index={UR} earliest=-15m | head 5 | table _time, _raw", "--raw")
    assert r.returncode == 3
    r = cli("search", f"index={UR} earliest=-15m | head 5 | table _time, _raw", "--raw", "--context", "89592")
    assert r.returncode == 0 and "secret raw" in r.stdout


def test_dry_run_prints_plan_without_calling_client(cli):
    r = cli("search", f"index={UR} earliest=-15m | stats count", "--dry-run")
    assert r.returncode == 0 and "DRY RUN" in r.stdout and "search index=" in r.stdout
    assert not cli.calls.exists()


def test_access_check_reports_per_instance(cli):
    r = cli("access-check", "--env", "prod")
    assert "OK" in r.stdout and "aws-ccb-prod" in r.stdout


def test_build_subcommand_delegates(cli):
    r = cli("build", "--seal", "89592", "--step", "0")
    assert r.returncode == 0 and r.stdout.startswith("index=") and "| stats count" in r.stdout


def test_budget_warning_after_many_rows(cli):
    for _ in range(3):
        cli("search", f"index={UR} earliest=-15m | table status", env_over={"SPLUNK_TRIAGE_RUN": "t1"})
    big = FAKE_CLIENT.replace("] * 3", "] * 400")
    (cli.data.parent / "splunk-triage" / "scripts" / "splunk_client.py").write_text(big)
    r = cli("search", f"index={UR} earliest=-15m | table status", env_over={"SPLUNK_TRIAGE_RUN": "t1"})
    assert "budget:" in r.stderr and "Aggregate" in r.stderr


# --- shell- and agent-neutral invocation -------------------------------------------------

def test_base_url_flag_overrides_environment(cli):
    """A Copilot agent on PowerShell cannot prefix a command with VAR=value; the flag must win."""
    r = cli("search", f"index={UR} earliest=-15m | stats count", "--base-url", PROD,
            env_over={"SPLUNK_BASE_URL": "https://evil.example.com:443"})
    assert r.returncode == 0, r.stderr
    rec = json.loads((cli.data / "audit.log").read_text().splitlines()[-1])
    assert rec["host"] == PROD


def test_base_url_flag_is_host_checked_too(cli):
    r = cli("search", f"index={UR} earliest=-15m | stats count", "--base-url", "https://evil.example.com:443")
    assert r.returncode == 6 and not cli.calls.exists()


def test_missing_base_url_points_at_the_flag(cli):
    r = cli("search", f"index={UR} earliest=-15m | stats count", env_over={"SPLUNK_BASE_URL": ""})
    assert r.returncode == 2 and "--base-url" in r.stderr


def test_spl_from_file_with_at_prefix(cli, tmp_path):
    """Quote-heavy SPL can be handed over as @file in any shell; the guard still runs on it."""
    q = tmp_path / "q.spl"
    q.write_text(f'index={UR} earliest=-15m latest=now "response.statusCode">=500 | stats count by status\n')
    r = cli("search", f"@{q}", "--context", "89592")
    assert r.returncode == 0, r.stderr
    assert '"response.statusCode">=500' in json.loads(cli.calls.read_text().splitlines()[0])["spl"]
    q.write_text(f"index={UR} earliest=-15m | outputlookup x\n")
    r = cli("search", f"@{q}")
    assert r.returncode == 3
