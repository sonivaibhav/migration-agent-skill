"""The eval suites and mock CLI must be internally consistent so a grader can run them."""
import json
import os
import subprocess
import sys
import pathlib

import pytest
import yaml

EVALS = pathlib.Path(__file__).resolve().parents[1] / "evals"
LAYERS = ["layer-1-routing", "layer-2-execution", "layer-3-output"]


@pytest.mark.parametrize("layer", LAYERS)
def test_suite_shape(layer):
    suite = yaml.safe_load((EVALS / layer / "test-suite.yaml").read_text())
    assert suite["layer"] == int(layer[6])
    ids = [c["id"] for c in suite["cases"]]
    assert len(ids) == len(set(ids)), "duplicate case ids"
    assert len(ids) >= 10
    for c in suite["cases"]:
        assert c["prompt"].strip()
        assert c["must"] and all(isinstance(m, str) for m in c["must"])
        assert c["must_not"] and all(isinstance(m, str) for m in c["must_not"])
    assert (EVALS / layer / "evaluator-prompt.md").read_text().count("PASS|FAIL") >= 1


@pytest.mark.parametrize("layer", LAYERS)
def test_evaluator_prompt_names_every_output_field(layer):
    text = (EVALS / layer / "evaluator-prompt.md").read_text()
    for key in ("case:", "must:", "must_not:", "verdict:"):
        assert key in text


def test_fixtures_are_valid():
    for fx in (EVALS / "fixtures").glob("*.json"):
        d = json.loads(fx.read_text())
        assert d["match"] and isinstance(d["rows"], list), fx.name


def _mock(*args, env=None):
    return subprocess.run([sys.executable, str(EVALS / "mock_cli.py"), "search", *args],
                          capture_output=True, text=True, env={**os.environ, **(env or {})})


def test_mock_cli_applies_guard(tmp_path):
    log = tmp_path / "calls.log"
    r = _mock("index=cfs_digital_ultimate_rewards_aws_89592 earliest=-1h | outputlookup x", env={"EVAL_CALLS_LOG": str(log)})
    assert r.returncode == 3 and "REJECTED" in r.stderr
    rec = json.loads(log.read_text().splitlines()[-1])
    assert "rejected" in rec


def test_mock_cli_returns_redacted_fixture(tmp_path):
    log = tmp_path / "calls.log"
    spl = 'index=cfs_digauthciam_81712 sourcetype=cfs_digauthciam_ig_lob_aws_access_audit_st transactionId="a1b2-7" earliest=-1h | table transactionId, userId'
    r = _mock(spl, "--json", env={"EVAL_CALLS_LOG": str(log)})
    assert r.returncode == 0, r.stderr
    rows = json.loads(r.stdout)
    assert rows[0]["transactionId"] == "a1b2-7"
    assert rows[0]["userId"] == "[redacted]", "owner-only field must be redacted without --context 81712"
    r2 = _mock(spl, "--json", "--context", "81712", env={"EVAL_CALLS_LOG": str(log)})
    assert json.loads(r2.stdout)[0]["userId"] == "jane.doe"
    assert len(log.read_text().splitlines()) == 2


def test_mock_cli_logs_context_and_flags(tmp_path):
    log = tmp_path / "calls.log"
    _mock("index=cfs_digital_ultimate_rewards_aws_89592 earliest=-1h | stats count", "--context", "89592",
          env={"EVAL_CALLS_LOG": str(log)})
    rec = json.loads(log.read_text())
    assert rec["context"] == "89592" and rec["json"] is False and "rejected" not in rec
