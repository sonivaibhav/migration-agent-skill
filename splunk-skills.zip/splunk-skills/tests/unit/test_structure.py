"""Tree and file-shape invariants. If these fail, the agent's blind reads break."""
import json
import re
import pathlib

import pytest
import yaml

REQUIRED_SEAL_FILES = ["seal.yaml", "fields.yaml", "links.yaml", "alerts.yaml", "notes.md", "queries.md"]
CORE_REFS = ["query-performance.md", "triage-ladder.md", "correlation-method.md", "output-format.md", "data-handling.md"]


def test_skill_md_frontmatter(skill):
    text = (skill / "SKILL.md").read_text()
    fm = text.split("---")[1]
    meta = yaml.safe_load(fm)
    assert meta["name"] == "splunk-triage" == skill.name, "name must equal the folder name"
    assert "rewards-splunk-cli" in meta["description"], "old name must stay discoverable via description"
    assert "splunk" in meta["description"].lower() and "triage" in meta["description"].lower()
    assert len(meta["description"]) < 1100


def test_skill_md_has_no_per_seal_table(skill):
    """SKILL.md must route via resolve.py / registry, never carry an index map."""
    text = (skill / "SKILL.md").read_text()
    assert "cfs_digital_ultimate_rewards_aws_89592" not in text
    assert "rpex_111863" not in text
    assert "resolve.py" in text and "registry.yaml" in text


def test_skill_md_loads_guardrails_first(skill):
    text = (skill / "SKILL.md").read_text()
    assert "core/guardrails.md" in text.split("## 1. Resolve")[0], "guardrails must be referenced before step 1"


def test_skill_md_has_fast_and_full_paths(skill):
    text = (skill / "SKILL.md").read_text()
    assert "Fast path" in text and "Full path" in text
    assert "resolve.py" in text and "build_query.py" in text
    assert len(text.split()) < 1100, "SKILL.md must stay short; move detail to references"


def test_no_incidents_files(seals):
    for sid, s in seals.items():
        assert not (s["dir"] / "incidents.md").exists(), f"{sid}: incidents.md was folded into queries.md provenance"


def test_seal_yaml_has_no_journeys_key(seals):
    for sid, s in seals.items():
        assert "journeys" not in s["seal"], f"{sid}: journeys is derived by build_registry"


def test_core_references_exist(skill):
    for name in CORE_REFS:
        assert (skill / "core" / "references" / name).exists(), name


def test_every_seal_has_fixed_filenames(seals):
    for sid, s in seals.items():
        for f in REQUIRED_SEAL_FILES:
            assert (s["dir"] / f).exists(), f"{s['dir'].name} missing {f}"
        assert (s["dir"] / "overrides").is_dir()


def test_seal_folder_name_matches_manifest(seals):
    for sid, s in seals.items():
        assert s["dir"].name == f"{sid}-{s['seal']['name']}"


def test_template_seal_is_complete(skill):
    t = skill / "seals" / "_template"
    for f in REQUIRED_SEAL_FILES:
        assert (t / f).exists(), f
    assert "<SEAL_ID>" in (t / "seal.yaml").read_text()


def test_schemas_are_valid_json(skill):
    for p in (skill / "core" / "schemas").glob("*.json"):
        json.loads(p.read_text())


def test_registry_is_fresh(skill, registry, seals, journeys):
    assert {s["id"] for s in registry["seals"]} == set(seals)
    assert {j["name"] for j in registry["journeys"]} == set(journeys)
    for rs in registry["seals"]:
        assert rs["dir"] == seals[rs["id"]]["dir"].name


def test_org_yaml_shape(org):
    assert org["org"]
    assert {"max_rows", "max_window_hours", "default_window", "high_volume_window"} <= set(org["limits"])
    groups = {i["group"] for i in org["instances"]}
    for i in org["instances"]:
        assert i["environment"] in {"prod", "test"}
        assert i["url"].startswith("https://")
    assert groups


def test_every_seal_instance_group_exists(seals, org):
    groups = {i["group"] for i in org["instances"]}
    for sid, s in seals.items():
        assert s["seal"]["instance_group"] in groups, sid


def test_core_is_org_neutral(skill, org, seals):
    bad = []
    for p in (skill / "core").rglob("*.md"):
        text = p.read_text()
        if re.search(rf"\b{re.escape(org['org'])}\b", text):
            bad.append(f"{p.name}: org name")
        for inst in org["instances"]:
            if inst["url"] in text:
                bad.append(f"{p.name}: instance host")
        for sid in seals:
            if sid in text:
                bad.append(f"{p.name}: seal {sid}")
    assert not bad, bad


def test_no_docs_folder(skill):
    assert not (skill.parent / "docs").exists()


def test_rename_shim_points_to_new_name(skill):
    shim = skill.parent / "rewards-splunk-cli" / "SKILL.md"
    assert shim.exists()
    assert "splunk-triage" in shim.read_text()


def test_agent_facing_text_is_model_and_shell_neutral(skill):
    """Copilot (GPT or Claude models) and Claude Code all read the same SKILL.md."""
    text = (skill / "SKILL.md").read_text()
    for word in ("SPLUNK_BASE_URL=", "Anthropic", "Claude"):
        assert word not in text, f"SKILL.md must not assume one agent or shell: {word!r}"
    flat = " ".join(text.split())
    if "sub-agent" in flat or "subagent" in flat:
        assert "if your runtime" in flat, "sub-agents may be mentioned only as an option some runtimes have"
    assert "--base-url" in text and "python" in text and "fanout" in text
    for ref in (skill / "core").rglob("*.md"):
        body = ref.read_text()
        assert "SPLUNK_BASE_URL=" not in body and "Claude" not in body, ref
