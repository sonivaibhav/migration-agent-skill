"""resolve.py routing: the agent must land on the right seal(s) and journey without listing seals/."""
import pytest

from resolve import resolve


def seal_ids(res):
    return [s["id"] for s in res["seals"]]


@pytest.mark.parametrize("query,journey,first_seal", [
    ("UR sign-in failures elevated today in prod", "ur-sign-in", "81712"),
    ("users cannot log in to ultimate rewards", "ur-sign-in", "81712"),
    ("CAAS challenge 500s", "ur-sign-in", "81712"),
    ("trace frTraceId abc-123 from UR into ForgeRock", "ur-forgerock-request", "89592"),
    ("gateway timeout 504 on rewards-activity", "ur-forgerock-request", "89592"),
    ("redemption history failing on UR", "ur-redemption-history", "89592"),
    ("cashback order failed for a profile", "ur-cashback-order", "89592"),
    ("statement credit redeem for cash errors", "ur-cashback-order", "89592"),
])
def test_journey_routing(query, journey, first_seal):
    res = resolve(query)
    assert res["journey"] and res["journey"]["name"] == journey, res
    assert seal_ids(res)[0] == first_seal
    assert res["hops"], "a journey must expand to hops"
    for h in res["hops"]:
        assert "error" not in h, h


@pytest.mark.parametrize("query,seal", [
    ("rpex_aws_rbes_st 400s", "111863"),
    ("balance service errors on mobile", "111863"),
    ("cfs_digital_85980 page errors", "85980"),
    ("CXO web telemetry for a profile", "85980"),
    ("DPS gateway 5xx", "88082"),
    ("envoy access latency", "88082"),
    ("WL white label rewards 500s", "89592"),
    ("89592 latency", "89592"),
    ("wcmur_cfs_ultimate_rewards_ecs_uraccess_st", "89592"),
])
def test_seal_routing_by_alias_index_or_sourcetype(query, seal):
    res = resolve(query)
    assert seal in seal_ids(res), res


def test_no_match_is_explicit():
    res = resolve("something entirely unrelated to any application")
    assert not res["seals"] and res["journey"] is None


def test_case_insensitive():
    assert seal_ids(resolve("RPEX")) == seal_ids(resolve("rpex"))


def test_hop_carries_key_and_skew(seals):
    res = resolve("trace frTraceId into ForgeRock")
    hop = res["hops"][0]
    assert hop["link"] == "89592/fr-request"
    assert hop["from"]["field"] == "frTraceId" and hop["to_field"] == "transactionId"
    assert hop["skew_s"] == {"before": 10, "after": 2}
    assert hop["status"] == "confirmed"


def test_placeholder_hop_is_labelled():
    res = resolve("cashback order failed")
    statuses = {h["link"]: h["status"] for h in res["hops"]}
    assert statuses["89592/cashback-order"] == "placeholder"


def test_instances_match_seal_group_and_env(org):
    res = resolve("UR 5xx")
    groups = {s["instance_group"] for s in res["seals"]}
    assert res["instances"] and {i["group"] for i in res["instances"]} <= groups
    assert {i["environment"] for i in res["instances"]} == {"prod"}
    assert {i["environment"] for i in resolve("UR 5xx in uat")["instances"]} == {"test"}


def test_fast_path_prints_a_query_and_reads_nothing():
    res = resolve("Check UR Prod logs for new errors")
    assert res["path"] == "fast" and res["kind"] == "errors" and res["env"] == "prod"
    assert res["first_query"].startswith("index=cfs_digital_ultimate_rewards_aws_89592")
    assert "status>=500" in res["first_query"] and "earliest=-15m" in res["first_query"]
    assert len(res["explain"]) == 3
    assert res["read"] == []


def test_fast_path_latency():
    res = resolve("UR latency looks bad in prod")
    assert res["path"] == "fast" and res["kind"] == "latency"
    assert "p99" in res["first_query"] and "/1000" in res["first_query"], "UR responseTime is microseconds"


def test_fast_path_respects_uat_instance():
    res = resolve("UR 500s in UAT")
    assert res["env"] == "test"
    assert all(i["environment"] == "test" for i in res["instances"]) and res["instances"]


def test_around_time_becomes_absolute_window():
    res = resolve("UR errors at 2:05pm")
    assert res["time"] == {"mode": "around", "clock": "14:05"}
    assert 'earliest="' in res["first_query"] and ":13:50:00" in res["first_query"] and ":14:20:00" in res["first_query"]


def test_since_time_runs_to_now():
    res = resolve("WL 500s since 2pm")
    assert res["time"] == {"mode": "since", "clock": "14:00"}
    assert ':14:00:00" latest=now' in res["first_query"]
    assert "wlaccess" in res["first_query"], "WL must query the WL sourcetype"


def test_app_alias_picks_sourcetype():
    res = resolve("RPEX balance volume")
    assert res["path"] == "fast" and "rpex_aws_rbes_st" in res["first_query"]


def test_registry_first_matching_handles_unknown_text_fast():
    res = resolve("nothing here matches anything at all")
    assert res["path"] == "full" and not res["seals"]


def test_alert_name_wins_and_is_fast():
    res = resolve("UR Prod splunk alert triggered UR Prod 5xx Rate")
    assert res["alert"] and res["alert"]["name"] == "UR Prod 5xx Rate"
    assert res["path"] == "fast" and res["first_query"]
    assert any(n.startswith("Then:") for n in res["notes"])


def test_full_path_read_list_is_minimal():
    res = resolve("users cannot sign in to ultimate rewards")
    assert res["path"] == "full"
    reads = res["read"]
    assert reads[0] == "core/references/triage-ladder.md"
    assert "core/references/correlation-method.md" in reads
    assert sum(1 for r in reads if r.endswith("notes.md")) == 1, "notes.md only for the entry seal"
    assert not any(r.endswith("queries.md") for r in reads), "recipes are listed by title, not read wholesale"
    assert all(s["recipes"] is not None for s in res["seals"])


def test_single_seal_without_standard_query_falls_to_full_with_recipes():
    res = resolve("RPEX balance service slow in UAT")
    assert res["path"] == "full" and res["journey"] is None
    assert any("Latency from MONETA_PERF" in r for r in res["seals"][0]["recipes"])


def test_alias_word_does_not_trigger_a_journey():
    """'RPEX' is both a seal alias and a journey trigger; alone it must not pick the journey."""
    res = resolve("RPEX 500s")
    assert res["journey"] is None and res["seals"][0]["id"] == "111863"
    assert resolve("redemption history failing")["journey"]["name"] == "ur-redemption-history"


def test_forced_journey_flag():
    res = resolve("", journey_name="ur-sign-in")
    assert res["journey"]["name"] == "ur-sign-in"


def test_journey_only_touches_declared_seals(journeys, seals):
    """Every seal a journey touches must be a real seal, and resolve must not add extras."""
    for name in journeys:
        res = resolve("", journey_name=name)
        touched = {h["from_seal"] for h in res["hops"] if "error" not in h}
        touched |= {h["to_seal"] for h in res["hops"] if "error" not in h and not str(h["to_seal"]).startswith("<")}
        assert touched <= set(seal_ids(res)) <= (touched | {journeys[name]["journey"].get("entry")})
        assert seal_ids(res)[0] == journeys[name]["journey"]["entry"], "entry seal is always read first"


def test_high_volume_flag_surfaces():
    res = resolve("CXO web errors")
    assert res["seals"][0]["volume"] == "high"


def test_recipe_word_routes_to_the_recipe_not_a_generic_query():
    res = resolve("UR traffic by region")
    assert res["path"] == "full" and res["recipe"] == "Traffic by region" and res["first_query"] is None
    assert resolve("Which platforms were affected on UR?")["recipe"] == "Traffic by platform"


def test_id_pattern_routes_a_pasted_token():
    res = resolve("A customer sent an error page with trace 0.ab12.4567.cd89")
    assert res["seals"][0]["id"] == "81712" and res["recipe"].startswith("Browser trace token")
    res = resolve("trace 9f3a1c2e-1234-4abc-9def-0123456789ab-7")
    assert res["seals"][0]["id"] == "89592" and res["kind"] == "trace"


def test_generic_word_gateway_does_not_pull_in_forgerock():
    res = resolve("DPS gateway 5xx")
    assert res["path"] == "fast" and [s["id"] for s in res["seals"]] == ["88082"]
    assert "digital_envoy_access_st" in res["first_query"]


def test_render_prints_a_shell_neutral_run_line():
    """The agent copies this line as-is; it must not need VAR=value prefixes (PowerShell has none)."""
    from resolve import render
    text = render(resolve("Check UR Prod logs for new errors"))
    assert "run with: --base-url https://aws-ccb-prod.prod.aws.jpmchase.net:443 --context 89592" in text
    assert "SPLUNK_BASE_URL" not in text


def test_trace_words_beat_error_words_on_a_tie():
    """'why did this profile get 401s' needs an identifier and Step 4, not the fast 5xx query."""
    res = resolve("Why did this profile get repeated 401s on UR?")
    assert res["kind"] == "trace" and res["path"] == "full"


def test_alias_word_does_not_pick_a_recipe():
    """'ForgeRock' is in a recipe title; alone it must not route every ForgeRock question to that recipe."""
    res = resolve("Is the ForgeRock gateway timing out?")
    assert res["recipe"] is None and res["path"] == "fast" and res["kind"] == "latency"


def test_two_apps_of_one_seal_is_not_a_single_app_question():
    res = resolve("Did UR and WL both have errors at 3pm?")
    assert res["path"] == "full" and res["recipe"] == "UR vs WL in one search"
    assert any("Two apps" in n for n in res["notes"])


def test_trace_recipe_needs_a_trace_question_or_an_identifier():
    assert resolve("UR access log 500s")["recipe"] is None                      # 'access' alone must not pick the profile recipe
    assert resolve("UR app log to access log for profile 1234567890")["recipe"] == "App log to access log for one profile"


def test_kind_without_standard_query_falls_back_to_the_kind_recipe():
    res = resolve("RPEX balance service slow in UAT")
    assert res["path"] == "full" and res["recipe"] == "Latency from MONETA_PERF"


def test_every_sample_prompt_routes_as_documented(skill):
    """first-run/SAMPLE-PROMPTS.md promises a path per prompt; the resolver must keep that promise."""
    import re
    text = (skill.parent / "first-run" / "SAMPLE-PROMPTS.md").read_text()
    rows = re.findall(r"^\| `([^`]+)` \| ([^|]+) \| ([^|]+) \|$", text, flags=re.M)
    assert len(rows) >= 20
    for prompt, want, _ in rows:
        q = prompt.replace("<id>", "1234567890").replace("<paste one from step 5>", "0.ab12.4567.cd89")
        if "<" in q:
            continue
        res = resolve(q)
        assert want.strip().startswith(res["path"]), f"{prompt!r}: doc says {want.strip()}, resolver {res['path']}"
        if "RECIPE" in want:
            assert res["recipe"], f"{prompt!r}: doc promises a recipe"
        if "alert" in want:
            assert res["alert"], f"{prompt!r}: doc promises an alert match"


def test_journey_prints_a_ready_fanout_of_step1_per_hop_seal():
    """'Which hop fails' is one CLI call, not N agent turns; it must not depend on the agent runtime."""
    from resolve import render
    res = resolve("users cannot sign in to Ultimate Rewards since 2pm")
    fan = res["fanout"]
    assert fan and fan["kind"] == "errors" and len(fan["queries"]) == 2
    assert {q["label"] for q in fan["queries"]} == {"81712-forgerock", "89592-ur"}
    assert all('earliest="' in q["spl"] and "| head 20" in q["spl"] for q in fan["queries"]), "time clause and top-N carried into every hop"
    text = render(res)
    line = next(l for l in text.splitlines() if "splunk_cli.py fanout" in l)
    assert "--labels 81712-forgerock,89592-ur" in line and line.count("'") == 4 and "\\" not in line, "one pasteable line, no shell continuation"


def test_single_seal_questions_have_no_fanout():
    assert resolve("Check UR Prod logs for new errors")["fanout"] is None
