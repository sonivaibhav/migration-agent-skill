"""Content consistency across seals: join keys, display names, units, and the graph."""
import re

import pytest

from _common import find_link


def all_fields(seal):
    for st, body in (seal["fields"].get("sourcetypes") or {}).items():
        for f in (body or {}).get("fields", []) or []:
            yield st, f


def test_every_seal_has_a_time_field(seals):
    for sid, s in seals.items():
        if not s["fields"].get("sourcetypes"):
            continue
        for st, body in s["fields"]["sourcetypes"].items():
            raws = {f["raw"] for f in body["fields"]}
            assert "_time" in raws, f"{sid}/{st} has no _time"


def test_join_user_fields_map_to_profile_id(seals):
    """Anything tagged join: user must be a Profile ID or a documented identity field."""
    for sid, s in seals.items():
        for st, f in all_fields(s):
            if f.get("join") == "user":
                assert f["pii"] == "indirect", f"{sid}/{st}/{f['raw']} join:user must be pii indirect"
                assert f.get("mask", "hash") == "hash", f"{sid}/{st}/{f['raw']} join:user must hash so it stays joinable"


def test_latency_fields_declare_a_unit(seals):
    for sid, s in seals.items():
        for st, f in all_fields(s):
            if "Latency" in f["display"] or "Duration" in f["display"] or "Elapsed" in f["display"]:
                note = f.get("note", "")
                assert f.get("unit") or "NOT CONFIRMED" in note.upper() or "unit" in note.lower(), \
                    f"{sid}/{st}/{f['raw']} latency without unit"


def test_ur_response_time_is_microseconds(seals):
    ur = seals["89592"]["fields"]["sourcetypes"]["wcmur_cfs_ultimate_rewards_ecs_uraccess_st"]["fields"]
    rt = next(f for f in ur if f["raw"] == "responseTime")
    assert rt["unit"] == "us"


def test_display_name_profile_id_is_consistent(seals):
    """Every field that equals UR smCigProfileId must display as 'Profile ID'."""
    for sid, s in seals.items():
        for st, f in all_fields(s):
            note = f.get("note", "").lower()
            if "equals" in note and "smcigprofileid" in note and f.get("join") == "user" and "{}" not in f["raw"]:
                assert f["display"] == "Profile ID", f"{sid}/{st}/{f['raw']}"


def test_direct_pii_is_never_public_clear(seals):
    for sid, s in seals.items():
        for st, f in all_fields(s):
            if f.get("pii") == "direct":
                assert not (f.get("visibility", "public") == "public" and f.get("mask", "hash") == "none"), \
                    f"{sid}/{st}/{f['raw']} leaks direct PII"


def test_forgerock_sign_in_name_is_owner_only(seals):
    fr = seals["81712"]["fields"]["sourcetypes"]["cfs_digauthciam_ig_lob_aws_access_audit_st"]["fields"]
    uid = next(f for f in fr if f["raw"] == "userId")
    assert uid["pii"] == "direct" and uid["visibility"] == "owner"


def test_links_point_at_sourcetypes_the_destination_declares(seals):
    for sid, s in seals.items():
        for link in s["links"]["links"]:
            to = str(link["to"])
            if to.startswith("<") or to not in seals:
                continue
            if link.get("to_sourcetype"):
                declared = {st["name"] for i in seals[to]["seal"]["indexes"] for st in i["sourcetypes"]}
                assert link["to_sourcetype"] in declared, f"{sid}/{link['id']} -> {to}: {link['to_sourcetype']} not declared by {to}"


def test_links_from_field_exists_in_source_fields(seals):
    for sid, s in seals.items():
        raws = {f["raw"] for _, f in all_fields(s)}
        for link in s["links"]["links"]:
            frm = link.get("from")
            if frm:
                assert frm["field"] in raws, f"{sid}/{link['id']}: from.field {frm['field']} not in fields.yaml"


def test_request_links_have_skew(seals):
    for sid, s in seals.items():
        for link in s["links"]["links"]:
            if link["kind"] == "request" and link["status"] == "confirmed":
                assert link.get("skew_s"), f"{sid}/{link['id']} confirmed request link needs skew_s"


def test_window_links_have_no_false_key(seals):
    for sid, s in seals.items():
        for link in s["links"]["links"]:
            if link["kind"] == "window":
                assert not link.get("skew_s"), f"{sid}/{link['id']}: window links compare windows; no skew"


def test_ur_rpex_is_window_not_request(seals):
    """The cross-index tests proved 0 shared traceIds; the edge must say so."""
    link = find_link(seals, "89592/rpex-redemption-history")
    assert link["kind"] == "window"


def test_every_journey_has_an_entry_seal_that_exists(journeys, seals):
    for name, j in journeys.items():
        assert j["journey"]["entry"] in seals, name


def test_every_journey_trigger_is_lowercase_matchable(journeys):
    for name, j in journeys.items():
        for t in j["journey"]["triggers"]:
            assert isinstance(t, str) and t.strip(), f"{name}: bad trigger {t!r}"


def test_queries_md_every_spl_has_window_and_index(seals):
    block = re.compile(r"```spl\n(.*?)```", re.S)
    for sid, s in seals.items():
        text = (s["dir"] / "queries.md").read_text()
        for b in block.findall(text):
            assert "earliest=" in b, f"{sid} queries.md block without earliest"
            assert "index=" in b or "index IN" in b, f"{sid} queries.md block without index"


def test_queries_md_event_lists_end_with_head_and_table(seals):
    """A query that lists events must cap rows; otherwise _raw rides along and the cap bites silently."""
    block = re.compile(r"```spl\n(.*?)```", re.S)
    agg = re.compile(r"\|\s*(stats|timechart|chart|top|rare|eventstats)\b")
    for sid, s in seals.items():
        for b in block.findall((s["dir"] / "queries.md").read_text()):
            if agg.search(b):
                continue
            assert "| head" in b, f"{sid}: event-listing query without | head:\n{b[:120]}"
            assert "| table" in b, f"{sid}: event-listing query without | table:\n{b[:120]}"


def test_no_transaction_command_anywhere(skill):
    for p in skill.rglob("*.md"):
        for b in re.findall(r"```spl\n(.*?)```", p.read_text(), re.S):
            assert not re.search(r"\|\s*transaction\b", b), f"{p}: transaction is banned"


def test_no_tstats_anywhere(skill):
    for p in skill.rglob("*.md"):
        for b in re.findall(r"```spl\n(.*?)```", p.read_text(), re.S):
            assert not re.search(r"\|\s*tstats\b", b), f"{p}: tstats is banned"


def test_multi_index_queries_start_with_search(skill):
    """A query with two index= clauses must start with 'search' or the CLI breaks on the leading paren."""
    for p in skill.rglob("queries.md"):
        for b in re.findall(r"```spl\n(.*?)```", p.read_text(), re.S):
            if b.count("index=") >= 2 or b.lstrip().startswith("("):
                assert b.lstrip().startswith("search"), f"{p}:\n{b[:100]}"


def test_caas_sourcetype_typo_is_preserved(seals):
    """The real Splunk name has one 'c'. A 'corrected' spelling returns nothing."""
    fr = {st["name"] for i in seals["81712"]["seal"]["indexes"] for st in i["sourcetypes"]}
    assert "cfs_digauthciam_ig_aws_acess_audit_st" in fr
    assert "cfs_digauthciam_ig_aws_access_audit_st" not in fr


def test_ur_access_sourcetypes_have_no_underscore_before_access(seals):
    ur = {st["name"] for i in seals["89592"]["seal"]["indexes"] for st in i["sourcetypes"] if st.get("status") == "active"}
    assert "wcmur_cfs_ultimate_rewards_ecs_uraccess_st" in ur
    assert "wcmur_cfs_ultimate_rewards_ecs_wlaccess_st" in ur
    assert not any("_access_st" in s for s in ur)


def test_high_volume_seals_default_to_short_window_in_queries(seals):
    """A seal marked volume: high should not ship a Step-1 starter wider than 1h."""
    for sid, s in seals.items():
        if s["seal"]["volume"] != "high":
            continue
        text = (s["dir"] / "queries.md").read_text()
        for b in re.findall(r"```spl\n(.*?)```", text, re.S):
            e = re.search(r"earliest=-(\d+)([hd])", b)
            l = re.search(r"latest=-(\d+)([hd])", b)
            if not e:
                continue
            hours = int(e.group(1)) * (24 if e.group(2) == "d" else 1)
            if l:  # a baseline slice like -169h..-168h is 1h wide
                hours -= int(l.group(1)) * (24 if l.group(2) == "d" else 1)
            assert hours <= 24, f"{sid}: shipped SPL wider than 24h:\n{b[:100]}"


def test_queries_md_has_index_table_and_few_recipes(seals):
    for sid, s in seals.items():
        text = (s["dir"] / "queries.md").read_text()
        assert "| Recipe | Use when |" in text, f"{sid}: recipes need the index table at the top"
        n = len(re.findall(r"^## ", text, re.M))
        assert n <= 8, f"{sid}: {n} recipes; standard shapes belong in build_query.py"
        assert "build_query.py" in text, f"{sid}: point to the builder for standard questions"


def test_shipped_spl_is_short(skill):
    for p in skill.rglob("queries.md"):
        for b in re.findall(r"```spl\n(.*?)```", p.read_text(), re.S):
            assert len(b.strip().splitlines()) <= 10, f"{p.name}: a recipe over 10 lines is hard to trust:\n{b[:80]}"


def test_every_active_sourcetype_has_roles_or_is_unmapped(seals):
    for sid, s in seals.items():
        sts = (s["fields"] or {}).get("sourcetypes") or {}
        for i in s["seal"]["indexes"]:
            for st in i["sourcetypes"]:
                if st.get("status", "active") != "active":
                    continue
                body = sts.get(st["name"])
                assert body is not None, f"{sid}: active sourcetype {st['name']} has no fields.yaml entry"
                assert body.get("roles"), f"{sid}/{st['name']}: roles missing; build_query cannot compose"


def test_roles_name_declared_fields(seals):
    for sid, s in seals.items():
        for st, body in ((s["fields"] or {}).get("sourcetypes") or {}).items():
            declared = {f["raw"] for f in body.get("fields", [])}
            for role, fld in (body.get("roles") or {}).items():
                assert fld.strip('"') in declared, f"{sid}/{st}: role {role}={fld} not declared"


def test_alerts_yaml_shape(seals):
    for sid, s in seals.items():
        al = s["alerts"]
        assert al["seal"] == sid
        for a in al["alerts"]:
            assert a["name"] and a["means"] and a["kind"] in ("errors", "latency", "volume", "custom")


def test_ur_has_a_platform_decode(seals):
    ur = seals["89592"]["fields"]["sourcetypes"]["wcmur_cfs_ultimate_rewards_ecs_uraccess_st"]["fields"]
    f = next(x for x in ur if x["raw"] == "authInfo")
    assert f["decode"]["C30"] == "Web" and f["display"] == "Platform"


def test_text_fields_have_caps(seals):
    for sid, s in seals.items():
        for st, body in ((s["fields"] or {}).get("sourcetypes") or {}).items():
            for f in body.get("fields", []):
                if f["raw"] in ("message", "message.log.message"):
                    assert f.get("text") and f.get("max_chars"), f"{sid}/{st}/{f['raw']} needs text: true and max_chars"
