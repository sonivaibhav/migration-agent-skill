"""onboard_seal.py drafts a valid, scored seal from an answers file; setup.py links and validates."""
import subprocess
import sys

import yaml

ANSWERS = {
    "id": "55555", "name": "cashback",
    "description": "Cashback redemption service; places statement-credit orders for UR",
    "aliases": "Cashback, cash back, statement credit",
    "index": "cfs_cashback_55555",
    "sourcetypes": "cashback_api_access_st:access, cashback_api_app_st:application",
    "instance_group": "CCB", "owners": "Cashback team", "volume": "medium",
    "repos": "ssh://git@bitbucketdc/wcmrt/cashback-api.git",
    "fields": "field count\n_time 500\nuri 500\nstatus 500\nresponseTimeMs 500\nprofileId 480\nfrTraceId 470\n"
              "customerName 120\ncardNumber 3\nmessage 500\nuserAgent 500\norderAmount 200\npodName 500\n",
    "downstream": "88082:frTraceId",
    "alerts": "Cashback Prod 5xx Rate, Cashback Order Latency p99",
}


def run(tmp_seal, *args):
    return subprocess.run([sys.executable, str(tmp_seal / "scripts" / args[0]), *args[1:]],
                          capture_output=True, text=True, cwd=tmp_seal)


def test_onboard_from_answers_is_valid_and_scored(tmp_seal, tmp_path):
    ans = tmp_path / "a.yaml"
    ans.write_text(yaml.safe_dump(ANSWERS))
    r = run(tmp_seal, "onboard_seal.py", "--answers", str(ans))
    assert r.returncode == 0, r.stdout + r.stderr
    assert "created seals/55555-cashback/" in r.stdout
    assert "0 errors" in r.stdout, r.stdout
    assert "55555 55555-cashback" in r.stdout and "/100" in r.stdout

    d = tmp_seal / "seals" / "55555-cashback"
    fields = yaml.safe_load((d / "fields.yaml").read_text())
    st = fields["sourcetypes"]["cashback_api_access_st"]
    roles = st["roles"]
    assert roles["status"] == "status" and roles["endpoint"] == "uri" and roles["latency"] == "responseTimeMs"
    assert roles["id"] == "profileId" and roles["trace"] == "frTraceId"
    by_raw = {f["raw"]: f for f in st["fields"]}
    assert by_raw["cardNumber"]["visibility"] == "never"
    assert by_raw["customerName"]["pii"] == "direct" and by_raw["customerName"]["visibility"] == "owner"
    assert by_raw["profileId"]["mask"] == "hash"
    assert by_raw["message"]["text"] is True and by_raw["message"]["max_chars"] == 300
    assert by_raw["uri"]["pii"] == "none"
    assert "UNIT NOT CONFIRMED" in by_raw["responseTimeMs"]["note"]
    assert "errors" in fields["focus"] and "latency" in fields["focus"]

    links = yaml.safe_load((d / "links.yaml").read_text())["links"]
    assert links[0]["to"] == "88082" and links[0]["status"] == "placeholder" and "verify_query" in links[0]
    alerts = yaml.safe_load((d / "alerts.yaml").read_text())["alerts"]
    assert {a["kind"] for a in alerts} == {"errors", "latency"}
    assert "check" in (d / "fields.yaml").read_text()


def test_onboarded_seal_routes_fast(tmp_seal, tmp_path):
    ans = tmp_path / "a.yaml"
    ans.write_text(yaml.safe_dump(ANSWERS))
    run(tmp_seal, "onboard_seal.py", "--answers", str(ans))
    r = run(tmp_seal, "resolve.py", "cashback 5xx in prod")
    assert r.stdout.startswith("PATH: fast") and "55555" in r.stdout
    r = run(tmp_seal, "resolve.py", "cashback order failed for a profile")
    assert "JOURNEY: ur-cashback-order" in r.stdout


def test_onboard_rejects_duplicate(tmp_seal, tmp_path):
    ans = tmp_path / "a.yaml"
    ans.write_text(yaml.safe_dump({**ANSWERS, "id": "89592", "name": "ur"}))
    r = run(tmp_seal, "onboard_seal.py", "--answers", str(ans))
    assert r.returncode != 0 and "already exists" in (r.stdout + r.stderr)


def test_onboard_template_and_fieldsummary(tmp_seal):
    r = run(tmp_seal, "onboard_seal.py", "--print-template")
    assert "id:" in r.stdout and "sourcetypes:" in r.stdout
    r = run(tmp_seal, "onboard_seal.py", "--fieldsummary", "idx", "st")
    assert "fieldsummary" in r.stdout and "earliest=-5m" in r.stdout


def test_setup_links_and_validates(tmp_seal, tmp_path):
    skills = tmp_path / "skills"
    r = run(tmp_seal, "setup.py", "--yes", "--skills-dir", str(skills))
    assert (skills / "splunk-triage").is_symlink() or (skills / "splunk-triage").is_dir()
    assert "seal files validate" in r.stdout
    assert "Try:" in r.stdout
    # the stub CLI is reported as a FIX, not hidden
    assert "SPL-only" in r.stdout


def test_validate_score_runs_for_all(skill):
    r = subprocess.run([sys.executable, str(skill / "scripts" / "validate.py"), "--score"], capture_output=True, text=True, cwd=skill)
    assert r.returncode == 0
    assert r.stdout.count("/100") == 5
