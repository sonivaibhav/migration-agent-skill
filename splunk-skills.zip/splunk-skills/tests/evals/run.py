#!/usr/bin/env python3
"""Minimal eval runner. Hands each case to an agent command you supply, collects the transcript
and the mock CLI call log, and writes one grading packet per case for a grader model.

    python3 tests/evals/run.py --layer 1 --cmd "copilot -p '{prompt}'" --out /tmp/evals
    python3 tests/evals/run.py --layer 2 --list           # just print the cases

{prompt} is replaced with the case prompt. Put tests/evals/mock_cli.py on PATH as splunk_cli.py
(or point the skill's SKILLS_DIR at a copy where scripts/splunk_cli.py is the mock) so the agent
runs against canned data. The packet is: case YAML + transcript + calls.jsonl; feed it with the
layer's evaluator-prompt.md to the grader and keep its verdict next to the packet.
"""
from __future__ import annotations

import argparse
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
LAYERS = {1: "layer-1-routing", 2: "layer-2-execution", 3: "layer-3-output"}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--layer", type=int, required=True, choices=LAYERS)
    ap.add_argument("--cmd", help="agent command with {prompt}")
    ap.add_argument("--out", default="/tmp/splunk-triage-evals")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--only", help="case id")
    a = ap.parse_args()
    layer = HERE / LAYERS[a.layer]
    suite = yaml.safe_load((layer / "test-suite.yaml").read_text())
    cases = [c for c in suite["cases"] if not a.only or c["id"] == a.only]
    if a.list or not a.cmd:
        for c in cases:
            print(f"{c['id']:<34} {c['prompt']}")
        if not a.cmd:
            print("\n(pass --cmd to run them)")
        return 0
    out = Path(a.out) / LAYERS[a.layer]
    out.mkdir(parents=True, exist_ok=True)
    grader = (layer / "evaluator-prompt.md").read_text()
    for c in cases:
        pdir = out / c["id"]
        pdir.mkdir(exist_ok=True)
        calls = pdir / "calls.jsonl"
        calls.unlink(missing_ok=True)
        env = {**os.environ, "EVAL_CALLS_LOG": str(calls)}
        cmd = a.cmd.replace("{prompt}", shlex.quote(c["prompt"]))
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, env=env)
        (pdir / "transcript.txt").write_text(r.stdout + ("\n--- stderr ---\n" + r.stderr if r.stderr else ""))
        (pdir / "case.yaml").write_text(yaml.safe_dump(c, sort_keys=False))
        (pdir / "grader-input.md").write_text(grader + "\n\n---\n\n# Case\n\n" + yaml.safe_dump(c, sort_keys=False)
                                              + "\n# Transcript\n\n" + (pdir / "transcript.txt").read_text()
                                              + "\n# CLI calls\n\n" + (calls.read_text() if calls.exists() else "(none)"))
        print(f"{c['id']:<34} exit {r.returncode}  → {pdir}")
    print(f"\nPackets in {out}. Grade each grader-input.md with a model; the verdict format is at the top of the file.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
