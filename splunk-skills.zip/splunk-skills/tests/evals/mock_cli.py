#!/usr/bin/env python3
"""Mock splunk_cli.py for evals. Same argv as the real CLI, same guard layer,
canned rows from fixtures/<name>.json chosen by substring match on the SPL."""
import argparse, json, os, sys, pathlib
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "splunk-triage" / "scripts"))
from guard import GuardError, Limits, Redactor, check_spl, format_table

ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
s = sub.add_parser("search"); s.add_argument("spl"); s.add_argument("--base-url"); s.add_argument("--context"); s.add_argument("--json", action="store_true")
s.add_argument("--max-results", type=int); s.add_argument("--confirm-window", action="store_true"); s.add_argument("--save")
s.add_argument("--focus"); s.add_argument("--raw", action="store_true"); s.add_argument("--baseline", action="store_true")
f = sub.add_parser("fanout"); f.add_argument("spl", nargs="+"); f.add_argument("--labels"); f.add_argument("--base-url"); f.add_argument("--context")
f.add_argument("--json", action="store_true"); f.add_argument("--max-results", type=int); f.add_argument("--confirm-window", action="store_true")
f.add_argument("--save"); f.add_argument("--focus")
a = ap.parse_args()
spls = a.spl if isinstance(a.spl, list) else [a.spl]
spls = [pathlib.Path(s[1:]).read_text(encoding="utf-8").strip() if s.startswith("@") and len(s) > 1 else s for s in spls]  # same @file convention
a.raw = getattr(a, "raw", False)

log = os.environ.get("EVAL_CALLS_LOG")


def one(spl, label=None):
    rec = {"cmd": a.cmd, "label": label, "spl": spl, "context": a.context, "json": a.json, "max_results": a.max_results,
           "confirm_window": a.confirm_window, "save": a.save}
    lim = Limits.from_org(confirm_window=a.confirm_window, max_results=a.max_results, raw=a.raw, context=a.context)
    check_spl(spl, lim)                                   # raises GuardError
    rows = []
    for fx in sorted((HERE / "fixtures").glob("*.json")):
        d = json.loads(fx.read_text())
        if all(tok in spl for tok in d["match"]):
            rows = d["rows"]; rec["fixture"] = fx.name; break
    rows = Redactor(context=a.context, raw=a.raw, focus=a.focus).redact_rows(rows, spl, json_mode=a.json)
    if log: open(log, "a").write(json.dumps(rec) + "\n")
    return rows


if a.cmd == "fanout":
    labels = a.labels.split(",") if a.labels else [f"q{i + 1}" for i in range(len(spls))]
    try:
        for s in spls:                                    # all or nothing, like the real CLI
            check_spl(s, Limits.from_org(confirm_window=a.confirm_window, max_results=a.max_results, raw=False, context=a.context))
    except GuardError as e:
        print(f"REJECTED: {e}", file=sys.stderr); sys.exit(3)
    results = {lab: one(s, lab) for lab, s in zip(labels, spls)}
    if a.json:
        print(json.dumps({lab: {"rows": r, "cut_at_cap": False, "seconds": 0.1} for lab, r in results.items()}, indent=1))
    else:
        print(f"{len(results)}/{len(spls)} queries in 0.3s wall, 3 at a time")
        for lab, r in results.items():
            print(f"\n# {lab}  ({len(r)} rows, 0.1s)\n{format_table(r)}")
    sys.exit(0)

a.spl = spls[0]
try:
    rows = one(a.spl)
except GuardError as e:
    if log: open(log, "a").write(json.dumps({"cmd": "search", "spl": a.spl, "context": a.context, "rejected": str(e)}) + "\n")
    print(f"REJECTED: {e}", file=sys.stderr); sys.exit(3)
print(json.dumps(rows, indent=1) if a.json else format_table(rows))
