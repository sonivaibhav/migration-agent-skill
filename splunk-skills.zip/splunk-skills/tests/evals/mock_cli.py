#!/usr/bin/env python3
"""Mock splunk_cli.py for evals. Same argv as the real CLI, same guard layer,
canned rows from fixtures/<name>.json chosen by substring match on the SPL."""
import argparse, json, os, sys, pathlib
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "splunk-triage" / "scripts"))
from guard import GuardError, Limits, Redactor, check_spl, format_table

ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
s = sub.add_parser("search"); s.add_argument("spl"); s.add_argument("--base-url"); s.add_argument("--context"); s.add_argument("--json", action="store_true")
s.add_argument("--max-results", type=int); s.add_argument("--confirm-window", action="store_true"); s.add_argument("--save")
s.add_argument("--focus"); s.add_argument("--raw", action="store_true"); s.add_argument("--baseline", action="store_true")
a = ap.parse_args()
if a.spl.startswith("@") and len(a.spl) > 1:  # same @file convention as the real CLI
    a.spl = pathlib.Path(a.spl[1:]).read_text(encoding="utf-8").strip()

log = os.environ.get("EVAL_CALLS_LOG")
rec = {"spl": a.spl, "context": a.context, "json": a.json, "max_results": a.max_results, "confirm_window": a.confirm_window, "save": a.save}
try:
    lim = Limits.from_org(confirm_window=a.confirm_window, max_results=a.max_results, raw=a.raw, context=a.context)
    check_spl(a.spl, lim)
except GuardError as e:
    rec["rejected"] = str(e)
    if log: open(log, "a").write(json.dumps(rec) + "\n")
    print(f"REJECTED: {e}", file=sys.stderr); sys.exit(3)

rows = []
for fx in sorted((HERE / "fixtures").glob("*.json")):
    d = json.loads(fx.read_text())
    if all(tok in a.spl for tok in d["match"]):
        rows = d["rows"]; rec["fixture"] = fx.name; break
rows = Redactor(context=a.context, raw=a.raw, focus=a.focus).redact_rows(rows, a.spl, json_mode=a.json)
if log: open(log, "a").write(json.dumps(rec) + "\n")
print(json.dumps(rows, indent=1) if a.json else format_table(rows))
