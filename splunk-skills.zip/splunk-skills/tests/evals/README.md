# Agent evals

Three layers, each a `test-suite.yaml` of cases and an `evaluator-prompt.md`
that a grader model applies to the transcript. Cases run the skill against a
mocked CLI (`mock_cli.py`) that records every call and returns canned rows, so
no Splunk access is needed and prod data is never touched.

| Layer | Tests | Pass bar |
|---|---|---|
| 1 routing | Did the agent call `resolve.py` first, follow `PATH: fast` without opening seal files, match alerts by name, read only the listed files on `PATH: full`, and never list `seals/`? | Every `must` true; no `must_not` tripped |
| 2 execution | Did it start at the right ladder step, use the hop's key and skew, pass `--context`, aggregate on high-volume seals, stop at a guard rejection, and ask before >24h? | Same |
| 3 output | Does the report follow output-format: plain Summary, Impact, Severity word, Findings with display names, SPL with time bounds, no raw field names or clear PII, caveat on placeholders? | Same |

Run: `python3 tests/evals/run.py --layer 1 --cmd "copilot -p '{prompt}'"` — any agent
CLI that takes a prompt works (`claude -p '{prompt}'`, a Copilot or codex CLI); `run.py`
loops over the cases, saves each transcript with the mock CLI's call log, and writes a
grading packet. Grade the packets with whichever model you trust; the verdict format is
at the top of each `grader-input.md`.

Mock CLI contract: `mock_cli.py search '<SPL>' [--base-url U] [--context X] [--json]` writes the
call to `$EVAL_CALLS_LOG` as JSON and prints the rows for the matching fixture
in `fixtures/`. It applies `scripts/guard.py` exactly like the real CLI, so a
rejected query exits 3 with the guard message.
