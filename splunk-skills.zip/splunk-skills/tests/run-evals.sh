#!/usr/bin/env bash
# Unit + security run locally and in CI. The three agent eval layers need a
# model harness; wire your runner to tests/evals/<layer>/test-suite.yaml with
# EVAL_CALLS_LOG set and PATH pointing at tests/evals/mock_cli.py as splunk_cli.py.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 splunk-triage/scripts/validate.py
python3 splunk-triage/scripts/build_registry.py >/dev/null
git diff --quiet -- splunk-triage/registry.yaml 2>/dev/null || { echo "registry.yaml is stale; commit the regenerated file"; exit 1; }
python3 -m pytest -q tests
