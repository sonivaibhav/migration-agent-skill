import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
SKILL = ROOT / "splunk-triage"
sys.path.insert(0, str(SKILL / "scripts"))

import pytest
import yaml


@pytest.fixture(scope="session")
def skill():
    return SKILL


@pytest.fixture(scope="session")
def seals():
    from _common import load_seals
    return load_seals()


@pytest.fixture(scope="session")
def journeys():
    from _common import load_journeys
    return load_journeys()


@pytest.fixture(scope="session")
def registry():
    return yaml.safe_load((SKILL / "registry.yaml").read_text())


@pytest.fixture(scope="session")
def org():
    return yaml.safe_load((SKILL / "org.yaml").read_text())


@pytest.fixture
def tmp_seal(tmp_path, monkeypatch):
    """Copy seals/ and journeys/ to tmp so a test can mutate them, and point
    _common at the copy. Returns the tmp seals dir."""
    import shutil, _common
    dst = tmp_path / "splunk-triage"
    shutil.copytree(SKILL, dst, ignore=shutil.ignore_patterns("__pycache__"))
    monkeypatch.setattr(_common, "SKILL_DIR", dst)
    monkeypatch.setattr(_common, "SEALS_DIR", dst / "seals")
    monkeypatch.setattr(_common, "JOURNEYS_DIR", dst / "journeys")
    monkeypatch.setattr(_common, "REGISTRY", dst / "registry.yaml")
    monkeypatch.setattr(_common, "ORG", dst / "org.yaml")
    return dst
