---
name: rewards-splunk-cli
description: >-
  Renamed. This skill is now splunk-triage. Kept for one release so existing
  links keep working. Use /splunk-triage for production triage across UR, WL,
  RPEX, ForgeRock/CAAS and other CCB seals.
---

# rewards-splunk-cli → splunk-triage

This skill was renamed to `splunk-triage`. Do not run searches from here.

Tell the user:

> `rewards-splunk-cli` is now `splunk-triage`. Run
> `python3 <repo>/splunk-triage/scripts/setup.py` to update your
> link, then use `/splunk-triage …`.

Then continue the request with the `splunk-triage` skill if it is loaded.
