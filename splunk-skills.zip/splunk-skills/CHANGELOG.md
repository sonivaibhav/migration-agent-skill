# Changelog

## 0.1.0 — 2026-11-07

First release of `splunk-triage` (replaces `rewards-splunk-cli`).

- One folder per seal (`seal.yaml`, `fields.yaml`, `links.yaml`, `alerts.yaml`, `notes.md`, `queries.md`);
  journeys chain seals; `core/` holds every rule once and stays org-neutral.
- `resolve.py`: fast path for single-seal standard questions and known alerts (first query printed,
  no seal files read); full path with hops, keys and skew; alias-aware journey matching; app aliases
  pick the sourcetype; recipe titles and pasted identifier shapes route to the right place (alias and
  kind words never pick a recipe; identifier recipes need a trace question or a pasted id; two apps
  of one seal compare rather than merge; trace words win ties over error words); a `FANOUT` line
  for every journey; the run line carries `--base-url` and `--context`.
- `build_query.py`: ladder steps 0–5 composed from `fields.yaml` roles; `--trend` (≤ 60 buckets),
  `--baseline`, `--around`, `--since`, `--collapse`, `--app`, `--env`; breakdowns end at `top_rows`;
  text cut on the indexers with the length shipped for the CLI's marker; pure counts from the index
  summary where a sourcetype's `indexed_in` lists the environment; three plain lines per query.
- `guard.py`: created fields inherit the rules of their sources (`eval x=profileId`, `rename`, `stats
  values(...) as`, `rex` all stay hashed); relative-to-relative windows measured by width; a gated
  leading `| tstats` (index summary, no data models). Read-only allowlist, bounded windows (relative, absolute, snaps, all-time refused),
  `index=*` refused, redaction with visibility/owner context, per-run salted hashing, text truncation
  with a visible marker, projection to the seal's focus, decodes, row collapse, budget warning,
  `--raw` limited to five rows with the owning seal's context.
- `splunk_cli.py`: complete; needs only `splunk_client.py` with `login()` and `search()`. Dry-run,
  baseline, access-check, host allowlist, audit log, exit codes. `fanout` runs several guarded
  searches in one call, `limits.max_concurrent_searches` at a time; the resolver prints a ready
  fan-out (Step 1 per hop) for every journey. Every setting is a flag
  (`--base-url`, `--context`), and `@file` passes quote-heavy SPL, so the same command line works
  from Copilot (GPT or Claude models) or Claude Code on bash, zsh, PowerShell and cmd.
- `onboard_seal.py`: questions or an answers file → all six files drafted with `check` marks,
  PII and role heuristics, placeholder links, alerts, completeness score.
- `setup.py`: one command. `first-run/`: plan, CLI integration guide, facts to validate, sample prompts,
  live contract check.
- Tests: unit, security (guard contract), CLI integration with a fake client, agent eval suites
  with a mocked CLI.
