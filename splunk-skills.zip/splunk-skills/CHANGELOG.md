# Changelog

## 0.1.0 — 2026-11-07

First release of `splunk-triage` (replaces `rewards-splunk-cli`).

- One folder per seal (`seal.yaml`, `fields.yaml`, `links.yaml`, `alerts.yaml`, `notes.md`, `queries.md`);
  journeys chain seals; `core/` holds every rule once and stays org-neutral.
- `resolve.py`: fast path for single-seal standard questions and known alerts (first query printed,
  no seal files read); full path with hops, keys and skew; alias-aware journey matching; app aliases
  pick the sourcetype; recipe titles and pasted identifier shapes route to the right place.
- `build_query.py`: ladder steps 0–5 composed from `fields.yaml` roles; `--trend`, `--baseline`,
  `--around`, `--since`, `--collapse`, `--app`; three plain explanation lines per query.
- `guard.py`: read-only allowlist, bounded windows (relative, absolute, snaps, all-time refused),
  `index=*` refused, redaction with visibility/owner context, per-run salted hashing, text truncation
  with a visible marker, projection to the seal's focus, decodes, row collapse, budget warning,
  `--raw` limited to five rows with the owning seal's context.
- `splunk_cli.py`: complete; needs only `splunk_client.py` with `login()` and `search()`. Dry-run,
  baseline, access-check, host allowlist, audit log, exit codes. Every setting is a flag
  (`--base-url`, `--context`), and `@file` passes quote-heavy SPL, so the same command line works
  from Copilot (GPT or Claude models) or Claude Code on bash, zsh, PowerShell and cmd.
- `onboard_seal.py`: questions or an answers file → all six files drafted with `check` marks,
  PII and role heuristics, placeholder links, alerts, completeness score.
- `setup.py`: one command. `first-run/`: plan, CLI integration guide, facts to validate, sample prompts,
  live contract check.
- Tests: unit, security (guard contract), CLI integration with a fake client, agent eval suites
  with a mocked CLI.
