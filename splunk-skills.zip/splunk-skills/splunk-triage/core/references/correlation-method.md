# Correlation Method

How to move between seals. The keys live in each seal's `links.yaml`; the journeys in
`journeys/` chain them; the resolver prints the hops with key and skew. This file is the method,
which is the same for every pair.

## Where things live

| Question | File |
|---|---|
| What does seal A send to seal B, on which field? | `seals/<A>/links.yaml`: the caller owns the edge |
| Display name, unit, PII class of that field | each seal's `fields.yaml` |
| In what order do the hops happen for a user action? | `journeys/<name>.yaml` |

Never restate a field or a key in a second file. Reference it.

## An edge

```yaml
- id: fr-request
  to: "<DEST_SEAL_ID>"
  from: { sourcetype: <source_sourcetype>, field: <trace_field> }
  to_field: <dest_trace_field>
  kind: request                      # request | user | window
  skew_s: { before: 10, after: 2 }   # destination event relative to the source event
  status: confirmed                  # or placeholder, with a verify_query the owner runs in prod
```

`request` joins one request to one request: use `=`. `user` joins one person's activity across
systems: many to many, narrow it with the window and an endpoint. `window` means there is no key:
compare the 5xx share of responses over the same window and treat agreement as a lead, not proof.

## Time skew

Correlated events do not share a timestamp. A downstream search that reuses the upstream window
misses events, and the empty result looks like no activity. Take the anchor time `t` from the
upstream event (`| eval t=_time`) and build the downstream window from the edge:
`earliest=<t - before> latest=<t + after>`. Widen backward toward sign-in, forward toward
application work. Use a relative window only when `t` is unknown.

## Order of work

1. Anchor on something concrete: a profile ID, a trace ID, an endpoint, a pod, a window.
2. Confirm the symptom in the seal that shows it (ladder Step 1).
3. Take the journey, or the single edge, that leaves that seal. The resolver printed them.
4. Carry the key and the skew window into the next seal. Repeat until a signature names the layer.

When the question is "which hop fails", run Step 1 on every hop's seal at once and compare, then
go deep on the one that moved.

## Reading a zero result downstream

In order of likelihood: the window ignored the skew; the sourcetype token is wrong; the field is
not extracted in this environment; the request never reached this seal. Check them in that order
and say which you ruled out.

## Placeholders

An edge with `status: placeholder` is a hypothesis. Use it, label the result unconfirmed, and
offer the owner its `verify_query`. When they confirm it, propose the edge as `confirmed` in a
pull request.
