# Writing SPL

Read this only when no built query or recipe fits and you write SPL yourself. The builder and
the recipes already follow it.

## Where filters go

Every simple comparison goes in the base search, before the first pipe. `index=…
sourcetype=… status>=500 earliest=-15m latest=now` is filtered on the indexers; `| where
status>=500` scans everything first. `| where` is right in two cases only: comparing two fields
(`where p99 > p50*3`) and filtering after an aggregate (`stats … | where total > 50`).

Production has indexed fields; UAT does not. The same SPL is correct in both, but UAT relies
on the time window for almost all of its cost, so narrow the window harder there.

## What reaches the agent

Everything a search returns is read by a language model. Three lines keep a result to what the
question asked:

```spl
| fields status, uri, frTraceId        ← stop extracting the rest
| fields - _raw                        ← drop the raw event on the indexers
| head 20 | table status, uri, frTraceId   ← an event list ends here; table is a pure projection
```

Free text (`message`) is 300–1,000 characters and on RPEX doubled: `| eval message_len=
len(mvindex(message, 0)), message=substr(mvindex(message, 0), 1, 300)` before `table` cuts it on
the indexers; the CLI turns `message_len` into the usual `…[+N chars]` marker. A breakdown ends
with `| sort - count | head 20`: the top twenty rows answer "where", the total comes from Step 0. For a time series the agent will read, prefer
`| bin _time span=5m | stats count by _time, status` (only non-zero cells) over `timechart` (every
bin times every value). At Step 4, `stats earliest(_time) as start, latest(_time) as end, count,
values(level), list(message) by traceId | eval messages=mvindex(messages, 0, 4)` turns 50 log
lines into one row.

The CLI also projects to the seal's focus when the SPL has no `table`, caps text fields at their
`max_chars` with a visible marker, and drops `_raw` unless `--raw`. The ladder says when `_raw`
is the evidence.

## Field names

Quote a name with a dot, hyphen or braces in `fields`, `table`, `by` and in the base search:
`"response.statusCode">=500`, `"channel-type"=UR`. Inside `eval`, single quotes:
`eval failed=if('response.statusCode'>=400, 1, 0)`. A name ending in `{}` breaks `eval`
altogether; use `table` or `rename`.

## Exact lookups

`field="<value>"` when you know the field. `TERM(<value>)` for a bare ID that can sit in several
fields; it matches a whole token bounded by major breakers (space, quote, comma, bracket), so
`TERM(0.a1b2.123.c3d4)` works but `TERM(123)` will not find `profileid=123`; write
`TERM(profileid=123)`. Never a leading wildcard (`*foo`): it forces a full scan.

## Aggregates

`stats`, `timechart`, `top`. Never `transaction`: it is memory-bound and truncates silently, so a
partial result looks complete; `stats … by sessionId` gives the same answer.

`| tstats count where index=… sourcetype=… earliest=… latest=… [by field]` counts from the index
summary without reading one event, which makes a volume check on a busy index near-free. It has
one trap: a field that is not indexed in that environment returns 0, which reads as "no traffic".
So the builder uses it only for pure counts, only in the environments a sourcetype's `indexed_in`
lists (the owner confirms with the same query against `stats`), and never with data models. Write
it by hand under the same rule, or not at all.

## More than one index

Start with the word `search`, keep each index's filters inside its own branch, merge columns
with `coalesce`:

```spl
search (index=A sourcetype=a key="<X>") OR (index=B sourcetype=b key2="<X>") earliest=<t-before> latest=<t+after>
| eval path=coalesce(uri, uriPath), code=coalesce(status, 'response.statusCode')
| table _time, index, path, code
```

The CLI prepends `search` only before `index=`; a query starting with `(`, `index IN` or
`TERM(` must start with `search` itself.

## Map an unmapped sourcetype

Before you report on a sourcetype with no `fields.yaml` entry, list its fields and map them
(`onboard_seal.py --fieldsummary <index> <sourcetype>` prints this query). Keep the window at
one minute on a very high volume index.

```spl
index=<index> sourcetype=<sourcetype> earliest=-1m latest=now
| head 200
| fieldsummary maxvals=0
| where count>0
| table field, count, distinct_count
| sort - count
```
