# Triage Ladder

Some indexes write thousands of events a minute. Climb from the top: each step answers the
question the next one needs, and every step is a `build_query.py --step <n>` away.

| Step | Question | Shape | Rows |
|---|---|---|---|
| 0 Count | Is anything happening? | `stats count` | 1 |
| 1 Breakdown | Where, and what kind? | `stats count by status, endpoint \| head 20` · `--kind latency` · `--trend 5m` (≤ 60 buckets) | ≤ 20 |
| 2 Signature | Which error, how often? | `level=ERROR … stats count by logger, message` | ≤ 20 |
| 3 Sample | What does one look like? | `dedup status, endpoint \| head 20 \| table …` | ≤ 20 |
| 4 Trace | What happened to this one request or person? | `key="value" … --collapse` (one row) or `sort 0 _time \| head 50 \| table` | 1–50 |
| 5 Raw | Is the extracted value right? | `key="value" \| head 5 \| table _time, _raw` with `--raw` | ≤ 5 |

## Rules

- Start at the lowest step that answers the question. "Is sign-in broken?" is Step 1. "Why did
  this profile get a 500?" is Step 4, after Step 1 confirmed the window has the error.
- `volume: high` seals start with a 15-minute window; widen in steps (1h, then 4h) when the count
  is small, past 1h only when the user asks, and ask before 24 hours of production.
- Never run Step 3 or 4 without a filter from Step 1 or 2. Totals come from `stats`, never from
  counting rows in a sample.
- Compare against a baseline before calling a number high: `--baseline` runs the same query one
  week earlier.
- Each pod or seal hop is an independent Step 1. When a journey has more than one hop and the
  question is "where does it fail", run Step 1 on every hop's seal in one `fanout` call (the
  resolver prints it) and compare before going deep on one.

## Reading a table instead of raw events

The access and JSON logs here are fully extracted: a table of named fields holds the same facts
as `_raw` in a fraction of the bytes. Three rules keep that honest.

1. **An empty cell is "not extracted on this row", never "no value".** A blank join key, status
   or time on a row that should carry one is a Step 5 trigger.
2. **A cut marker (`…[+N chars]`) means you have not read the whole value.** Fetch that one row
   (Step 5, or `--raw` on the recipe) before you name a cause from it.
3. **Every number in the report traces to a named column in the SPL you ran.** A value you pulled
   out of free text with `rex` is checked against one raw row before it goes in the Findings.

Step 5 is for evidence, not browsing: an empty cell, a hidden cause in a truncated message, a
sourcetype with no field map, or one number that decides the finding. Say in the report which
row you confirmed and why.

## Composition rule

A query the reader cannot follow is a query they have to take on trust. One transform per line,
eight lines at most. If a question needs more, run two queries and say why. Under every SPL in
the report, three plain lines: what it filters, what it groups, what the numbers mean. The
builder prints those lines for you.
