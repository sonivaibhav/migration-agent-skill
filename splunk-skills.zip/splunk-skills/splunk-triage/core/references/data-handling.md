# Data Handling

**Author reference.** Read this when you write or review a `fields.yaml`. It is not loaded
during triage: the CLI enforces every rule here, and `guardrails.md` carries the two lines the
agent needs.

Production logs hold customer data. This file defines the classes, what the CLI does with
each, and what a seal may change.

## PII classes (`fields.yaml` → `pii`)

| Class | Meaning | Examples |
|---|---|---|
| `none` | Operational value, no link to a person | status, uri, pod, responseTime, trace IDs |
| `indirect` | Identifies a person only when joined with another system | profile ID, session ID, IP address |
| `direct` | Identifies a person on its own | name, email, phone, account number, address |

## Visibility (`fields.yaml` → `visibility`)

| Level | Prints when | Who may set it |
|---|---|---|
| `public` | Always, subject to `mask` | Any seal, for `pii: none` or `indirect` |
| `owner` | Only when `--context` equals the seal that owns the field | The owning seal, for its own `direct` fields |
| `never` | Never. Replaced by `[redacted]` | Core. A seal cannot lower it |

Defaults when a field has no entry in `fields.yaml`: `pii: indirect`,
`visibility: public`, `mask: hash`. Unmapped fields are therefore hashed, not
shown. Map the field to show it in clear.

## Masks (`fields.yaml` → `mask`)

| Mask | Output | Use |
|---|---|---|
| `none` | Clear value | `pii: none` only |
| `hash` | 12-char salted hash, salt per CLI run | IDs you need to follow across hops |
| `last4` | `…1234` | Account-like values where the tail is enough |
| `redact` | `[redacted]` | Anything else |

The hash salt is generated per CLI run and never written to disk. The same
value hashes the same way across every query in one run, so a profile can be
followed from one seal to the next. It cannot be reversed and does not survive
the run.

## Text and decodes

`text: true` marks a free-text field. The CLI keeps the first multivalue entry and truncates to
`max_chars` (default 200) with a visible `…[+N chars]`. `decode:` maps a code to its meaning; the
CLI prints `MON (Chase Retail - iPhone)`, `(missing)` for `-` or empty, `(unknown)` otherwise.
Fields displayed as "HTTP Status" are decoded from a built-in table.

## Core pattern guards

Applied to every printed string, including `_raw` and `message`, regardless of
seal settings: 13 to 19 digit sequences that pass a Luhn check, national ID
formats, and email addresses are replaced with `[redacted]`. A seal cannot
disable these.

## What a seal may change

- Map its own fields and choose `public` or `owner` for them.
- Choose a mask for its own `indirect` fields.
- Set `owner` on a `direct` field so its own team can see it in context.

## What a seal may not change

- Lower `never` to anything else.
- Set `visibility: owner` on a field another seal owns.
- Turn off the pattern guards or the per-run hashing.

`validate.py` rejects a `fields.yaml` that attempts any of these.

## In reports

Display names only. A hashed value appears as the display name plus the hash
(`Profile ID a1b2c3d4e5f6`). Say in one clause when a finding depends on a
redacted field. Never ask the user to supply the clear value.
