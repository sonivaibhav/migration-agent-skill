# Report Format

The reader is triaging under time pressure. The top must make sense to someone with no
technical background; the bottom must let an engineer verify and continue. Target: under 200
words of prose, one table, one query. A seal may replace this file with `overrides/output-format.md`.

For a fast-path answer (one seal, one standard question) use the short form in `SKILL.md`.

## Structure

```
## What happened
Three sentences: what broke, who or what it affected and what they saw, whether it is still
happening. No SPL, no raw field names, no index names. Expand every acronym once
(CAAS, Challenge as a Service); explain every status code once (500, a server error).

## Severity · Confidence
Severity: Critical | Major | Minor | Informational, plus a short reason.
Confidence: High | Medium | Low, plus one reason (a placeholder edge, a cut sample, a redacted
field the finding leans on).

## Findings
One table, at most 8 rows. Display names from fields.yaml (Profile ID, Latency (ms), FR Trace
ID). First column "What happened" in plain words. Hashes next to their display name are fine.

## Query
The one query that produced the Findings table, as run, with earliest/latest and the --context.
Under it, three plain lines: what it filters, what it groups, what the numbers mean (the builder
prints them). Then one line: "Queries run: N (list on request)".

## Next step
One line: the next query or action. Omit only when the investigation is complete.
```

## Rules

- Latency in ms to one decimal, or seconds to three. Convert before you compare two seals.
- Times in the user's local time, timezone stated once, readable (2:05 PM ET).
- `dc(AMSESSION)` and similar are sessions, never customers, users or people.
- A capped list (`head`, or exactly the row cap) is disclosed as cut; the total comes from `stats`.
- A finding that leans on a flagged field or a placeholder edge carries one clause saying so. No
  general disclaimers.
- A zero result is a finding: what you searched, the window, the likely causes in order, the SPL.
- No Splunk UI links. Show the SPL.

## Words

| Use | Not |
|---|---|
| endpoint | URL, route (page only for a browser page in CXO web) |
| request | call, hit |
| sign-in | login, auth (authentication only for service-to-service) |
| profile ID | user ID, customer ID |
| latency | response time |
| window | time range, period |
| pod | server (server only for `server.ip`) |
| FR Trace ID, OTel Trace ID, X-Ray Trace, RPEX Trace ID | a bare "trace ID" when two kinds appear |

## Example

````
## What happened
People signing in to Ultimate Rewards hit an error page for about three hours overnight,
from around 1:00 AM to 4:00 AM Eastern on July 17. The Chase sign-in challenge service (CAAS,
Challenge as a Service) could not finish the sign-in step. It recovered on its own.

## Severity · Confidence
Major: sign-in failed across the whole service for a sustained period.
High: the failure count comes from the challenge service's own access log, not a sample.

## Findings
| What happened | When (ET) | Status | Where |
|---|---|---|---|
| Sign-in step failed, 394 times in 200+ sessions | Jul 17, 1–4 AM | 500 (server error) | all 6 pods, evenly |
| Occasional sign-in failures | rest of the day | 500 (server error) | 3–19 per hour, normal background |

Even spread across pods points to a shared fault behind the challenge service, not one machine.

## Query
```spl
index=<signin_index> sourcetype=<signin_challenge_sourcetype> httpCode=500
  "https://secure.chase.com/web/auth/challenge?fromOrigin=https://ultimaterewardspoints.chase.com"
  earliest=-24h latest=now
| fields ENV1, AMSESSION
| fields - _raw
| stats count as errors, dc(AMSESSION) as sessions by ENV1
```
Filters: CAAS access audit, failed challenges that came from the UR site, last 24 hours.
Groups: by pod.
Shows: failures and distinct sessions per pod.
Queries run: 3 (list on request)

## Next step
Check what changed behind the challenge service around 1:00 AM: a deploy or a dependency.
````
