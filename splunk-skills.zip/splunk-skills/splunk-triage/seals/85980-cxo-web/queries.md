# CXO Web Recipes

Standard questions need no recipe: `build_query.py --seal 85980 --step <0-5>`. The two recipes
below encode the UR signals (profile ID via `TERM()`, and the UR site in the page address).
Every query here starts with `search` because the filter is a bare term.

| Recipe | Use when |
|---|---|
| Pages one UR user visited | A profile ID; what did the browser show them? |
| UR sign-in challenges by page | Sign-in page errors; how many browsers saw the challenge |

---

## Pages one UR user visited

```spl
search index=cfs_digital_85980 TERM(<PROFILE_ID>) earliest=-15m latest=now
| fields "message.screen.currentURL", "message.visitor.profileId"
| fields - _raw
| rename "message.screen.currentURL" as page, "message.visitor.profileId" as profileId
| stats count, values(page) as pages by profileId
```

## UR sign-in challenges by page

`users` is a distinct count of profile IDs: close to people, not identical.

```spl
search index=cfs_digital_85980 "ultimaterewardspoints.chase.com" earliest=-15m latest=now
| fields "message.screen.currentURL", "message.visitor.profileId"
| fields - _raw
| rename "message.screen.currentURL" as page
| stats count, dc("message.visitor.profileId") as users by page
| sort - count
| head 20
```
