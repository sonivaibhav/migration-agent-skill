# CXO Web Notes

CXO web holds the client side telemetry from the Chase web application. The
browser sends the events. The Octagon framework produces them.

**This is not a server log.** A missing event can mean a browser that did not
report. It does not prove a failed request. Read the UR access log for the
server truth.

## Index and sourcetype

One index, `cfs_digital_85980`, confirmed in production. It holds one
sourcetype, `cfs_digital_85980_cpo_client`; a sourcetype filter adds nothing.

The volume is very high. Use a short window (15 minutes) and put every filter
in the base search. Start at ladder Step 0.

## Field traps

- Events are nested JSON with 500+ extracted names; most fields are present on a small share of
  events (coverage is in `fields.yaml`). An empty cell usually means "not on this event type".
- Quote dotted names (`"message.visitor.profileId"`) and rename before `stats`; names ending in
  `{}` are multivalue and break `eval`.
- `traceId` is internal to CXO, not a UR trace. `channelId` is not the UR `authInfo` cookie.
- `message.log.performance.*` (client timing) is on about 12 percent of events.
- `DataCenter`, `Env`, `IPaddress`, `Swimlane` exist and are empty.

## UR traffic

Two signals isolate Ultimate Rewards activity in this index.

| Signal | Use |
|---|---|
| `"message.visitor.profileId"` equals the UR `smCigProfileId` | Follow one user |
| `"message.screen.currentURL"` contains `ultimaterewardspoints.chase.com` | Find the UR sign-in challenge |

The sign-in challenge address carries the UR parameters. Example:

```
https://secure.chase.com/web/auth/challenge?fromOrigin=https://ultimaterewardspoints.chase.com#/challenge/caas/challenge/challenge?applicationId=MON&clientId=REWARDS&eventId=COMBINE_POINTS
```

`clientId=REWARDS` marks the rewards client. `eventId` names the journey. This
is the same anchor that the CAAS access audit uses (`89592/caas-signin`).

## Reading results

- CXO confirms what the browser showed; the UR access log is the server truth. No CXO events for a
  profile the UR log shows is a browser that did not report, not a failure.
- The challenge page repeating for one profile is a sign-in loop: hop to the CAAS access audit on
  the same `fromOrigin` (journey `ur-sign-in`).
