# DPS Gateway Recipes

Standard questions need no recipe: `build_query.py --seal 88082 --step <0-5>` on the envoy
sourcetype (snake_case). The tomcat sourcetype (camelCase) has no status field mapped, so the
builder cannot do errors there; use the UR-origin recipe. Queries with a bare term start with
`search`.

| Recipe | Use when |
|---|---|
| Live sourcetypes | Before any per-service query; the set of ~60 changes |
| UR-originated traffic through DPS | Is the gateway part of a UR problem? |
| UR vs DPS over the same window | Compare both sides' 5xx share when UR looks like a gateway problem |

---

## Live sourcetypes

```spl
index=cfs_digital_88082 earliest=-5m latest=now
| stats count by sourcetype
| sort - count
```

## UR-originated traffic through DPS

`Referer` carries the UR site for UR-originated requests. Half the events carry no profile.

```spl
search index=cfs_digital_88082 sourcetype=cfs_digital_tomcat_access_st "ultimaterewardspoints"
  earliest=-15m latest=now
| fields Referer, profileId, responseTimeMs
| fields - _raw
| stats count, dc(profileId) as users, avg(responseTimeMs) as avg_ms by Referer
| sort - count
| head 20
```

## UR vs DPS over the same window

No request key. The envoy sourcetype has `response_code`; the tomcat sourcetype has none mapped.

```spl
search (index=cfs_digital_ultimate_rewards_aws_89592 sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st)
    OR (index=cfs_digital_88082 sourcetype=digital_envoy_access_st)
  earliest=-15m latest=now
| fields _time, index, status, response_code
| fields - _raw
| eval code=tonumber(coalesce(status, response_code)), layer=if(index="cfs_digital_88082", "DPS", "UR")
| bin _time span=5m
| stats count as responses, count(eval(code>=500)) as errors by _time, layer
| eval error_rate_pct=round(errors/responses*100, 2)
```
