# DPS Gateway Notes

This index holds the Digital Presentation Services (DPS) gateway. DPS sits
between the browser or the mobile application and the backend services.

The index carries web traffic and mobile traffic together. Do not read a result
here as mobile activity without a channel filter.

## Index and regions

`cfs_digital_88082`, confirmed in production. Production runs in `us-east-1`,
`us-east-2`, and `us-west-2`. The `region` field carries the value on the envoy
sourcetype.

## Sourcetypes

The index holds about 60 sourcetypes, and the set changes. The two access
sourcetypes carry most of the traffic, and their volume is very high. Start at
ladder Step 0 with a 5 to 15 minute window.

The `<service>` token in the per-service sourcetypes names the backend.
Confirmed values include `rr_accts`, `rl_accts`, `rr_pymts`, `wr_pymts`,
`wr_accts`, `wr_profile`, `rr_profile`, `rr_docs`, `wl_auth`.

Before you query a per-service sourcetype, list the live ones:

```spl
index=cfs_digital_88082 earliest=-5m latest=now
| stats count by sourcetype
| sort - count
```

The per-service sourcetypes have no field map. Map one before you report on it
(see Map an Unmapped Sourcetype in
[query-performance.md](../../core/references/query-performance.md)).

`app_name` on the envoy sourcetype holds `envoy-router`, `envoy-egress-proxy`,
or `envoy-df-proxy`.

## Field traps

**Two naming conventions.** The envoy sourcetype uses `snake_case`
(`profile_id`, `response_code`); the DPS application sourcetype uses
`camelCase` (`profileId`, `responseTimeMs`). A field name from one returns
nothing against the other, and nothing looks like no traffic.

**Unconfirmed units.** Envoy `duration` and DPS `responseTime` have no
confirmed unit. `responseTimeMs` is milliseconds. Report only `responseTimeMs`
until the others are confirmed.

**Half the events have no identity.** The identity fields carry a value on
about half of the events. A request that has not signed in has no profile.

**Session is not UR's session.** DPS `sessionId` is a DPS session, not the UR
access-log `sessionId`.

## UR traffic

Two signals isolate UR traffic.

| Signal | Use |
|---|---|
| `Referer` contains `ultimaterewardspoints.chase.com` | Find every UR-originated request |
| `profileId` or `profile_id` equals the UR `smCigProfileId` | Follow one user |

The `Referer` values include the UR home address, the CAAS sign-in challenge
with `fromOrigin=https://ultimaterewardspoints.chase.com`, and the SiteMinder
sign-off redirect with a `TARGET` back to UR.

Use this index when a UR problem looks like a gateway problem. Compare the UR
access log status against the DPS status over the same window.

## Reading results

- DPS 5xx on the same path and window as UR 5xx points behind DPS: list the live per-service
  sourcetypes and check that service's `_metrics_hystrix_st` for open circuits. DPS 2xx with UR
  5xx points at UR itself.
- A `Referer` showing the SiteMinder sign-off `TARGET` loop is a session problem (journey `ur-sign-in`).
