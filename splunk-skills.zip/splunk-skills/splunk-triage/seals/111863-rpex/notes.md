# RPEX Notes

One index, four services; the services table is in `seal.yaml`. Select the service before
writing SPL and filter on the sourcetype, not on `http.endpoint`.

**Two services carry Ultimate Rewards traffic.** `rpex_aws_roex_st` (order history) is the main
one; most events carry `channel-type=UR`, a few `LSP`. `rpex_aws_app_st` (account profile) also
carries `channel-type=UR` at very low volume and has no field map. **`rpex_aws_rbes_st` is the
mobile balance service:** every event is `MOBILE_NATIVE`, UR never calls it, do not use it to
answer a UR web question.

Avoid `index="*111863*"`; a leading wildcard on `index` scans every index name.

## Log shape

Events are JSON (`KV_MODE=json`). Three consequences:

- Quote dotted keys (`"http.endpoint"`) and hyphenated keys (`"channel-type"`,
  `"online-profile-identifier"`); an unquoted hyphen breaks `eval` and `stats`.
- `message` and `level` appear twice per record, so they are multivalue. A `rex` on `message`
  matches both and doubles every count; take `mvindex(<field>, 0)` after the `rex`.
- `DataCenter` exists and is empty.

## Logger catalog

`logger` is the fastest way to slice RPEX behaviour.

| Logger | Emits | Read for |
|---|---|---|
| `MONETA_REQUEST` | `EVENT=[REQUEST] QUERY_PARAMS=[...]` | The inbound request |
| `MONETA_RESPONSE` | `EVENT=[RESPONSE] STATUS=[<code>]` | The HTTP status the caller saw |
| `MONETA_PERF` | `EVENT=[<channel>] TIME=[<ms>]` | Latency per request, **milliseconds** |
| `PHOTON_AAA_LOGGER` | `Authentication Success: [<userId>]` | Service-to-service auth outcome |
| `…RBEXExceptionHandler` | A handled exception (balance service) | The cause of a 4xx |

`MONETA_*` events on `roex` carry no `channel-type`; a `"channel-type"=UR` filter drops them.

## Field traps

| Field | Trap |
|---|---|
| `userId` / `user` (roex) | A service account (one for UR, one for LSP), not an end user |
| `remote-host` | The calling server (a UR pod), not a person |
| `traceId` / `trace-id` | Internal to RPEX; never reaches the UR index. Prefer `traceId` (93% coverage) |
| `online-profile-identifier` (rbes) | Present on about two thirds of lines; a count that depends on it undercounts |
| `channel-type` in UAT | Returned `WEB` on the balance service; prod returns `MOBILE_NATIVE` |

## No request-level join to UR

Two tests: 29,942 distinct `traceId` values across the UR app log and `rbes`, and 105,405 across
the UR logs and `roex`; **0 shared** in both. The systems use separate trace contexts. Use these
instead: `channel-type=UR` on `roex` (which traffic came from UR), `remote-host` (which UR server
sent it), `smCigProfileId` ↔ `online-profile-identifier` on `rbes` (one person on two channels,
not one request), and time correlation of the 5xx share of responses (not `ERROR` lines).

## Environments

Prod: `us-east-1` only, source `/var/log/prod-useast-1/<service>/<prefix>_aws_app.log`.
UAT: source `/var/log/test-useast-1/rewards-balance-experience-service/rbex_aws_app.log`, ECS
cluster `ecsff11-rpexuatue1-v1`.
