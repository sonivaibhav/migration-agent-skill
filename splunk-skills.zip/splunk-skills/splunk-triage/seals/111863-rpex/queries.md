# RPEX Recipes

Standard questions need no recipe: `build_query.py --seal 111863 --sourcetype <service> --step <0-5>`.
Pick the service first (`roex` = UR order history, `rbes` = mobile balance); the index holds four.
RPEX puts its status and latency inside `message`, so the recipes below `rex` them out.

| Recipe | Use when |
|---|---|
| Channel mix across services | You do not know which service answers the question |
| Response status mix | You need the HTTP status callers actually saw |
| DPS call failures | RPEX logs `DPS call FAILED`; which status and how slow |
| Latency from MONETA_PERF | Latency question; the builder has no latency role here |
| Constraint-violation causes | 400s on the balance service: which field was invalid |
| UR vs RPEX over the same window | Did an RPEX failure cause a UR failure? No request key exists |

---

## Channel mix across services

```spl
index=rpex_111863 earliest=-15m latest=now
| fields sourcetype, "channel-type"
| fields - _raw
| rename "channel-type" as channel
| stats count by sourcetype, channel
| sort - count
```

## Response status mix

`MONETA_RESPONSE` carries the status the caller saw. `message` is doubled on every event; the
`mvindex` keeps counts honest.

```spl
index=rpex_111863 sourcetype=rpex_aws_roex_st logger=MONETA_RESPONSE earliest=-15m latest=now
| fields message
| fields - _raw
| rex field=message "STATUS=\[(?<httpCode>\d+)\]"
| eval httpCode=mvindex(httpCode, 0)
| stats count by httpCode
| sort - count
```

## DPS call failures

```spl
index=rpex_111863 sourcetype=rpex_aws_roex_st "DPS call FAILED" earliest=-15m latest=now
| fields message
| fields - _raw
| rex field=message "status (?<statusCode>[^\.]+) took (?<ms>[^\.]+)ms"
| eval statusCode=mvindex(statusCode, 0), ms=tonumber(mvindex(ms, 0))
| stats count, avg(ms) as avg_ms, max(ms) as max_ms by statusCode
```

## Latency from MONETA_PERF

Milliseconds. UR `responseTime` is microseconds; convert before comparing.

```spl
index=rpex_111863 sourcetype=rpex_aws_roex_st logger=MONETA_PERF earliest=-15m latest=now
| fields message
| fields - _raw
| rex field=message "EVENT=\[(?<channel>[^\]]+)\] TIME=\[(?<ms>\d+)\]"
| eval channel=mvindex(channel, 0), ms=tonumber(mvindex(ms, 0))
| stats p50(ms) as p50_ms, p95(ms) as p95_ms, p99(ms) as p99_ms, count by channel
| sort - p99_ms
```

## Constraint-violation causes

```spl
index=rpex_111863 sourcetype=rpex_aws_rbes_st "RBEXExceptionHandler" "ConstraintViolation"
  earliest=-15m latest=now
| fields message
| fields - _raw
| rex field=message "error=(?<violation>[^\n]+)"
| eval violation=substr(mvindex(violation, 0), 1, 120)
| stats count by violation
| sort - count
```

Provenance: a 27 Jul 2026 UAT 400 traced to `Invalid channel-type`: client validation, not a
DPS failure.

## UR vs RPEX over the same window

There is no request-level join (0 of 105,405 trace IDs shared; see `notes.md`). Count responses
on both sides, not `ERROR` lines, and compare the 5xx share per 5 minutes. A rise in both is a
lead, not proof.

RPEX, all channels:

```spl
index=rpex_111863 sourcetype=rpex_aws_roex_st logger=MONETA_RESPONSE earliest=-15m latest=now
| fields _time, message
| fields - _raw
| rex field=message "STATUS=\[(?<code>\d+)\]"
| eval code=tonumber(mvindex(code, 0))
| bin _time span=5m
| stats count as responses, count(eval(code>=500)) as errors by _time
| eval error_rate_pct=round(errors/responses*100, 2)
```

UR access, same window:

```spl
index=cfs_digital_ultimate_rewards_aws_89592 sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st
  earliest=-15m latest=now
| fields _time, status
| fields - _raw
| bin _time span=5m
| stats count as responses, count(eval(status>=500)) as errors by _time
| eval error_rate_pct=round(errors/responses*100, 2)
```

The RPEX query counts every channel because `MONETA_RESPONSE` events carry no `channel-type`.
When the UR-only share matters, attribute each response to its trace's channel with
`eventstats values("channel-type") by traceId` over a short window (the trace carries the
channel on its other events); it is heavier, so run it second, not first.
