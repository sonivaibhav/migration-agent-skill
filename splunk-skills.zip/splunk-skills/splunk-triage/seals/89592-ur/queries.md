# UR and WL Recipes

Standard questions need no recipe: `build_query.py --seal 89592 --step <0-5> --kind errors|latency|volume`
(errors by endpoint, latency percentiles, a sample, one request, one profile). A recipe is SPL
that encodes something the builder cannot derive. For the WL tier, change the sourcetype token
(`_ur_st` → `_wl_st`, `_uraccess_st` → `_wlaccess_st`) and nothing else.

| Recipe | Use when |
|---|---|
| Error rate by endpoint | Endpoints carry very different traffic, so a count misleads |
| Traffic by region | You need to know whether one AWS region is failing |
| Traffic by platform | You need to know whether web or a mobile WebView is affected |
| App log to access log for one profile | You have a profile ID and need both logs in one timeline |
| UR vs WL in one search | You need to know whether both tiers are affected |

---

## Error rate by endpoint

Generic shape; copy it to any access log. 50 errors on a busy endpoint can be healthier
than 5 on a quiet one.

```spl
index=cfs_digital_ultimate_rewards_aws_89592 sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st
  earliest=-15m latest=now
| fields uri, status
| fields - _raw
| stats count(eval(status>=500)) as errors, count as total by uri
| eval error_rate=round(errors/total*100, 2)
| where total > 50
| sort - error_rate
```

The `| where` is correct here: it filters after the aggregate.

## Traffic by region

The access log has no region field. Derive it from the `source` path. The application log
has `cloud.region` directly; use that when the question allows the app log.

```spl
index=cfs_digital_ultimate_rewards_aws_89592 sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st
  earliest=-15m latest=now
| rex field=source "ecs-prod-(?<region>us-east-\d)"
| stats count by region
```

Add `| bin _time span=5m` before `stats` and `_time,` to the `by` for a trend.

## Traffic by platform

`authInfo` is the `auth-site-info` cookie; the CLI decodes the codes (`MON` → Chase Retail -
iPhone) and prints `(missing)` for an absent cookie. Counts requests to UR and WL, which
include the Chase mobile WebViews. It does not count native mobile requests to other services.

```spl
index=cfs_digital_ultimate_rewards_aws_89592
  (sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st OR sourcetype=wcmur_cfs_ultimate_rewards_ecs_wlaccess_st)
  earliest=-15m latest=now
| fields sourcetype, authInfo, status
| eval tier=if(sourcetype="wcmur_cfs_ultimate_rewards_ecs_uraccess_st", "UR", "WL")
| stats count as requests, count(eval(status>=500)) as errors by tier, authInfo
| sort tier, - requests
```

Keep the Missing and Unknown rows in the report.
Provenance: production UR and WL access logs showed `C30`, `MOD`, `MON`, `MOP`, and `-` on 2 November 2026.

## App log to access log for one profile

Join on Profile ID and Endpoint, never on `sessionId` (the two logs hold different values).
The app log leads the access log by up to 2 seconds. Strip the leading `@` from `requestUri`.

```spl
search (index=cfs_digital_ultimate_rewards_aws_89592 sourcetype=wcmur_cfs_ultimate_rewards_ecs_ur_st userId="<PROFILE_ID>")
    OR (index=cfs_digital_ultimate_rewards_aws_89592 sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st smCigProfileId="<PROFILE_ID>")
    earliest=-1h latest=now
| eval endpoint=coalesce(ltrim(requestUri, "@"), uri), latency_ms=round(responseTime/1000, 1)
| eval message=substr(mvindex(message, 0), 1, 200)
| sort 0 _time
| head 50
| table _time, sourcetype, endpoint, status, level, latency_ms, pod, message
```

## UR vs WL in one search

```spl
index=cfs_digital_ultimate_rewards_aws_89592
  (sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st OR sourcetype=wcmur_cfs_ultimate_rewards_ecs_wlaccess_st)
  status>=500 earliest=-15m latest=now
| fields sourcetype, status
| eval tier=if(sourcetype="wcmur_cfs_ultimate_rewards_ecs_uraccess_st", "UR", "WL")
| stats count by tier, status
| sort tier, - count
```

---

Provenance that shaped this seal: `frTraceId` = ForgeRock `transactionId` confirmed on a live
request (24 Aug 2026); the 28 Aug 2026 UAT 504 on `/rewards-activity` was the Identity Gateway
timing out at 15 s while UR served the same request 200 (see the browser-token recipe in
`81712-forgerock/queries.md`); the 17 Jul 2026 sign-in spike was 394 CAAS 500s spread evenly
across six pods, a shared backend fault.
