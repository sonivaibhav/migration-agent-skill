# UR / WL Notes

Read this when a field below shows up in a result. The field map is `fields.yaml`.

## Two tiers, one index

UR (Ultimate Rewards) and WL (White Label Rewards) each write an application log and an access
log to the same index. Pick the tier before writing SPL; the wrong sourcetype returns nothing,
and nothing looks like no traffic. The access sourcetypes are `uraccess` / `wlaccess` with no
underscore before `access`. The three EKS legacy sourcetypes still receive residual traffic and
use different field names: never query them.

Production runs in `us-east-1` and `us-east-2` under one sourcetype; the access log has no
region field (derive it from `source`), the app log has `cloud.region`.

## Field traps

Five fields have names that do not describe their values. Each has produced a wrong conclusion.

| Field | Looks like | Actually is | Do |
|---|---|---|---|
| `responseTime` | milliseconds | **microseconds** (Tomcat 10.1 `%D`) | divide by 1000; the builder does |
| `remoteIp` | the client | the load balancer (distinct count 1) | use `xForwardedFor` |
| `requestId` | a request ID | the Tomcat thread name | group by `frTraceId` instead |
| access `traceId` | a trace ID | the composite X-Ray header | use `frTraceId` for ForgeRock; extract `Root=` only if you must |
| `sessionId` (app vs access) | the same session | two different values | join the logs on Profile ID + Endpoint, never on session |

`authInfo` is the platform cookie; the CLI decodes it. `-` or empty means no cookie and is
reported as Missing, never counted as web. Native mobile requests to other services do not carry
it.

Baseline (Aug 2026): p50 about 13 ms, p99 under 1 s, liveness probe about 2 ms. Compare to one
week earlier before calling a value slow.

## Known gaps

- A known ingestion fault truncates a small share of production access records. A missing
  access record does not prove a failed request; check the app log.
- `DataCenter` is in the schema and always empty.
- The app log's user-context fields differ by environment (`userSession`/`userDetails` in UAT,
  `USER_DETAILS` in prod). Never query them or use them to detect the environment.
- UAT source paths are not recorded; confirm before filtering on `source` in UAT.

## Failure signatures (this seal)

| Symptom | Means | Next |
|---|---|---|
| Errors on one `pod` | Instance health | Error rate per pod vs traffic per pod |
| Errors on all pods | Deploy or dependency | Compare to deploy time; hop downstream |
| 500 in app log, 200 in access | Asynchronous path | Stay in the app log |
| Same round latency across failures | A timeout, not slow work | Find the layer that owns that value |
| No access record for a known app error | Ingestion gap | Do not report the request as failed |

Cross-seal signatures (401 → ForgeRock token, 504 → gateway timeout, sign-in 500 → CAAS) live in
the journeys `ur-forgerock-request` and `ur-sign-in`.
