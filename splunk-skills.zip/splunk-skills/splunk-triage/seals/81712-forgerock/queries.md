# ForgeRock Recipes

Standard questions need no recipe: `build_query.py --seal 81712 --step <0-5>` (one request by
`transactionId`, errors by endpoint, latency). The CAAS sourcetype needs `--sourcetype
cfs_digauthciam_ig_aws_acess_audit_st` (one `c` in `acess`). These recipes encode the three
things the builder cannot know: the `profileid=` prefix, the browser trace token, and the UR
sign-in challenge address.

| Recipe | Use when |
|---|---|
| ForgeRock errors for one profile | You have a UR profile ID and a sign-in or token problem |
| Browser trace token across UR and ForgeRock | A user sent an error-page token like `0.ab12.4567.cd89` |
| CAAS sign-in failures from UR | Sign-in page errors; is the challenge service failing? |
| CAAS failures by pod | A CAAS spike: one bad pod, or every pod (shared backend)? |

---

## ForgeRock errors for one profile

The profile ID sits inside `trackingIds{}` as `profileid=<id>`, so the search term keeps the
prefix. One failure followed by a success is a normal token refresh; repeated failures with no
success is a session problem.

```spl
index=cfs_digauthciam_81712 sourcetype=cfs_digauthciam_ig_lob_aws_access_audit_st
  TERM(profileid=<PROFILE_ID>) "response.statusCode">=400 earliest=-1h latest=now
| fields _time, transactionId, uriPath, "response.statusCode"
| fields - _raw
| sort 0 _time
| head 20
| table _time, transactionId, uriPath, "response.statusCode"
```

## Browser trace token across UR and ForgeRock

The dotted token on a browser error page (`0.<hex>.<num>.<hex>`) is the Identity Gateway request
ID. It is not the `frTraceId` and matches no single field, so search it as a literal across both
indexes; it appears with the `frTraceId`/`transactionId` pair, then pivot on that.

```spl
search ((index=cfs_digital_ultimate_rewards_aws_89592 sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st)
     OR (index=cfs_digauthciam_81712 sourcetype=cfs_digauthciam_ig_lob_aws_access_audit_st))
  TERM("<BROWSER_TOKEN>") earliest=-2h latest=now
| eval layer=if(sourcetype="wcmur_cfs_ultimate_rewards_ecs_uraccess_st", "UR access", "FR gateway")
| eval code=coalesce(status, 'response.statusCode'), ms=coalesce(round(responseTime/1000, 1), responseTimeMs)
| sort 0 _time
| head 20
| table _time, layer, uri, uriPath, code, ms, frTraceId, transactionId
```

Provenance: resolved the 28 Aug 2026 UAT 504 on `/rewards-activity`; the gateway returned 504 at
its 15 s ceiling and UR served the same request 200 later.

## CAAS sign-in failures from UR

No trace key links UR to CAAS. The CAAS access audit records the challenge address, and a sign-in
from Ultimate Rewards carries the UR site in `fromOrigin`. `500` means the challenge failed.

```spl
index=cfs_digauthciam_81712 sourcetype=cfs_digauthciam_ig_aws_acess_audit_st
  "https://secure.chase.com/web/auth/challenge?fromOrigin=https://ultimaterewardspoints.chase.com"
  earliest=-1h latest=now
| fields _time, httpCode
| fields - _raw
| bin _time span=5m
| stats count by _time, httpCode
```

For the last 24 hours use `earliest=-24h` and `span=1h`. Wider than that is above the production
cap: ask first, then `--confirm-window`.

## CAAS failures by pod

`errors` counts failed challenges; `sessions` counts distinct `AMSESSION` values. A session count
is not a count of people, and one session can reach more than one pod, so do not add the rows.
Even spread across pods = shared backend fault. One pod = instance fault.

```spl
index=cfs_digauthciam_81712 sourcetype=cfs_digauthciam_ig_aws_acess_audit_st httpCode=500
  "https://secure.chase.com/web/auth/challenge?fromOrigin=https://ultimaterewardspoints.chase.com"
  earliest=-1h latest=now
| fields ENV1, AMSESSION
| fields - _raw
| stats count as errors, dc(AMSESSION) as sessions by ENV1
| sort - errors
```

Provenance: characterized the 17 Jul 2026 UR sign-in spike: 394 server errors between 1 and 4 AM
ET, spread evenly across six pods.
