# ForgeRock Notes

ForgeRock is the Chase sign-in platform. CAAS (Challenge as a Service), the sign-in challenge
step, logs here too. Use the log type name in prose.

| Log type | Sourcetype | Use it for |
|---|---|---|
| UR traffic audit | `cfs_digauthciam_ig_lob_aws_access_audit_st` | The join target from UR (`transactionId` = UR `frTraceId`) |
| CAAS access audit | `cfs_digauthciam_ig_aws_acess_audit_st` | A sign-in failure |
| Access Management audit | `cfs_digauthciam_am_aws_audit_access_st` | The policy decision behind a request; its `transactionId` differs, join via the UR traffic audit first |

The CAAS sourcetype is spelled `acess` with one `c`; that is the name in Splunk. The `_lob_`
token separates the two Identity Gateway sourcetypes. The index holds 28 sourcetypes; these three
matter for rewards.

<!-- NOT YET CAPTURED: original forgerock.md lines 59+ (CAAS and AM field tables). -->

## Field traps

| Field | Trap | Do |
|---|---|---|
| `userId` (UR traffic audit) | It is the sign-in name, not the profile ID | Profile ID is `profileid=` inside `trackingIds{}`; search `TERM(profileid=<id>)` |
| `trackingIds{}` | Braces break `eval` | Quote it in `fields`/`table`; never `eval` on it |
| `sessionid` inside `trackingIds{}` | Not the UR `sessionId` | Do not join them |
| `responseTimeMs` / `response.elapsedTime` | Milliseconds (UR is microseconds) | Convert before comparing |
| `AMSESSION` | A masked session token | `dc()` counts sessions, not people; not a UR join key |

## Reading outcomes

- One failure then a success is a normal token refresh. Repeated failures with no success is a
  session problem.
- A gateway 504 at about 15,000 ms with a UR access 200 for the same request is the Identity
  Gateway timing out, not a UR fault.
- The ForgeRock event precedes the UR request by up to 10 s; widen backward when pivoting from UR.
- CAAS 500s spread evenly across `ENV1` pods is a shared backend fault; one pod is an instance fault.
