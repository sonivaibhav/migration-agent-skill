# Put a file here with the same name as one in core/references/ to replace it for this seal.
# Replace semantics only. Additive practice belongs in notes.md.
