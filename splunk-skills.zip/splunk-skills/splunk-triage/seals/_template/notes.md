# <Name> Notes

Field traps, decode tables, environment differences, failure signatures.
Prose only; the field map is fields.yaml.
