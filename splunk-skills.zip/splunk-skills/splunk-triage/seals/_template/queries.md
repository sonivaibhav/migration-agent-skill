# <Name> Recipes

Standard questions need no recipe: `build_query.py --seal <SEAL_ID> --step <0-5> --kind errors|latency|volume`.
Add a recipe only for SPL that encodes something the builder cannot derive: a filter string, a
`rex`, a special search key. Keep each under 8 lines; end an event list with `| head 20 | table`.

| Recipe | Use when |
|---|---|
| _none yet_ | |

---
