#!/usr/bin/env python3
"""Reference implementation of the CLI guard layer. The real splunk_cli.py MUST
route every search through these, in this order; tests/security pins them.

    check_spl(spl, limits)                  raises GuardError before anything runs
    Redactor(...).redact_rows(rows, spl)    visibility, masks, truncation, projection, decode
    format_table(rows)                      compact text output for the agent
    Budget(path).add(rows, bytes)           per-run counter; warns when a run gets expensive

Pure Python; stdlib + PyYAML; no network.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from datetime import datetime

from _common import load_yaml, registry, seals_for_indexes, ORG

# ------------------------------------------------------------------ SPL guard

WRITE_COMMANDS = {
    "outputlookup", "collect", "sendemail", "delete", "outputcsv", "rest", "script", "runshellscript",
    "map", "savedsearch", "dbxquery", "summaryindex", "mcollect", "meventcollect", "outputtext", "sendalert",
}
PROJECTING = {"table", "fields", "stats", "timechart", "chart", "top", "rare", "eventstats"}
_PIPE_SPLIT = re.compile(r"\|(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)")
_FIRST_WORD = re.compile(r"^\s*([A-Za-z_]+)")
_EARLIEST = re.compile(r"\bearliest\s*=\s*(\S+)")
_INDEX = re.compile(r"\bindex\s*(?:=|\s+IN\s*\()\s*([A-Za-z0-9_*,\s\"']+)", re.I)
_REL_WINDOW = re.compile(r"^-(\d+)([smhdw])(@\w+)?$")
_LATEST = re.compile(r"\blatest\s*=\s*(\S+)")
_ABS = re.compile(r'^"?(\d{2}/\d{2}/\d{4}:\d{2}:\d{2}:\d{2})"?$')
_ABS_FMT = "%m/%d/%Y:%H:%M:%S"
_HEAD = re.compile(r"\|\s*head\s+(\d+)", re.I)
_AGG_CMDS = {"stats", "timechart", "chart", "top", "rare", "tstats", "eventstats"}


class GuardError(Exception):
    """Raised before the query leaves the machine. Exit code 3."""


@dataclass
class Limits:
    max_rows: int = 1000
    max_window_hours: float = 24
    confirm_window: bool = False
    max_results: int | None = None
    raw: bool = False
    context: str | None = None

    @classmethod
    def from_org(cls, **over) -> "Limits":
        lim = load_yaml(ORG).get("limits", {}) if ORG.exists() else {}
        return cls(max_rows=lim.get("max_rows", 1000), max_window_hours=lim.get("max_window_hours", 24), **over)


def _abs(s: str) -> datetime | None:
    m = _ABS.match(s.strip())
    return datetime.strptime(m.group(1), _ABS_FMT) if m else None


def window_hours(earliest: str, latest: str | None) -> float | None:
    """Width of the search window in hours. None means 'cannot tell', which the guard treats as too wide.
    Relative: -15m, -1h, -1d@d (a snap adds one unit, conservatively). Absolute: "11/07/2026:14:05:00"
    with latest absolute or now. earliest=0 / 1 / @d-only are all-time or unparseable: None."""
    m = _REL_WINDOW.match(earliest.strip())
    if m:
        n, unit, snap = int(m.group(1)), m.group(2), m.group(3)
        per = {"s": 1 / 3600, "m": 1 / 60, "h": 1, "d": 24, "w": 168}[unit]
        return n * per + (per if snap else 0)
    e = _abs(earliest)
    if e is None:
        return None
    if latest is None or latest.strip().lower() == "now":
        return max((datetime.now() - e).total_seconds() / 3600, 0)
    l = _abs(latest)
    if l is None:
        lm = _REL_WINDOW.match(latest.strip())
        if lm:                                 # absolute earliest, relative latest: width to now is the upper bound
            return max((datetime.now() - e).total_seconds() / 3600, 0)
        return None
    return max((l - e).total_seconds() / 3600, 0)


def pipe_segments(spl: str) -> list[str]:
    return [s.strip() for s in _PIPE_SPLIT.split(spl) if s.strip()]


def indexes_in(spl: str) -> list[str]:
    out: list[str] = []
    for m in _INDEX.finditer(spl):
        for tok in re.split(r"[,\s]+", m.group(1).strip().strip(")")):
            tok = tok.strip("\"'")
            if tok:
                out.append(tok)
    return out


def owning_seals(spl: str, seals: dict | None = None) -> set[str]:
    idx = set(indexes_in(spl))
    if seals is not None:
        return {sid for sid, s in seals.items() if idx & {i["name"] for i in s["seal"].get("indexes", [])}}
    return {r["id"] for r in registry().get("seals", []) if idx & set(r.get("indexes", []))}


_CREATED = re.compile(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>|\beval\s+([A-Za-z_][A-Za-z0-9_]*)\s*=|\bas\s+\"?([A-Za-z_][A-Za-z0-9_]*)\"?", re.I)


_AGG_OUT = re.compile(r"^(count|percent|dc|distinct_count|avg|mean|sum|min|max|median|mode|stdev|var|range|"
                      r"p\d+|perc\d+|exactperc\d+|earliest|latest|first|last|values|list|estdc)(\(.*\))?$", re.I)


def created_fields(spl: str) -> set[str]:
    """Names the SPL itself creates: rex groups, eval targets, 'as' aliases. Never dropped by projection."""
    return {g for m in _CREATED.finditer(spl) for g in m.groups() if g}


def is_created(name: str, spl: str, created: set[str]) -> bool:
    """A field the SPL produced (an alias, an eval, a rex group, or an aggregate output like count)."""
    return name in created or (_AGG_OUT.match(name) is not None and any(
        _FIRST_WORD.match(seg) and _FIRST_WORD.match(seg).group(1).lower() in _AGG_CMDS for seg in pipe_segments(spl)[1:]))


def has_projection(spl: str) -> bool:
    for seg in pipe_segments(spl)[1:]:
        w = _FIRST_WORD.match(seg)
        if w and w.group(1).lower() in PROJECTING:
            return True
    return False


def check_spl(spl: str, limits: Limits) -> dict:
    """Return {'effective_max_rows': int} or raise GuardError."""
    s = spl.strip()
    if not s:
        raise GuardError("empty SPL")
    if s.startswith("|"):
        head = _FIRST_WORD.match(s[1:])
        if not head or head.group(1).lower() != "makeresults":
            raise GuardError("SPL may start with 'index=', 'search', or '| makeresults' only")
        return {"effective_max_rows": 1}
    head = _FIRST_WORD.match(s)
    if not (s.lower().startswith("index=") or (head and head.group(1).lower() == "search")):
        raise GuardError("SPL must start with 'index=' or the word 'search' (the CLI prepends 'search' only before 'index=')")
    idx = indexes_in(s)
    if not idx:
        raise GuardError("index= is required in the base search")
    if any(i == "*" or i.startswith("*") for i in idx):
        raise GuardError("index=* or a leading wildcard scans every index; name the index")
    m = _EARLIEST.search(s)
    if not m:
        raise GuardError("earliest= is required in the base search")
    lm = _LATEST.search(s)
    hours = window_hours(m.group(1), lm.group(1) if lm else None)
    if not limits.confirm_window:
        if hours is None:
            raise GuardError(f"cannot tell how wide earliest={m.group(1)} is (all-time, or an unparsed form); "
                             f"use -15m/-1h/-24h or an absolute \"mm/dd/yyyy:HH:MM:SS\" pair, or ask the user and pass --confirm-window")
        if hours > limits.max_window_hours:
            raise GuardError(f"window {m.group(1)} is about {hours:.0f}h, over the {limits.max_window_hours:.0f}h cap; "
                             f"ask the user, then pass --confirm-window")

    segs = pipe_segments(s)
    for seg in segs[1:]:
        w = _FIRST_WORD.match(seg)
        cmd = w.group(1).lower() if w else ""
        if cmd in WRITE_COMMANDS:
            raise GuardError(f"command '{cmd}' is not allowed (read-only skill)")
        if cmd == "inputlookup" and "append=" in seg.lower():
            raise GuardError("inputlookup append= is not allowed")

    if limits.raw:
        hm = _HEAD.search(s)
        if not hm or int(hm.group(1)) > 5:
            raise GuardError("--raw needs '| head N' with N <= 5")
        owners = owning_seals(s)
        if len(owners) != 1 or limits.context != next(iter(owners)):
            raise GuardError("--raw works on one seal's index at a time, with --context set to that owning seal "
                             f"(indexes here belong to: {', '.join(sorted(owners)) or 'no registered seal'})")

    last_cmd = ""
    for seg in reversed(segs[1:]):
        w = _FIRST_WORD.match(seg)
        if w and w.group(1).lower() not in {"sort", "head", "table", "fields", "rename", "eval", "where", "fillnull"}:
            last_cmd = w.group(1).lower()
            break
    effective = limits.max_rows
    if limits.max_results and limits.max_results > limits.max_rows:
        if last_cmd not in _AGG_CMDS:
            raise GuardError("--max-results above the cap is allowed only for an aggregate query")
        effective = limits.max_results
    return {"effective_max_rows": effective}


# ------------------------------------------------------------------ redaction

NEVER_FIELDS = {"ssn", "socialSecurityNumber", "cardNumber", "pan", "accountNumber", "dob", "dateOfBirth"}
CORE_SUPPRESS = {"_raw", "punct", "splunk_server", "linecount", "timestartpos", "timeendpos",
                 "index", "sourcetype", "source", "host", "eventtype", "tag"}
HTTP_STATUS = {"200": "ok", "201": "created", "204": "no content", "301": "redirect", "302": "redirect",
               "304": "not modified", "400": "bad request", "401": "sign-in required", "403": "forbidden",
               "404": "not found", "408": "request timeout", "409": "conflict", "422": "invalid input",
               "429": "rate limited", "500": "server error", "502": "bad gateway", "503": "unavailable",
               "504": "gateway timeout"}
_PAN = re.compile(r"(?<!\d)\d{13,19}(?!\d)")
_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_SSN = re.compile(r"(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)")
REDACTED = "[redacted]"
DEFAULT_TEXT_CAP = 200


def _luhn(digits: str) -> bool:
    total, alt = 0, False
    for ch in reversed(digits):
        d = int(ch)
        if alt:
            d = d * 2 - 9 if d * 2 > 9 else d * 2
        total += d
        alt = not alt
    return total % 10 == 0


def pattern_guard(value: str) -> str:
    value = _PAN.sub(lambda m: REDACTED if _luhn(m.group()) else m.group(), value)
    value = _SSN.sub(REDACTED, value)
    value = _EMAIL.sub(REDACTED, value)
    return value


def truncate(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    return value[:limit] + f"…[+{len(value) - limit} chars]"


@dataclass
class Redactor:
    context: str | None = None
    raw: bool = False
    focus: str | None = None
    salt: bytes = field(default_factory=lambda: os.urandom(16))
    seals: dict | None = None                 # injected in tests; otherwise loaded per query from the registry
    _KV = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)=(.+)$")

    def _rules_for(self, indexes: list[str]):
        """field -> rule (stricter visibility wins across seals), suppress set, projection list.
        Loads only the seals that own the indexes in the query."""
        rules: dict[str, dict] = {}
        suppress = set(CORE_SUPPRESS)
        projection: list[str] = []
        rank = {"never": 3, "owner": 2, "public": 1}
        owners = self.seals if self.seals is not None else seals_for_indexes(indexes)
        for sid, s in owners.items():
            owns = {i["name"] for i in s["seal"].get("indexes", [])}
            if not (owns & set(indexes)):
                continue
            f = s["fields"] or {}
            suppress |= set(f.get("suppress", []) or [])
            if not projection:
                projection = list((f.get("focus") or {}).get(self.focus or "", []) or f.get("defaults") or [])
            for st in (f.get("sourcetypes") or {}).values():
                for fld in (st or {}).get("fields", []) or []:
                    r = {**fld, "_owner": sid}
                    key = str(fld["raw"])
                    prev = rules.get(key)
                    if prev is None or rank.get(r.get("visibility", "public"), 1) > rank.get(prev.get("visibility", "public"), 1):
                        rules[key] = r
        return rules, suppress, projection

    def _hash(self, v: str) -> str:
        return hmac.new(self.salt, v.encode("utf-8"), hashlib.sha256).hexdigest()[:12]

    def _mask(self, v: str, mask: str) -> str:
        if mask == "none":
            return v
        if mask == "hash":
            kv = self._KV.match(v)
            return f"{kv.group(1)}={self._hash(kv.group(2))}" if kv else self._hash(v)
        if mask == "last4":
            return "…" + v[-4:] if len(v) > 4 else REDACTED
        return REDACTED

    @staticmethod
    def _decode(v: str, rule: dict | None) -> str:
        if rule is None:
            return v
        table = rule.get("decode")
        if table:
            if v in ("", "-"):
                return "(missing)"
            return f"{v} ({table[v]})" if v in table else f"{v} (unknown)"
        if rule.get("display") == "HTTP Status" and v in HTTP_STATUS:
            return f"{v} ({HTTP_STATUS[v]})"
        return v

    def redact_rows(self, rows: list[dict], spl: str, json_mode: bool = False) -> list[dict]:
        rules, suppress, projection = self._rules_for(indexes_in(spl))
        project = bool(projection) and not has_projection(spl) and not self.raw
        keep = set(projection) | created_fields(spl)
        out = []
        for row in rows:
            new = {}
            for k, v in row.items():
                if k == "_raw" and self.raw:
                    new[k] = pattern_guard(truncate(str(v), 2000))
                    continue
                if k in suppress:
                    continue
                if k.startswith("_") and k != "_time":
                    continue
                if k == "_time" and not json_mode:
                    continue
                if project and k != "_time" and k not in keep:
                    continue
                if v is None:
                    new[k] = v
                    continue
                vals = v if isinstance(v, list) else [v]
                r = rules.get(k)
                if r is None and is_created(k, spl, keep):
                    red = [pattern_guard(str(x)) for x in vals]      # a number the query computed, print it
                    new[k] = red if (isinstance(v, list) and len(red) > 1) else red[0]
                    continue
                if k in NEVER_FIELDS or (r and r.get("visibility") == "never"):
                    new[k] = REDACTED
                    continue
                if r and r.get("visibility") == "owner":
                    if self.context != r["_owner"]:
                        new[k] = REDACTED
                        continue
                    mask = "none"
                elif r is None:
                    mask = "hash"
                else:
                    mask = r.get("mask", "none" if r.get("pii") == "none" else "hash")
                is_text = bool(r and (r.get("text") or r.get("max_chars")))
                if is_text and not self.raw and len(vals) > 1:
                    vals = vals[:1]
                red = [self._mask(str(x), mask) for x in vals]
                if mask == "none":
                    red = [pattern_guard(x) for x in red]
                    if is_text and not self.raw:
                        cap = int((r or {}).get("max_chars", DEFAULT_TEXT_CAP))
                        red = [truncate(x, cap) for x in red]
                    red = [self._decode(x, r) for x in red]
                new[k] = red if (isinstance(v, list) and len(red) > 1) else red[0]
            out.append(new)
        return out


# ------------------------------------------------------------------ output

def format_table(rows: list[dict]) -> str:
    """Header once, one row per line, identical consecutive rows collapsed with ×N."""
    if not rows:
        return "(0 rows)"
    cols: list[str] = []
    for r in rows:
        for k in r:
            if k not in cols:
                cols.append(k)
    lines = [" | ".join(cols)]
    prev, rep = None, 0

    def cell(v):
        return ", ".join(map(str, v)) if isinstance(v, list) else ("" if v is None else str(v))

    for r in rows:
        line = " | ".join(cell(r.get(c)) for c in cols)
        if line == prev:
            rep += 1
            continue
        if rep:
            lines[-1] += f"  ×{rep + 1}"
            rep = 0
        lines.append(line)
        prev = line
    if rep:
        lines[-1] += f"  ×{rep + 1}"
    lines.append(f"({len(rows)} rows)")
    return "\n".join(lines)


# ------------------------------------------------------------------ budget

@dataclass
class Budget:
    """Per-run counter kept in a small JSON file. The CLI prints status() to stderr when it is not empty."""
    path: Path
    soft_rows: int = 300
    soft_bytes: int = 40_000

    def add(self, rows: int, nbytes: int) -> dict:
        state = {"rows": 0, "bytes": 0, "queries": 0, "started": time.time()}
        if self.path.exists():
            try:
                state.update(json.loads(self.path.read_text()))
            except Exception:
                pass
        state["rows"] += rows
        state["bytes"] += nbytes
        state["queries"] += 1
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(state))
        return state

    def status(self, state: dict) -> str:
        if state["rows"] > self.soft_rows or state["bytes"] > self.soft_bytes:
            return (f"budget: {state['queries']} queries, {state['rows']} rows, {state['bytes'] // 1000} KB this run. "
                    f"Aggregate (stats) before sampling again.")
        return ""
