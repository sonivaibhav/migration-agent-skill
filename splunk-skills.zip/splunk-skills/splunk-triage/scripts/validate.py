#!/usr/bin/env python3
"""Validate seals, links, journeys, and markdown. Exit 1 on any error.

Checks
  - every seal.yaml / fields.yaml / links.yaml / journey matches its JSON schema
    (jsonschema package optional; structural checks still run without it)
  - folder name is <id>-<name> and matches seal.yaml
  - every link.to is a known seal (or a <PLACEHOLDER> for status: placeholder)
  - every journey hop resolves to <seal>/<link id>
  - fields.yaml never lowers a core 'never' field, never sets owner on another seal's field
  - no clear identifiers in example files (long digit runs that pass Luhn, emails)
  - every ```spl block has index= and earliest= (or starts with '| makeresults')
  - core/ never mentions the org name or an instance host
  - seal overrides/ only contain filenames that exist in core/references/
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from _common import SKILL_DIR, SEALS_DIR, ORG, load_journeys, load_seals, load_yaml, find_link

SCHEMAS = SKILL_DIR / "core" / "schemas"
CORE_REFS = SKILL_DIR / "core" / "references"
NEVER_FIELDS = {"ssn", "socialSecurityNumber", "cardNumber", "pan", "accountNumber", "dob", "dateOfBirth"}

errors: list[str] = []
warnings: list[str] = []


def err(msg: str) -> None:
    errors.append(msg)


def warn(msg: str) -> None:
    warnings.append(msg)


def schema_check(obj, schema_name: str, where: str) -> None:
    try:
        import jsonschema  # type: ignore
    except ImportError:
        return
    schema = json.loads((SCHEMAS / schema_name).read_text(encoding="utf-8"))
    for e in jsonschema.Draft202012Validator(schema).iter_errors(obj):
        err(f"{where}: schema: {'/'.join(str(p) for p in e.path) or '<root>'}: {e.message}")


def luhn_ok(digits: str) -> bool:
    total, alt = 0, False
    for ch in reversed(digits):
        d = int(ch)
        if alt:
            d = d * 2 - 9 if d * 2 > 9 else d * 2
        total += d
        alt = not alt
    return total % 10 == 0


PAN = re.compile(r"(?<!\d)\d{13,19}(?!\d)")
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
SPL_BLOCK = re.compile(r"```spl\n(.*?)```", re.S)


def check_text_file(p: Path) -> None:
    text = p.read_text(encoding="utf-8", errors="replace")
    for m in PAN.finditer(text):
        if luhn_ok(m.group()):
            err(f"{p}: possible card number '{m.group()[:4]}…' in an example file")
    for m in EMAIL.finditer(text):
        if not m.group().endswith(("example.com", "example.org")):
            warn(f"{p}: email address '{m.group()}' in an example file")
    if p.suffix == ".md":
        for block in SPL_BLOCK.findall(text):
            b = block.strip()
            if b.startswith("|") or b.startswith("#"):
                continue
            if "index=" not in b and "index IN" not in b:
                err(f"{p}: spl block without index=: {b.splitlines()[0][:70]}")
            if "earliest=" not in b:
                err(f"{p}: spl block without earliest=: {b.splitlines()[0][:70]}")


def main() -> int:
    seals = load_seals()
    journeys = load_journeys()
    org = load_yaml(ORG) if ORG.exists() else {}

    # seals
    for sid, s in seals.items():
        d, meta = s["dir"], s["seal"]
        where = f"seals/{d.name}"
        schema_check(meta, "seal.schema.json", f"{where}/seal.yaml")
        expected = f"{sid}-{meta.get('name')}"
        if d.name != expected:
            err(f"{where}: folder should be '{expected}' to match seal.yaml")
        if meta.get("instance_group") not in {i.get("group") for i in org.get("instances", [])}:
            err(f"{where}/seal.yaml: instance_group '{meta.get('instance_group')}' not in org.yaml")
        for req in ("fields.yaml", "links.yaml", "alerts.yaml", "notes.md", "queries.md"):
            if not (d / req).exists():
                err(f"{where}: missing {req}")
        # fields
        f = s["fields"]
        if f:
            schema_check(f, "fields.schema.json", f"{where}/fields.yaml")
            if str(f.get("seal")) != sid:
                err(f"{where}/fields.yaml: seal '{f.get('seal')}' != {sid}")
            envs = {i.get("environment") for i in org.get("instances", [])}
            for st, body in (f.get("sourcetypes") or {}).items():
                declared = {str(x.get("raw")) for x in (body or {}).get("fields", []) or []}
                for role, fld_name in ((body or {}).get("roles") or {}).items():
                    if str(fld_name).strip('"') not in declared:
                        err(f"{where}/fields.yaml: {st} role {role}={fld_name} is not a declared field")
                for env in (body or {}).get("indexed_in", []) or []:
                    if env not in envs:
                        err(f"{where}/fields.yaml: {st} indexed_in '{env}' is not an environment in org.yaml ({', '.join(sorted(e for e in envs if e))})")
                for fld in (body or {}).get("fields", []) or []:
                    raw = str(fld.get("raw", ""))
                    if raw in NEVER_FIELDS and fld.get("visibility", "public") != "never":
                        err(f"{where}/fields.yaml: '{raw}' is on the core never-list; visibility cannot be lowered")
                    if fld.get("pii") == "direct" and fld.get("visibility", "public") == "public" and fld.get("mask", "hash") == "none":
                        err(f"{where}/fields.yaml: '{raw}' is pii: direct but public and unmasked")
                    if fld.get("pii") == "none" and fld.get("visibility") == "owner":
                        warn(f"{where}/fields.yaml: '{raw}' is pii: none but owner-only; intended?")
        # links
        l = s["links"]
        schema_check(l, "links.schema.json", f"{where}/links.yaml")
        ids = set()
        for link in l.get("links", []) or []:
            lid = link.get("id")
            if lid in ids:
                err(f"{where}/links.yaml: duplicate link id '{lid}'")
            ids.add(lid)
            to = str(link.get("to", ""))
            if to.startswith("<"):
                if link.get("status") != "placeholder":
                    err(f"{where}/links.yaml:{lid}: placeholder destination but status is not placeholder")
            elif to not in seals:
                err(f"{where}/links.yaml:{lid}: unknown destination seal '{to}'")
            if link.get("status") == "placeholder" and not link.get("verify_query"):
                warn(f"{where}/links.yaml:{lid}: placeholder without verify_query")
        # overrides
        ov = d / "overrides"
        if ov.exists():
            for p in ov.iterdir():
                if p.name != "README.md" and not (CORE_REFS / p.name).exists():
                    err(f"{where}/overrides/{p.name}: no matching file in core/references/")
        for p in d.rglob("*"):
            if p.is_file() and p.suffix in {".md", ".yaml", ".yml"}:
                check_text_file(p)

    # journeys
    for name, j in journeys.items():
        jj, p = j["journey"], j["path"]
        schema_check(jj, "journey.schema.json", str(p))
        if jj.get("name") != p.stem:
            err(f"{p}: name '{jj.get('name')}' != filename '{p.stem}'")
        if jj.get("entry") and jj["entry"] not in seals:
            err(f"{p}: entry seal '{jj['entry']}' unknown")
        for hop in jj.get("hops", []) or []:
            if find_link(seals, hop.get("link", "")) is None:
                err(f"{p}: hop '{hop.get('link')}' does not resolve")

    # journey triggers must not be bare seal aliases (they would hijack single-seal questions)
    alias_set = set()
    for sid, s in seals.items():
        alias_set |= {str(a).lower() for a in s["seal"].get("aliases", [])} | {str(s["seal"].get("name", "")).lower(), sid}
    for name, j in journeys.items():
        trigs = [str(x).lower() for x in j["journey"].get("triggers", []) or []]
        own = [x for x in trigs if x not in alias_set]
        if trigs and not own:
            err(f"{j['path']}: every trigger is also a seal alias; add at least one journey-specific phrase "
                f"(alias words never count toward a journey match)")
    # alerts.yaml
    for sid, s in seals.items():
        al = s.get("alerts") or {}
        if al:
            schema_check(al, "alerts.schema.json", f"seals/{s['dir'].name}/alerts.yaml")
            if str(al.get("seal")) != sid:
                err(f"seals/{s['dir'].name}/alerts.yaml: seal '{al.get('seal')}' != {sid}")
            for a in al.get("alerts", []) or []:
                if a.get("first_query") and ("earliest=" not in a["first_query"] or "index=" not in a["first_query"]):
                    err(f"seals/{s['dir'].name}/alerts.yaml:{a.get('name')}: first_query needs index= and earliest=")

    # core must be org-neutral
    org_name = str(org.get("org", "")).strip()
    hosts = [i.get("url", "") for i in org.get("instances", [])]
    for p in (SKILL_DIR / "core").rglob("*.md"):
        text = p.read_text(encoding="utf-8")
        if org_name and re.search(rf"\b{re.escape(org_name)}\b", text):
            err(f"{p}: core/ mentions the org name '{org_name}'")
        for h in hosts:
            if h and h in text:
                err(f"{p}: core/ mentions instance host {h}")
        for sid in seals:
            if sid in text:
                warn(f"{p}: core/ mentions seal id {sid}")
        check_text_file(p)

    for w in warnings:
        print(f"WARN  {w}")
    for e in errors:
        print(f"ERROR {e}")
    print(f"\n{len(seals)} seals, {len(journeys)} journeys, {len(errors)} errors, {len(warnings)} warnings")
    return 1 if errors else 0


if __name__ == "__main__" and "--score" not in sys.argv:
    sys.exit(main())


# ------------------------------------------------------------------ completeness score
def score_seal(sid: str, seals: dict, journeys: dict) -> tuple[int, list[str]]:
    """0-100 and the list of what is missing. Used by --score and by onboard_seal.py."""
    s = seals[sid]
    f = s["fields"] or {}
    pts, missing = 0, []

    def check(cond, weight, what):
        nonlocal pts
        if cond:
            pts += weight
        else:
            missing.append(what)

    sts = f.get("sourcetypes") or {}
    active = [st for i in s["seal"].get("indexes", []) for st in i.get("sourcetypes", []) if st.get("status", "active") == "active"]
    check(any(len((sts.get(st["name"]) or {}).get("fields", []) or []) >= 5 for st in active), 10, "a sourcetype with at least 5 mapped fields")
    roles_all = {r for st in sts.values() for r in ((st or {}).get("roles") or {})}
    for role in ("status", "endpoint", "id", "trace"):
        check(role in roles_all, 8, f"roles.{role} on a sourcetype (build_query needs it)")
    check("latency" in roles_all or "message" in roles_all, 6, "roles.latency or roles.message")
    focus = f.get("focus") or {}
    check("errors" in focus, 8, "focus.errors")
    check(len(focus) >= 2, 4, "a second focus (latency / trace)")
    unconfirmed = [x["raw"] for st in sts.values() for x in ((st or {}).get("fields") or []) if "NOT CONFIRMED" in str(x.get("note", "")).upper()]
    check(not unconfirmed, 6, f"confirm units for: {', '.join(unconfirmed)}" if unconfirmed else "")
    links = (s["links"] or {}).get("links") or []
    check(bool(links), 6, "at least one outbound link (or a note that this seal calls nothing)")
    confirmed = sum(1 for l in links if l.get("status") == "confirmed")
    check(links and confirmed == len(links), 10, f"{len(links) - confirmed} placeholder link(s) to confirm in prod" if links else "")
    in_journey = any(hop["link"].split("/")[0] == sid or any(
        (l.get("to") == sid) for l in links) for j in journeys.values() for hop in j["journey"].get("hops", []))
    in_journey = in_journey or any(sid in {h["link"].split("/")[0] for h in j["journey"].get("hops", [])}
                                   or j["journey"].get("entry") == sid for j in journeys.values())
    check(in_journey, 8, "membership in at least one journey")
    alerts = (s.get("alerts") or {}).get("alerts") or []
    check(bool(alerts), 8, "at least one Splunk alert in alerts.yaml")
    notes = (s["dir"] / "notes.md").read_text(encoding="utf-8", errors="replace") if (s["dir"] / "notes.md").exists() else ""
    check("trap" in notes.lower(), 5, "a 'Field traps' section in notes.md (even 'none known')")
    q = (s["dir"] / "queries.md").read_text(encoding="utf-8", errors="replace") if (s["dir"] / "queries.md").exists() else ""
    check("```spl" in q, 5, "at least one recipe in queries.md")
    check(bool(s["seal"].get("owners")) and not any(str(o).startswith("<") for o in s["seal"]["owners"]), 4, "real owners in seal.yaml")
    check(bool(s["seal"].get("repos")), 4, "repos in seal.yaml (lets the agent find code for an exception)")
    return min(pts, 100), [m for m in missing if m]


def print_scores(only: str | None = None) -> None:
    seals, journeys = load_seals(), load_journeys()
    for sid in sorted(seals):
        if only and sid != only:
            continue
        pts, missing = score_seal(sid, seals, journeys)
        grade = "A" if pts >= 85 else "B" if pts >= 65 else "C" if pts >= 45 else "D"
        print(f"{sid} {seals[sid]['dir'].name:24s} {pts:3d}/100  {grade}")
        for m in missing:
            print(f"      - {m}")


if __name__ == "__main__" and "--score" in sys.argv:
    i = sys.argv.index("--score")
    print_scores(sys.argv[i + 1] if len(sys.argv) > i + 1 and not sys.argv[i + 1].startswith("-") else None)
    sys.exit(0)
