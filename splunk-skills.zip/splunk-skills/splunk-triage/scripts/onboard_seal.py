#!/usr/bin/env python3
"""Onboard a seal in one sitting: a few questions, a field list, and the files are drafted.

    onboard_seal.py                      # interactive
    onboard_seal.py --answers my.yaml    # same questions, from a file (template: --print-template)
    onboard_seal.py --print-template > my.yaml

What it does
  1. Asks for the seal id, name, aliases, index, sourcetypes, instance group, owners, volume, repos.
  2. Takes a field list (paste the output of the fieldsummary query, or a CSV/JSON from the CLI)
     and drafts fields.yaml: PII class, mask and visibility by name, roles by name, text caps.
     Every guess is marked `# check` so the owner reviews it; the safe default is hash.
  3. Asks what this app calls downstream -> placeholder links.yaml with a verify_query each.
  4. Asks for Splunk alert names -> alerts.yaml.
  5. Writes seal.yaml, notes.md (with the traps the heuristics noticed), queries.md (empty index),
     runs validate.py, build_registry.py, and prints the completeness score with what is missing.

Nothing here touches Splunk. The fieldsummary query to run first is printed by --fieldsummary <index> <sourcetype>.
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

import yaml

from _common import SEALS_DIR, SKILL_DIR, ORG, load_yaml

HERE = Path(__file__).resolve().parent

DIRECT = re.compile(r"(name|email|phone|mobile|addr|address|ssn|social|dob|birth|passport|license|account|acct|card|pan|iban|taxid|tin)", re.I)
NEVER = re.compile(r"^(ssn|socialSecurityNumber|cardNumber|pan|accountNumber|dob|dateOfBirth)$")
ID_LIKE = re.compile(r"(id$|_id|Id$|identifier|visitor|session|cookie|token|ip$|ipaddr|remote)", re.I)
TEXT = re.compile(r"(message|msg|text|description|exception|stack|trace$|error$|errors$|reason|detail|payload|body|useragent|user_agent|agent$|referer|referrer|url|uri$|path$)", re.I)
ROLE_PATTERNS = [
    ("status", re.compile(r"^(status|statusCode|status_code|httpCode|http_code|response\.statusCode|response_code|responseCode|code)$", re.I)),
    ("endpoint", re.compile(r"^(uri|uriPath|path|url|requestUri|endpoint|http\.endpoint|route|request_path|currentURL|message\.screen\.currentURL)$", re.I)),
    ("latency", re.compile(r"^(responseTime|responseTimeMs|response_time|duration|latency|elapsed|elapsedTime|took|time_ms|timeMs|response\.elapsedTime)$", re.I)),
    ("id", re.compile(r"(profile|customer|user).*id|^(profileId|profile_id|userId|user_id|smCigProfileId|online-profile-identifier)$", re.I)),
    ("trace", re.compile(r"(trace|transaction|correlation|request).?id$", re.I)),
    ("session", re.compile(r"session", re.I)),
    ("level", re.compile(r"^(level|loglevel|log_level|severity)$", re.I)),
    ("logger", re.compile(r"^(logger|class|category|component)$", re.I)),
    ("message", re.compile(r"^(message|msg|log\.message|message\.log\.message)$", re.I)),
    ("pod", re.compile(r"(pod|instance|container|host(name)?)$", re.I)),
    ("channel", re.compile(r"channel", re.I)),
]
NONE_PII = re.compile(r"^(status|code|method|level|logger|class|pod|host|region|env|environment|cluster|namespace|version|app|application|service|route|bytes|duration|latency|count|protocol|thread|port|zone)", re.I)
TIME_WORDS = re.compile(r"(time|duration|latency|elapsed|took)", re.I)


def display_name(raw: str) -> str:
    last = raw.split(".")[-1].replace("{}", "")
    words = re.sub(r"[_\-]", " ", re.sub(r"([a-z])([A-Z])", r"\1 \2", last)).split()
    s = " ".join(w if w.isupper() else w.capitalize() for w in words)
    return s.replace("Id", "ID").replace("Url", "URL").replace("Uri", "URI") or raw


def classify(raw: str) -> dict:
    """One field -> fields.yaml entry. Conservative: unknown => indirect/hash."""
    e: dict = {"raw": raw, "display": display_name(raw)}
    if raw == "_time":
        return {"raw": "_time", "display": "Time", "pii": "none", "mask": "none"}
    if NEVER.search(raw):
        e.update(pii="direct", visibility="never", mask="redact")
    elif TIME_WORDS.search(raw) and not DIRECT.search(raw):
        e.update(pii="none", mask="none", unit="ms", note="UNIT NOT CONFIRMED: ms guessed. Confirm against one raw event")
    elif DIRECT.search(raw) and not NONE_PII.match(raw):
        e.update(pii="direct", visibility="owner", mask="redact", note="check: direct PII guessed from the name")
    elif TEXT.search(raw):
        e.update(pii="indirect", mask="none", text=True, max_chars=300, note="check: free text guessed from the name")
    elif ID_LIKE.search(raw):
        e.update(pii="indirect", mask="hash", note="check: identifier guessed from the name")
    elif NONE_PII.match(raw):
        e.update(pii="none", mask="none")
    else:
        e.update(pii="indirect", mask="hash", note="check: unknown field, hidden behind a hash until reviewed")
    return e


def roles_for(fields: list[str]) -> dict:
    roles: dict = {}
    for role, pat in ROLE_PATTERNS:
        for f in fields:
            if role not in roles and pat.search(f):
                roles[role] = f
                break
    return roles


def parse_field_list(text: str) -> list[str]:
    """Accepts fieldsummary output (field count distinct_count), one-per-line, CSV header, or JSON list."""
    text = text.strip()
    if not text:
        return []
    if text.startswith("["):
        import json
        data = json.loads(text)
        return [d["field"] if isinstance(d, dict) else str(d) for d in data]
    out = []
    for line in text.splitlines():
        line = line.strip().strip("|").strip()
        if not line or line.lower().startswith(("field", "---")):
            continue
        tok = re.split(r"[\s,|]+", line)[0].strip('"')
        if tok and tok not in out:
            out.append(tok)
    return out


QUESTIONS = [
    ("id", "Seal ID (digits only)", None),
    ("name", "Short name, lowercase, used in the folder name (e.g. cashback)", None),
    ("description", "One line: what the application does", ""),
    ("aliases", "How people refer to it, comma separated (names, acronyms, the index name)", ""),
    ("index", "Splunk index name", None),
    ("sourcetypes", "Sourcetypes as name:kind, comma separated. kind = access | application | metrics | other", None),
    ("instance_group", "Instance group from org.yaml", "first"),
    ("owners", "Owning team or distribution list, comma separated", ""),
    ("volume", "Volume: low | medium | high (thousands of events per minute = high)", "high"),
    ("repos", "Source repo URLs, comma separated (optional)", ""),
    ("fields", "Field list: paste fieldsummary output, or a path to a file with it (optional)", ""),
    ("downstream", "What does this app call? seal_id:field_it_sends, comma separated (optional, e.g. 81712:frTraceId)", ""),
    ("alerts", "Splunk alert names configured for this seal, comma separated (optional)", ""),
]


def ask_all(answers: dict | None) -> dict:
    org = load_yaml(ORG) if ORG.exists() else {}
    groups = sorted({i.get("group") for i in org.get("instances", [])})
    out = {}
    for key, prompt, default in QUESTIONS:
        if answers is not None:
            val = answers.get(key, default)
        else:
            d = f" [{groups[0] if default == 'first' and groups else default}]" if default is not None else ""
            val = input(f"{prompt}{d}: ").strip() or (groups[0] if default == "first" and groups else default)
        if val is None or val == "":
            if default is None:
                raise SystemExit(f"{key} is required")
            val = groups[0] if default == "first" and groups else default
        out[key] = val
    return out


def split_list(v) -> list[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    return [x.strip() for x in str(v).split(",") if x.strip()]


def draft(a: dict) -> Path:
    sid, name = str(a["id"]).strip(), str(a["name"]).strip().lower()
    if not sid.isdigit():
        raise SystemExit("seal id must be digits")
    dest = SEALS_DIR / f"{sid}-{name}"
    if dest.exists():
        raise SystemExit(f"{dest} already exists")
    dest.mkdir(parents=True)
    (dest / "overrides").mkdir()
    (dest / "overrides" / "README.md").write_text("# A file here with the same name as one in core/references/ replaces it for this seal.\n")

    sts = []
    for item in split_list(a["sourcetypes"]):
        nm, _, kind = item.partition(":")
        sts.append({"name": nm.strip(), "kind": (kind.strip() or "application"), "status": "active"})
    aliases = split_list(a.get("aliases", "")) + [a["index"], sid]
    seal = {"id": sid, "name": name, "description": a.get("description") or f"{name} application logs",
            "apps": [name], "aliases": list(dict.fromkeys(aliases)), "app_aliases": {}, "id_patterns": {},
            "indexes": [{"name": a["index"], "sourcetypes": sts}],
            "instance_group": a["instance_group"], "owners": split_list(a.get("owners", "")) or ["<owning team>"],
            "volume": a.get("volume", "high"), "pii_class": "indirect"}
    repos = split_list(a.get("repos", ""))
    if repos:
        seal["repos"] = repos
    (dest / "seal.yaml").write_text(yaml.safe_dump(seal, sort_keys=False, allow_unicode=True, width=120))

    # fields
    raw_fields_text = a.get("fields", "") or ""
    if raw_fields_text and Path(raw_fields_text).exists():
        raw_fields_text = Path(raw_fields_text).read_text()
    field_names = parse_field_list(raw_fields_text)
    entries = [classify(f) for f in field_names if not f.startswith("_") or f == "_time"]
    if not any(e["raw"] == "_time" for e in entries):
        entries.insert(0, {"raw": "_time", "display": "Time", "pii": "none", "mask": "none"})
    roles = roles_for([e["raw"] for e in entries])
    for e in entries:                       # an endpoint is operational, not PII; keep the cap for query strings
        if e["raw"] == roles.get("endpoint"):
            e.update(pii="none", mask="none", text=True, max_chars=200)
            e.pop("note", None)
    errors_focus = ["_time"] + [roles[r] for r in ("status", "endpoint", "id", "trace") if r in roles]
    latency_focus = ["_time"] + [roles[r] for r in ("endpoint", "status", "latency") if r in roles]
    fields_doc = {"seal": sid, "defaults": list(errors_focus) if len(errors_focus) > 1 else ["_time"], "sample_rows": 20,
                  "focus": {"errors": list(errors_focus)} if len(errors_focus) > 1 else {}, "suppress": [], "sourcetypes": {}}
    if len(latency_focus) > 2 and "latency" in roles:
        fields_doc["focus"]["latency"] = list(latency_focus)
    first_st = sts[0]["name"] if sts else "<sourcetype>"
    fields_doc["sourcetypes"][first_st] = {"roles": roles, "fields": entries}
    for st in sts[1:]:
        fields_doc["sourcetypes"][st["name"]] = {"roles": {}, "fields": [{"raw": "_time", "display": "Time", "pii": "none", "mask": "none"}]}
    header = ("# Drafted by onboard_seal.py. Every line marked 'check' is a guess from the field name.\n"
              "# Safe default is hash. Review pii/visibility/mask, confirm units, fill roles for the other sourcetypes.\n")
    (dest / "fields.yaml").write_text(header + yaml.safe_dump(fields_doc, sort_keys=False, allow_unicode=True, width=140))

    # links
    links = []
    for item in split_list(a.get("downstream", "")):
        to, _, fld = item.partition(":")
        fld = fld.strip() or roles.get("trace", "<field>")
        links.append({"id": f"to-{to.strip()}", "to": to.strip(), "from": {"sourcetype": first_st, "field": fld},
                      "to_field": "<field on the destination side>", "kind": "request", "skew_s": {"before": 5, "after": 5},
                      "status": "placeholder",
                      "verify_query": f'search (index={a["index"]} {fld}="<X>") OR (index=<DEST_INDEX> <DEST_FIELD>="<X>") earliest=-1h latest=now\n| stats count by index, sourcetype',
                      "note": "Drafted by onboarding. Run verify_query in prod, fill to_field and skew, set status: confirmed."})
    (dest / "links.yaml").write_text("# Outbound edges: what this seal sends to other seals. The caller owns the edge.\n"
                                     + yaml.safe_dump({"seal": sid, "links": links}, sort_keys=False, allow_unicode=True, width=140))

    # alerts
    alerts = []
    for nm in split_list(a.get("alerts", "")):
        kind = "latency" if re.search(r"latenc|slow|p9\d|timeout", nm, re.I) else "errors" if re.search(r"error|5xx|fail|exception", nm, re.I) else "custom"
        al = {"name": nm, "means": "<one plain sentence: what fired and what users saw>", "kind": kind, "sourcetype": first_st,
              "severity_default": "Major", "then": "<what to check after the first query>"}
        if kind == "errors" and "status" in roles:
            al["where"] = f"{roles['status']}>=500"
        alerts.append(al)
    (dest / "alerts.yaml").write_text("# Splunk alerts configured for this seal.\n"
                                      + yaml.safe_dump({"seal": sid, "alerts": alerts}, sort_keys=False, allow_unicode=True, width=140))

    # notes + queries
    traps = []
    for e in entries:
        if "UNIT NOT CONFIRMED" in str(e.get("note", "")):
            traps.append(f"- `{e['raw']}`: unit guessed as ms. Confirm against one raw event before reporting latency.")
        if e.get("visibility") == "owner":
            traps.append(f"- `{e['raw']}`: treated as direct PII; only `--context {sid}` sees it. Change in fields.yaml if that is wrong.")
    (dest / "notes.md").write_text(f"# {display_name(name)} Notes\n\n{seal['description']}\n\n## Field traps\n\n"
                                   + ("\n".join(traps) if traps else "- None known yet. Add one line per field whose name does not describe its value.")
                                   + "\n\n## Failure signatures\n\n| Symptom | Probable layer | Next step |\n|---|---|---|\n| | | |\n")
    (dest / "queries.md").write_text(f"# {display_name(name)} Recipes\n\nStandard questions need no recipe: `build_query.py --seal {sid} --step 1 --kind errors`.\n"
                                     "Add a recipe only for SPL that encodes knowledge the builder cannot derive (a filter string, a rex, a special key).\n\n"
                                     "## Recipes\n\n_None yet._\n")
    return dest


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--answers", help="YAML file with the answers (see --print-template)")
    ap.add_argument("--print-template", action="store_true")
    ap.add_argument("--fieldsummary", nargs=2, metavar=("INDEX", "SOURCETYPE"), help="print the SPL that lists fields")
    a = ap.parse_args()
    if a.print_template:
        print("# Answers for onboard_seal.py --answers this.yaml")
        for key, prompt, default in QUESTIONS:
            print(f"{key}: {'' if default in (None, 'first') else repr(default)}   # {prompt}")
        return 0
    if a.fieldsummary:
        idx, st = a.fieldsummary
        print(f"index={idx} sourcetype={st} earliest=-5m latest=now\n| head 500\n| fieldsummary maxvals=0\n| where count>0\n| table field, count, distinct_count\n| sort - count")
        print("\n# Paste the 'field' column (or the whole output) as the 'fields' answer.")
        return 0
    answers = yaml.safe_load(Path(a.answers).read_text()) if a.answers else None
    dest = draft(ask_all(answers))
    print(f"\ncreated {dest.relative_to(SKILL_DIR)}/")
    subprocess.run([sys.executable, str(HERE / "validate.py")], cwd=SKILL_DIR)
    subprocess.run([sys.executable, str(HERE / "build_registry.py")], cwd=SKILL_DIR)
    print()
    subprocess.run([sys.executable, str(HERE / "validate.py"), "--score", dest.name.split("-")[0]], cwd=SKILL_DIR)
    print("\nNext: review every 'check' line in fields.yaml, run each verify_query in prod, fill alerts 'means' and 'then'. Commit all files plus registry.yaml.")
    print("Optional, once it works: run '| tstats count where index=<index> sourcetype=<sourcetype> earliest=-15m latest=now by <status field>' in prod;"
          " if it matches the stats version, add 'indexed_in: [prod]' to that sourcetype in fields.yaml and volume checks stop reading events.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
