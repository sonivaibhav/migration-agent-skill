#!/usr/bin/env python3
"""Compose a standard-step SPL from a seal's fields.yaml. No Splunk, no LLM.

    build_query.py --seal 89592 --step 1 --kind errors
    build_query.py --seal 89592 --step 3 --kind errors --where 'uri="/rewards-activity"'
    build_query.py --seal 89592 --step 4 --key frTraceId --value abc-7
    build_query.py --seal 111863 --sourcetype rpex_aws_rbes_st --step 1 --kind latency
    build_query.py --seal 89592 --step 1 --kind errors --baseline
    build_query.py --seal 89592 --step 1 --kind errors --around "2026-11-07 14:05" --span 30m

Steps (triage ladder): 0 count · 1 breakdown · 2 signature · 3 sample · 4 trace · 5 raw.
Kinds: errors · latency · volume. The sourcetype's `roles:` say which field is the
status, endpoint, latency, id, trace, level, logger, message, pod.

Prints the SPL, then three plain lines (filters / groups / shows) for the report.
--json prints {"spl", "explain", "baseline_spl"}.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime, timedelta

from _common import load_seal, load_yaml, ORG

SPECIAL = re.compile(r"[.\-{}\s]")
REL = re.compile(r"^-(\d+)([smhd])$")
UNIT_DIV = {"us": 1000, "ms": 1, "s": 0.001}


class BuildError(Exception):
    pass


def q(field: str) -> str:
    """Quote a field name for fields/table/by when it has a dot, hyphen or braces."""
    return f'"{field}"' if SPECIAL.search(field) else field


def eq(field: str) -> str:
    """Field reference inside eval/where: single quotes when special."""
    return f"'{field}'" if SPECIAL.search(field) else field


def norm_window(win: str) -> str:
    """Accept '2h' or '-2h'; return '-2h'."""
    win = win.strip()
    return win if win.startswith("-") else "-" + win


def rel_minutes(win: str) -> int:
    win = norm_window(win)
    m = REL.match(win)
    if not m:
        raise BuildError(f"window must be relative like -15m or -1h, got {win}")
    n, u = int(m.group(1)), m.group(2)
    return n * {"s": 0, "m": 1, "h": 60, "d": 1440}[u] or 1


def baseline_window(win: str) -> str:
    """Same width, one week earlier. -1h -> earliest=-10140m latest=-10080m."""
    w = rel_minutes(win)
    return f"earliest=-{10080 + w}m latest=-10080m"


SPLUNK_ABS = "%m/%d/%Y:%H:%M:%S"


def parse_clock_or_date(s: str) -> datetime:
    for f in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M", "%H:%M"):
        try:
            t = datetime.strptime(s, f)
            if f == "%H:%M":
                now = datetime.now()
                t = t.replace(year=now.year, month=now.month, day=now.day)
                if t > now:                      # "at 2pm" said in the morning means yesterday 2pm
                    t -= timedelta(days=1)
            return t
        except ValueError:
            continue
    raise BuildError(f"time must look like 'YYYY-MM-DD HH:MM' or 'HH:MM', got {s}")


def around_window(around: str, span: str) -> str:
    """Absolute window centred on a time, in the user's local TZ (Splunk reads it in the search head's user TZ)."""
    t = parse_clock_or_date(around)
    half = timedelta(minutes=rel_minutes("-" + span.lstrip("-")) / 2)
    return f'earliest="{(t - half).strftime(SPLUNK_ABS)}" latest="{(t + half).strftime(SPLUNK_ABS)}"'


def since_window(since: str) -> str:
    """From a time until now."""
    return f'earliest="{parse_clock_or_date(since).strftime(SPLUNK_ABS)}" latest=now'


class Builder:
    def __init__(self, seal_id: str, sourcetype: str | None = None, prefer: str = "access", key: str | None = None,
                 app: str | None = None, env: str | None = None):
        rec = load_seal(seal_id)
        if rec is None:
            raise BuildError(f"unknown seal {seal_id}")
        self.seal = rec
        self.app = app
        self.env = env
        self.meta = self.seal["seal"]
        self.fields = self.seal["fields"] or {}
        self.org = load_yaml(ORG) if ORG.exists() else {}
        self.index, self.sourcetype, self.kind_of_st = self._pick_sourcetype(sourcetype, prefer, key)
        st = (self.fields.get("sourcetypes") or {}).get(self.sourcetype) or {}
        self.roles: dict = st.get("roles") or {}
        self.declared = {f["raw"]: f for f in st.get("fields", []) or []}
        self.sample_rows = int(self.fields.get("sample_rows", 20))
        self.top_rows = int(self.fields.get("top_rows", 20))
        # tstats reads the index summary (tsidx) instead of events: near-free on a high-volume index, but it
        # returns 0 for a field that is not indexed. The owner lists the environments where the sourcetype's
        # fields are indexed (INDEXED_EXTRACTIONS) after checking; without that, every query reads events.
        self.tstats_ok = bool(env) and env in (st.get("indexed_in") or [])

    def _declares(self, st_name: str, field: str) -> bool:
        st = (self.fields.get("sourcetypes") or {}).get(st_name) or {}
        return any(f["raw"] == field for f in st.get("fields", []) or [])

    def _pick_sourcetype(self, want, prefer, key):
        """Explicit name wins. Else: a sourcetype that declares --key, else the preferred kind
        (access for errors/latency/volume, application for signatures), else the first active one."""
        active = [(idx["name"], st) for idx in self.meta.get("indexes", [])
                  for st in idx.get("sourcetypes", []) if st.get("status", "active") == "active"]
        if not active:
            raise BuildError(f"seal {self.meta['id']} has no active sourcetype")
        if self.app:                                       # "WL 500s" -> only the wl sourcetypes
            scoped = [(i, st) for i, st in active if st.get("app") == self.app]
            if scoped:
                active = scoped
        if want:
            for i, st in active:
                if st["name"] == want:
                    return i, st["name"], st.get("kind", "application")
            raise BuildError(f"sourcetype {want} not declared for seal {self.meta['id']}")
        if key:
            for i, st in active:
                if self._declares(st["name"], key):
                    return i, st["name"], st.get("kind", "application")
            raise BuildError(f"no sourcetype of seal {self.meta['id']} declares field {key}")
        for i, st in active:
            if st.get("kind") == prefer:
                return i, st["name"], st.get("kind", "application")
        i, st = active[0]
        return i, st["name"], st.get("kind", "application")

    # ----- helpers
    def role(self, name: str, required: bool = True) -> str | None:
        f = self.roles.get(name)
        if f is None and required:
            raise BuildError(f"seal {self.meta['id']}/{self.sourcetype} has no '{name}' role in fields.yaml; "
                             f"add roles.{name} or write the SPL by hand")
        return f

    def window(self, win: str | None) -> str:
        lim = self.org.get("limits", {})
        if win is None:
            win = lim.get("high_volume_window", "-15m") if self.meta.get("volume") == "high" else lim.get("default_window", "-1h")
        return norm_window(win)

    def focus_fields(self, focus: str | None) -> list[str]:
        focus_map = self.fields.get("focus") or {}
        wanted = focus_map.get(focus or "", None) or self.fields.get("defaults") or ["_time"]
        out = [f for f in wanted if f == "_time" or f in self.declared]
        return out or ["_time"]

    def text_caps(self, cols: list[str]) -> list[str]:
        """Cut free text on the indexers, keeping its full length in <field>_len so the CLI can print the
        usual cut marker (the ladder's 'read the full row' signal) without moving the text."""
        caps = []
        for c in cols:
            d = self.declared.get(c, {})
            if d.get("text"):
                n = int(d.get("max_chars", 200))
                caps.append(f"| eval {c}_len=len(mvindex({eq(c)}, 0)), {eq(c)}=substr(mvindex({eq(c)}, 0), 1, {n})")
        return caps

    def trend_span_ok(self, win: str, trend: str) -> None:
        """Keep a trend to at most 60 buckets so the result stays readable and small."""
        buckets = rel_minutes(win) / max(rel_minutes("-" + trend.lstrip("-")), 1)
        if buckets > 60:
            for span in ("1m", "5m", "15m", "30m", "1h", "4h", "1d"):
                if rel_minutes(win) / rel_minutes("-" + span) <= 60:
                    raise BuildError(f"--trend {trend} over {win} is {buckets:.0f} buckets; use --trend {span} (<= 60 buckets)")
            raise BuildError(f"--trend {trend} over {win} is too many buckets; widen the span")

    def default_where(self, kind: str) -> str:
        if kind == "errors":
            if self.kind_of_st == "access" or self.role("status", False):
                return f"{q(self.role('status'))}>=500"
            return f"{q(self.role('level'))}=ERROR"
        return ""

    # ----- steps
    def build(self, step: int, kind: str = "errors", where: str | None = None, window: str | None = None,
              focus: str | None = None, key: str | None = None, value: str | None = None,
              head: int | None = None, by: list[str] | None = None, collapse: bool = False,
              time_clause: str | None = None, trend: str | None = None) -> tuple[str, list[str]]:
        win = self.window(window)
        if trend and time_clause is None:
            self.trend_span_ok(win, trend)
        time_clause = time_clause or f"earliest={win} latest=now"
        base = f"index={self.index} sourcetype={self.sourcetype}"
        where = where if where is not None else ("" if step in (4, 5) else self.default_where(kind))
        if step in (4, 5) and key and value:
            where = f'{q(key)}="{value}"' + (f" {where}" if where else "")
        when = time_clause.replace('earliest=', 'from ').replace(' latest=', ' to ')
        top = head or self.top_rows

        # Pure counts with no filter can come from the index summary when the owner confirmed it is indexed here.
        if self.tstats_ok and not where and step in (0, 1) and (step == 0 or kind == "volume" or trend):
            lines = [f"| tstats count where {base} {time_clause}"]
            explain = [f"Filters: {self.sourcetype}, {when} (index summary only, no events read)"]
            if step == 0:
                explain += ["Groups: nothing; one number", "Shows: how many events the index holds for the window"]
            elif trend:
                col = (by or [None])[0]
                lines[0] += f" by _time span={trend}" + (f", {q(col)}" if col else "")
                explain += [f"Groups: by {trend} time bucket" + (f" and {col}" if col else ""), "Shows: how the volume moved over the window"]
            else:
                ep = self.role("endpoint")
                lines[0] += f" by {q(ep)}"
                lines += ["| sort - count", f"| head {top}"]
                explain += [f"Groups: by {ep}", f"Shows: request volume per endpoint, top {top}"]
            return "\n".join(lines), explain

        if where:
            base += f" {where}"
        base += f" {time_clause}"
        lines, explain = [base], []
        explain.append(f"Filters: {self.sourcetype}" + (f", {where}" if where else "") + f", {when}")

        if step == 0:
            lines += ["| stats count"]
            explain += ["Groups: nothing; one number", "Shows: how many events matched"]

        elif step == 1:
            if kind == "latency":
                lat, ep = self.role("latency"), self.role("endpoint")
                div = UNIT_DIV.get(self.declared.get(lat, {}).get("unit", "ms"), 1)
                lines += [f"| fields {q(ep)}, {q(lat)}", "| fields - _raw",
                          f"| stats p50({eq(lat)}) as p50, p95({eq(lat)}) as p95, p99({eq(lat)}) as p99, count by {q(ep)}"]
                if div != 1:
                    lines += [f"| eval p50_ms=round(p50/{div}, 1), p95_ms=round(p95/{div}, 1), p99_ms=round(p99/{div}, 1)",
                              f"| fields {q(ep)}, count, p50_ms, p95_ms, p99_ms", "| sort - p99_ms", f"| head {top}"]
                    explain += [f"Groups: by {ep}", f"Shows: latency percentiles in ms (raw {lat} is {self.declared.get(lat, {}).get('unit', 'ms')}), slowest {top} endpoints"]
                else:
                    lines += ["| sort - p99", f"| head {top}"]
                    explain += [f"Groups: by {ep}", f"Shows: latency percentiles in ms, slowest {top} endpoints"]
            elif kind == "volume":
                ep = self.role("endpoint")
                lines += [f"| fields {q(ep)}", "| fields - _raw", f"| stats count by {q(ep)}", "| sort - count", f"| head {top}"]
                explain += [f"Groups: by {ep}", f"Shows: request volume per endpoint, top {top}"]
            elif trend:
                col = (by or [None])[0] or self.role("status", False) or self.role("level", False) or self.role("logger")
                lines += [f"| fields _time, {q(col)}", "| fields - _raw", f"| bin _time span={trend}",
                          f"| stats count by _time, {q(col)}"]
                explain += [f"Groups: by {trend} time bucket and {col}", "Shows: how the count moved over the window; only non-zero cells"]
            else:
                cols = by or [c for c in (self.role("status", False), self.role("endpoint", False)) if c]
                if not cols:
                    cols = [self.role("logger")]
                lines += [f"| fields {', '.join(q(c) for c in cols)}", "| fields - _raw",
                          f"| stats count by {', '.join(q(c) for c in cols)}", "| sort - count", f"| head {top}"]
                explain += [f"Groups: by {', '.join(cols)}", f"Shows: how many errors of each kind, biggest {top} first"]

        elif step == 2:
            if self.role("logger", False):
                lg, msg = self.role("logger"), self.role("message", False)
                cols = [lg] + ([msg] if msg else [])
                lines += [f"| fields {', '.join(q(c) for c in cols)}", "| fields - _raw"]
                lines += self.text_caps(cols)
                lines += [f"| stats count by {', '.join(q(c) for c in cols)}", "| sort - count", f"| head {head or self.sample_rows}"]
                explain += [f"Groups: by {', '.join(cols)}", "Shows: the distinct error signatures, most frequent first"]
            else:
                cols = [c for c in (self.role("status", False), self.role("endpoint", False), self.role("pod", False)) if c]
                lines += [f"| fields {', '.join(q(c) for c in cols)}", "| fields - _raw",
                          f"| stats count by {', '.join(q(c) for c in cols)}", "| sort - count", f"| head {top}"]
                explain += [f"Groups: by {', '.join(cols)}", f"Shows: whether errors sit on one endpoint or one pod, top {top}"]

        elif step == 3:
            cols = self.focus_fields(focus or kind)
            sig = [c for c in (self.role("status", False), self.role("endpoint", False)) if c and c in cols]
            lines += [f"| fields {', '.join(q(c) for c in cols)}", "| fields - _raw"]
            lines += self.text_caps(cols)
            if sig:
                lines += [f"| dedup {', '.join(q(c) for c in sig)}"]
            lines += [f"| head {head or self.sample_rows}", f"| table {', '.join(q(c) for c in cols)}"]
            explain += [f"Groups: one row per distinct {' + '.join(sig) if sig else 'event'}", f"Shows: up to {head or self.sample_rows} examples with {', '.join(cols)}"]

        elif step == 4:
            if not (key and value):
                raise BuildError("step 4 needs --key and --value")
            cols = self.focus_fields(focus or "trace")
            if collapse:
                msg = self.role("message", False)
                agg = ["earliest(_time) as start", "latest(_time) as end", "count as lines"]
                for r in ("level", "logger", "status", "endpoint"):
                    f = self.role(r, False)
                    if f:
                        agg.append(f"values({eq(f)}) as {r}s")
                if msg:
                    agg.append(f"list({eq(msg)}) as messages")
                lines += [f"| stats {', '.join(agg)} by {q(key)}"]
                if msg:
                    lines += ["| eval messages=mvindex(messages, 0, 4)"]
                explain += [f"Groups: one row for {key}", "Shows: when it started and ended, how many lines, the first five messages"]
            else:
                lines += [f"| fields {', '.join(q(c) for c in cols)}", "| fields - _raw"]
                lines += self.text_caps(cols)
                lines += ["| sort 0 _time", f"| head {head or 50}", f"| table {', '.join(q(c) for c in cols)}"]
                explain += [f"Groups: every event for {key}, in time order", f"Shows: {', '.join(cols)}"]

        elif step == 5:
            if not (key and value):
                raise BuildError("step 5 needs --key and --value")
            lines += [f"| head {min(head or 5, 5)}", "| table _time, _raw"]
            explain += ["Groups: nothing", "Shows: the raw event, to confirm an extracted value. Run with --raw and --context <owning seal>"]
        else:
            raise BuildError("step must be 0-5")
        return "\n".join(lines), explain


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seal", required=True)
    ap.add_argument("--sourcetype")
    ap.add_argument("--step", type=int, required=True)
    ap.add_argument("--kind", default="errors", choices=["errors", "latency", "volume"])
    ap.add_argument("--where", help="SPL filter fragment; replaces the default for the kind")
    ap.add_argument("--window", help="how far back: 15m, 1h, 4h (leading '-' optional); default from org.yaml by volume")
    ap.add_argument("--around", help="centre time, 'YYYY-MM-DD HH:MM' or 'HH:MM' (your TZ)")
    ap.add_argument("--since", help="from this time until now, same formats as --around")
    ap.add_argument("--span", default="30m", help="width with --around")
    ap.add_argument("--app", help="restrict to this app's sourcetypes (seal.yaml apps), e.g. wl")
    ap.add_argument("--env", choices=["prod", "test"], help="lets pure counts use the index summary where fields.yaml says they are indexed")
    ap.add_argument("--focus"); ap.add_argument("--key"); ap.add_argument("--value")
    ap.add_argument("--head", type=int); ap.add_argument("--by", nargs="*")
    ap.add_argument("--collapse", action="store_true", help="step 4: one row per key")
    ap.add_argument("--trend", metavar="SPAN", help="step 1: count over time buckets, e.g. 5m or 1h")
    ap.add_argument("--baseline", action="store_true", help="also print the same query one week earlier")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    try:
        b = Builder(a.seal, a.sourcetype, prefer="application" if a.step == 2 else "access", key=a.key, app=a.app, env=a.env)
        tc = around_window(a.around, a.span) if a.around else (since_window(a.since) if a.since else None)
        spl, explain = b.build(a.step, a.kind, a.where, a.window, a.focus, a.key, a.value, a.head, a.by, a.collapse, tc, a.trend)
        base_spl = None
        if a.baseline and not a.around:
            win = b.window(a.window)
            base_spl = spl.replace(f"earliest={win} latest=now", baseline_window(win))
    except BuildError as e:
        print(f"build error: {e}", file=sys.stderr)
        return 2
    if a.json:
        print(json.dumps({"spl": spl, "explain": explain, "baseline_spl": base_spl}, indent=1))
    else:
        print(spl)
        print()
        for e in explain:
            print(e)
        if base_spl:
            print("\n# baseline, same window one week earlier:")
            print(base_spl)
    return 0


if __name__ == "__main__":
    sys.exit(main())
