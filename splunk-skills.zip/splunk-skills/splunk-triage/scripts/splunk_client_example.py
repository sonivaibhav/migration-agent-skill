"""The interface splunk_cli.py expects from YOUR login/search code.

Copy this file to scripts/splunk_client.py and fill the two functions from your working
scripts. Keep everything else about your code (Kerberos/ADFS sign-in, token cache, retries,
TLS settings) inside this module; the CLI never sees a token.

Rules the CLI relies on:
  - login() signs in with Kerberos only (no passwords, no browser), caches the session per host
    under ~/.agent_data/splunk-triage/tokens/ with owner-only permissions, and NEVER prints or
    logs a token or cookie. It may read SPLUNK_SESSION / SPLUNK_CSRF overrides if you support them.
  - search() runs ONE blocking search and returns rows as dicts (the JSON results output_mode),
    at most max_rows of them, within timeout_s. It raises SearchError on a failed job or a
    poll timeout; it never returns a partial result as if it were complete.
  - Both raise AuthError when sign-in fails or the session is rejected (HTTP 401/403), so the
    CLI can sign in again once and retry.
  - TLS verification stays on. REQUESTS_CA_BUNDLE for the corporate CA. Do not honour any
    "insecure" switch.
"""
from __future__ import annotations


class AuthError(Exception):
    """Sign-in failed or the session was rejected."""


class SearchError(Exception):
    """The search job failed, timed out, or returned an error."""


def login(base_url: str):
    """Return an opaque session object for base_url ('https://host:port'). Raise AuthError."""
    raise NotImplementedError("fill from your login script")


def search(session, base_url: str, spl: str, max_rows: int, timeout_s: int = 120) -> list[dict]:
    """Run `spl` (already starts with 'search' or '|'), return up to max_rows rows as dicts.
    Raise AuthError on 401/403, SearchError on job failure or timeout."""
    raise NotImplementedError("fill from your search script")
