#!/usr/bin/env python3
"""splunk_cli.py — the only path from the agent to Splunk.

    splunk_cli.py search '<SPL>' --base-url https://host:443 --context 89592 [--json] [--focus errors]
        [--raw] [--baseline] [--max-results N] [--confirm-window] [--save PATH] [--dry-run]
    splunk_cli.py build --seal 89592 --step 1 --kind errors ...      # same as scripts/build_query.py
    splunk_cli.py access-check [--env prod|test]                      # sign in to each instance in org.yaml

`--base-url` works the same in every shell (bash, zsh, PowerShell, cmd). The SPLUNK_BASE_URL
environment variable is the fallback when the flag is absent. When the SPL is awkward to quote in
your shell, write it to a file and pass `@path/to/query.spl` instead of the SPL text.

Flow for `search`:  guard.check_spl  →  splunk_client.login/search  →  guard.Redactor  →  table or JSON
                    →  guard.Budget (stderr warning)  →  audit line  →  --save
Your sign-in and search code lives in scripts/splunk_client.py (see splunk_client_example.py).
Without it, `search` runs in SPL-only mode: the guard runs, the plan is printed, nothing is sent.

Exit codes: 0 ok · 2 usage · 3 rejected by the guard (nothing ran) · 4 sign-in · 5 search failed or timed out · 6 host not in org.yaml
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

from _common import load_yaml, ORG
from guard import Budget, GuardError, Limits, Redactor, check_spl, format_table

try:
    import splunk_client as client  # type: ignore
except ImportError:                 # SPL-only mode until the org's module is in place
    client = None

DATA_DIR = Path(os.environ.get("SPLUNK_TRIAGE_DATA", Path.home() / ".agent_data" / "splunk-triage"))
AUDIT = DATA_DIR / "audit.log"


def to_api_spl(spl: str) -> str:
    s = spl.strip()
    return s if s.startswith(("search", "|")) else "search " + s


def allowed_hosts() -> dict[str, dict]:
    org = load_yaml(ORG) if ORG.exists() else {}
    return {f"{i['url'].rstrip('/')}:{i.get('port', 443)}": i for i in org.get("instances", [])}


class HostError(Exception):
    """SPLUNK_BASE_URL is not an instance listed in org.yaml."""


def check_host(base_url: str) -> dict:
    hosts = allowed_hosts()
    key = base_url.rstrip("/")
    if key.count(":") == 1:                          # scheme only, no port
        key += ":443"
    if key not in hosts:
        raise HostError(f"{base_url} is not an instance in org.yaml; allowed: {', '.join(sorted(hosts)) or 'none'}")
    return hosts[key]


def audit(base_url: str, spl: str, context: str | None, rows: int, status: str) -> None:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        with AUDIT.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({"ts": datetime.now().isoformat(timespec="seconds"), "host": base_url,
                                 "spl_sha256": hashlib.sha256(spl.encode("utf-8")).hexdigest(), "context": context,
                                 "rows": rows, "status": status}) + "\n")
    except OSError:
        pass


def run_search(base_url: str, spl: str, max_rows: int) -> list[dict]:
    """Sign in, search, sign in again once on an auth error."""
    session = client.login(base_url)
    try:
        return client.search(session, base_url, to_api_spl(spl), max_rows)
    except client.AuthError:
        session = client.login(base_url)
        return client.search(session, base_url, to_api_spl(spl), max_rows)


def spl_arg(value: str) -> str:
    """`@path` reads the SPL from a file: the shell-neutral way to pass quote-heavy SPL."""
    if value.startswith("@") and len(value) > 1:
        return Path(value[1:]).read_text(encoding="utf-8").strip()
    return value


def cmd_search(a: argparse.Namespace) -> int:
    a.spl = spl_arg(a.spl)
    base_url = (a.base_url or os.environ.get("SPLUNK_BASE_URL", "")).strip()
    limits = Limits.from_org(confirm_window=a.confirm_window, max_results=a.max_results, raw=a.raw, context=a.context)
    try:
        plan = check_spl(a.spl, limits)
    except GuardError as e:
        print(f"REJECTED: {e}", file=sys.stderr)
        audit(base_url or "-", a.spl, a.context, 0, "rejected")
        return 3
    max_rows = plan["effective_max_rows"]
    queries = [("now", a.spl)]
    if a.baseline:
        from build_query import baseline_window
        import re
        m = re.search(r"earliest=(-\d+[smhdw])\s+latest=now", a.spl)
        if not m:
            print("REJECTED: --baseline needs a relative window like 'earliest=-1h latest=now'", file=sys.stderr)
            return 3
        queries.append(("one week earlier", a.spl.replace(m.group(0), baseline_window(m.group(1)))))

    if client is None or a.dry_run:
        mode = "DRY RUN" if client is not None else "SPL-ONLY MODE (scripts/splunk_client.py not installed)"
        print(f"{mode}: guard passed; would run on {base_url or '<no --base-url given>'} with max_rows={max_rows}"
              f"{' as ' + a.context if a.context else ''}:")
        for label, q in queries:
            print(f"# {label}\n{to_api_spl(q)}")
        return 0

    if not base_url:
        print("error: pass --base-url <url>:<port> (the resolver prints it; instances live in org.yaml)", file=sys.stderr)
        return 2
    try:
        check_host(base_url)
    except HostError as e:
        print(f"error: {e}", file=sys.stderr)
        audit(base_url, a.spl, a.context, 0, "host-refused")
        return 6
    red = Redactor(context=a.context, raw=a.raw, focus=a.focus)
    out_parts, json_parts, total_rows = [], {}, 0
    for label, q in queries:
        try:
            rows = run_search(base_url, q, max_rows)
        except client.AuthError as e:
            print(f"sign-in failed: {e}", file=sys.stderr)
            audit(base_url, q, a.context, 0, "auth-failed")
            return 4
        except client.SearchError as e:
            print(f"search failed: {e}", file=sys.stderr)
            audit(base_url, q, a.context, 0, "search-failed")
            return 5
        rows = red.redact_rows(rows, q, json_mode=a.json)
        total_rows += len(rows)
        cut = len(rows) >= max_rows
        if a.json:
            json_parts[label] = {"rows": rows, "cut_at_cap": cut}
        else:
            body = format_table(rows) + (f"\n(result cut at the {max_rows}-row cap; aggregate with stats for a total)" if cut else "")
            out_parts.append((f"# {label}\n" if len(queries) > 1 else "") + body)
        audit(base_url, q, a.context, len(rows), "ok")
    if a.json:
        output = json.dumps(json_parts["now"]["rows"] if len(json_parts) == 1 else json_parts, indent=1)
    else:
        output = "\n\n".join(out_parts)
    print(output)
    run_id = os.environ.get("SPLUNK_TRIAGE_RUN") or datetime.now().strftime("%Y%m%d%H")
    budget = Budget(DATA_DIR / f"run-{run_id}.json")
    warn = budget.status(budget.add(total_rows, len(output)))
    if warn:
        print(warn, file=sys.stderr)
    if a.save:
        Path(a.save).write_text(output + "\n", encoding="utf-8")
    return 0


def cmd_access_check(a: argparse.Namespace) -> int:
    if client is None:
        print("scripts/splunk_client.py is not installed; nothing to check (see first-run/CLI-INTEGRATION.md)")
        return 1
    org = load_yaml(ORG) if ORG.exists() else {}
    bad = 0
    for inst in org.get("instances", []):
        if a.env and inst.get("environment") != a.env:
            continue
        base = f"{inst['url'].rstrip('/')}:{inst.get('port', 443)}"
        t0 = time.time()
        try:
            rows = run_search(base, "| makeresults | eval ok=1", 1)
            print(f"  OK   {inst['name']:<26} {base}  ({time.time() - t0:.1f}s, {len(rows)} row)")
        except Exception as e:  # noqa: BLE001 — report, never print a token
            bad += 1
            print(f"  FAIL {inst['name']:<26} {base}  {type(e).__name__}: {str(e)[:120]}")
    return 1 if bad else 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["build"]:
        from build_query import main as build_main
        sys.argv = ["build_query.py"] + argv[1:]
        return build_main()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("search", help="run one SPL through the guard, redact, print")
    s.add_argument("spl", help="the SPL text, or @path to a file holding it")
    s.add_argument("--base-url", help="Splunk instance <url>:<port> from org.yaml (falls back to SPLUNK_BASE_URL)")
    s.add_argument("--context", help="the seal you investigate for (unlocks its owner-only fields)")
    s.add_argument("--focus", help="projection from fields.yaml when the SPL has no table")
    s.add_argument("--raw", action="store_true", help="print _raw (head <= 5, owning seal's context)")
    s.add_argument("--baseline", action="store_true", help="also run the same query one week earlier")
    s.add_argument("--json", action="store_true", help="JSON rows, keeps _time")
    s.add_argument("--max-results", type=int)
    s.add_argument("--confirm-window", action="store_true", help="the user agreed to a window over the cap")
    s.add_argument("--save", help="write the redacted output here")
    s.add_argument("--dry-run", action="store_true", help="run the guard and print the plan; send nothing")
    s.set_defaults(fn=cmd_search)
    c = sub.add_parser("access-check", help="sign in to each instance in org.yaml and run a trivial search")
    c.add_argument("--env", choices=["prod", "test"])
    c.set_defaults(fn=cmd_access_check)
    sub.add_parser("build", help="compose SPL from fields.yaml (see build_query.py --help)")
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
