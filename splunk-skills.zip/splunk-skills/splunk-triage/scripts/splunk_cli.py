#!/usr/bin/env python3
"""splunk_cli.py — the only path from the agent to Splunk.

    splunk_cli.py search '<SPL>' --base-url https://host:443 --context 89592 [--json] [--focus errors]
        [--raw] [--baseline] [--max-results N] [--confirm-window] [--save PATH] [--dry-run]
    splunk_cli.py fanout '<SPL 1>' '<SPL 2>' --labels ur,forgerock --base-url ... --context 89592
                                                                      # several searches in one call, run together
    splunk_cli.py build --seal 89592 --step 1 --kind errors ...      # same as scripts/build_query.py
    splunk_cli.py access-check [--env prod|test]                      # sign in to each instance in org.yaml

`--base-url` works the same in every shell (bash, zsh, PowerShell, cmd). The SPLUNK_BASE_URL
environment variable is the fallback when the flag is absent. When the SPL is awkward to quote in
your shell, write it to a file and pass `@path/to/query.spl` instead of the SPL text.

Flow for `search`:  guard.check_spl  →  splunk_client.login/search  →  guard.Redactor  →  table or JSON
                    →  guard.Budget (stderr warning)  →  audit line  →  --save
Your sign-in and search code lives in scripts/splunk_client.py (see splunk_client_example.py).
Without it, `search` runs in SPL-only mode: the guard runs, the plan is printed, nothing is sent.

Exit codes: 0 ok · 2 usage · 3 rejected by the guard (nothing ran) · 4 sign-in · 5 search failed or timed out · 6 host not in org.yaml
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path

from _common import load_yaml, ORG
from guard import Budget, GuardError, Limits, Redactor, check_spl, format_table

try:
    import splunk_client as client  # type: ignore
except ImportError:                 # SPL-only mode until the org's module is in place
    client = None

DATA_DIR = Path(os.environ.get("SPLUNK_TRIAGE_DATA", Path.home() / ".agent_data" / "splunk-triage"))
AUDIT = DATA_DIR / "audit.log"


def to_api_spl(spl: str) -> str:
    s = spl.strip()
    return s if s.startswith(("search", "|")) else "search " + s


def allowed_hosts() -> dict[str, dict]:
    org = load_yaml(ORG) if ORG.exists() else {}
    return {f"{i['url'].rstrip('/')}:{i.get('port', 443)}": i for i in org.get("instances", [])}


class HostError(Exception):
    """SPLUNK_BASE_URL is not an instance listed in org.yaml."""


def check_host(base_url: str) -> dict:
    hosts = allowed_hosts()
    key = base_url.rstrip("/")
    if key.count(":") == 1:                          # scheme only, no port
        key += ":443"
    if key not in hosts:
        raise HostError(f"{base_url} is not an instance in org.yaml; allowed: {', '.join(sorted(hosts)) or 'none'}")
    return hosts[key]


def audit(base_url: str, spl: str, context: str | None, rows: int, status: str) -> None:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        with AUDIT.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({"ts": datetime.now().isoformat(timespec="seconds"), "host": base_url,
                                 "spl_sha256": hashlib.sha256(spl.encode("utf-8")).hexdigest(), "context": context,
                                 "rows": rows, "status": status}) + "\n")
    except OSError:
        pass


def run_search(base_url: str, spl: str, max_rows: int) -> list[dict]:
    """Sign in, search, sign in again once on an auth error."""
    session = client.login(base_url)
    try:
        return client.search(session, base_url, to_api_spl(spl), max_rows)
    except client.AuthError:
        session = client.login(base_url)
        return client.search(session, base_url, to_api_spl(spl), max_rows)


def spl_arg(value: str) -> str:
    """`@path` reads the SPL from a file: the shell-neutral way to pass quote-heavy SPL."""
    if value.startswith("@") and len(value) > 1:
        return Path(value[1:]).read_text(encoding="utf-8").strip()
    return value


def max_workers(n: int) -> int:
    """Concurrent searches: never above org.yaml limits.max_concurrent_searches (Splunk's per-user job quota
    is often 3; a fourth job queues or fails)."""
    org = load_yaml(ORG) if ORG.exists() else {}
    cap = int((org.get("limits") or {}).get("max_concurrent_searches", 3))
    return max(1, min(n, cap))


def baseline_of(spl: str) -> str:
    from build_query import baseline_window
    import re
    m = re.search(r"earliest=(-\d+[smhdw])\s+latest=now", spl)
    if not m:
        raise GuardError("--baseline needs a relative window like 'earliest=-1h latest=now'")
    return spl.replace(m.group(0), baseline_window(m.group(1)))


def run_queries(base_url: str, queries: list[tuple[str, str]], limits: Limits, a: argparse.Namespace) -> int:
    """Guard every query first (all or nothing), then run them together, redact, print, audit, budget.
    `queries` is [(label, spl)]. Returns the exit code."""
    plans = {}
    for label, spl in queries:
        try:
            plans[label] = check_spl(spl, limits)
        except GuardError as e:
            print(f"REJECTED ({label}): {e}" if len(queries) > 1 else f"REJECTED: {e}", file=sys.stderr)
            audit(base_url or "-", spl, a.context, 0, "rejected")
            return 3
    max_rows = max(p["effective_max_rows"] for p in plans.values())

    if client is None or a.dry_run:
        mode = "DRY RUN" if client is not None else "SPL-ONLY MODE (scripts/splunk_client.py not installed)"
        print(f"{mode}: guard passed; would run {len(queries)} quer{'y' if len(queries) == 1 else 'ies'} on "
              f"{base_url or '<no --base-url given>'} with max_rows={max_rows}{' as ' + a.context if a.context else ''}"
              f"{', ' + str(max_workers(len(queries))) + ' at a time' if len(queries) > 1 else ''}:")
        for label, spl in queries:
            print(f"# {label}\n{to_api_spl(spl)}")
        return 0

    if not base_url:
        print("error: pass --base-url <url>:<port> (the resolver prints it; instances live in org.yaml)", file=sys.stderr)
        return 2
    try:
        check_host(base_url)
    except HostError as e:
        print(f"error: {e}", file=sys.stderr)
        for _, spl in queries:
            audit(base_url, spl, a.context, 0, "host-refused")
        return 6

    red = Redactor(context=a.context, raw=getattr(a, "raw", False), focus=a.focus)
    results: dict[str, list[dict]] = {}
    failures: dict[str, tuple[int, str]] = {}
    t0 = time.time()
    timing: dict[str, float] = {}

    def one(label: str, spl: str):
        s = time.time()
        try:
            rows = run_search(base_url, spl, max_rows)
        except client.AuthError as e:
            return label, None, (4, f"sign-in failed: {e}"), time.time() - s
        except client.SearchError as e:
            return label, None, (5, f"search failed: {e}"), time.time() - s
        return label, rows, None, time.time() - s

    with ThreadPoolExecutor(max_workers=max_workers(len(queries))) as pool:
        for label, rows, failure, dt in pool.map(lambda q: one(*q), queries):
            timing[label] = dt
            spl = dict(queries)[label]
            if failure:
                failures[label] = failure
                audit(base_url, spl, a.context, 0, "auth-failed" if failure[0] == 4 else "search-failed")
                continue
            results[label] = red.redact_rows(rows, spl, json_mode=a.json)
            audit(base_url, spl, a.context, len(results[label]), "ok")

    total_rows = sum(len(r) for r in results.values())
    if a.json:
        if len(queries) == 1 and results:
            output = json.dumps(next(iter(results.values())), indent=1)
        else:
            output = json.dumps({label: {"rows": rows, "cut_at_cap": len(rows) >= max_rows, "seconds": round(timing[label], 1)}
                                 for label, rows in results.items()}, indent=1)
    else:
        parts = []
        for label, _ in queries:
            if label not in results:
                continue
            rows = results[label]
            body = format_table(rows) + (f"\n(result cut at the {max_rows}-row cap; aggregate with stats for a total)" if len(rows) >= max_rows else "")
            parts.append((f"# {label}  ({len(rows)} rows, {timing[label]:.1f}s)\n" if len(queries) > 1 else "") + body)
        if len(queries) > 1:
            parts.insert(0, f"{len(results)}/{len(queries)} queries in {time.time() - t0:.1f}s wall, "
                            f"{max_workers(len(queries))} at a time")
        output = "\n\n".join(parts)
    print(output)
    for label, (code, msg) in failures.items():
        print(f"{label}: {msg}", file=sys.stderr)

    run_id = os.environ.get("SPLUNK_TRIAGE_RUN") or datetime.now().strftime("%Y%m%d%H")
    budget = Budget(DATA_DIR / f"run-{run_id}.json")
    warn = budget.status(budget.add(total_rows, len(output)))
    if warn:
        print(warn, file=sys.stderr)
    if a.save:
        Path(a.save).write_text(output + "\n", encoding="utf-8")
    return min(code for code, _ in failures.values()) if failures else 0


def cmd_search(a: argparse.Namespace) -> int:
    a.spl = spl_arg(a.spl)
    base_url = (a.base_url or os.environ.get("SPLUNK_BASE_URL", "")).strip()
    limits = Limits.from_org(confirm_window=a.confirm_window, max_results=a.max_results, raw=a.raw, context=a.context)
    queries = [("now", a.spl)]
    if a.baseline:
        try:
            queries.append(("one week earlier", baseline_of(a.spl)))
        except GuardError as e:
            print(f"REJECTED: {e}", file=sys.stderr)
            return 3
    return run_queries(base_url, queries, limits, a)


def cmd_fanout(a: argparse.Namespace) -> int:
    """Several guarded searches in one call, run together: Step 1 on every hop of a journey, or the same
    question on several sourcetypes. One --context for all (you investigate for one seal)."""
    spls = [spl_arg(s) for s in a.spl]
    labels = [x.strip() for x in a.labels.split(",")] if a.labels else []
    if labels and len(labels) != len(spls):
        print(f"error: --labels names {len(labels)} queries, {len(spls)} given", file=sys.stderr)
        return 2
    labels = labels or [f"q{i + 1}" for i in range(len(spls))]
    base_url = (a.base_url or os.environ.get("SPLUNK_BASE_URL", "")).strip()
    limits = Limits.from_org(confirm_window=a.confirm_window, max_results=a.max_results, raw=False, context=a.context)
    a.raw = False
    return run_queries(base_url, list(zip(labels, spls)), limits, a)


def cmd_access_check(a: argparse.Namespace) -> int:
    if client is None:
        print("scripts/splunk_client.py is not installed; nothing to check (see first-run/CLI-INTEGRATION.md)")
        return 1
    org = load_yaml(ORG) if ORG.exists() else {}
    bad = 0
    for inst in org.get("instances", []):
        if a.env and inst.get("environment") != a.env:
            continue
        base = f"{inst['url'].rstrip('/')}:{inst.get('port', 443)}"
        t0 = time.time()
        try:
            rows = run_search(base, "| makeresults | eval ok=1", 1)
            print(f"  OK   {inst['name']:<26} {base}  ({time.time() - t0:.1f}s, {len(rows)} row)")
        except Exception as e:  # noqa: BLE001 — report, never print a token
            bad += 1
            print(f"  FAIL {inst['name']:<26} {base}  {type(e).__name__}: {str(e)[:120]}")
    return 1 if bad else 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["build"]:
        from build_query import main as build_main
        sys.argv = ["build_query.py"] + argv[1:]
        return build_main()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("search", help="run one SPL through the guard, redact, print")
    s.add_argument("spl", help="the SPL text, or @path to a file holding it")
    s.add_argument("--base-url", help="Splunk instance <url>:<port> from org.yaml (falls back to SPLUNK_BASE_URL)")
    s.add_argument("--context", help="the seal you investigate for (unlocks its owner-only fields)")
    s.add_argument("--focus", help="projection from fields.yaml when the SPL has no table")
    s.add_argument("--raw", action="store_true", help="print _raw (head <= 5, owning seal's context)")
    s.add_argument("--baseline", action="store_true", help="also run the same query one week earlier")
    s.add_argument("--json", action="store_true", help="JSON rows, keeps _time")
    s.add_argument("--max-results", type=int)
    s.add_argument("--confirm-window", action="store_true", help="the user agreed to a window over the cap")
    s.add_argument("--save", help="write the redacted output here")
    s.add_argument("--dry-run", action="store_true", help="run the guard and print the plan; send nothing")
    s.set_defaults(fn=cmd_search)
    f = sub.add_parser("fanout", help="several guarded searches in one call, run together (Step 1 on every hop)")
    f.add_argument("spl", nargs="+", help="two or more SPL texts, or @file each")
    f.add_argument("--labels", help="comma-separated names, one per query, in order (e.g. seal folder names)")
    f.add_argument("--base-url", help="Splunk instance <url>:<port> from org.yaml (falls back to SPLUNK_BASE_URL)")
    f.add_argument("--context", help="the seal you investigate for; one context for every query")
    f.add_argument("--focus"); f.add_argument("--json", action="store_true"); f.add_argument("--max-results", type=int)
    f.add_argument("--confirm-window", action="store_true"); f.add_argument("--save"); f.add_argument("--dry-run", action="store_true")
    f.set_defaults(fn=cmd_fanout)
    c = sub.add_parser("access-check", help="sign in to each instance in org.yaml and run a trivial search")
    c.add_argument("--env", choices=["prod", "test"])
    c.set_defaults(fn=cmd_access_check)
    sub.add_parser("build", help="compose SPL from fields.yaml (see build_query.py --help)")
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
