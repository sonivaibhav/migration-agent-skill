#!/usr/bin/env python3
"""Turn a plain-language request into: path, seal(s), journey, hops, instance, first query.
No LLM, no Splunk. Matches against registry.yaml, then loads only the seals it needs, so the
cost does not grow with the number of seals.

    resolve.py "Check UR prod logs for new errors"
    resolve.py "UR Prod splunk alert triggered: UR Prod 5xx Rate"
    resolve.py "WL 500s since 2pm"
    resolve.py "trace frTraceId abc-7 into ForgeRock"
    resolve.py --json "..."

PATH fast  — one seal, standard question (errors / latency / volume) or a known alert.
             The first query is printed; run it, report in the short form. Open no seal files.
PATH full  — a journey, more than one seal, a trace, or an unrecognised question.
             Read the listed files; use the hops' keys and skew.
"""
from __future__ import annotations

import argparse
import json
import re
import sys

from _common import find_link, load_journeys, load_seal, load_yaml, registry, registry_is_stale, ORG, SEALS_DIR
from build_query import BuildError, Builder, around_window, since_window

WORD = re.compile(r"[a-z0-9][a-z0-9_.\-{}]*")
KINDS = {
    "errors": ["error", "errors", "exception", "exceptions", "5xx", "5xxs", "500", "500s", "502", "502s", "503", "503s",
               "504", "504s", "4xx", "4xxs", "400", "400s", "401", "401s", "403", "fail", "failed", "failing", "failure",
               "failures", "broken", "down", "not working", "issue", "issues", "outage"],
    "latency": ["slow", "slowness", "latency", "p99", "p95", "response time", "timeout", "timeouts", "timing", "taking long", "degraded"],
    "volume": ["traffic", "volume", "how many", "requests", "count", "throughput", "spike in traffic"],
    "trace": ["trace", "frtraceid", "transactionid", "traceid", "this request", "follow", "profile", "session", "user id", "for a user"],
}
ENV_TEST = ["uat", "test", "non-prod", "nonprod", "dev", "staging"]
STOP = {"the", "and", "for", "one", "two", "over", "same", "from", "into", "with", "across", "through", "by", "a", "an", "of",
        "errors", "error", "5xx", "500s", "request", "requests", "query", "queries", "window", "prod", "uat", "live", "mix",
        "ur", "wl", "rpex", "dps", "caas", "cxo", "web", "vs", "user", "users", "profile", "per", "in", "on", "to"}


def stem(w: str) -> str:
    return w[:-1] if len(w) > 4 and w.endswith("s") else w


def recipe_match(text: str, titles: list[str]) -> str | None:
    """A recipe title whose distinctive word appears in the question, e.g. 'region', 'platform', 'token'."""
    words = {stem(w) for w in text.split()}
    for title in titles:
        tw = {stem(w) for w in norm(title).split() if len(w) >= 4 and w not in STOP}
        if tw & words:
            return title
    return None


def id_pattern_hits(raw_query: str, reg: dict) -> list[tuple[str, str, str]]:
    """(seal id, pattern name, token) for every whitespace token that matches a seal's id_patterns."""
    hits = []
    for tok in re.split(r"[\s,;]+", raw_query or ""):
        tok = tok.strip("\"'`()[]<>")
        if not tok:
            continue
        for r in reg["seals"]:
            for name, pat in (r.get("id_patterns") or {}).items():
                try:
                    if re.match(pat, tok):
                        hits.append((r["id"], name, tok))
                except re.error:
                    continue
    return hits
TIME_AT = re.compile(r"\b(at|around|about|since|from|after)\s+(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)\b", re.I)


def norm(s: str) -> str:
    return " ".join(WORD.findall(s.lower()))


def phrase_hits(text: str, phrases) -> list[str]:
    t = f" {text} "
    return [str(p) for p in phrases or [] if norm(str(p)) and f" {norm(str(p))} " in t]


def detect_kind(text: str) -> str | None:
    best, best_n = None, 0
    for k, words in KINDS.items():
        n = sum(1 for w in words if f" {w} " in f" {text} ")
        if n > best_n:
            best, best_n = k, n
    return best


def detect_env(text: str) -> str:
    return "test" if any(f" {w} " in f" {text} " for w in ENV_TEST) else "prod"


def parse_clock(raw: str) -> str | None:
    m = re.match(r"^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$", raw.strip().lower())
    if not m:
        return None
    h, mi, ap = int(m.group(1)), int(m.group(2) or 0), m.group(3)
    if ap == "pm" and h < 12:
        h += 12
    if ap == "am" and h == 12:
        h = 0
    return f"{h:02d}:{mi:02d}" if 0 <= h < 24 and 0 <= mi < 60 else None


def resolve(query: str, journey_name: str | None = None) -> dict:
    reg = registry()
    journeys = load_journeys()
    text = norm(query or "")
    out = {"query": query, "path": "full", "env": detect_env(text), "kind": detect_kind(text),
           "time": None, "alert": None, "seals": [], "journey": None, "hops": [], "instances": [],
           "first_query": None, "explain": [], "read": [], "notes": [], "recipe": None}
    if registry_is_stale():
        out["notes"].append("registry.yaml is older than the seal files; run scripts/build_registry.py (matching used a fresh in-memory build)")

    m = TIME_AT.search(query or "")
    if m:
        clock = parse_clock(m.group(2))
        if clock:
            out["time"] = {"mode": "since" if m.group(1).lower() in ("since", "from", "after") else "around", "clock": clock}

    # ---- alerts first: an alert name beats everything
    for r in reg["seals"]:
        for al in r.get("alerts", []):
            if phrase_hits(text, [al["name"]] + list(al.get("aliases", []))):
                full = load_seal(r["id"], reg)
                hit = next(a for a in (full.get("alerts") or {}).get("alerts", []) if a["name"] == al["name"])
                out["alert"] = {**hit, "seal": r["id"]}
                break
        if out["alert"]:
            break

    # ---- seals by alias / app alias / index / sourcetype / id
    seal_hits, app_hint, st_hint = [], {}, {}
    for r in reg["seals"]:
        phrases = list(r.get("aliases", [])) + [r["id"], r.get("name", "")] + list(r.get("indexes", []))
        phrases += [st["name"] for st in r.get("sourcetypes", [])]
        hits = phrase_hits(text, phrases)
        for app, al in (r.get("app_aliases") or {}).items():
            ah = phrase_hits(text, al)
            if ah:
                hits += ah
                app_hint.setdefault(r["id"], app)
        for st in r.get("sourcetypes", []):
            if phrase_hits(text, [st["name"]]):
                st_hint[r["id"]] = st["name"]
        if hits:
            seal_hits.append((sum(len(norm(h).split()) for h in hits), r["id"], hits))
    seal_hits.sort(reverse=True)
    chosen = [sid for _, sid, _ in seal_hits[:3]]
    for sid, name, tok in id_pattern_hits(query, reg):
        if sid not in chosen:
            chosen.insert(0, sid)
        out["kind"] = out["kind"] or "trace"
        out["notes"].append(f"Identifier shaped like {name} (seal {sid}): {tok}")
    if out["alert"] and out["alert"]["seal"] not in chosen:
        chosen.insert(0, out["alert"]["seal"])

    # ---- journeys: alias words never count, so "RPEX 500s" stays single-seal
    alias_words = set()
    for r in reg["seals"]:
        alias_words |= {norm(str(a)) for a in r.get("aliases", [])} | {norm(str(r.get("name", "")))}
        for al in (r.get("app_aliases") or {}).values():
            alias_words |= {norm(str(a)) for a in al}
    journey_hits = []
    for name, j in journeys.items():
        if journey_name and name != journey_name:
            continue
        jj = j["journey"]
        hits = [h for h in phrase_hits(text, jj.get("triggers", [])) if norm(h) not in alias_words]
        score = sum(len(norm(h).split()) for h in hits) or (1 if journey_name else 0)
        if score and jj.get("entry") in chosen:
            score += 1
        if score:
            journey_hits.append((score, name, hits))
    journey_hits.sort(reverse=True)

    loaded: dict[str, dict] = {}
    if journey_hits and not out["alert"]:
        _, jname, jhits = journey_hits[0]
        jj = journeys[jname]["journey"]
        out["journey"] = {"name": jname, "owner": jj.get("owner"), "entry": jj.get("entry"),
                          "matched": jhits, "description": jj.get("description")}
        for hop in jj.get("hops", []):
            link = find_link(loaded, hop["link"], reg)
            if link is None:
                out["hops"].append({"link": hop["link"], "error": "unresolved link"})
                continue
            out["hops"].append({"link": hop["link"], "when": hop.get("when"), "from_seal": link["from_seal"],
                                "to_seal": link.get("to"), "kind": link.get("kind"), "status": link.get("status"),
                                "from": link.get("from"), "to_field": link.get("to_field"),
                                "to_sourcetype": link.get("to_sourcetype"), "skew_s": link.get("skew_s"), "note": link.get("note")})
            for sid in (link["from_seal"], link.get("to")):
                if sid and not str(sid).startswith("<") and sid not in chosen and load_seal(sid, reg):
                    chosen.append(sid)
        entry = jj.get("entry")
        if entry:
            if entry in chosen:
                chosen.remove(entry)
            chosen.insert(0, entry)
        if jj.get("signatures"):
            out["notes"].append("Signatures: " + " · ".join(f"{s['symptom']} → {s['layer']}" for s in jj["signatures"][:4]))

    by_id = {r["id"]: r for r in reg["seals"]}
    for sid in chosen:
        r = by_id.get(sid)
        if not r:
            continue
        qmd = SEALS_DIR / r["dir"] / "queries.md"
        recipes = re.findall(r"^## (.+)$", qmd.read_text(encoding="utf-8"), re.M) if qmd.exists() else []
        out["seals"].append({"id": sid, "dir": f"seals/{r['dir']}", "name": r.get("name"), "volume": r.get("volume"),
                             "instance_group": r.get("instance_group"), "indexes": r.get("indexes", []),
                             "focus": r.get("focus", []), "recipes": [x for x in recipes if x.lower() not in ("recipes", "index")],
                             "repos": r.get("repos", []), "app": app_hint.get(sid), "sourcetype": st_hint.get(sid)})

    groups = {s["instance_group"] for s in out["seals"]}
    if ORG.exists():
        for inst in load_yaml(ORG).get("instances", []):
            if inst.get("group") in groups and inst.get("environment") == out["env"]:
                out["instances"].append({k: inst[k] for k in ("name", "group", "environment", "url", "port") if k in inst})

    # ---- path + first query
    def time_clause():
        if not out["time"]:
            return None
        return since_window(out["time"]["clock"]) if out["time"]["mode"] == "since" else around_window(out["time"]["clock"], "30m")

    single = len(out["seals"]) == 1 and not out["journey"]
    recipe = recipe_match(text, out["seals"][0]["recipes"]) if single and not out["alert"] else None
    if recipe:
        out["recipe"] = recipe
        out["notes"].insert(0, f"Recipe: '{recipe}' in {out['seals'][0]['dir']}/queries.md answers this; read that section only")
    if out["alert"]:
        out["path"] = "fast"
        al, sid = out["alert"], out["alert"]["seal"]
        try:
            if al.get("first_query"):
                out["first_query"], out["explain"] = al["first_query"].strip(), [f"Alert '{al['name']}': {al['means']}"]
            else:
                b = Builder(sid, al.get("sourcetype"))
                kind = al.get("kind") if al.get("kind") in ("errors", "latency", "volume") else "errors"
                spl, ex = b.build(1, kind, where=al.get("where"), focus=al.get("focus"), time_clause=time_clause())
                out["first_query"], out["explain"] = spl, [f"Alert '{al['name']}': {al['means']}"] + ex
            if al.get("then"):
                out["notes"].append(f"Then: {al['then']}")
        except BuildError as e:
            out["path"], out["notes"] = "full", out["notes"] + [f"alert matched but no query could be built: {e}"]
    elif single and not recipe and out["kind"] in ("errors", "latency", "volume"):
        s = out["seals"][0]
        try:
            b = Builder(s["id"], s["sourcetype"], app=s["app"])
            out["first_query"], out["explain"] = b.build(1, out["kind"], time_clause=time_clause())
            out["path"] = "fast"
        except BuildError as e:
            out["notes"].append(f"no standard query for this seal: {e}")

    if out["path"] == "full":
        out["read"].append("core/references/triage-ladder.md")
        if out["journey"] or len(out["seals"]) > 1:
            out["read"].append("core/references/correlation-method.md")
        for i, s in enumerate(out["seals"]):
            out["read"].append(f"{s['dir']}/fields.yaml")
            if i == 0:
                out["read"].append(f"{s['dir']}/notes.md")
        out["notes"].append("Open another seal's notes.md only when one of its fields shows up in a result. "
                            "Open a queries.md section by its title below only when no built query fits.")
    return out


def render(r: dict) -> str:
    L = []
    if not r["seals"] and not r["journey"]:
        return ("No match. Read registry.yaml and pick a seal by alias or index name; if none fits, say so and offer "
                "scripts/onboard_seal.py." + ("".join("\nNOTE: " + n for n in r["notes"])))
    t = f"   time={r['time']['mode']} {r['time']['clock']}" if r["time"] else ""
    L.append(f"PATH: {r['path']}   env={r['env']}   kind={r['kind'] or '-'}{t}")
    if r["alert"]:
        L.append(f"ALERT: {r['alert']['name']}  (seal {r['alert']['seal']}, default severity {r['alert'].get('severity_default', '-')})")
    if r["journey"]:
        j = r["journey"]
        L.append(f"JOURNEY: {j['name']}  entry seal {j['entry']}  matched: {', '.join(j['matched']) or '-'}")
        for i, h in enumerate(r["hops"], 1):
            if "error" in h:
                L.append(f"  hop {i}: {h['link']}  !! {h['error']}"); continue
            frm = f"{h['from']['sourcetype']}.{h['from']['field']}" if h.get("from") else "-"
            skew = f"-{h['skew_s']['before']}s/+{h['skew_s']['after']}s" if h.get("skew_s") else "-"
            L.append(f"  hop {i}: {h['link']}  {h['from_seal']} -> {h['to_seal']}  {h['kind']}  {h['status']}  key {frm} -> {h.get('to_field') or '-'}  skew {skew}")
            if h.get("when"):
                L.append(f"         when: {h['when']}")
    L.append("SEALS:")
    for s in r["seals"]:
        extra = (f"  app={s['app']}" if s["app"] else "") + (f"  sourcetype={s['sourcetype']}" if s["sourcetype"] else "") + (f"  repos={','.join(s['repos'])}" if s["repos"] else "")
        L.append(f"  {s['id']}  {s['dir']}  volume={s['volume']}  focus={','.join(s['focus']) or '-'}{extra}")
        if s["recipes"] and r["path"] == "full":
            L.append(f"         recipes: {' · '.join(s['recipes'])}")
    if r.get("recipe"):
        L.append(f"RECIPE: {r['recipe']}")
    if r["instances"]:
        L.append("INSTANCE: " + "; ".join(f"{i['url']}:{i['port']}" for i in r["instances"]))
    if r["first_query"]:
        base = f"{r['instances'][0]['url']}:{r['instances'][0]['port']}" if len(r["instances"]) == 1 else "<one INSTANCE above>"
        L.append(f"FIRST QUERY (run with: --base-url {base} --context {r['seals'][0]['id']}):")
        L += ["  " + l for l in r["first_query"].splitlines()]
        L += ["  # " + e for e in r["explain"]]
    if r["read"]:
        L.append("READ: " + ", ".join(r["read"]))
    for n in r["notes"]:
        L.append(f"NOTE: {n}")
    return "\n".join(L)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("query", nargs="?", default="")
    ap.add_argument("--journey")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    r = resolve(a.query, a.journey)
    print(json.dumps(r, indent=2) if a.json else render(r))
    return 0 if (r["seals"] or r["journey"]) else 1


if __name__ == "__main__":
    sys.exit(main())
