#!/usr/bin/env python3
"""Bare scaffold of seals/<id>-<name>/ from seals/_template/. Prefer onboard_seal.py, which asks the
questions and drafts fields, links and alerts; use this only to get an empty folder.

    python3 new_seal.py 12345 cashback

Replaces <SEAL_ID> and <short-name> in the template files. Fill seal.yaml and
fields.yaml, then run validate.py and build_registry.py.
"""
from __future__ import annotations

import shutil
import sys

from _common import SEALS_DIR


def main(argv: list[str]) -> int:
    if len(argv) != 3 or not argv[1].isdigit():
        print(__doc__)
        return 2
    sid, name = argv[1], argv[2].lower()
    dest = SEALS_DIR / f"{sid}-{name}"
    if dest.exists():
        print(f"{dest} already exists")
        return 1
    shutil.copytree(SEALS_DIR / "_template", dest)
    for p in dest.rglob("*"):
        if p.is_file():
            t = p.read_text(encoding="utf-8").replace("<SEAL_ID>", sid).replace("<short-name>", name)
            p.write_text(t, encoding="utf-8")
    print(f"created seals/{dest.name}/  — fill seal.yaml and fields.yaml, then:")
    print("  python3 scripts/validate.py && python3 scripts/build_registry.py")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
