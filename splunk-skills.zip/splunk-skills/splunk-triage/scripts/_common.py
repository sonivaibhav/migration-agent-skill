"""Shared loaders for the splunk-triage scripts. Stdlib + PyYAML only.

Two ways to read seals:
  load_seals()          every seal, every file. For validate/registry/onboarding.
  registry() + load_seal(id)   the generated registry for matching, then only the seals you need.
                        For resolve and the CLI, so cost does not grow with the number of seals.
"""
from __future__ import annotations

import sys
from functools import lru_cache
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    sys.exit("PyYAML is required: python3 -m pip install --user 'pyyaml>=6.0.3'")

SKILL_DIR = Path(__file__).resolve().parent.parent
SEALS_DIR = SKILL_DIR / "seals"
JOURNEYS_DIR = SKILL_DIR / "journeys"
REGISTRY = SKILL_DIR / "registry.yaml"
ORG = SKILL_DIR / "org.yaml"
GRAPH = SKILL_DIR / "GRAPH.md"
SEAL_FILES = ("seal.yaml", "fields.yaml", "links.yaml", "alerts.yaml")


def load_yaml(path: Path):
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def seal_dirs() -> list[Path]:
    if not SEALS_DIR.exists():
        return []
    return sorted(p for p in SEALS_DIR.iterdir() if p.is_dir() and not p.name.startswith("_"))


def _read_seal_dir(d: Path) -> dict | None:
    seal = load_yaml(d / "seal.yaml")
    sid = str(seal.get("id", "")).strip()
    if not sid:
        return None
    return {
        "dir": d,
        "seal": seal,
        "fields": load_yaml(d / "fields.yaml") if (d / "fields.yaml").exists() else {},
        "links": load_yaml(d / "links.yaml") if (d / "links.yaml").exists() else {"links": []},
        "alerts": load_yaml(d / "alerts.yaml") if (d / "alerts.yaml").exists() else {"alerts": []},
    }


def load_seals() -> dict[str, dict]:
    """seal id -> {'dir', 'seal', 'fields', 'links', 'alerts'} for every seal."""
    out = {}
    for d in seal_dirs():
        rec = _read_seal_dir(d)
        if rec:
            out[rec["seal"]["id"] if isinstance(rec["seal"]["id"], str) else str(rec["seal"]["id"])] = rec
    return out


def load_seal(sid: str, reg: dict | None = None) -> dict | None:
    """One seal by id, found through the registry when available (one directory read)."""
    reg = reg if reg is not None else registry()
    for r in reg.get("seals", []):
        if r["id"] == sid:
            rec = _read_seal_dir(SEALS_DIR / r["dir"])
            if rec:
                return rec
    for d in seal_dirs():                      # registry missing or stale: scan
        if d.name.split("-", 1)[0] == sid:
            return _read_seal_dir(d)
    return None


def registry_is_stale() -> bool:
    """True when any seal or journey file is newer than registry.yaml (or it is missing)."""
    if not REGISTRY.exists():
        return True
    reg_m = REGISTRY.stat().st_mtime
    newest = 0.0
    for d in seal_dirs():
        for f in SEAL_FILES:
            p = d / f
            if p.exists():
                newest = max(newest, p.stat().st_mtime)
    for p in JOURNEYS_DIR.glob("*.yaml") if JOURNEYS_DIR.exists() else []:
        newest = max(newest, p.stat().st_mtime)
    return newest > reg_m + 1


@lru_cache(maxsize=1)
def registry() -> dict:
    """The generated registry, or one built on the fly from the seal files when it is missing or stale."""
    if REGISTRY.exists() and not registry_is_stale():
        return load_yaml(REGISTRY)
    from build_registry import build          # local import: build_registry imports this module
    return build()


def seals_for_indexes(indexes) -> dict[str, dict]:
    """Only the seals that own one of these indexes, loaded from disk."""
    want = set(indexes)
    out = {}
    for r in registry().get("seals", []):
        if want & set(r.get("indexes", [])):
            rec = load_seal(r["id"])
            if rec:
                out[r["id"]] = rec
    return out


def load_journeys() -> dict[str, dict]:
    out = {}
    if not JOURNEYS_DIR.exists():
        return out
    for p in sorted(JOURNEYS_DIR.glob("*.yaml")):
        j = load_yaml(p)
        out[j.get("name", p.stem)] = {"path": p, "journey": j}
    return out


def find_link(seals: dict, ref: str, reg: dict | None = None) -> dict | None:
    """Resolve '<seal>/<id>' to the link dict, loading the seal on demand when it is not in `seals`."""
    if "/" not in ref:
        return None
    sid, lid = ref.split("/", 1)
    rec = seals.get(sid) or load_seal(sid, reg)
    if rec is None:
        return None
    seals.setdefault(sid, rec)
    for link in (rec.get("links") or {}).get("links", []) or []:
        if link.get("id") == lid:
            return {**link, "from_seal": sid}
    return None
