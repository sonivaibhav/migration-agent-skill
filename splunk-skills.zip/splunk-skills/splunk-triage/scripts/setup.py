#!/usr/bin/env python3
"""One-command setup for splunk-triage.

    python3 splunk-triage/scripts/setup.py              # check + fix, asks once before changing anything
    python3 splunk-triage/scripts/setup.py --yes        # no questions
    python3 splunk-triage/scripts/setup.py --skills-dir ~/.claude/skills

Does, in order: Python >= 3.9 · PyYAML (installs to the user site if missing) · links this
folder into the agent's skills dir (copies on Windows) · replaces an old rewards-splunk-cli
link · validates the seal files · rebuilds registry.yaml · runs `splunk_cli.py access-check`
when scripts/splunk_client.py is present · prints a first command to try.
Kerberos, VPN and CA bundles stay with you; it says what to do when one is missing.
"""
from __future__ import annotations

import argparse
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent
NAME = SKILL.name
OLD = "rewards-splunk-cli"
CANDIDATES = [Path.home() / ".copilot" / "skills", Path.home() / ".claude" / "skills"]


def say(ok: bool, msg: str) -> None:
    print(("  OK   " if ok else "  FIX  ") + msg)


def confirm(prompt: str, yes: bool) -> bool:
    return yes or input(f"{prompt} [y/N] ").strip().lower() == "y"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--skills-dir")
    a = ap.parse_args()
    problems = 0
    print(f"splunk-triage setup from {SKILL}\n")

    # python
    ok = sys.version_info >= (3, 9)
    say(ok, f"Python {platform.python_version()}" + ("" if ok else "  -> install Python 3.9 or newer"))
    problems += not ok

    # pyyaml
    try:
        import yaml  # noqa: F401
        say(True, "PyYAML")
    except ImportError:
        say(False, "PyYAML missing")
        if confirm("Install PyYAML into your user site with pip?", a.yes):
            subprocess.run([sys.executable, "-m", "pip", "install", "--user", "-q", "pyyaml"], check=False)
        else:
            problems += 1

    # skills dir
    target_dir = Path(a.skills_dir).expanduser() if a.skills_dir else next((c for c in CANDIDATES if c.exists()), CANDIDATES[0])
    target_dir.mkdir(parents=True, exist_ok=True)
    link = target_dir / NAME
    want_copy = platform.system() == "Windows"
    if link.is_symlink() and link.resolve() == SKILL:
        say(True, f"linked at {link}")
    elif link.exists():
        say(True, f"{link} exists (a copy; re-run after each update)" if want_copy else f"{link} exists but is not a link to this folder")
    else:
        say(False, f"not in {target_dir}")
        if confirm(f"{'Copy' if want_copy else 'Link'} {NAME} into {target_dir}?", a.yes):
            if want_copy:
                shutil.copytree(SKILL, link, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache"))
            else:
                link.symlink_to(SKILL, target_is_directory=True)
            say(True, f"{'copied' if want_copy else 'linked'} to {link}")
        else:
            problems += 1
    old = target_dir / OLD
    if old.exists() or old.is_symlink():
        say(False, f"old {OLD} still present at {old}")
        if confirm("Move it to skills-backup/ next to the skills dir?", a.yes):
            backup = target_dir.parent / "skills-backup"
            backup.mkdir(exist_ok=True)
            shutil.move(str(old), str(backup / OLD))
            say(True, f"moved to {backup / OLD}")

    # validate + registry
    r = subprocess.run([sys.executable, str(HERE / "validate.py")], capture_output=True, text=True, cwd=SKILL)
    say(r.returncode == 0, "seal files validate" if r.returncode == 0 else "validate.py found problems:\n" + r.stdout)
    problems += r.returncode != 0
    subprocess.run([sys.executable, str(HERE / "build_registry.py")], capture_output=True, text=True, cwd=SKILL)
    say(True, "registry.yaml rebuilt")

    # your sign-in/search module
    if not (HERE / "splunk_client.py").exists():
        say(False, "scripts/splunk_client.py missing: searches run in SPL-only mode until you add your login/search "
                   "functions there (first-run/CLI-INTEGRATION.md; template: scripts/splunk_client_example.py)")
    else:
        r = subprocess.run([sys.executable, str(HERE / "splunk_cli.py"), "access-check"], cwd=SKILL)
        say(r.returncode == 0, "Splunk access check" if r.returncode == 0 else "Splunk access check failed; see lines above")
        problems += r.returncode != 0

    print()
    print("Try:   /splunk-triage Check UR prod logs for new errors")
    print("       /splunk-triage UR Prod splunk alert triggered <alert name>")
    py = "python" if platform.system() == "Windows" else "python3"
    print(f"Add your application:   {py} splunk-triage/scripts/onboard_seal.py")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
