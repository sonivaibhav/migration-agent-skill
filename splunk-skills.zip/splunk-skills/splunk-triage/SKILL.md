---
name: splunk-triage
description: >-
  Production triage across downstream systems without waiting on an SME. Resolves which seal
  (application) and journey a question is about, runs short read-only Splunk searches through a
  CLI that redacts customer data, and reports in plain language with the query that ran. Covers
  every seal registered under seals/ (UR, WL, RPEX, ForgeRock and CAAS sign-in, CXO web, DPS
  gateway, redemption partners). Formerly rewards-splunk-cli. Use when someone says splunk,
  triage, prod investigation, incident, alert fired, trace a request, 5xx spike, latency,
  sign-in failures, redemption or balance failures, or names an index, seal ID, profile ID or
  trace ID. Not for dashboards, alerts configuration, non-production log analysis, or Splunk
  credentials.
argument-hint: "What broke, for whom, since when, which environment"
classification: BETA
---

# splunk-triage

```
 question ──► resolve.py ──► PATH fast: first query printed ──► CLI ──► short report
                 │                                                ▲
                 └──► PATH full: journey, hops (key + skew),      │  guard.py: read-only,
                      seals to read ──► build_query.py / recipe ──┘  bounds, redaction
   seals/<id>-<name>/   seal.yaml · fields.yaml (roles, focus) · links.yaml · alerts.yaml · notes.md · queries.md
   journeys/            ordered hops across seals        org.yaml  instances & limits     core/  rules, once
```

Read `core/guardrails.md` once per session. `{SKILLS_DIR}` is the folder this file's parent sits
in (`~/.copilot/skills`, `~/.claude/skills` or the repo's skills folder). The commands below take
every setting as a flag, so they run unchanged in bash, zsh, PowerShell and cmd; on Windows write
`python` for `python3`. Then:

## 1. Resolve

```bash
python3 {SKILLS_DIR}/splunk-triage/scripts/resolve.py "<the user's words>"
```

It prints `PATH`, the environment, the seal(s), the instance, and either a ready first query
(fast) or the journey hops with key and skew plus the files to read (full). `RECIPE: <title>`
means one section of that seal's `queries.md` answers the question: read that section only and
run it. No match: read `registry.yaml`; still nothing: say no seal is registered and offer
`scripts/onboard_seal.py`.

## 2a. Fast path (one seal, a standard question or a known alert)

Run the printed query with the printed `--base-url` and `--context`. Open no seal files. No rows: say so with the
window and offer the next one (15m → 1h → 4h); widen past 1h only when asked. A few rows: one
Step 2 or 3 query (`build_query.py --seal <id> --step 2|3`) and stop. Report in the short form:

```
**<Seal> <env>, last <window>:** <one sentence: how many of what, where>.
<Severity word>, <Confidence word>. <One sentence on the biggest row or that it is normal background.>
<the SPL that ran, then its three plain lines>
Next: <one line>  ·  Queries run: N
```

## 2b. Full path (a journey, several seals, a trace, or an unclear question)

Read only what the resolver listed: the ladder, the correlation method when seals are crossed,
`fields.yaml` for each seal, `notes.md` for the entry seal. Open another `notes.md` only when
one of its fields appears in a result; open a `queries.md` section by the recipe title the
resolver printed only when no built query fits; read `query-performance.md` only to write new SPL.

Then climb the ladder: `build_query.py --seal <id> --step <n> [--kind errors|latency|volume]
[--where …] [--key f --value v] [--trend 5m] [--baseline] [--around "14:05" --span 30m] [--since "14:00"] [--app wl]`.
Take hop keys and skew from the resolver output, never from memory. When the question is "which
hop fails", run Step 1 on each hop's seal (at the same time if your runtime can, otherwise back
to back) and compare before going deep on one. When the user gives code context or a repo, read
it alongside Step 1 and join the two at the findings; `seal.yaml` `repos` and `code_hints` say
where an exception class lives.

Run every query through the CLI:

```bash
python3 {SKILLS_DIR}/splunk-triage/scripts/splunk_cli.py search '<SPL>' --base-url <url>:<port> --context <seal-id> [--json] [--focus errors] [--baseline]
```

`--base-url` is the `INSTANCE` the resolver printed. When the SPL is hard to quote in your shell,
save it to a file and pass `@path/to/query.spl`. `--json` only when `_time` matters (trends). The CLI projects to the seal's focus when the SPL
has no `table`, caps text with a visible `…[+N chars]`, decodes codes (`500 (server error)`), and
collapses repeated rows. A guard rejection is final.

## 3. Check, then report

Before concluding: an empty cell is "not extracted", a cut marker means read the full row (Step
5, `--raw`, `head ≤ 5`, owning seal's context), exactly the row cap means the list is cut, the
same round latency on every failure is a timeout, a placeholder hop is a hypothesis. Then
`core/references/output-format.md` (or the seal's `overrides/output-format.md`): What happened ·
Severity and Confidence · Findings · Query with its three plain lines · Next step.

## 4. Leave something behind

When a new query or a confirmed key resolved the incident, give the user the entry to paste: a
`queries.md` recipe (title, when, SPL, provenance), a `links.yaml` edge with `status: confirmed`,
or an `alerts.yaml` entry. The owning team merges it. Do not edit skill files yourself.

## Setup and onboarding

`python3 splunk-triage/scripts/setup.py` checks and fixes the install. If the CLI says
`SPL-ONLY MODE` (no `splunk_client.py` yet), hand the user the SPL with its time bounds and
report no findings; `--dry-run` shows the guard's verdict and the plan without sending anything. `python3 splunk-triage/scripts/onboard_seal.py` adds an application in one
sitting and prints a completeness score; `validate.py --score` shows what a seal still lacks.
