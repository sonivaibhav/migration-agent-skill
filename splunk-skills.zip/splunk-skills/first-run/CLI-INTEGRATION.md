# Plugging your login and search scripts into the CLI

`splunk_cli.py` is complete. It needs exactly two functions from you, in
`splunk-triage/scripts/splunk_client.py`. Everything about *how* you sign in and search stays in
your code; the CLI only decides *whether* a query may run and *what* may be printed.

```
splunk_cli.py  (shipped)                      splunk_client.py  (yours)
  parse flags                                   login(base_url) -> session
  guard.check_spl  ─── reject? exit 3 ──►         Kerberos/ADFS, token cache, TLS
  check_host (org.yaml)                         search(session, base_url, spl, max_rows) -> rows
  login → search → (AuthError? login once more)   one blocking job, JSON rows, raises on failure
  guard.Redactor → format_table / JSON
  Budget → audit line → --save
```

## Step by step

1. `cp splunk-triage/scripts/splunk_client_example.py splunk-triage/scripts/splunk_client.py`
2. Move your sign-in code into `login(base_url)`. Return whatever your search needs (a
   `requests.Session`, a token, a small object). Raise `AuthError` on any 401/403 or Kerberos
   failure. Keep your cache; put it under `~/.agent_data/splunk-triage/tokens/`, owner-only.
3. Move your search code into `search(session, base_url, spl, max_rows, timeout_s=120)`. The
   `spl` already starts with `search` or `|`. Return `list[dict]` (one dict per result row, the
   JSON results shape). Cap at `max_rows`. Raise `SearchError` on a failed job or a poll timeout;
   never return a partial result silently. `search` may be called from a few threads at once
   (the `fanout` subcommand); each call gets its own `login()` result, so keep per-call state
   out of module globals.

   Job parameters that cut Splunk's work without changing the rows (set them when you create
   the job; the SPL already names every field it needs):

   | Parameter | Value | Why |
   |---|---|---|
   | `adhoc_search_level` | `fast` | no automatic field discovery; a `\| table` query otherwise extracts every field of every event |
   | `status_buckets` | `0` | no timeline histogram |
   | `exec_mode` | `oneshot` (or `blocking`) | one request, results in the response; no polling loop to get wrong |
   | `count` / `max_count` | `max_rows` | the row cap enforced at the source |
   | `output_mode` | `json` | the shape `list[dict]` expects |
   | `preview` | `0` on `/export` | if you stream from `search/v2/jobs/export`, never return preview rows |
   | `timeout` | `timeout_s` | let Splunk reap the job if the client dies |

4. Your module may read `SPLUNK_SESSION` / `SPLUNK_CSRF` overrides and `REQUESTS_CA_BUNDLE`. It
   must ignore any "insecure TLS" switch.
5. `python3 splunk-triage/scripts/splunk_cli.py access-check --env test`
6. `python3 first-run/check_cli_contract.py --env test`

## Is my module structured well? A checklist

Tick each line by reading your `splunk_client.py`; the contract check covers the ones marked ✔.

| | Check | Why |
|---|---|---|
| ✔ | Only two public functions plus two exception classes | The CLI imports nothing else; anything more is surface you maintain |
| ✔ | `login` never prints or logs a token, cookie or header value, including in exceptions | Exceptions reach stderr and the audit trail |
| | Token cache file is created with mode 0600, in `~/.agent_data/splunk-triage/tokens/<host>.json` | Shared machines |
| | Cache TTL honours `SPLUNK_CACHE_TTL_HOURS` (default 8) and an invalid value falls back to 8 | Same behaviour as before |
| ✔ | `search` returns `[]` for a search with no results, not `None` | The redactor iterates |
| ✔ | `search` respects `max_rows` (pass it as the job's `count`/`max_count`, and slice) | The row cap is a guard rule |
| | The job is created with `adhoc_search_level=fast` and `status_buckets=0` | Field discovery on a busy index costs more than the search itself |
| ✔ | Three `search` calls at once from three threads all succeed | `fanout` runs hop queries together; Splunk's per-user job quota (often 3) must not be exceeded by `limits.max_concurrent_searches` |
| | `search` polls the job with a deadline and raises `SearchError("timeout")` past `timeout_s` | A hung job must not hang the agent |
| ✔ | `search` raises `AuthError` on 401/403 so the CLI re-signs once | Expired sessions |
| | Redirects are followed only to hosts you allow (ADFS and the Splunk hosts in `org.yaml`) | Sign-in redirect safety |
| | No network call happens at import time | `splunk_cli.py build` and `--dry-run` import your module without Splunk |
| | No dependency beyond `requests` + the Kerberos backend | Keeps `requirements.txt` true |
| | The module runs on Windows (SSPI) and macOS/Linux (GSSAPI) via the same two functions | One code path for everyone |

## Running the security tests against your module

`tests/security` and `tests/unit/test_cli_integration.py` run against a fake client in a temp
copy, so they pass regardless of your code. To exercise yours:

```bash
python3 first-run/check_cli_contract.py --env test        # real CLI, real UAT, safe queries only
```

It runs: five guard rejections (must exit 3 with no network call), `| makeresults`, one
`stats count` on each seal's index over 5 minutes, `--raw` without context (must exit 3),
`--baseline`, `--dry-run`, a `fanout` of three counts at once (proves the job quota), and a
refused host via the environment and via `--base-url` (must exit 6). Nothing it runs reads
more than one row of real data.

## What you can delete from your old CLI

Write subcommands (saved searches, dashboards, export), the old `check_setup.py`, any
`known-instances.yml` reader (the CLI reads `org.yaml`), and any output formatting. Keep the
sign-in, the cache, and the search engine.
