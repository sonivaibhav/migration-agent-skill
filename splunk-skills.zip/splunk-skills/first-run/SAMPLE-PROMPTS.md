# Sample prompts

Type them as `/splunk-triage <prompt>` (or just ask in plain words when the skill is active).
Each line says which path the resolver should take, so you can tell when something is off.

## A ten-minute tour for a new team member

Do these in order; together they show the ladder, the fast and full paths, and the guardrails.

1. `Check UR prod logs for new errors` — fast path, one query, a short report. Notice the three
   plain lines under the SPL and that the Profile ID column is a hash.
2. `Same, but since 2pm` — the window becomes absolute `14:00 → now`.
3. `UR latency looks bad in prod` — fast path, percentiles already in ms.
4. `Is that normal? compare to last week` — the agent re-runs with `--baseline`.
5. `Show me a sample of those 5xx` — one Step 3 query: 20 de-duplicated rows, not 100.
6. `Which platforms were affected?` — decoded platform names, a Missing row, never "Web" for a
   missing cookie.
7. `Users cannot sign in to Ultimate Rewards since 2pm` — full path: the `ur-sign-in` journey,
   two hops. The resolver prints a `FANOUT` line; the agent runs it once, gets both hops' Step 1
   side by side, then uses the CAAS recipe with the UR-origin filter on the hop that moved.
8. `Trace frTraceId <paste one from step 5> into ForgeRock` — one request across two seals with
   the skew window; the ForgeRock sign-in name stays `[redacted]`.
9. `Export those rows to a lookup so I can share them` — refused (read-only), offered as a
   redacted table instead.
10. `Show me the last two weeks` — the agent asks before a 14-day production search.

## By seal

### UR / WL (89592)

| Prompt | Path | What you should see |
|---|---|---|
| `Check UR prod logs for new errors` | fast | 5xx by status and endpoint, last 15 min |
| `WL 500s in prod` | fast | the **WL** access sourcetype, not UR |
| `UR 5xx around 2:05pm` | fast | a 30-minute window centred on 14:05 |
| `UR traffic by region` | full, `RECIPE: Traffic by region` | the region recipe (`rex` on `source`), not a generated query |
| `UR app errors for the profile the customer gave: <id>` | full | Step 4 on the app log; the id appears as a hash and as `<PROFILE_ID>` in the SPL |
| `Did UR and WL both have errors at 3pm?` | full | the UR-vs-WL recipe |
| `UR Prod splunk alert triggered: UR Prod 5xx Rate` | fast (alert) | the alert's query, its `then` line as Next |

### ForgeRock / CAAS (81712)

| Prompt | Path | What you should see |
|---|---|---|
| `CAAS 500s in prod` | fast | CAAS access audit, `httpCode>=500` by Referer |
| `Why did this profile get repeated 401s on UR?` | full | `TERM(profileid=…)` recipe; one failure then success = token refresh |
| `A customer sent an error page with trace 0.ab12.4567.cd89` | full | the browser-token recipe across both indexes |
| `Is the ForgeRock gateway timing out?` | fast (latency) | `responseTimeMs` percentiles; 15,000 ms rows are the gateway ceiling |

### RPEX (111863)

| Prompt | Path | What you should see |
|---|---|---|
| `RPEX 500s` | fast | order-experience service, `level=ERROR` by logger |
| `RPEX balance service slow in UAT` | full | the MONETA_PERF latency recipe (latency lives in `message`), UAT instance |
| `What status are RPEX callers seeing?` | full | the response-status-mix recipe (`MONETA_RESPONSE`) |
| `Did RPEX cause the UR redemption history errors at 14:05?` | full | the UR-vs-RPEX window comparison; no request join, said plainly |
| `Which channel is sending RPEX the most traffic?` | full | channel mix across services |

### CXO web (85980)

| Prompt | Path | What you should see |
|---|---|---|
| `CXO web errors in prod` | fast | `loglevel=ERROR` by component, 15 min |
| `CXO web errors on UR pages` | full | two seals named (CXO and UR), so the agent reads both field maps and uses the UR signal recipe |
| `What pages did profile <id> see in the browser?` | full | the pages recipe via `TERM()`; a note that CXO shows what the browser reported, not the server truth |
| `How many browsers hit the UR sign-in challenge?` | full | challenges by page; "users" called out as distinct profile IDs |

### DPS gateway (88082)

| Prompt | Path | What you should see |
|---|---|---|
| `DPS gateway 5xx` | fast | envoy sourcetype, `response_code>=500` by path |
| `Is the gateway part of the UR problem?` | full | UR-originated traffic through DPS recipe, then the UR-vs-DPS window compare |
| `Which backend services is DPS calling right now?` | full | live sourcetypes list first (the set changes) |

## Journeys (more than one seal)

| Prompt | Path | What you should see |
|---|---|---|
| `Users cannot sign in to Ultimate Rewards since 2pm; which hop is failing?` | full, `FANOUT` | one `splunk_cli.py fanout` call labelled `81712-forgerock,89592-ur`; a comparison before any sample |
| `Redemption history is failing for everyone` | full | the `ur-redemption-history` journey; Step 1 on each hop via the fan-out, then the RPEX recipe |
| `Cashback orders are not going through` | full | the `ur-cashback-order` journey; the placeholder hop is reported as a hypothesis |

## Prompts that should be refused or bounced

| Prompt | Expected |
|---|---|
| `Delete the bad events` / `Export to CSV` / `Email me the results` | Refused: read-only. Redacted table offered |
| `Show me raw events for the last hour` | Refused at that size; `--raw` is 5 rows for one request, with the owning seal's context |
| `Search all indexes for this id` | Refused: `index=*` scans everything; the resolver names the seal instead |
| `Look up what John Smith did yesterday` | Refused: identifiers come from incidents, not names |
| `Just paste the customer's SSN into the query` | The SSN never appears in prose or the shown SPL; pattern guards scrub it from results |

## Onboarding prompts (for a team adding its seal)

- `Onboard my application to splunk-triage` — the agent runs `onboard_seal.py` with you.
- `Print the field list query for index X sourcetype Y` — `onboard_seal.py --fieldsummary`.
- `What is my seal missing?` — `validate.py --score <id>`.
- `What does my seal connect to?` — `GRAPH.md`.
