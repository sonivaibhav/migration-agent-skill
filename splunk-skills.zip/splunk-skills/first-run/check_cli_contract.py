#!/usr/bin/env python3
"""Contract check for the real splunk_cli.py + your splunk_client.py, against a live instance.

    python3 first-run/check_cli_contract.py --env test          # default: UAT
    python3 first-run/check_cli_contract.py --env prod --seal 89592

Every query here is bounded to 5 minutes and one row. Guard rejections are checked first and
must exit 3 before any network call. Prints a PASS/FAIL table and exits 1 on any FAIL.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "splunk-triage"
CLI = SKILL / "scripts" / "splunk_cli.py"
sys.path.insert(0, str(SKILL / "scripts"))

from _common import load_yaml, registry, ORG  # noqa: E402


def run(args, env):
    t0 = time.time()
    r = subprocess.run([sys.executable, str(CLI), *args], capture_output=True, text=True, env=env, cwd=SKILL)
    return r, time.time() - t0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--env", default="test", choices=["prod", "test"])
    ap.add_argument("--seal", help="only this seal's index for the live search rows")
    a = ap.parse_args()

    org = load_yaml(ORG)
    inst = next((i for i in org["instances"] if i["environment"] == a.env), None)
    if not inst:
        sys.exit(f"no {a.env} instance in org.yaml")
    base = f"{inst['url'].rstrip('/')}:{inst.get('port', 443)}"
    env = {**os.environ, "SPLUNK_BASE_URL": base, "SPLUNK_TRIAGE_RUN": "contract-check"}
    if not (SKILL / "scripts" / "splunk_client.py").exists():
        sys.exit("scripts/splunk_client.py is missing; see first-run/CLI-INTEGRATION.md")

    reg = registry()
    seals = [s for s in reg["seals"] if not a.seal or s["id"] == a.seal]
    idx0 = seals[0]["indexes"][0]
    results = []

    def check(name, args, want_code, must_be_fast=False, stdout_has=None, stderr_has=None):
        r, dt = run(args, env)
        ok = r.returncode == want_code
        if must_be_fast and dt > 3:
            ok = False
        if stdout_has and stdout_has not in r.stdout:
            ok = False
        if stderr_has and stderr_has not in r.stderr:
            ok = False
        results.append((ok, name, f"exit {r.returncode} ({dt:.1f}s)" + ("" if ok else f"  {r.stderr.strip()[:100] or r.stdout.strip()[:100]}")))

    # guard rejections: exit 3, under 3 s (no network)
    check("reject write command", ["search", f"index={idx0} earliest=-5m | outputlookup x", "--context", seals[0]["id"]], 3, True, stderr_has="REJECTED")
    check("reject missing earliest", ["search", f"index={idx0} | stats count"], 3, True)
    check("reject all-time window", ["search", f"index={idx0} earliest=0 | stats count"], 3, True)
    check("reject index=*", ["search", "index=* earliest=-5m | stats count"], 3, True)
    check("reject --raw without owner context", ["search", f"index={idx0} earliest=-5m | head 5 | table _raw", "--raw"], 3, True)
    r, dt = run(["search", f"index={idx0} earliest=-5m | stats count"], {**env, "SPLUNK_BASE_URL": "https://not-in-org.example.com:443"})
    results.append((r.returncode == 6, "refuse unknown host", f"exit {r.returncode} ({dt:.1f}s)"))

    # dry run: plan only
    check("dry-run prints plan", ["search", f"index={idx0} earliest=-5m | stats count", "--dry-run"], 0, stdout_has="DRY RUN")

    # live, minimal
    check("access-check", ["access-check", "--env", a.env], 0, stdout_has="OK")
    for s in seals:
        for idx in s["indexes"]:
            check(f"stats count on {idx}", ["search", f"index={idx} earliest=-5m latest=now | stats count", "--context", s["id"]], 0, stdout_has="count")
    check("one redacted row", ["search", f"index={idx0} earliest=-5m latest=now | head 1 | table *", "--context", seals[0]["id"]], 0)
    check("baseline runs twice", ["search", f"index={idx0} earliest=-5m latest=now | stats count", "--baseline"], 0, stdout_has="one week earlier")
    check("json keeps _time", ["search", f"index={idx0} earliest=-5m latest=now | bin _time span=5m | stats count by _time", "--json"], 0, stdout_has="_time")
    # three searches at once: proves the Splunk job quota allows limits.max_concurrent_searches from this account
    check("fanout, 3 at once", ["fanout", *(f"index={idx0} earliest=-5m latest=now | stats count" for _ in range(3)),
                                "--labels", "a,b,c", "--base-url", base], 0, stdout_has="3/3 queries")
    check("--base-url flag refuses unknown host", ["search", f"index={idx0} earliest=-5m | stats count", "--base-url", "https://not-in-org.example.com:443"], 6)

    print(f"\ncontract check against {base}\n")
    for ok, name, detail in results:
        print(f"  {'PASS' if ok else 'FAIL'}  {name:<42} {detail}")
    bad = sum(1 for ok, *_ in results if not ok)
    print(f"\n{len(results) - bad}/{len(results)} passed")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
