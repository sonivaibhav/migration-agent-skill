# Facts to validate

Everything below was transcribed from photos of your screen, or is a default I chose. A wrong
token returns an empty result that looks like "no traffic", so check each once. Most rows are
one query. Run them through the CLI (`splunk_cli.py search '…' --context <seal>`) or the Splunk UI.
Tick, or correct the file named in the last column.

## Instances and access

| Check | How | Correct in |
|---|---|---|
| The four instance URLs and ports | `splunk_cli.py access-check` prints OK for each | `org.yaml` |
| `access_request` link | Replace the placeholder with the real How-To link | `org.yaml` |
| `timezone` matches your Splunk user profile | Splunk UI → account settings → time zone | `org.yaml` |

## Index and sourcetype names (one per seal)

| Check | Query | Correct in |
|---|---|---|
| UR/WL sourcetypes, incl. the three EKS legacy ones still receiving traffic | `index=cfs_digital_ultimate_rewards_aws_89592 earliest=-15m \| stats count by sourcetype` | `seals/89592-ur/seal.yaml` |
| `uraccess`/`wlaccess` have no underscore before `access` | same query; the names must match exactly | `seal.yaml`, `fields.yaml`, `queries.md` |
| ForgeRock: `cfs_digauthciam_ig_lob_aws_access_audit_st` (with `_lob_`) and `cfs_digauthciam_ig_aws_acess_audit_st` (one `c`) | `index=cfs_digauthciam_81712 earliest=-15m \| stats count by sourcetype` | `seals/81712-forgerock/seal.yaml` |
| RPEX four sourcetypes | `index=rpex_111863 earliest=-15m \| stats count by sourcetype` | `seals/111863-rpex/seal.yaml` |
| CXO single sourcetype `cfs_digital_85980_cpo_client` | `index=cfs_digital_85980 earliest=-1m \| stats count by sourcetype` | `seals/85980-cxo-web/seal.yaml` |
| DPS `digital_envoy_access_st` and `cfs_digital_tomcat_access_st` | `index=cfs_digital_88082 earliest=-5m \| stats count by sourcetype` | `seals/88082-dps-gateway/seal.yaml` |

## Field names and roles (what the builder depends on)

For each active sourcetype, run the field list once and compare with `fields.yaml`:

```
index=<index> sourcetype=<sourcetype> earliest=-1m latest=now | head 200 | fieldsummary maxvals=0 | where count>0 | table field, count | sort - count
```

| Check | Expect | Correct in |
|---|---|---|
| UR access: `uri status responseTime smCigProfileId frTraceId sessionId authInfo xForwardedFor remoteIp requestId` | all present | `seals/89592-ur/fields.yaml` |
| UR app: `userId requestUri level logger message pod traceId` | all present | same |
| FR UR traffic audit: `transactionId uriPath response.statusCode responseTimeMs userId trackingIds{}` | all present | `seals/81712-forgerock/fields.yaml` |
| FR CAAS: `httpCode appname ENV1 Referer AMSESSION XJpmcClientRequestID` | all present | same; the CAAS and AM tables (original lines 59+) were never photographed, so this one is from memory |
| RPEX roex/rbes: `channel-type traceId logger level message http.endpoint online-profile-identifier` | all present | `seals/111863-rpex/fields.yaml` |
| DPS envoy snake_case vs tomcat camelCase | `profile_id` on envoy, `profileId` on tomcat | `seals/88082-dps-gateway/fields.yaml` |
| DPS tomcat has **no** status field mapped | if `fieldsummary` shows one (e.g. `statusCode`), add it and the `status` role | same |

## Units (one event each)

| Check | Query | Expect | Correct in |
|---|---|---|---|
| UR `responseTime` is microseconds | `index=cfs_digital_ultimate_rewards_aws_89592 sourcetype=wcmur_cfs_ultimate_rewards_ecs_uraccess_st earliest=-5m \| head 1 \| table responseTime` | a value like `13245` for a ~13 ms request | `fields.yaml` unit `us` |
| FR `responseTimeMs` is ms | same shape on the FR sourcetype | small integers | unit `ms` |
| DPS `duration` (envoy) and `responseTime` (tomcat): unit **not confirmed** | same shape | decide `us`/`ms` | `seals/88082-dps-gateway/fields.yaml`, remove `NOT CONFIRMED` |
| RPEX `MONETA_PERF` `TIME=[ms]` | recipe "Latency from MONETA_PERF" | plausible ms | `notes.md` |

## Decodes and signals

| Check | Query | Correct in |
|---|---|---|
| `authInfo` codes seen in prod: `C30 MOD MON MOP -` (and PB codes if Private Bank traffic exists) | `… uraccess_st earliest=-1h \| stats count by authInfo` | `seals/89592-ur/fields.yaml` `decode:` |
| CAAS `Referer` for UR sign-ins contains `fromOrigin=https://ultimaterewardspoints.chase.com` | `… acess_audit_st earliest=-15m "ultimaterewardspoints" \| stats count by Referer \| head 5` | `81712 queries.md`, `89592 links.yaml caas-signin` |
| RPEX `channel-type` values per service (`UR`, `LSP`, `MOBILE_NATIVE`) | `index=rpex_111863 earliest=-15m \| stats count by sourcetype, "channel-type"` | `seals/111863-rpex/seal.yaml` notes |
| CXO `message.screen.currentURL` carries `ultimaterewardspoints.chase.com` | recipe "UR sign-in challenges by page" | `85980 notes.md` |

## Join keys (the five placeholders, plus two confirmations)

| Edge | Verify | Then |
|---|---|---|
| `89592/fr-request` (confirmed Aug 24) | re-run its `verify_query` with a fresh `frTraceId` | keep `confirmed` |
| `89592/cashback-order` placeholder | needs the cashback seal first (`onboard_seal.py`), then run `verify_query` | fill `to`, `to_field`, `skew_s`, `status: confirmed` |
| `81712/caas-downstream` placeholder | ask the CIAM team what CAAS calls and which header crosses | same |
| `81712/am-audit` placeholder | `verify_query` with a known trace | same |
| `111863/dps-call` placeholder | `verify_query` with an RPEX `traceId` from a `DPS call FAILED` line | same |
| `88082/backend-service`, `88082/caas-client-request` placeholders | DPS team | same |

## Defaults I chose that you may want to change

| Default | Where | Why you might change it |
|---|---|---|
| High-volume window 15 m, default 1 h, cap 24 h, row cap 1,000 | `org.yaml` `limits` | Your Splunk search quotas |
| `sample_rows: 20` per seal | `fields.yaml` | Noisier seals lower it |
| Text cap 300 chars on `message` | `fields.yaml` | Stack traces: raise to 500 if the first line rarely names the cause |
| Severity default `Major` on the UR example alert | `seals/89592-ur/alerts.yaml` | Replace the whole example entry with real alerts |
| Volume `high` on all five seals | `seal.yaml` | `medium` or `low` seals start with a 1 h window |
