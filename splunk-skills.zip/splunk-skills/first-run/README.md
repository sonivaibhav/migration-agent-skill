# First run on your org machine

Ordered. Each step says what to run and what "done" looks like. Expect about two hours for
steps 1–6 if Kerberos already works on the machine; the rest is team time.
Delete this folder once the pilot is over, or keep it as the onboarding guide for new orgs.
Commands are written for bash/zsh with `python3`; on Windows PowerShell use `python` and the
same flags. The agent side is the same whichever model runs the skill (Copilot with GPT or
Claude models, Claude Code): the skill never relies on model-specific tools or sub-agents.

| # | Step | Run | Done when |
|---|---|---|---|
| 1 | Clone and set up | `git clone …/splunk-skills.git && python3 splunk-skills/splunk-triage/scripts/setup.py` | Every line `OK` except `splunk_client.py missing` |
| 2 | Prove the agent flow without Splunk | In your agent: `/splunk-triage Check UR prod logs for new errors` | The agent runs `resolve.py`, then `splunk_cli.py … --dry-run` or sees `SPL-ONLY MODE`, and hands you a 5–7 line query with three plain lines under it. No seal files opened |
| 3 | Plug in your login/search code | Follow [CLI-INTEGRATION.md](CLI-INTEGRATION.md): copy `scripts/splunk_client_example.py` to `scripts/splunk_client.py`, fill `login()` and `search()` | `python3 splunk-triage/scripts/splunk_cli.py access-check --env test` prints `OK` for the UAT instance |
| 4 | Run the contract check against the real CLI | `python3 first-run/check_cli_contract.py --env test` | All rows `PASS`. This proves the guard runs before the network, redaction happens after, and exit codes match |
| 5 | First real question, UAT | `/splunk-triage UR 500s in UAT` | A short-form report with a real count. If the count is 0 the agent offers the next window; that is correct |
| 6 | First real question, prod | `/splunk-triage Check UR prod logs for new errors` then `/splunk-triage UR latency looks bad in prod` | Two reports under 120 words each. Check the numbers against the Splunk UI once |
| 7 | Validate what I transcribed from photos | [VALIDATE.md](VALIDATE.md), top to bottom | Each row ticked or corrected. Most are one query each |
| 8 | Fill in the org facts | `seals/*/seal.yaml` owners and repos · `seals/*/alerts.yaml` real alert names · `org.yaml` access link | `validate.py --score` no longer lists "real owners" or "alert" for the seals you own |
| 9 | Confirm the five placeholder links | Run each `verify_query` in `seals/*/links.yaml` in prod (one request you already know), fill `to_field` and `skew_s`, set `status: confirmed` | `GRAPH.md` shows solid arrows; `validate.py --score` drops the placeholder line |
| 10 | Full path, two seals | `/splunk-triage users cannot sign in to Ultimate Rewards since 2pm` | The agent follows the `ur-sign-in` hops, uses the CAAS recipe, reports with Severity and Confidence |
| 11 | Onboard the first new seal with its team | `python3 splunk-triage/scripts/onboard_seal.py` with the team on the call; paste their `fieldsummary` output when asked | `validate.py --score` grade B or better (A once links are confirmed); `resolve.py "<their app> 5xx"` is `PATH: fast` |
| 12 | Hand teams the prompts | [SAMPLE-PROMPTS.md](SAMPLE-PROMPTS.md) | Each team tries its own section |

## What to watch in the first week

- **Zero-row answers.** They are usually right (quiet window), but check that the sourcetype token
  is exact once per seal: `index=<index> earliest=-15m | stats count by sourcetype`.
- **Severity and Confidence.** If reports say Major with High confidence on a 3-row sample, the
  agent skipped the ladder; the eval case `e01` catches it.
- **Budget warnings on stderr.** They mean the agent is sampling instead of aggregating; that is
  the report to look at.
- **Audit log.** `~/.agent_data/splunk-triage/audit.log` has one line per query (hash, context,
  rows, status; never SPL or results). It tells you who-asked-what volume without reading reports.

## Scaling after the pilot

- One PR per seal, reviewed by that team; CI (`bitbucket-pipelines.yml`) runs `validate.py`,
  the registry freshness check and the tests. Nothing in `core/` changes for a new seal.
- `validate.py --score` is the gate for "ready": B or better before announcing a seal.
- Another org: copy `splunk-triage/`, replace `org.yaml` and `seals/`, keep `core/`.
