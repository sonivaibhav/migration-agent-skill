#!/usr/bin/env bash
# ============================================================================
#  staff-dev-env :: bootstrap
#
#  Designed for a corporate-managed macOS (Apple Silicon) where:
#    - Homebrew is NOT allowed
#    - /usr/bin and /usr/local are not writable
#    - some CLI tools are already provided by the company's internal catalog
#
#  Everything here is ADDITIVE and USER-SCOPE:
#    binaries  -> ~/.local/bin  and  ~/.local/share/mise
#    config    -> ~/.config/staff-dev-env
#    ~/.zshrc  -> gains exactly ONE source line
#
#  Uninstall = delete ~/.local/share/mise, ~/.config/staff-dev-env,
#              and remove the one line from ~/.zshrc.
#
#  NOTHING IS WRITTEN until you have seen `sde-preflight` output and confirmed.
#
#  Usage:
#     ./install.sh --preflight     # AUDIT ONLY. Read-only. Start here.
#     ./install.sh --backup-only   # snapshot your current config, change nothing
#     ./install.sh                 # preflight, then ask, then install
#     ./install.sh --core          # tier 1 tools only
#     ./install.sh --dry-run       # show every action, perform none
#     ./install.sh --no-tools      # config only, skip binary installs
#     ./install.sh --yes           # skip the confirmation prompt (CI / re-runs)
# ============================================================================
set -euo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${STAFF_DEV_ENV_HOME:-$HOME/.config/staff-dev-env}"
LOCAL_BIN="$HOME/.local/bin"
BACKUP_ROOT="$HOME/.config/staff-dev-env-backups"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/$STAMP"

DRY_RUN=0
NO_TOOLS=0
CORE_ONLY=0
ASSUME_YES=0
PREFLIGHT_ONLY=0
BACKUP_ONLY=0
SKIP_PREFLIGHT=0

for arg in "$@"; do
  case "$arg" in
    --dry-run)        DRY_RUN=1 ;;
    --no-tools)       NO_TOOLS=1 ;;
    --core)           CORE_ONLY=1 ;;
    --preflight)      PREFLIGHT_ONLY=1 ;;
    --backup-only)    BACKUP_ONLY=1 ;;
    --skip-preflight) SKIP_PREFLIGHT=1 ;;
    -y|--yes|--i-read-the-preflight) ASSUME_YES=1 ;;
    -h|--help)        sed -n '1,32p' "$0"; exit 0 ;;
    *) echo "unknown flag: $arg" >&2; exit 1 ;;
  esac
done

# ---------------------------------------------------------------- output ----
c_ok()   { printf '\033[32m  ok\033[0m   %s\n' "$*"; }
c_add()  { printf '\033[36m add\033[0m   %s\n' "$*"; }
c_skip() { printf '\033[90mskip\033[0m   %s\n' "$*"; }
c_warn() { printf '\033[33mwarn\033[0m   %s\n' "$*"; }
c_head() { printf '\n\033[1m== %s\033[0m\n' "$*"; }

run() {
  if [ "$DRY_RUN" = 1 ]; then printf '\033[90m  dry\033[0m   %s\n' "$*"; else eval "$@"; fi
}

# ===========================================================================
#  STEP 0 — AUDIT WHAT YOU ALREADY HAVE
#  Read-only. Runs before anything is written, every time.
# ===========================================================================
PF_REPORT="$BACKUP_ROOT/preflight-$STAMP.txt"
if [ "$SKIP_PREFLIGHT" = 0 ] && [ -x "$SRC_DIR/bin/sde-preflight" ]; then
  mkdir -p "$BACKUP_ROOT"
  set +e
  STAFF_DEV_ENV_SRC="$SRC_DIR" bash "$SRC_DIR/bin/sde-preflight" --report "$PF_REPORT"
  PF_RC=$?
  set -e
  echo
  c_ok "preflight report saved: $PF_REPORT"
else
  PF_RC=0
fi

if [ "$PREFLIGHT_ONLY" = 1 ]; then
  echo
  c_ok "audit only — nothing was changed."
  exit "$PF_RC"
fi

# ===========================================================================
#  STEP 1 — BACK UP EVERYTHING WE COULD POSSIBLY TOUCH
#  Runs before the first write, always, even if you pass --yes.
# ===========================================================================
take_backup() {
  local made=0
  mkdir -p "$BACKUP_DIR"
  for f in "$HOME/.zshrc" "$HOME/.zshenv" "$HOME/.zprofile" "$HOME/.gitconfig" \
           "$HOME/.ideavimrc" "$HOME/.tmux.conf" "$HOME/.config/tmux/tmux.conf" \
           "$HOME/.config/git/ignore" "$HOME/.config/git/config"; do
    if [ -e "$f" ] || [ -L "$f" ]; then
      local rel="${f#$HOME/}"
      mkdir -p "$BACKUP_DIR/$(dirname "$rel")"
      cp -aP "$f" "$BACKUP_DIR/$rel"
      made=1
    fi
  done

  # A record of your shell's state, so you can diff behaviour later, not just files.
  command -v zsh >/dev/null 2>&1 && \
    zsh -ic 'print -l ${(k)functions} ${(k)aliases}' 2>/dev/null | sort -u \
      > "$BACKUP_DIR/shell-names-before.txt" || true
  command -v git >/dev/null 2>&1 && \
    git config --global --list > "$BACKUP_DIR/gitconfig-global-before.txt" 2>/dev/null || true

  # Self-contained restore script. No dependency on this repo still existing.
  cat > "$BACKUP_DIR/restore.sh" <<'RESTORE'
#!/usr/bin/env bash
# Restore the config that was in place before staff-dev-env was installed.
# Safe to run more than once.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "restoring from $HERE"

# 1. put the original files back
for rel in .zshrc .zshenv .zprofile .gitconfig .ideavimrc .tmux.conf \
           .config/tmux/tmux.conf .config/git/ignore .config/git/config; do
  if [ -e "$HERE/$rel" ] || [ -L "$HERE/$rel" ]; then
    mkdir -p "$HOME/$(dirname "$rel")"
    cp -aP "$HERE/$rel" "$HOME/$rel"
    echo "  restored ~/$rel"
  fi
done

# 2. remove files we created that did not exist before
for rel in .ideavimrc .config/tmux/tmux.conf .config/git/ignore; do
  if [ ! -e "$HERE/$rel" ] && [ -L "$HOME/$rel" ]; then
    rm -f "$HOME/$rel"; echo "  removed ~/$rel (did not exist before)"
  fi
done

# 3. strip our block from ~/.zshrc if the backup predates it
if [ -f "$HOME/.zshrc" ] && grep -qF '# >>> staff-dev-env >>>' "$HOME/.zshrc"; then
  sed -i.sde-bak '/# >>> staff-dev-env >>>/,/# <<< staff-dev-env <<</d' "$HOME/.zshrc"
  echo "  removed the staff-dev-env block from ~/.zshrc"
fi

# 4. drop our gitconfig include
git config --global --unset-all include.path 2>/dev/null || true
echo "  removed include.path from ~/.gitconfig"

echo
echo "done. run: exec zsh"
echo "the tools themselves are still in ~/.local/share/mise — remove with:"
echo "  rm -rf ~/.local/share/mise ~/.config/staff-dev-env"
RESTORE
  chmod +x "$BACKUP_DIR/restore.sh"
  [ "$made" = 1 ] || echo "(no existing config files found to back up)"
}

if [ "$DRY_RUN" = 0 ]; then
  c_head "backup"
  take_backup
  c_ok "snapshot: $BACKUP_DIR"
  c_ok "undo any time with: $BACKUP_DIR/restore.sh"
else
  c_head "backup"
  c_skip "dry run — would snapshot to $BACKUP_DIR"
fi

if [ "$BACKUP_ONLY" = 1 ]; then
  echo
  c_ok "backup only — nothing else was changed."
  exit 0
fi

# ===========================================================================
#  STEP 2 — CONFIRM
# ===========================================================================
if [ "$DRY_RUN" = 0 ] && [ "$ASSUME_YES" = 0 ]; then
  echo
  cat <<EOF
  About to modify:
    ~/.zshrc                    APPEND one marked block at the end
    ~/.gitconfig                APPEND one include.path line
    ~/.ideavimrc                REPLACE with a symlink (backed up above)
    ~/.config/tmux/tmux.conf    REPLACE with a symlink (backed up above)
    ~/.config/git/ignore        REPLACE with a symlink (backed up above)
    ~/.local/bin/*              add 4 symlinked scripts

  Never touched: ~/.vimrc, ~/.config/nvim, VS Code settings.json,
                 /etc/*, /usr/bin, anything your company manages.

  Full undo: $BACKUP_DIR/restore.sh
EOF
  if [ "${PF_RC:-0}" != 0 ]; then
    printf '\n\033[33m  preflight reported conflicts — see %s\033[0m\n' "$PF_REPORT"
  fi
  if [ ! -t 0 ]; then
    echo; c_warn "not an interactive terminal — refusing to guess. Re-run with --yes."
    exit 1
  fi
  printf '\n  proceed? [y/N] '
  read -r reply
  case "$reply" in
    y|Y|yes|YES) ;;
    *) echo; c_ok "aborted. Your backup is still at $BACKUP_DIR"; exit 0 ;;
  esac
fi

# ------------------------------------------------------------ environment ----
c_head "environment"

case "$(uname -s)" in
  Darwin) c_ok "macOS $(sw_vers -productVersion 2>/dev/null || echo '?') on $(uname -m)" ;;
  *)      c_warn "not macOS — script still works but was written for macOS/zsh" ;;
esac

if [ -n "${ZSH_VERSION:-}" ] || [ -x /bin/zsh ]; then
  c_ok "zsh present"
else
  c_warn "zsh not found; this config targets zsh"
fi

run "mkdir -p '$LOCAL_BIN' '$DEST'"

# ----------------------------------------------------------------- mise ----
# mise is the ONE dependency we add. It is a single static binary that installs
# other single static binaries into ~/.local/share/mise. No admin, no /usr/local,
# no package manager. If your company catalog already ships a tool, we skip it.
install_mise() {
  if command -v mise >/dev/null 2>&1; then
    c_skip "mise already installed ($(command -v mise))"
    return
  fi
  if [ -x "$LOCAL_BIN/mise" ]; then
    c_skip "mise already at $LOCAL_BIN/mise"
    return
  fi
  c_add "installing mise -> $LOCAL_BIN/mise"
  run "curl -fsSL https://mise.run | MISE_INSTALL_PATH='$LOCAL_BIN/mise' sh"
}

# mise_tool <mise-registry-name> [ubi-fallback owner/repo]
mise_tool() {
  local name="$1" fallback="${2:-}" bin="${3:-$1}"
  if command -v "$bin" >/dev/null 2>&1 && [ "${FORCE:-0}" != 1 ]; then
    c_skip "$bin (already on PATH: $(command -v "$bin"))"
    return
  fi
  c_add "$name"
  if [ "$DRY_RUN" = 1 ]; then
    printf '\033[90m  dry\033[0m   mise use -g %s\n' "$name"
    return
  fi
  if ! mise use -g "$name" >/dev/null 2>&1; then
    if [ -n "$fallback" ]; then
      c_warn "registry miss for $name, trying ubi:$fallback"
      mise use -g "ubi:$fallback" >/dev/null 2>&1 || c_warn "could not install $name"
    else
      c_warn "could not install $name"
    fi
  fi
}

if [ "$NO_TOOLS" = 0 ]; then
  c_head "the minimal set :: 3 tools"
  # Deliberately short. If your tools come from a corporate portal, use
  # --no-tools instead and let the portal supply them; nothing below is
  # required for the config to work.
  install_mise
  export PATH="$LOCAL_BIN:$PATH"
  eval "$("$LOCAL_BIN/mise" activate bash 2>/dev/null || mise activate bash)" 2>/dev/null || true

  mise_tool ripgrep  BurntSushi/ripgrep      rg      # search
  mise_tool fzf      junegunn/fzf            fzf     # every picker
  # tmux is usually on the base image already; mise_tool skips it if so
  mise_tool tmux     tmux/tmux               tmux

  if [ "$CORE_ONLY" = 0 ]; then
    c_head "worth having :: 3 more, all optional"
    mise_tool fd     sharkdp/fd              fd      # feeds fzf; rg covers it otherwise
    mise_tool bat    sharkdp/bat             bat     # readable fzf previews
    mise_tool delta  dandavison/delta        delta   # readable git log / diff
  fi
fi

# --------------------------------------------------------------- config ----
c_head "config"

link() {
  local src="$1" dst="$2"
  if [ -L "$dst" ] && [ "$(readlink "$dst")" = "$src" ]; then
    c_skip "$(basename "$dst") already linked"
    return
  fi
  # Two backups on purpose: the snapshot in $BACKUP_DIR (for restore.sh) and a
  # .bak sibling right next to the original (for when you want to diff in place).
  if [ -e "$dst" ] && [ ! -L "$dst" ]; then
    c_warn "existing $dst -> kept as $dst.bak.$STAMP (also in $BACKUP_DIR)"
    run "mv '$dst' '$dst.bak.$STAMP'"
  elif [ -L "$dst" ]; then
    c_warn "replacing symlink $dst (was -> $(readlink "$dst"))"
  fi
  run "mkdir -p '$(dirname "$dst")'"
  run "ln -sfn '$src' '$dst'"
  c_add "$dst -> $src"
}

# stage the repo contents into $DEST so the symlinks survive you moving the repo
if [ "$SRC_DIR" != "$DEST" ]; then
  run "mkdir -p '$DEST'"
  run "cp -R '$SRC_DIR/zsh' '$SRC_DIR/git' '$SRC_DIR/tmux' '$SRC_DIR/bin' '$SRC_DIR/editor' '$SRC_DIR/ai' '$DEST/' 2>/dev/null || true"
fi

# bin/ -> ~/.local/bin
if [ -d "$DEST/bin" ]; then
  for f in "$DEST"/bin/*; do
    [ -f "$f" ] || continue
    run "chmod +x '$f'"
    link "$f" "$LOCAL_BIN/$(basename "$f")"
  done
fi

link "$DEST/tmux/tmux.conf"        "$HOME/.config/tmux/tmux.conf"
link "$DEST/editor/ideavimrc"      "$HOME/.ideavimrc"
link "$DEST/git/gitignore_global"  "$HOME/.config/git/ignore"

# ----------------------------------------------------------------- zshrc ----
c_head "zsh wiring"

MARKER="# >>> staff-dev-env >>>"
ZSHRC="$HOME/.zshrc"
if [ -f "$ZSHRC" ] && grep -qF "$MARKER" "$ZSHRC"; then
  c_skip "~/.zshrc already wired"
else
  c_add "appending source line to ~/.zshrc (additive, nothing removed)"
  if [ "$DRY_RUN" = 0 ]; then
    {
      printf '\n%s\n' "$MARKER"
      printf 'export STAFF_DEV_ENV_HOME="%s"\n' "$DEST"
      printf '[ -f "$STAFF_DEV_ENV_HOME/zsh/init.zsh" ] && source "$STAFF_DEV_ENV_HOME/zsh/init.zsh"\n'
      printf '# <<< staff-dev-env <<<\n'
    } >> "$ZSHRC"
  fi
fi

# --------------------------------------------------------------- git cfg ----
c_head "git"

if git config --global --get-all include.path 2>/dev/null | grep -q 'staff-dev-env'; then
  c_skip "gitconfig include already present"
else
  c_add "adding include.path to ~/.gitconfig"
  c_warn "precedence: OUR values override same-named keys set earlier in ~/.gitconfig"
  run "git config --global --add include.path '$DEST/git/gitconfig.include'"
fi
# NOTE ON PRECEDENCE: git applies an include at the point where the include
# directive appears. Because we APPEND it, our values override same-named keys
# set EARLIER in your ~/.gitconfig — user.email, credential.helper and proxy
# settings are safe because we never set them, but core.pager / aliases / merge
# settings are not. `sde-preflight` lists exactly which of your keys this hits.
#
# To make YOUR settings win instead, move the include.path line UP, above your
# own [core]/[alias] sections in ~/.gitconfig.
# Verify what actually took effect:  git config --global --show-origin -l

if command -v delta >/dev/null 2>&1; then
  c_ok "delta found — the include already wires it as pager/difftool"
else
  c_warn "delta not on PATH; git will fall back to the default pager"
fi

# ----------------------------------------------------------------- done ----
if [ "$DRY_RUN" = 0 ]; then
  c_head "what changed in your shell"
  # An after-the-fact diff of your shell's name table. This is the honest answer
  # to "did it break anything?" — you can see every name that appeared or moved.
  if command -v zsh >/dev/null 2>&1 && [ -s "$BACKUP_DIR/shell-names-before.txt" ]; then
    zsh -ic 'print -l ${(k)functions} ${(k)aliases}' 2>/dev/null | sort -u \
      > "$BACKUP_DIR/shell-names-after.txt" || true
    added=$(comm -13 "$BACKUP_DIR/shell-names-before.txt" "$BACKUP_DIR/shell-names-after.txt" 2>/dev/null | wc -l | tr -d ' ')
    lost=$(comm -23 "$BACKUP_DIR/shell-names-before.txt" "$BACKUP_DIR/shell-names-after.txt" 2>/dev/null | wc -l | tr -d ' ')
    c_ok "$added names added"
    if [ "${lost:-0}" != "0" ]; then
      c_warn "$lost names no longer resolve — review:"
      comm -23 "$BACKUP_DIR/shell-names-before.txt" "$BACKUP_DIR/shell-names-after.txt" | sed 's/^/         /'
    else
      c_ok "0 of your previous names disappeared"
    fi
    c_ok "full before/after in $BACKUP_DIR/shell-names-*.txt"
  fi
fi

c_head "done"
cat <<EOF

  Next:
    1.  exec zsh                     reload your shell
    2.  sde-doctor                   verify what installed and what didn't
    3.  sde-help                     list every function/alias this adds
    4.  open docs/00-GUIDE.md        the 6-week plan

  UNDO — one command, restores every file exactly as it was:
      $BACKUP_DIR/restore.sh

  Audit trail kept in $BACKUP_DIR :
      preflight report, original config files, before/after shell name lists

  Manual undo, if you prefer:
    - delete the block between the staff-dev-env markers in ~/.zshrc
    - git config --global --unset-all include.path
    - rm -rf ~/.config/staff-dev-env ~/.local/share/mise

EOF
