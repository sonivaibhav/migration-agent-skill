---
name: splunk-investigate
description: Run SPL searches against Splunk from the terminal and interpret the results. Use whenever the user asks about production errors, log volume, latency percentiles, a request trace, or wants to correlate application behaviour with AWS infrastructure events.
allowed-tools: ["shell(splunkq:*)"]
---

<!--
  GOES IN one of:
     .github/skills/splunk-investigate/SKILL.md     (repo, shared with the team)
     ~/.copilot/skills/splunk-investigate/SKILL.md  (just you, every project)

  A SKILL is different from an AGENT. An agent is a persona with a whole
  subagent context. A skill is a bundle of instructions + files that gets
  injected when it is relevant, into whatever agent is already running. Use
  skills for "here is how to use this tool correctly"; use agents for "here is
  a role with its own workspace and constraints".

  NOTE ON `allowed-tools`: this pre-approves ONLY `splunkq`, so the skill can
  run searches without a confirmation prompt each time, while every other shell
  command still requires your approval. That narrow scoping is the whole point —
  do not widen it to `shell(*)`.
-->

# Splunk investigation

## The tool

```bash
splunkq [-e <earliest>] [-l <latest>] [-f table|csv|json] [-m <rows>] [-v] '<SPL>'
```

Read-only. Hits Splunk's search export endpoint only. Caps at 500 rows by
default. Credentials come from `~/.config/staff-dev-env/splunk.env`; never ask
the user to paste a token into the chat.

## Non-negotiables

1. **Bound every search.** Always pass `-e`. Always aggregate (`stats`,
   `timechart`) or `| head N`. An unbounded export streams gigabytes.
2. **Snap time ranges when comparing** (`-1h@m`, `-1d@d`, `@d`). Without the
   `@`, bucket boundaries move between runs and two "identical" searches
   disagree.
3. **Filter left, transform right.** `index` → `sourcetype` → bare keyword terms
   → `stats`. Streaming commands run on the indexers in parallel; the first
   transforming command is a barrier after which everything is single-threaded
   on one search head.
4. **Never `join`.** It silently truncates at the subsearch limit (50k rows /
   60s) and gives you a wrong answer with no error. Correlate with
   `stats values(...) by <id>` instead.
5. **Redact.** Never echo a token, password, cookie, session id, full PAN, SSN,
   or email address into the conversation. Say that you redacted it.
6. **No results means no results.** Report it. Do not invent a plausible log
   line, and do not silently widen the window — say you are widening it and why.

## Query patterns

### Error rate over time, by service
```bash
splunkq -e -4h@m -l @m \
'index=<idx> level=ERROR | timechart span=5m count by service limit=10 useother=f'
```

### Error rate as a percentage (the number people actually care about)
```bash
splunkq -e -1h@m -l @m \
'index=<idx>
 | stats count as total, count(eval(status>=500)) as errors by service
 | eval error_rate=round(100.0*errors/total,2)
 | where total>100 | sort - error_rate'
```

### Latency percentiles by endpoint
```bash
splunkq -e -1h@m -l @m \
'index=<idx> duration=*
 | stats count, perc50(duration) as p50, perc95(duration) as p95, perc99(duration) as p99 by endpoint
 | sort - p95 | head 20'
```
Report p95/p99, not the average. An average hides the tail, and the tail is what
users experience.

### Normalise error messages before ranking them
Raw messages contain ids and timestamps, so every one looks unique:
```bash
splunkq -e -1h \
'index=<idx> level=ERROR
 | rex field=message mode=sed "s/[0-9a-f-]{36}/UUID/g s/\d{4,}/N/g"
 | stats count, dc(trace_id) as traces, min(_time) as first by message
 | sort - count | head 15 | convert ctime(first)'
```

### Trace one request across every index — the correlation idiom
```bash
splunkq -e -4h \
'index=* "<trace-id>"
 | eval svc=coalesce(service, application, kubernetes.container_name, sourcetype)
 | sort 0 _time
 | table _time index svc level status message | head 300'
```
And the aggregate form, when you have many ids and want the shape of the flow:
```bash
splunkq -e -1h \
'index=<a> OR index=<b>
 | stats min(_time) as start, max(_time) as end,
         values(service) as services, values(status) as statuses,
         count as hops by trace_id
 | eval duration_ms=round((end-start)*1000,0)
 | where duration_ms > 2000 | sort - duration_ms | head 20'
```

### Correlate an error onset with a deploy
```bash
splunkq -e -6h@h -l @h \
'(index=<app> level=ERROR) OR (index=<cicd> event=deploy)
 | eval kind=if(index=="<cicd>","DEPLOY","ERROR")
 | timechart span=5m count by kind'
```

### ALB: is it the load balancer or the target?
```bash
splunkq -e -1h@m -l @m \
'index=<aws> sourcetype=aws:elb:accesslogs elb_status_code>=500
 | stats count by elb_status_code, target_status_code, target_group_arn
 | sort - count'
```
`elb_status_code` without a `target_status_code` means the ALB generated the
error itself (no healthy target, timeout, or rejected connection). With one,
the target returned it. These are completely different incidents.

### Kubernetes pod restarts / OOM
```bash
splunkq -e -6h \
'index=<k8s> ("OOMKilled" OR "CrashLoopBackOff" OR "Back-off restarting")
 | stats count, values(reason) as reasons, latest(_time) as last
   by kubernetes.namespace_name, kubernetes.pod_name
 | sort - count | convert ctime(last)'
```

## Time modifier reference

| Modifier | Means |
|---|---|
| `-15m` | 15 minutes ago |
| `-1h@h` … `@h` | the previous **full** clock hour — stable, comparable |
| `-1d@d` … `@d` | all of yesterday |
| `@d` | since midnight today |
| `-7d@d` … `@d` | the last 7 full days, excluding today's partial |
| `@w0` | since the start of this week (Sunday) |

Snap units: `@s @m @h @d @w @mon @q @y`. Rule of thumb: **snap when comparing,
don't snap when tailing.**

## Gotchas that produce wrong answers silently

- Subsearches are capped (10k rows for `format`/`append`, 50k for others) and
  time out at 60s — **and they truncate without raising an error**. If a
  subsearch could return more than a few thousand rows, restructure with `stats`.
- Search terms are case-**insensitive**; field *names* and `eval` string
  comparisons are case-**sensitive**. `status=OK` and `status=ok` are different
  in `where`, the same in `search`.
- Leading wildcards (`*Timeout`) cannot use the term index and scan every event.
- `transaction` is expensive and lossy at scale; `stats by <id>` does the same
  job faster in nearly every case.
- `--level fast` (the default in `splunkq`) skips field discovery. If an
  expected field is missing, rerun with `--level smart` before concluding the
  data isn't there.
