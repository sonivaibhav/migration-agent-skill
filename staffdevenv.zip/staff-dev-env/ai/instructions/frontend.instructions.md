---
applyTo: "**/*.{ts,tsx,js,jsx,html,scss}"
---

<!--
  GOES IN: .github/instructions/frontend.instructions.md
  These load ONLY when a matching file is in context. This is how you get
  detailed, opinionated guidance without paying for it on every single request.
  That `applyTo` glob is the whole point — use several narrow files rather than
  one broad one.
-->

# Frontend code

## React microfrontends

- Function components only. No class components, no `React.FC` type annotation
  (it adds an implicit `children` we do not want).
- A component that fetches must handle all four states: loading, empty, error,
  data. A PR with only the happy path is incomplete.
- `useEffect` with an empty dep array to fetch on mount is the pattern we are
  migrating **away** from — use the query layer in `@org/shared-data`.
- Every effect that subscribes, listens or times must return a cleanup. MFEs
  are mounted and unmounted repeatedly by single-spa; a missing cleanup does
  not leak once, it leaks every navigation.

## Angular shell

- Standalone components. `NgModule` only where legacy code already requires it.
- `OnPush` change detection by default.
- Unsubscribe with `takeUntilDestroyed(this.destroyRef)`. Never `.subscribe()`
  without a teardown, and never call `.subscribe()` inside another `.subscribe()` —
  use `switchMap`/`concatMap`/`mergeMap` and pick deliberately:
  - `switchMap` — cancel the previous (typeahead, route-driven fetches)
  - `concatMap` — preserve order, run one at a time (writes)
  - `mergeMap` — parallel, order not guaranteed
  - `exhaustMap` — ignore new while one is in flight (submit buttons)
  Choosing the wrong one is our most common RxJS bug; if you use `mergeMap`,
  say in a comment why order doesn't matter.

## Styling

- Angular Material components before hand-rolled ones. If Material has it, use it.
- No inline `style=` attributes. No `!important` — if you need it, the selector
  is wrong.
- Do not add a new global stylesheet; styles are component-scoped.

## Accessibility (this is not optional in an enterprise app)

- Interactive elements are `<button>`/`<a>`, never a `<div onClick>`.
- Every form control has an associated label. Every icon-only button has an
  accessible name.
- Test queries use `getByRole`/`getByLabelText`. If you cannot write the query,
  the markup is inaccessible — fix the markup, don't add a `data-testid`.

## Performance in an MFE context

- Never add a dependency that duplicates one already in the shared import map
  (`react`, `react-dom`, `rxjs`, `@angular/*`, `single-spa`). Check
  `pnpm why <pkg> -r` before adding anything.
- Lazy-load routes. An MFE's initial bundle should not contain code for a route
  the user hasn't navigated to.
- Prefer `import type` for type-only imports so they are erased from the bundle.
