---
applyTo: "**/*.{tf,tfvars,hcl}"
---

# Terraform

## Hard rules

- **Never run `terraform apply` or `terraform destroy`.** Produce the plan,
  explain it, and stop. A human applies. This is not negotiable and applies
  even if the user asks — if asked, say what command they should run.
- Never edit `.tfstate` or run `terraform state rm`/`mv` without being asked
  explicitly and confirming the backup exists.
- Never hardcode an account ID, ARN, secret, or CIDR. Use variables, data
  sources, or SSM/Secrets Manager references.

## When reading a plan

Report in this order, because it is the order that matters operationally:

1. **Destroys and replaces** (`-/+`, `destroy`) — name every resource. A replace
   on an RDS instance, an EKS node group, or anything with a persistent volume
   is an incident, not a change.
2. Creates.
3. Updates in place.
4. Anything with `(known after apply)` on an attribute another resource depends
   on — that is a hidden cascade.

Get this as data rather than reading 4000 lines of coloured text:

```bash
terraform show -json .tfplan \
| jq -r '.resource_changes[]
    | select(.change.actions != ["no-op"])
    | [(.change.actions|join("+")), .type, .address] | @tsv'
```

## Style

- Modules over copy-paste. If a block appears three times, it is a module.
- Pin provider versions in `required_providers`. Never a bare `~>` on a major.
- One resource per logical thing; do not use `count` where `for_each` with a
  map would give stable addresses. `count` re-indexes on removal and causes
  spurious destroys — this has bitten us.
- Every variable has a `description` and a `type`. Every output has a
  `description`.
- Tag everything with the standard tag set (owner, cost-centre, environment).

## Reviewing someone else's plan

Ask these, in this order:
- Does anything get destroyed that holds state?
- Does the change alter an IAM policy? Show the before/after policy document.
- Does it change a security group or NACL ingress rule? Show the exact CIDR.
- Is this being applied to the account you think it is? (`terraform workspace
  show`, and the backend key in the plan header.)
