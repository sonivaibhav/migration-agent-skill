---
applyTo: "**/*.{spec,test}.{ts,tsx,js,jsx}"
---

# Tests

## The bar

A test is good when it fails for exactly one reason and that reason is a real
regression. Tests that assert implementation details fail on every refactor and
teach the team to ignore red builds.

- Test observable behaviour through the public surface: rendered output, emitted
  events, returned values. Not internal state, not private methods, not the
  number of times a hook ran.
- Query by role/label/text (Testing Library). `data-testid` is a last resort and
  needs a comment saying why the accessible query was impossible.
- One behaviour per `it`. If the test name contains "and", split it.
- Name tests as sentences about behaviour: `it('disables submit while the form
  is pending')`, not `it('works')` or `it('test submit')`.

## Mocking

- HTTP is mocked with **MSW** at the network layer, using handlers in
  `src/mocks/handlers.ts`. Do not mock `fetch`, `axios`, or the app's own data
  layer — those mocks pass while the real integration is broken.
- Do not mock the thing you are testing. If a test needs five mocks to run, the
  unit under test has too many dependencies; say so rather than adding a sixth.
- Timers: `vi.useFakeTimers()` / `jest.useFakeTimers()` with an explicit
  `advanceTimersByTime`. Never `await new Promise(r => setTimeout(r, 500))` —
  that is a flaky test with extra steps.

## Async

- `await` every assertion that depends on an async update (`findBy*`,
  `waitFor`). A missing await is the #1 source of flake in this repo.
- No arbitrary sleeps. If you cannot express the wait as a condition, the test
  is asserting on the wrong thing.

## Mutation testing (Stryker)

We measure mutation score, not just line coverage, because 100% line coverage
with no assertions is common and worthless. When you add a conditional, add the
test case that would fail if the condition were inverted — that is precisely
what Stryker checks.

Run the narrow version while iterating:
```bash
pnpm exec stryker run --mutate 'src/path/to/file.ts'
```

## Playwright (e2e)

- Use `getByRole` locators, never CSS/XPath selectors tied to markup structure.
- Use web-first assertions (`await expect(locator).toBeVisible()`) which retry;
  do not assert on a value you read once.
- Every test must be independent and able to run in parallel. No test may
  depend on data created by another test.
