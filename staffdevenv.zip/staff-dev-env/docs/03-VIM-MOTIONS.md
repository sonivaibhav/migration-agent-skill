# Vim motions without adopting Vim

The goal: stop reaching for arrow keys and the mouse while editing text, in
IntelliJ, VS Code, your shell, `less`, `k9s`, tmux copy-mode, and every server
you ssh into. You are not switching editors. You are learning a text-editing
grammar that happens to be implemented everywhere.

**Setup is three things, all already in this repo:**

| Where | What | Config |
|---|---|---|
| IntelliJ | IdeaVim plugin (Settings → Plugins → IdeaVim) | `editor/ideavimrc` → `~/.ideavimrc` |
| VS Code | `vscodevim.vim` extension | merge `editor/vscode-settings.jsonc` |
| zsh | already on (`bindkey -v`) | `zsh/30-vi-mode.zsh` |

---

## The one idea

Vim is not a set of shortcuts. It is a **grammar**:

```
        VERB          +      MOTION/TEXT OBJECT
     (what to do)          (what to do it to)

        d  delete            w    to the next word
        c  change            $    to end of line
        y  yank (copy)       iw   inner word
        v  select            i"   inside the quotes
        >  indent            a(   around the parentheses, brackets included
        gc comment           ip   inner paragraph
```

Learn 6 verbs and 12 motions and you have 72 commands you never memorised. That
compositional property is the entire value proposition. If you find yourself
memorising a list of two-key combinations, you are learning it wrong.

A count can go in front: `3dw` = delete three words. `d2j` = delete this line
and the two below.

---

## Learn in this order. Do not skip ahead.

### Stage 1 — survive (2 days)

| Key | Does |
|---|---|
| `h j k l` | left, down, up, right |
| `i` / `a` | insert before / after the cursor |
| `o` / `O` | open a new line below / above, and insert |
| `Esc` (or `jk`) | back to normal mode |
| `u` / `Ctrl-r` | undo / redo |
| `x` / `dd` | delete character / line |
| `:w` `:q` `:wq` | write, quit |

Rule for stage 1: **arrow keys are allowed.** Don't make it harder than it is.
The only thing you're building here is the reflex of pressing `Esc` when you
stop typing.

### Stage 2 — move (1 week)

This is the stage that stops you using arrow keys, because these are strictly
better.

| Key | Does |
|---|---|
| `w` `b` | forward / back one word |
| `e` | to the **end** of the current word |
| `W` `B` `E` | same, but WORDS (whitespace-delimited — better for paths and URLs) |
| `0` `^` `$` | start of line / first non-blank / end of line |
| `gg` `G` | top of file / bottom of file |
| `{` `}` | previous / next blank line — paragraph-ish jumps |
| `%` | jump to the matching bracket. Superb in JSX and nested config. |
| `f<char>` | jump **to** the next `<char>` on this line |
| `t<char>` | jump **till** just before the next `<char>` |
| `;` / `,` | repeat that jump forward / backward |
| `/text` `n` `N` | search, next, previous |
| `*` | search for the word under the cursor. Use constantly. |
| `Ctrl-o` / `Ctrl-i` | jump back / forward through your jump history |

`f` and `;` are the ones people underuse. `f,` then `;;;` walks you along a
function's arguments faster than anything else.

### Stage 3 — operators + text objects (THE important week)

This is where it clicks. Combine a verb with a text object:

```
i = "inner"  (contents only)        a = "around" (contents + delimiters)

ciw    change inner word              — cursor anywhere in the word
ci"    change inside the quotes       — cursor anywhere in the string
ci(    change inside the parens       — also ci) ; ci{ ci[ ci<
cit    change inside the HTML/JSX tag — this one is worth the whole exercise
ca(    change around the parens       — deletes the parens too
di{    delete inside the braces
yi(    yank inside the parens
vi"    select inside the quotes
dap    delete around paragraph
cia    change inner argument          — via argtextobj, one function parameter
```

Concretely, in your day:

| Task | Old way | New way |
|---|---|---|
| Replace a string literal | double-click, drag past the quote, retype | `ci"` |
| Replace a whole JSX prop value | select carefully with the mouse | `ci"` |
| Rewrite a function's arguments | select from `(` to `)` | `ci(` |
| Replace the text inside a `<div>` | click, shift-end, adjust | `cit` |
| Change one function parameter | select it precisely | `cia` |
| Delete a whole block | select from `{` to matching `}` | `di{` or `da{` |

**Cursor position doesn't matter** for text objects — anywhere inside the word,
string, or block works. That is why they're faster than any selection: there is
no aiming.

### Stage 4 — the dot, and visual mode (a few days)

`.` repeats your last change. This is the most underrated key in Vim.

```
ciwfoo<Esc>     change this word to "foo"
n.              find the next occurrence, repeat the change
n.              again
n.              again
```

That's a controlled find-and-replace where you approve each one. Far better than
a global regex when you're not 100% sure of the scope.

Visual mode when you need to see the selection first:

| Key | Does |
|---|---|
| `v` | character-wise selection |
| `V` | line-wise selection |
| `Ctrl-v` | **block** selection — the columnar one |
| `gv` | reselect what you had selected last |
| `o` | jump to the other end of the selection (to extend the other way) |

`Ctrl-v` block mode is what you want for editing a column of imports, adding a
prefix to ten lines, or deleting a column from a table. Select the block, press
`I`, type, press `Esc` — it applies to every line.

### Stage 5 — later, only if you want it

- **Macros:** `qa` start recording into register a, do things, `q` to stop,
  `@a` to replay, `10@a` to replay ten times. Excellent for repetitive
  transformations on log output or test fixtures.
- **Marks:** `ma` sets mark a, `'a` jumps back to it. `''` jumps to where you
  were before the last jump.
- **Registers:** `"ayy` yanks into register a, `"ap` pastes it. Lets you carry
  several clipboards.

Most people never need these and are still fast. Don't force it.

---

## The habit that matters more than any of the above

**When you catch yourself pressing a key more than twice in a row, stop and ask
what motion that is.**

```
jjjjjjj    → 7j, or } , or /searchterm, or 42G
xxxxxx     → 6x, or dw, or d$
ddddd      → 5dd, or d4j
<Esc>hhhh  → 4h, or F<char>, or 0
```

That reflex — not the config, not the plugin list — is what makes people fast.
It usually takes about two weeks to develop and then it's permanent.

---

## Where the motions work once you know them

This is the part people don't anticipate, and it's why this skill has better
transfer than anything else on your list:

- **IntelliJ** (IdeaVim) — with all IDE actions intact
- **VS Code** (Vim extension) — same
- **Your shell** — `Esc` then `ciw`, `f-`, `$`, `A`. Fixing the middle of a long
  `kubectl` command becomes trivial. `v` opens it in `$EDITOR`.
- **`less` and `man`** — `/search`, `n`, `G`, `gg` all work. Already.
- **`git log` / `git diff`** — same pager, same keys
- **tmux copy-mode** — `prefix [`, then `/`, `v`, `y`. Search a 50k-line build
  log without a mouse.
- **k9s** — vim keys throughout, plus `/` to filter
- **lazygit** — same
- **`kubectl edit`, `crontab -e`, any remote server** — the editor is vi. There
  is no way around it, and now you don't need one.
- **Chrome/Firefox** with Vimium, if you want it. Optional.

---

## Configuration notes specific to your setup

**IdeaVim:** `idearefactormode = keep` and `ideajoin` are set. The first keeps
you in normal mode after an IntelliJ refactor; the second makes `J` use
IntelliJ's smart join. `set which-key` gives you a popup showing what follows
`<leader>` — turn it off once you've stopped needing it.

**VS Code:** the `vim.handleKeys` block in the settings file is important. It
gives `Ctrl-C`, `Ctrl-V`, `Ctrl-P`, `Ctrl-F` and friends back to VS Code. Without
it you spend the first week fighting the extension over chords your hands
already know. Also note `vim.useSystemClipboard: true` — without it, yanking in
VS Code and pasting into your terminal doesn't work and you'll blame the wrong
thing.

**`jk` as Escape** is mapped in all three. It's the single best remap: your left
hand never leaves home row, and `jk` essentially never occurs in real text.

**`Esc` lag in the shell** is fixed by `KEYTIMEOUT=15` (module 30) and
`escape-time 0` (tmux.conf). Without those, `Esc` feels broken and you'll quit
after a day. This is the #1 reason people abandon shell vi-mode.

---

## Expectation setting

You will be measurably slower for about ten days. That's not a warning sign;
it's what learning a motor skill feels like — the same as touch-typing or a new
keyboard layout. Around day 10–14 it inverts.

If you're still slower after three weeks, stop. It genuinely doesn't suit
everyone's working memory, and there's no shame in it. The shell vi-mode and the
`v`-to-edit-command-line binding alone will still have been worth the setup.

**Practice tools, in order of usefulness:**

1. Your actual work. Just turn it on and use it.
2. `vimtutor` in a terminal — 25 minutes, built in, still the best introduction.
3. VS Code's "Vim" extension has no tutor, but IdeaVim ships an interactive one:
   IntelliJ → Help → Learn IDE Features → Vim.
4. vim-be-good (ThePrimeagen's practice game) if you like drills. Optional and
   requires Neovim, so skip it unless you already have one around.
