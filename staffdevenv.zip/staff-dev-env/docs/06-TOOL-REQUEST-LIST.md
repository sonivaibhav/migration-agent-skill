# Tools to request from your corporate portal

Cut down to match how you actually work: terminal, `git log`, `rg`, zsh aliases
and themes, vim, tmux, and directory shortcuts.

**Request three things. Stop there.** Use them for two weeks. If you then find
yourself wanting something specific, come back to the second table — but you
probably won't need most of it, and a tool you don't reach for is worse than no
tool, because it's still something you have to remember exists.

---

## Request these three

| Search the portal for | Also listed as | Why this one |
|---|---|---|
| **ripgrep** | `rg`, `BurntSushi/ripgrep` | Your main search. Whole-repo results in ~200ms instead of ~20s, and it honours `.gitignore` by default so you stop matching inside `node_modules`. This is the single biggest day-one difference. |
| **fzf** | `junegunn/fzf`, "command-line fuzzy finder" | The multiplier. It gives you `Ctrl-R` (fuzzy shell history) for free, and it's what makes the directory jumper, file finder, live-grep and every git picker work. Almost everything in the config is `list \| fzf \| act`. |
| **tmux** | — | You asked for it. Often already on the base engineering image — check before filing anything. |

That's the whole required list. Everything else in the config either uses what
macOS already ships, or degrades gracefully to it.

---

## Only if you find yourself wanting them

Genuinely optional. Nothing breaks without these.

| Search for | What it gives you | Worth it when |
|---|---|---|
| **git-delta** (`delta`) | Syntax-highlighted, line-numbered `git log`/`git diff` with moved-code detection | You said `git log` is a daily driver — this is the one I'd add fourth. Without it, git just uses the default pager. |
| **fd** | Friendlier `find` | You start using the file-finder a lot. Without it, fzf falls back to `rg --files`, which is nearly as good. |
| **bat** | `cat` with syntax highlighting | You want the fzf preview pane to be readable. Without it, previews fall back to `head`. |

## Deliberately dropped

Since you're moving off EKS and want to stay light, these are out — no k8s
tooling at all, and no tools whose only job is to be a nicer version of
something you already have:

| Dropped | Why |
|---|---|
| **k9s** | Kubernetes TUI. You're moving to ECS. Gone entirely, along with the whole k8s shell module. |
| **kubectl helpers** | Same reason. The `71-k8s` module is deleted, not disabled. |
| **yq** | You'd use it for k8s manifests. On ECS you mostly won't. |
| **lazygit** | A git TUI is a real tool, but you told me you live in `git log` — and the terminal git config plus `glf` (fuzzy log browser) covers that better. Add it later if interactive staging appeals. |
| **zoxide** | Overlaps with the directory shortcuts you asked for, which are built in and need no binary. Detail below. |
| **eza, difftastic, direnv, atuin, jq, gh** | Each is fine. None is worth a portal request before you've missed it. |

---

## Directory shortcuts need no tool at all

You asked for `cd` shortcuts to frequent folders. That's native zsh, so it costs
nothing and needs no approval. One file drives all of it:

```
# ~/.config/staff-dev-env/dirs.conf
work  = ~/work
repos = ~/work/repos/*
dl    = ~/Downloads
```

That single registration gives you four things at once:

```bash
j work              # explicit jump, with tab completion
cd ~work            # zsh named directory
j                   # fzf picker over everything registered
cd orders-mfe       # from ANYWHERE — the /* entry puts the parent on CDPATH
```

Plus a detail that's nicer than it sounds: because these are real zsh *named
directories*, your prompt prints `~work` and `~repos/orders-mfe` instead of a
long absolute path. Shorter prompt, and you can see at a glance which registered
area you're in.

Commands: `jl` list · `ja <name>` register the current directory · `je` edit the
file · `jr` reload.

`zoxide` does something adjacent — it *learns* your most-visited directories
rather than you declaring them. It's a good tool. But it's a binary to get
approved for a problem you've now solved, and explicit beats learned when you
want predictability. Skip it unless you miss it.

---

## Themes need no tool either

You mentioned zsh themes. There are three built in, switchable at runtime:

```bash
sde-theme            # show current + options
sde-theme compact    # try one now
```

`minimal` (two lines, quiet) · `compact` (one line — best inside tmux splits) ·
`verbose` (adds AWS profile + command duration) · `off` (keep your own).

I didn't ship Powerlevel10k or Starship, and the reason is specific rather than
snobbery: a prompt runs on **every single Enter**, and the usual failure is a
theme that shells out to `git status` each time. In a big repo that walks the
whole worktree and adds 200–400ms per prompt — which feels like "my machine is
slow" and is really "my prompt is slow". The built-in themes read the git branch
from a file and never fork. If you already run p10k and like it, set
`SDE_THEME=off` and keep it; nothing else changes.

---

## Paste-ready request text

> I'm requesting three command-line developer tools to improve productivity on
> our frontend codebase.
>
> All three are single static binaries — no installer, no daemon, no background
> service, no network callback, no elevated privileges. They install to the
> user's home directory and are removed by deleting a file. All are widely used,
> actively maintained, and MIT/Apache-2 licensed.
>
> - **ripgrep** — fast recursive code search
> - **fzf** — command-line fuzzy finder
> - **tmux** — terminal multiplexer (may already be on the standard image)

If it's easy to add more in one go, append: *git-delta, fd, bat* — same
properties, same licences.

---

## Installing once they arrive

```bash
./install.sh --preflight     # read-only audit — always first
./install.sh --no-tools      # config only; the portal supplies the binaries
```

`--no-tools` downloads nothing and installs no package manager. Modules check
for each tool at load time, so a partial set is fine: no `delta` means git uses
the default pager, no `fd` means fzf uses ripgrep to list files, no `fzf` means
you lose the pickers but keep history, git config, tmux, vim motions and the
directory shortcuts.
