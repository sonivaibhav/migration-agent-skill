# tmux, in one afternoon

## Why you specifically want this

Your work is inherently multi-process:

```
  Angular shell dev server     :4200
  React MFE #1                 :8081
  React MFE #2                 :8082
  Storybook                    :6006
  vitest --watch
  aws logs tail --follow (the backend you're integrating against)
  a shell for git
```

That's seven terminal tabs you recreate every morning, relaunch after every VPN
drop, and lose entirely when your laptop sleeps or your terminal app updates.

With tmux that's one named session that survives all of it. You detach, close
the laptop, come back tomorrow, `tmux a`, and everything is still running with
full scrollback.

That's the pitch. Not "power user terminal". Just: your dev servers stop dying.

---

## Do not learn tmux

Learn these six things, use them for a week, and stop. The rest of tmux is
available when you want it and will not improve your day before then.

**Prefix is `C-a`** (remapped from the default `C-b`, which requires a pinky
stretch and collides with vim's page-up).

| Binding | What it does | Why it's in the six |
|---|---|---|
| `prefix f` | fuzzy-find a project → session | The one that changes your day |
| `prefix \|` / `prefix -` | split vertically / horizontally | Mnemonic, opens in the current dir |
| `prefix h j k l` | move between panes | Vim keys, no arrow reaching |
| `prefix z` | zoom a pane full-screen, and back | Read one dev server's output, then return |
| `prefix [` then `/` | search the scrollback | Find an error in 40k lines of build output |
| `prefix d`, then `tmux a` | detach / reattach | The actual reason you're here |

That's it. Genuinely.

---

## The sessionizer — `prefix f`

This is the idea worth stealing (it's ThePrimeagen's, and it's the best script
in this repo). One keystroke fuzzy-finds any project on disk and drops you into
a tmux session named after it, creating it if it doesn't exist.

You stop *managing terminals*. You start *navigating projects*.

Set it up once:

```bash
cat > ~/.config/staff-dev-env/projects.conf <<'EOF'
# path              max-depth
~/code              2
~/work/repos        3
EOF
```

Then `prefix f`, type a few characters of a repo name, Enter. If you had that
project open with four running dev servers, you're back in it exactly as you
left it. If you didn't, you get a fresh session with a shell window and a
pre-split `run` window.

It also picks up the worktrees created by `gwt`, so a worktree is one keystroke
away too.

Bind it outside tmux as well, if your terminal allows a global hotkey to run
`tmux-sessionizer` — then it works from anywhere.

---

## The mental model

```
server
└── session          one per PROJECT. Named. Persistent.
    └── window       one per CONCERN. Like a browser tab.
        └── pane     one per PROCESS. A split.
```

The layout that works for a monorepo:

```
session "orders-monorepo"
├── window 1  shell     git, running commands
├── window 2  run       ┌ pane: shell dev server (:4200)
│                       └ pane: mfe-orders dev server (:8081)
├── window 3  test      vitest --watch
└── window 4  ops       aws logs tail --follow
```

Windows for things you switch *between*, panes for things you watch *at the same
time*. If you're not looking at two panes simultaneously, they should be windows.

---

## Everything else, for when you want it

### Sessions
```
prefix S        visual session picker (choose-tree)
prefix d        detach
prefix BSpace   last session
tmux ls         list sessions from outside
tmux a          attach to the most recent
tmux a -t name  attach to a specific one
tmux kill-session -t name
```

### Windows
```
prefix c        new window (in the current directory)
prefix 1..9     go to window N
prefix a        last window          ← the flip-flop key, use it constantly
prefix ,        rename window
prefix &        kill window
prefix <  >     move this window left / right in the list
prefix w        window picker across all sessions
```

### Panes
```
prefix |  -     split vertical / horizontal
prefix h j k l  navigate
prefix H J K L  resize (repeatable — hold the key)
prefix z        zoom toggle
prefix Space    cycle through preset layouts
prefix x        kill pane
prefix !        break this pane out into its own window
prefix @        join a pane from another window
prefix e        ★ synchronize-panes: type once, runs in EVERY pane
```

`prefix e` is genuinely useful for your setup: turn it on, `pnpm install` runs in
all four MFE panes at once, turn it off. Just remember to turn it off — this is
the one binding here that can do something you didn't intend.

### Copy mode (this is where tmux earns its keep)

```
prefix [        enter copy mode
prefix /        enter copy mode already searching backwards ← the one you want
/  ?            search forward / backward
n  N            next / previous match
v               begin selection      (vi keys — set in the config)
Ctrl-v          rectangle selection
y               copy to the macOS clipboard and exit
q / Esc         quit
g  G            top / bottom
Ctrl-u Ctrl-d   half page up / down
```

Searching a 50,000-line webpack build log for the one line that matters, without
a mouse and without re-running the build to pipe it to a file — that's the
capability. It's the same vim motions from
[03-VIM-MOTIONS.md](03-VIM-MOTIONS.md), which is why they're worth learning once.

---

## Config decisions in `tmux/tmux.conf`, and why

| Setting | Why |
|---|---|
| `set -s escape-time 0` | **Critical.** The default is 500ms, which makes `Esc` in vi-mode feel broken. This one line is the difference between vi-mode being usable and not. |
| `set -g mouse on` | Yes, really. Dragging a pane border is fine; purity isn't the goal. Note that with mouse on, selecting text scrolls into copy-mode — hold `Option` to do a native terminal selection instead. |
| `base-index 1` | Windows numbered from 1, matching your number row. |
| `renumber-windows on` | Close window 2 of 4 and you get 1,2,3 — not 1,3,4. |
| `history-limit 100000` | A full build log fits in the scrollback. |
| `set-clipboard on` | Yank in tmux → macOS clipboard, over OSC 52. Works over ssh too. |
| `-c "#{pane_current_path}"` on splits | New panes open where you were, not in `$HOME`. Small, felt every single time. |
| `mode-keys vi` | Copy mode uses vim motions. |
| No plugin manager | Everything above is built in. tpm is another install to justify and another thing to break on upgrade. |

---

## Interaction with IntelliJ and VS Code

You do **not** need to run your editor inside tmux, and you shouldn't.

The division that works:

- **Editor windows:** IntelliJ and VS Code, as normal. Native, with their
  debuggers and tool windows.
- **Everything else:** one tmux session per project, in your terminal app.
- **VS Code's integrated terminal:** leave it as a plain shell for one-off
  commands. Running tmux inside it means nested prefix keys and a bad time.

The one thing to configure: `terminal.integrated.macOptionIsMeta: true` in VS
Code (already in the settings file) so `Alt-b`/`Alt-f` word motions work in the
integrated terminal.

---

## Cheat sheet to print

```
PREFIX = Ctrl-a

  SESSIONS                      WINDOWS                   PANES
  f   project → session         c    new                  |    split vert
  S   session picker            1-9  go to N              -    split horiz
  d   detach                    a    last window          hjkl navigate
  $   rename session            ,    rename               HJKL resize
                                &    kill                 z    zoom
  $ tmux a        reattach      w    picker               x    kill
  $ tmux ls       list                                    e    sync panes
                                                          !    break out
  COPY MODE                                               Space cycle layout
  [   enter        /  search        v  select
  /   enter+search n  next          y  copy → clipboard
  q   quit         G  bottom        Ctrl-v  block select

  r   reload config
```
