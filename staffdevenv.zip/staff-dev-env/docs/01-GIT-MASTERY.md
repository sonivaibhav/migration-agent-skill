# Git: from functional to strong

You said your Git knowledge is functional and you want to understand the model
rather than memorise commands. Good instinct — Git has maybe eight concepts and
several hundred commands, and everyone who finds it confusing learned the
commands first.

This document is in that order: model, then reading history, then rewriting it,
then recovery, then the workflows that matter for a microfrontend monorepo.

---

## 1. The object model, in about ten minutes

Git is a content-addressed key-value store with four object types. Everything
else is a thin layer on top.

```
blob    file contents. No name, no path, no history. Just bytes.
tree    a directory listing: names → (blob | tree) hashes, plus file modes.
commit  a snapshot pointer: one root tree + zero-or-more parents
        + author + committer + message.
tag     a named pointer to an object, with its own message (annotated tags).
```

Every object's name is the SHA-1 of its contents. That's the whole trick: identical
content is stored once, and a hash is a cryptographic proof of everything
reachable from it.

**Look at it directly.** This is the twenty minutes that changes everything:

```bash
git cat-file -t HEAD          # commit
git cat-file -p HEAD          # the raw commit object: tree, parent, author, message
git cat-file -p HEAD^{tree}   # the root directory listing
git cat-file -p HEAD:src      # a subdirectory tree
git cat-file -p HEAD:package.json | head   # a blob
```

Now the three facts that follow from this, and they're the important ones:

**A commit is a full snapshot, not a diff.** Git shows you diffs because diffs
are useful to humans, but it computes them on demand by comparing two trees.
This is why `cherry-pick` and `rebase` can fail: they *have* to compute a diff
and re-apply it, and that application can conflict.

**A branch is a file containing a 41-byte hash.** Really:

```bash
cat .git/refs/heads/main        # or: git rev-parse main
```

That's it. `git branch feature` writes a new file. Branching is O(1) and costs
41 bytes, which is why Git's branching is good and Subversion's wasn't. And it
explains `reset`: `git reset --hard <sha>` overwrites that file and updates your
working tree. It doesn't delete anything — the old commits are still in
`.git/objects`, they just have nothing pointing at them.

**HEAD is a pointer to a branch (usually).** `.git/HEAD` contains
`ref: refs/heads/main`. "Detached HEAD" means it contains a raw SHA instead.
There is nothing wrong or dangerous about it; you're just on a commit that no
branch names, so if you move away without creating a branch, you'd have to use
the reflog to get back.

**Everything is a commit graph.** Merge, rebase, cherry-pick, revert: all of
them are "produce new commits, move a ref". Once you're thinking in terms of
"where does this ref point and what's reachable from it", the commands stop
needing to be memorised.

> **Mental model check.** What does `git reset --hard HEAD~1` actually do?
> Answer: writes `HEAD~1`'s SHA into `.git/refs/heads/<current>`, then makes the
> index and working tree match that tree. The commit you "deleted" is untouched
> in `.git/objects` and is in your reflog. That's why it's recoverable.

### The three trees

Every Git operation moves data between three places. Nearly all confusion about
`reset` and `checkout` comes from not knowing which one is being touched.

```
  HEAD              index (staging)         working tree
  what the last     what the next           what's on disk
  commit contains   commit will contain     right now
```

| Command | HEAD | index | working tree |
|---|:---:|:---:|:---:|
| `git reset --soft <c>` | ✓ moves | — | — |
| `git reset [--mixed] <c>` | ✓ moves | ✓ reset | — |
| `git reset --hard <c>` | ✓ moves | ✓ reset | ✓ **overwritten** |
| `git checkout <c>` | ✓ moves | ✓ | ✓ (refuses if it would lose work) |
| `git restore --staged <f>` | — | ✓ | — |
| `git restore <f>` | — | — | ✓ **overwritten** |

The two rows in bold are the only ones that can lose uncommitted work. Everything
else is recoverable. Internalise that and you can stop being nervous.

---

## 2. Reading history — `log` is a query language

Most people use maybe 5% of `git log`. It is a query engine over the commit
graph, and the queries below answer real questions you have weekly.

### The five queries worth memorising

```bash
# 1. WHEN did this string appear or disappear? ("pickaxe")
git log -S'featureFlagEnabled' --oneline
#    -S counts occurrences (added/removed). -G matches the diff text by regex.
#    This is THE tool for "who added this and why", and almost nobody knows it.

# 2. What happened to this one function, across renames?
git log -L :handleSubmit:src/OrderForm.tsx
#    -L follows a function or a line range through history. Across file renames.

# 3. What is on my branch that isn't on main? (and vice versa)
git log --oneline origin/main..HEAD      # mine only
git log --oneline HEAD..origin/main      # theirs only
git log --oneline --left-right origin/main...HEAD   # both, marked < and >
#    TWO dots = range. THREE dots = symmetric difference. This distinction shows
#    up in log, diff, and push refspecs, and it means DIFFERENT things in each.

# 4. Which commits touched this file, ignoring merges and whitespace?
git log --oneline --no-merges -w --follow -- packages/shared-ui/src/Button.tsx

# 5. Who owns this code, really?
git log --format='%an' -- packages/mfe-orders | sort | uniq -c | sort -rn | head
```

### Two dots vs three dots — the thing everyone gets wrong

```
git log  A..B      commits reachable from B but not A
git log  A...B     commits reachable from either, but not both

git diff A..B      SAME AS `git diff A B` — plain diff between two endpoints
git diff A...B     diff between B and the MERGE BASE of A and B
```

Note that the meanings are *inverted* between `log` and `diff`. That's a genuine
wart in Git, not a misunderstanding on your part.

**For code review, you almost always want `git diff main...HEAD`.** That shows
what *your branch* changed, excluding everything that landed on main since you
branched. It's what GitHub shows you in a PR. The alias is `git dm`.

### Formatting so you can actually read it

The `git l` alias in `gitconfig.include` gives you a graph, relative dates, and
authors. But `git log --format` is worth ten minutes of your time:

```bash
git log --format='%h %ad %an %s' --date=short
#         %h short sha   %ad author date   %an author name   %s subject
#         %d refs        %ar relative date %cn committer     %b body
```

And `glf` (module 60) makes it interactive: fuzzy-search subjects, live diff
preview, `Ctrl-Y` to copy a SHA.

### `git show` — one command, many objects

```bash
git show HEAD                 # commit message + diff
git show HEAD --stat          # just the file list
git show HEAD~3:src/app.ts    # a FILE as it was three commits ago. Prints to stdout.
git show main:package.json    # a file on another branch, without checking it out
git show HEAD^{tree}          # the tree object
git show v2.1.0               # a tag
```

`git show <rev>:<path>` is quietly one of the most useful commands in Git.
Comparing a config file across branches without switching branches is a
one-liner. The alias is `git cat <rev> <path>`.

### Revision syntax you should know

```
HEAD~3        three FIRST-parents back  (linear ancestry)
HEAD^2        the SECOND parent of a merge commit
HEAD@{2}      where HEAD was two moves ago      ← reflog syntax, not history
main@{yesterday}
main@{u}      the upstream of main (origin/main)
:/fix login   the most recent commit whose message matches
HEAD^{tree}   the tree of HEAD
```

`~` walks the first-parent chain; `^N` selects among a merge's parents. `HEAD~2`
and `HEAD^^` are the same thing; `HEAD^2` is entirely different.

---

## 3. Rewriting history — rebase without fear

### What rebase actually does

For each commit on your branch, Git computes its diff against its parent, then
replays that diff on top of the new base, producing a *new commit with a new
SHA*. Same content (usually), different identity.

```
before:   A---B---C  main
               \
                D---E---F  feature

git rebase main (from feature):

after:    A---B---C  main
                   \
                    D'--E'--F'  feature
```

D, E, F still exist in `.git/objects` and in your reflog. Nothing was destroyed;
you now have two sets of commits and your branch ref points at the new ones.

**The one rule:** don't rebase commits that other people have based work on.
Everything else about rebase is safe, because of the reflog.

### Interactive rebase — the actual workflow

```bash
git rb          # (alias) interactive rebase over just this branch's commits
```

That alias resolves the merge base with `origin/HEAD` automatically, so you can
never accidentally rewrite main's history — which is the fear that stops most
people using `rebase -i` at all.

In the todo list:

```
pick   a1b2c3d  feat: add order filter
squash e4f5g6h  fix typo               ← fold into the one above, edit message
fixup  h7i8j9k  fix another typo       ← fold in, DISCARD this message
reword l0m1n2o  feat: add order sort   ← keep the commit, edit the message only
edit   p3q4r5s  refactor: extract hook ← stop here so you can amend/split it
drop   t6u7v8w  debug logging          ← delete the commit
```

Reorder lines to reorder commits. Delete a line to drop it. The file is read
top-to-bottom = oldest-to-newest, which is the opposite of `git log` — that trips
up everyone once.

**Splitting a commit** (the one people don't know): mark it `edit`, then

```bash
git reset HEAD~          # un-commit it, keep the changes in the working tree
git add -p               # stage the first logical piece
git commit -m 'first piece'
git add -p && git commit -m 'second piece'
git rebase --continue
```

### The fixup workflow — this is the one that changes your week

Review comes back with twelve comments across five of your commits. The bad way
is one "address review comments" commit that touches everything. The good way:

```bash
# fix one thing, stage just that fix
git add -p
gfix                     # (module 60) fuzzy-pick which commit this belongs to
```

`gfix` creates a `fixup!` commit and immediately runs
`git rebase --autosquash --autostash`, which finds the target commit and folds
your fix into it. Your history stays as if you'd written it correctly the first
time, and the reviewer's next look is at clean commits.

`rebase.autosquash = true` and `rebase.autostash = true` are already set in
`gitconfig.include`, so `git rebase -i` does the right thing without flags.

### `git rerere` — the setting that makes rebasing bearable

**RE**use **RE**corded **RE**solution. Turned on in your config.

When you resolve a conflict, Git records the conflict's "shape" and your
resolution. Next time it sees the identical conflict — on a re-rebase, on
another branch, on a cherry-pick of the same change — it applies your resolution
automatically.

Rebasing a long-lived branch onto a fast-moving `main` normally means resolving
the same conflict every single time. With rerere you resolve it once. There is
no downside and it's a one-line config; it is arguably the single best
git setting that exists.

```bash
git rerere status      # what it's tracking right now
git rerere diff        # what it resolved for you
git rerere forget <path>   # you resolved it wrong; make it ask again
```

### `merge.conflictstyle = zdiff3` — also already on

Default conflict markers:

```
<<<<<<< HEAD
const timeout = 5000;
=======
const timeout = 3000;
>>>>>>> feature
```

You cannot tell who changed what. Was it 1000 before, and you both changed it?
Or was it 5000 and only they changed it? With `zdiff3`:

```
<<<<<<< HEAD
const timeout = 5000;
||||||| base
const timeout = 1000;
=======
const timeout = 3000;
>>>>>>> feature
```

Now you know: both sides changed it, from 1000. That third section is the entire
difference between guessing and knowing.

---

## 4. Recovery — why none of this is scary

### The reflog is your undo history

Every time a ref moves — commit, checkout, reset, rebase, merge, pull — Git
records the old value in the reflog. Kept ~90 days by default.

```bash
git reflog                              # HEAD's movements
git reflog show main                    # a specific branch's movements
git reset --hard HEAD@{3}               # go back to where you were 3 moves ago
git checkout -b rescue HEAD@{5}         # or safer: branch from it
```

Practise this **today** in a scratch repo:

```bash
git init /tmp/scratch && cd /tmp/scratch
echo a > f && git add . && git commit -m one
echo b > f && git commit -am two
echo c > f && git commit -am three
git reset --hard HEAD~2      # "destroy" two commits
git log --oneline            # they're gone
git reflog                   # ...they are not gone
git reset --hard HEAD@{1}    # back
```

Five minutes. The confidence it buys is worth far more, because the reason people
avoid rebase is fear, and this removes the basis for the fear.

The shell function `greflog` (module 60) makes this browsable with a diff preview.

### When the reflog isn't enough

```bash
git fsck --lost-found        # unreachable objects — commits with nothing pointing at them
git stash list               # you probably stashed it
git fsck --unreachable | grep commit | cut -d' ' -f3 | xargs git log --merges --no-walk
```

`git fsck --lost-found` finds commits that even the reflog forgot — for example
a commit made in a worktree you deleted.

### The four undos, and which to reach for

| Situation | Command |
|---|---|
| Committed too early, want the changes back | `git reset --soft HEAD~1` (alias: `git undo`) |
| Staged something you didn't mean to | `git restore --staged <file>` (`git unstage`) |
| Want to throw away working-tree edits to one file | `git restore <file>` (`git discard`) |
| Need to undo a commit that's already **pushed** | `git revert <sha>` — makes a *new* commit that inverts it. Never rewrite shared history. |

---

## 5. `git bisect` — the tool that feels like cheating

You know a test passed at v2.1.0 and fails now. 400 commits between. Binary
search finds the culprit in ~9 steps.

Manual:
```bash
git bisect start
git bisect bad                 # current commit is broken
git bisect good v2.1.0         # this tag was fine
# git checks out the midpoint; you test; then:
git bisect good    # or: git bisect bad
# ...repeat ~9 times
git bisect reset
```

Automated — this is the version you should actually use:
```bash
git bisect start HEAD v2.1.0
git bisect run pnpm --filter mfe-orders test -- OrderForm.spec.ts
```

Git runs the command at each step. Exit 0 = good, non-zero = bad, exit 125 =
skip (can't test this commit). It prints the first bad commit and stops. Go make
coffee.

**The trap in a monorepo:** if `node_modules` changed between the commits being
tested, your test may fail for the wrong reason. Wrap it:

```bash
git bisect run sh -c 'pnpm install --frozen-lockfile --silent && pnpm --filter mfe-orders test -- OrderForm.spec.ts'
```

Slow, but correct — and still 9 runs instead of 400.

The alias `git bisectrun '<cmd>'` wraps this.

---

## 6. Worktrees — the biggest workflow change available to you

### What they are

A worktree is a second (third, fourth) checkout that shares one `.git`
directory. Different branch checked out in each. Full-speed, no copying of
history, and `git fetch` in one is instantly visible in all.

```bash
gwt fix/order-total     # (module 60) creates ../<repo>.wt/fix-order-total and cds there
gwts                    # fuzzy-switch between worktrees
gwtrm                   # remove one
```

### Why they matter specifically for your architecture

You run an Angular shell plus several React MFEs. Switching branches means:

- Angular's `.angular/cache` invalidates → full rebuild
- Vite's dep-optimise cache invalidates → re-bundle
- If `pnpm-lock.yaml` differs, `node_modules` is now wrong → `pnpm install`
- Any running dev server is now serving a different branch's code, silently

That's minutes, several times a day, plus a class of "why is this not working"
bugs caused by a stale dev server.

With worktrees, each branch has its own directory, its own `node_modules`, its
own caches, and its own dev server on its own port. Nothing invalidates. You
`cd` and everything is exactly as you left it.

The three cases where this pays off hardest:

1. **Production hotfix while mid-feature.** No stash, no "wip: checkpoint"
   commit. `gwt hotfix/x`, fix, ship, `cd -`.
2. **Reviewing a colleague's PR while your branch is running.** Check it out in
   a worktree, run it on port 4300 next to yours on 4200, compare behaviour
   side by side.
3. **Bisecting.** Bisect in a worktree; your main checkout keeps working.

### The practical details

- `node_modules` is **not** shared. Run `pnpm install` once per worktree. pnpm's
  content-addressable store hardlinks from `~/Library/pnpm/store`, so this is
  fast and costs almost no disk.
- You cannot check out the same branch in two worktrees. Git refuses, which is
  correct.
- `git worktree prune` cleans up admin files after you delete a directory
  manually. `gwtrm` does it properly.
- The prompt (module 90) shows `⑂wt` when you're in a worktree. You will want
  that indicator more than you'd expect.

---

## 7. Aliases worth learning by heart

All installed via `gitconfig.include`. These are the ones to actually memorise:

```bash
git base       # prints the default branch, resolved robustly (origin/HEAD →
               # origin/main → origin/master → develop → …). Every other alias
               # below uses it, so they work on a fresh clone where origin/HEAD
               # was never set — the usual cause of "not a valid object name".
git s          # status --short --branch — the full status is mostly noise
git ap         # add --patch. Stage hunks. Do this every time.
git l          # graph log, one line per commit
git lb         # only the commits on THIS branch
git dm         # diff vs merge-base with main — what review will see
git rb         # interactive rebase over just this branch's commits
git sync       # fetch --prune && rebase onto origin/HEAD
git undo       # soft-reset the last commit, keep the changes
git can        # amend without editing the message ("oops, one more file")
git fix <sha>  # commit --fixup, pairs with autosquash
git rl         # reflog with relative dates
git gone       # delete every local branch whose remote is gone
git pick <str> # log -S: when did this string appear?
git cat <rev> <path>   # print a file at a revision
git churn      # most-changed files — where the complexity is
```

### `git add -p` deserves its own paragraph

It is the single highest-value habit in this document. It shows you every hunk
and asks: stage it? (`y`/`n`/`s` to split further/`e` to edit the hunk by hand).

You will catch: debug `console.log`s, a stray `.only` in a test, an unrelated
refactor you did while you were in there, a commented-out block. Every time. It
takes twenty extra seconds and it is the cheapest code review that exists.

---

## 8. lazygit — when to reach for it

Installed, and worth using for exactly two things:

- **Interactive staging.** Visual hunk and *line-level* staging is genuinely
  better than `git add -p` when a file has ten interleaved changes. Space to
  stage, `v` for line-select.
- **Interactive rebase.** Seeing the commit list with live diffs while you
  squash and reorder beats editing a todo file. `r` reword, `s` squash, `f`
  fixup, `Ctrl-J`/`Ctrl-K` to move commits.

For everything else — log queries, worktrees, bisect, reflog spelunking — the
CLI is faster and composes with the rest of your tools.

Don't let it become the way you use Git. The point is that you understand what
it's doing, and that you can do it on a machine that doesn't have it.

---

## 9. A 20-minute drill

Do this once, in a scratch repo, and most of the above will stick.

```bash
git init /tmp/gitdrill && cd /tmp/gitdrill
for i in 1 2 3 4 5; do echo "line $i" >> f.txt; git add . ; git commit -qm "commit $i"; done

git log --oneline                    # 1. read it
git cat-file -p HEAD                 # 2. see a commit's real contents
git cat-file -p HEAD^{tree}          # 3. see its tree
cat .git/refs/heads/main             # 4. a branch is a file with a sha in it

git reset --hard HEAD~3              # 5. "lose" three commits
git reflog                           # 6. find them
git reset --hard HEAD@{1}            # 7. get them back

git rebase -i HEAD~4                 # 8. squash two, reword one, drop one
                                     #    read the todo file's comments — they're good

git checkout -b other HEAD~2
echo conflict > f.txt && git commit -qam 'conflicting change'
git checkout main && git merge other # 9. cause a conflict, look at the zdiff3 markers
git merge --abort

git bisect start HEAD HEAD~4         # 10. bisect a few steps, then
git bisect reset

git worktree add ../drill-wt -b wt-branch    # 11. make a worktree, cd into it, look around
git worktree list
```

Twenty minutes. After it, `reset`, `reflog`, `rebase -i`, conflicts and
worktrees are things you've *done*, not things you've read about — and that is
the whole difference between functional and strong.
