# Agentic engineering with Copilot, safely

You have GitHub Copilot with Opus 5 access in IntelliJ and VS Code, and your org
is moving toward agentic engineering. You do not have Claude Code. Everything
below is Copilot-native.

The short version: **the leverage is not in the model, it's in the context and
the constraints you give it.** A Staff engineer's actual contribution to agentic
engineering is writing down the tribal knowledge and the guardrails. That's work
only you can do, and it's what this document is about.

---

## 1. The four extension points, and when to use each

Copilot has four ways to inject your context. People conflate them, then wonder
why their instructions get ignored or why every request is slow.

| Mechanism | Where it lives | When it loads | Use it for |
|---|---|---|---|
| **Repo instructions** | `.github/copilot-instructions.md` or `AGENTS.md` | On (nearly) every request in that repo | Architecture rules, conventions, "here be dragons" |
| **Path instructions** | `.github/instructions/*.instructions.md` with an `applyTo` glob | Only when a matching file is in context | Detailed per-area guidance (tests, terraform, Angular) |
| **Skills** | `.github/skills/<name>/SKILL.md` or `~/.copilot/skills/<name>/` | When the description matches your prompt, or `/name` | "Here is how to use this tool correctly" + bundled files |
| **Custom agents** | `.github/agents/<name>.agent.md` or `~/.copilot/agents/` | You pick it (`/agent`) or its description matches | A role with its own subagent context and its own tool restrictions |

The distinction that matters most:

- A **skill** is injected into whatever agent is already running. It's knowledge.
- An **agent** is a separate subagent with its own context window and its own
  allowed tool list. It's a role, with boundaries.

Use a skill for "how to write good SPL". Use an agent for "you are read-only and
here is your triage procedure". The `ai/` directory in this repo has working
examples of both.

**Precedence and cost.** Repo instructions are prepended to a large share of
requests, so every line costs tokens on every request. Keep
`copilot-instructions.md` under ~150 lines and push detail into path-scoped
`*.instructions.md` files, which only load when a matching file is in play. This
is the single most common mistake — a 600-line instructions file that makes every
request slower and mostly gets skimmed.

---

## 2. Repository instructions — the part only you can write

Start here. It's the highest-value artefact and it takes an afternoon.

`ai/copilot-instructions.md.template` and `ai/AGENTS.md.template` are annotated
starting points. Copy one, not both:

- If your org will only ever use Copilot → `.github/copilot-instructions.md`
- If your org may adopt other agent tooling → `AGENTS.md` at the root, and make
  `.github/copilot-instructions.md` a one-line pointer to it

**One source of truth.** Two drifting instruction files is worse than none,
because the agent will follow the stale one and nobody will notice.

### What to write

Write what an agent **cannot infer from the code.** It can read your `tsconfig`,
your eslint config, and your `package.json`. It cannot know:

- That the Angular shell must never import an MFE directly, because composition
  is at runtime through the import map.
- That two MFEs bundling their own `rxjs` is a production bug and not a style
  preference.
- That an un-torn-down subscription in an MFE leaks on every single mount cycle,
  not just once, because single-spa mounts and unmounts repeatedly.
- That `scripts/verify-externals.ts` keeps two files in sync and you must change
  both or neither.

**The highest-value section is "Things that will look wrong but are
intentional."** Every large codebase has ten of these. Without them, an agent
"helpfully" refactors a deliberate workaround and you find out in staging. That
list is pure Staff-engineer knowledge and it exists nowhere else.

### Nested files for a monorepo

`AGENTS.md` nests. The one closest to the file being edited wins:

```
/AGENTS.md                          workspace-wide
/packages/shell/AGENTS.md           Angular shell specifics
/packages/mfe-orders/AGENTS.md      that MFE's domain rules
```

That's the right granularity for you — it keeps the root file short and lets
each team own its own rules.

### Treat it as code

Review changes to it in PRs. When an agent does something wrong twice, that's a
missing line in the instructions file, not a reason to give up on the agent.
Over a few months this file becomes genuinely valuable onboarding documentation
for humans too — which is a nice side effect nobody expects.

---

## 3. Safe terminal access — the part that actually matters

This is where a Staff engineer earns their keep, because the failure mode is not
"the agent writes bad code" (you'll catch that in review). It's "the agent ran
`terraform apply` against prod because it seemed like the helpful thing to do".

### The layered model

**Layer 1 — sandbox.** Copilot CLI has `/sandbox enable`, which confines file
writes and command execution. Turn it on for exploratory work. It is the cheapest
protection available and you should default to it.

**Layer 2 — never blanket-approve.** `--allow-all` and `--yolo` exist. Do not use
them on a machine with live AWS credentials. In VS Code, keep
`"chat.tools.autoApprove": false` (it's in the settings file). The confirmation
prompt is not friction, it's the control.

Session-scoped approval ("yes, and approve this tool for the rest of the
session") is the right middle ground: approve `rg` and `pnpm test` once, keep
being asked about `aws` and `kubectl`.

**Layer 3 — scope tool access per agent.** This is the good one. A custom agent
declares its own `tools`, so `aws-triage` can be structurally incapable of
running a write command regardless of what it's asked. See
`ai/agents/aws-triage.agent.md` — the explicit forbidden list is the actual
product of that file.

**Layer 4 — read-only wrapper scripts.** Instead of giving an agent the AWS CLI,
give it `splunkq` — a 100-line script that can only call one read-only endpoint,
caps its own output, and reads its token from a 0600 file rather than the command
line. You can audit that script in five minutes. You cannot audit "the agent has
shell access".

This is a general principle worth internalising: **the safest tool to hand an
agent is a narrow script you wrote, not a broad tool you trust it to use
carefully.** A skill's `allowed-tools: ["shell(splunkq:*)"]` frontmatter
pre-approves exactly that one command and nothing else.

**Layer 5 — credential hygiene at the environment level.**

```bash
# an agent-safe shell: read-only AWS role, non-prod profile, no kube write access
export AWS_PROFILE=readonly-nonprod
```

Better still, run agent sessions in a shell whose AWS profile assumes a role
that has no write permissions at all. Then the guardrail is enforced by IAM
rather than by a prompt, and prompts can be talked out of things.

### A concrete policy to propose to your team

```
An agent may run, without asking:
  git log/diff/show/status/blame, rg, fd, bat, jq, ls, cat
  pnpm test / lint / typecheck / build
  splunkq (read-only by construction)

An agent must ask before:
  git push, git reset --hard, any history rewrite
  any aws command that is not describe-*/list-*/get-*
  any kubectl verb other than get/describe/logs/top
  installing or upgrading any dependency
  editing .github/workflows/, infra/, or any *.tf

An agent may never:
  terraform apply / destroy / state rm
  read secret VALUES (existence is fine)
  push to a protected branch
```

Put that in `AGENTS.md` (it's already in the template). It's not enforcement —
it's a stated norm, and stated norms are what make the exceptions visible.

---

## 4. Custom agents worth building for your environment

Three are included, in `ai/agents/`. Copy them to `~/.copilot/agents/` for
personal use, or `.github/agents/` to share with your team.

### `mfe-navigator` — build this first

"Where does X live, and what breaks if I change it" is a question you answer many
times a week, it's pure search, and it's exactly what an agent is good at. It's
also the one your team will benefit from most, because it encodes *how* to
navigate a single-spa monorepo — that static imports don't tell you what loads
at runtime, that the import map and the layout file are different concerns.

Commit this one.

### `splunk-investigator` — the biggest personal time saver

Paired with the `splunk-investigate` skill and the `splunkq` script, this turns
"something's wrong in prod" into a structured investigation with a timeline and
cited evidence, rather than twenty minutes of clicking through the Splunk UI.

The instructions encode the method, which is the valuable part: blast radius
before cause, normalise before counting, never `join`, always state confidence.

### `aws-triage` — read-only by construction

The value here is the constraint, not the prompt. A general-purpose agent will
eventually suggest `kubectl delete pod` to "fix" a crashloop. This one is
told, in one place, that it cannot — and it's told the triage *order*, which is
the thing juniors get wrong (they read application logs first; the pods'
restart reasons come first).

### Invoking them

```bash
copilot                                   # interactive
  /agent                                  # pick from the list
  /skills list                            # see what skills are loaded

copilot --agent aws-triage -p "why is orders-api unhealthy in staging?"
copilot --agent mfe-navigator -p "what depends on @org/shared-auth?"
```

---

## 5. MCP — what to actually connect

MCP lets an agent call external systems. It's genuinely useful and it's also
where the security exposure lives, so be deliberate.

```bash
copilot mcp add --transport http github https://api.githubcopilot.com/mcp/
```

Config lives at `~/.copilot/mcp-config.json`; see `ai/mcp-config.example.json`.

**Worth connecting:**

- **GitHub** — issues, PRs, Actions runs, code search across repos. Use the
  remote server so you get OAuth rather than storing a PAT in a file.
- **AWS documentation** (read-only, no credentials) — good ROI when you're
  writing Terraform and would otherwise have six doc tabs open.
- **Anything your platform team publishes internally** — an internal Splunk or
  Dynatrace MCP is strictly better than one you build, because it's already
  authenticated the way security wants and results stay in your tenancy.

**Think hard before connecting:**

An MCP server is arbitrary code with access to whatever you authenticate it to.
Before adding one, ask: who wrote it, does it run locally or ship your context to
a third party, and does your org's AI policy permit it? For a corporate machine,
"I found it on a registry" is not a sufficient answer.

**Where a script beats an MCP server:** for Splunk, `splunkq` + the
`splunk-investigate` skill gives you the same capability with a trust surface you
can read in five minutes. Prefer that until your platform team ships something
official. This applies more broadly than people expect — a small, auditable,
read-only script is often the better engineering answer.

---

## 6. Working patterns that hold up

**Ask for a plan before code, on anything non-trivial.** "Read these files and
tell me your approach before writing anything." Reviewing a plan takes a minute;
reviewing 400 lines of wrong code takes twenty.

**Give it the failing test, not the description.** "Here is the test, here is the
output, make it pass" produces dramatically better results than "the order total
is wrong". The test is an unambiguous specification and a verification loop in
one.

**Point at files, don't describe them.** In VS Code use `#file:` and `#selection:`.
Every file you name is context the model doesn't have to guess at, and guesses
are where hallucinations come from.

**Make it verify its own work.** "Run the tests and fix what fails" turns a
one-shot generation into a loop with a ground truth. This is most of the
difference between agent output that's useful and output that merely compiles.

**One task per session.** Context degrades as it fills with irrelevant history.
`/compact` when a session gets long; start fresh when you change task.

**Review agent diffs harder than human diffs, in the opposite direction.** Human
PRs tend to have local bugs. Agent PRs tend to be locally correct and
architecturally wrong — plausible code that ignores a boundary. `git dm` and read
the *shape* of the change, not just the lines.

**When it's wrong twice the same way, fix the instructions.** That's the
compounding loop. Every correction you write down is a correction you never make
again, for you or anyone on your team.

---

## 7. Specifically for AI-assisted debugging in your stack

**Splunk investigation.** Use the `splunk-investigator` agent. Give it the
symptom and the time window, not a query. Its job is to write the SPL; yours is
to check that the evidence supports the conclusion. Watch for the classic
failure: presenting correlation as cause. The agent's instructions tell it not
to, and you should still check.

**AWS/K8s investigation.** `aws-triage`. Always confirm the account in its first
message — an agent investigating the wrong account with total confidence is a
real and easy failure mode.

**Frontend bugs across the MFE boundary.** Give the agent three things: the
browser console output, the import map (`mfemap <url>`), and the relevant
component. Without the import map it cannot know which *build* of which MFE is
actually loaded, and it will confidently reason about the wrong source.

**Test failures.** Paste the full failure output including the diff. Modern test
runners produce excellent structured errors and truncating them throws away the
most useful context you have.

**Terraform plans.** Never let an agent apply. Have it read
`terraform show -json .tfplan` and report destroys and replaces first — that's
what `tfd` does, and it's what the `infra.instructions.md` file tells it to do.

---

## 8. Where you can lead on this

Your org is moving toward agentic engineering. The things that will matter, in
order of impact:

1. **A repo instructions file per major repo.** Highest leverage per hour spent,
   and it's the thing that makes every team member's agent better at once.
2. **A shared `.github/agents/` directory** with reviewed, versioned agents. When
   someone finds a better triage procedure, everyone gets it in the next pull.
3. **A stated tool-permission policy** so "can the agent run this" has an answer
   that isn't per-person judgement at 2am.
4. **Read-only wrapper scripts** for the systems agents keep needing —
   `splunkq` is the pattern. Small, auditable, one purpose.
5. **A norm that agent-authored changes are labelled in the PR.** Not to gatekeep
   — to build an accurate picture of where agents actually help, which nobody
   currently has.

The unglamorous observation: the teams that get value from agents are the ones
that wrote down how their system works. The teams that don't are the ones hoping
the model will figure it out. Writing that down was always a Staff engineer's
job; agents just made the payoff immediate.
