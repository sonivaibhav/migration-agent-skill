# A Staff Engineer's Terminal — minimal edition

Scoped to how you actually work: **git log · ripgrep · zsh aliases and themes ·
vim motions · tmux · directory shortcuts.** ECS, not EKS. Three tools, not
thirty.

> **The honest summary.** Roughly 80% of what you're after comes from four
> things: shell history that actually works, `fzf`, `ripgrep`, and two git
> settings (`rerere` + `zdiff3`). Everything else here is refinement.
>
> The remaining 20% isn't a tool at all. It's the habit of noticing a repeated
> action and spending four minutes turning it into a function or a shortcut. You
> will get more from writing ten mediocre shell functions than from installing
> forty good tools.

---

## 1. What to install, learn, configure, and skip

### Install — three things

| Tool | Why |
|---|---|
| **ripgrep** (`rg`) | Your main search. Whole-repo in ~200ms, honours `.gitignore` by default. |
| **fzf** | The multiplier. `Ctrl-R` alone justifies it; then every picker in this config is built on it. |
| **tmux** | You asked for it, and it's the reason your dev servers stop dying on VPN drops. Often already on the base image. |

Add **git-delta** fourth if it's easy — you live in `git log`, and delta is what
makes diffs readable. `fd` and `bat` after that. Nothing else.

### Learn — skills, not installs

| Skill | Why it's on the list |
|---|---|
| **Vim motions** — operators + text objects | Transfers to IntelliJ, VS Code, your shell, `less`, tmux copy-mode, and every server you ssh into. Highest-transfer skill available to you. |
| **`git log` as a query language** | You use it daily and are probably using ~5% of it. `-S`, `-L`, `..` vs `...` are the ones that pay. |
| **Interactive rebase + the fixup loop** | Turns "address 12 review comments" from a mess into a clean stack. |
| **Worktrees** | No stashing, no cache invalidation, no reinstall when you switch branches. |
| **fzf as a pattern** | `list \| fzf \| act`. Learn it once and you can build any picker you want, forever. |

### Configure — already yours, just set up badly by default

| Change | Impact |
|---|---|
| **zsh history** — 200k lines, shared across panes, written immediately | Enormous, for ~12 lines. Default is 1000 and per-session. |
| **`git rerere`** | Resolve a rebase conflict once; git replays it every time after. |
| **`merge.conflictstyle = zdiff3`** | Shows the common ancestor in conflicts. You stop guessing what the other side changed. |
| **`diff.algorithm = histogram`** | Better hunk matching, smaller diffs on refactors. |
| **`core.fsmonitor` + `untrackedCache`** | `git status` 1.2s → 90ms on a big checkout. |
| **Named directories + CDPATH** | Your `cd` shortcuts. Native zsh, no tool. |
| **IdeaVim** | Ships with IntelliJ. Zero install cost. |

### Understand — no install, just know it

- **A branch is a file containing a SHA.** Once you see that, `reset`, `rebase`
  and `reflog` stop being magic. Twenty minutes of reading, permanent payoff.
- **`git reflog` is your undo history.** Nothing committed is lost for ~90 days.
  This is the fact that makes rebase safe to experiment with.
- **zsh expands aliases before functions.** An alias you already have beats any
  function, regardless of load order. `sde-doctor` warns you when it happens.
- **Two dots vs three dots**, and the fact that they mean *inverted* things in
  `git log` and `git diff`. That's a real Git wart, not your misunderstanding.

### Skip

| Thing | Why not |
|---|---|
| **k9s / kubectl helpers** | You're moving to ECS. Removed entirely. |
| **oh-my-zsh** | ~3000 lines of framework wrapping ~40 lines of native zsh. Slows startup, hides what your shell does. |
| **Powerlevel10k / Starship** | Good tools. But a prompt runs on every Enter, and the common failure is one that shells out to `git status` each time — 200-400ms per prompt in a large repo. Three built-in themes here read a file and never fork. Already run p10k and like it? `SDE_THEME=off`. |
| **Neovim as a third editor** | You don't want to replace IntelliJ/VS Code, and you're right. Take the motions, leave the editor. |
| **zoxide** | Overlaps with the directory shortcuts you asked for, which need no binary. Explicit beats learned when you want predictability. |
| **lazygit, eza, yq, jq, gh, direnv, atuin, difftastic** | Each is fine. None is worth a portal request before you've actually missed it. |
| **tpm (tmux plugins)** | Everything needed is built into tmux. |

---

## 2. Four weeks

Time-boxed on purpose. Do not do two weeks at once — the failure mode for this
kind of project is installing everything on a Saturday and reverting on Tuesday.

### Week 0 — audit (15 minutes, writes nothing)

```bash
./install.sh --preflight
```

Read the collision table. It has a `WINNER` column, because the answer isn't
"whatever loads last": zsh expands **aliases before functions**, so if you
already have `alias gco='git checkout'` our richer `gco` is unreachable, with no
error. After install, `sde-doctor` warns and `sde-unshadow --fix` resolves it.

If it says `CLEAN`, go straight to week 1.

### Week 1 — the floor

```bash
./install.sh --no-tools
exec zsh
```

Then set up your directory shortcuts — this is the fastest visible win, so do it
first:

```bash
je              # opens dirs.conf; add your 3-5 most-used folders
```

```
work  = ~/work
repos = ~/work/repos/*
```

For one week, only these five habits:

- `grep -r` → **`rg`**
- opening the file tree → **`f`**
- `cd ../../packages/whatever` → **`j <name>`** or **`cd ~name`**
- searching for a string across the repo → **`s`** (live grep, Enter opens at the line)
- press **`Ctrl-R`** and actually use it

No tmux, no vim, no rebasing yet. The point of week 1 is that your hands stop
reaching for the old thing.

**You'll know it worked when** you get annoyed on a machine without `rg`.

### Week 2 — git

Read [01-GIT-MASTERY.md](01-GIT-MASTERY.md) sections 1–4. The config is already
installed; this week is about understanding *why*.

Daily:

- `git ap` (add --patch) instead of `git add .`, every time. This one habit
  catches more stray `console.log`s than any linter.
- `glf` to browse history instead of opening the GitHub UI.
- After each review round: stage the fix, run `gfix`, pick the commit it belongs
  to. Watch it get squashed into the right place automatically.
- Break something on purpose in a scratch repo and recover it with `greflog`.
  The confidence that buys is the whole point.

Set up worktrees on your main repo this week: `gwt <branch>`.

### Week 3 — tmux, six bindings only

Read [04-TMUX.md](04-TMUX.md). Learn exactly these:

| | |
|---|---|
| `prefix f` | fuzzy-jump to any project — the one that changes your day |
| `prefix \|` `prefix -` | split |
| `prefix h/j/k/l` | move between panes |
| `prefix z` | zoom a pane full-screen and back |
| `prefix [` then `/` | search the scrollback without a mouse |
| `prefix d` / `tmux a` | detach and reattach |

Set up `~/.config/staff-dev-env/projects.conf` on day one. Don't read the man
page. Don't add a plugin.

Also try `sde-theme compact` this week — one-line prompts are noticeably better
inside splits.

### Week 4 — vim motions, and your own automation

Install IdeaVim in IntelliJ and the Vim extension in VS Code; both configs are
in `editor/`. Your shell has been in vi-mode since week 1.

Only one thing matters: **learn operators + text objects, not individual
commands.** `ciw`, `ci"`, `ca(`, `dt,`, `cit`. Five of those beat fifty
memorised keystrokes. See [03-VIM-MOTIONS.md](03-VIM-MOTIONS.md).

Expect to be slower for about ten days. That's what learning a motor skill feels
like. If you're still slower after three weeks, stop — it doesn't suit everyone,
and shell vi-mode alone was still worth it.

In parallel, keep a text file open all week. Every time you type something
you've typed before, write it down. Friday, turn the top three into functions or
shortcuts. The pattern is always:

```bash
name() {
  local choice
  choice=$(<list things> | fzf --header 'pick one') || return
  <do something with> "$choice"
}
```

`zsh/50-nav.zsh` and `zsh/60-git.zsh` are worked examples. `j` is eight lines.

---

## 3. On ThePrimeagen's philosophy

He's right about the parts that matter here:

- **Remove friction, don't add features.** Every change should delete a step,
  not add a capability you'll use twice. That's why this edition is three tools.
- **Learn the primitive, not the wrapper.** `git rebase -i`, not a GUI button
  labelled "clean up commits". Primitives transfer; wrappers don't. Same reason
  you get IdeaVim rather than a new editor.
- **Speed compounds** — not because typing is your bottleneck, but because a
  fast loop keeps you *inside* the problem. Every 20-second wait is an
  invitation to check Slack, and rebuilding your mental model costs minutes.
- **Own your tools.** A config you wrote is debuggable at 2am. A framework you
  installed is not.

Where not to copy him: he has total machine control and his editor *is* his
job's tooling. You have neither. Take the motions, the tmux sessionizer, and the
git fluency; leave the Neovim rebuild.

**Courses, in the order that matches this plan:**

1. [Everything You'll Need to Know About Git](https://frontendmasters.com/courses/everything-git/) — do this one first and completely. Highest value for your stated goals, and it teaches the object model rather than a command list.
2. [VIM Fundamentals](https://frontendmasters.com/courses/vim-fundamentals/) — the motions and operators sections. Skip the config/plugin parts; you're not adopting Neovim.
3. [Developer Productivity v2](https://frontendmasters.com/courses/developer-productivity-v2/) — tmux and shell. Watch after week 3, so you have context.

Watch at 1.5×, and stop after each section to do the thing.

---

## 4. Reference

```bash
sde-help              # every command, with descriptions
sde-help git          # filtered
sde-doctor            # tools present/missing, shadowing warnings
sde-theme compact     # minimal | compact | verbose | off
jl                    # your directory shortcuts
sde-unshadow --fix    # unhide functions your aliases are covering
```

Turn a core module off, or an optional one on — both go in `~/.zshrc` **above**
the staff-dev-env block:

```bash
export SDE_DISABLE="90"          # keep your own prompt
export SDE_ENABLE="aws"          # ECS helpers on demand
```

Optional modules available: `aws` (ECS) · `terraform` · `splunk` · `frontend`.
