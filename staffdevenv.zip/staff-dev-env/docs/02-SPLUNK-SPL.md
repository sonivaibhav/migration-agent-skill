# Splunk 9.x SPL Field Guide — App + AWS Infra Investigation

Assumed context: Java/Spring Boot (JSON logs via HEC or forwarder), React/Angular MFEs (browser/RUM logs forwarded), EKS/ECS container logs, ALB access logs, CloudWatch Logs forwarded into Splunk 9.x.

Index/sourcetype names below are placeholders — substitute yours. Field names for ALB/CloudWatch are verified against AWS and the Splunk Add-on for AWS (see §8).

---

## 1. Search performance fundamentals

### 1.1 The pipeline model (why order matters)

A Splunk search has two halves:

| Phase | Where it runs | Commands |
|---|---|---|
| **Distributable streaming** | Indexers, in parallel, per-event | `search`, `eval`, `where`, `rex`, `spath`, `fields`, `lookup`, `fillnull`, `makemv`, `mvexpand`, `convert`, `bin` |
| **Centralized / transforming** | Search head, needs all data | `stats`, `timechart`, `chart`, `top`, `rare`, `dedup`, `sort`, `transaction`, `eventstats`, `streamstats`, `table`, `join`, `append` |

Splunk docs state the rule plainly: **"Place non-streaming commands as late as possible in your search string."** The first transforming command is a barrier — everything after it runs single-threaded on one search head.

### 1.2 Filter order that actually matters

Cost ranking, cheapest first:

1. **Time range** — selects which buckets are even opened. Biggest single lever. A 24h search over a 90d retention index touches ~1% of the buckets.
2. **`index=`** — bucket-level pruning. `index=*` forces every index.
3. **`sourcetype=` / `source=` / `host=`** — these are *indexed* fields; they prune via the tsidx metadata, not by reading raw events.
4. **Bare keyword terms** — resolved against the tsidx term dictionary before any raw event is decompressed. `index=app_prod NullPointerException` is far cheaper than `index=app_prod | where match(_raw,"NullPointerException")`.
5. **Search-time field comparisons** (`status=500`, `duration_ms>1000`) — require decompressing raw events and running extraction regexes. Most expensive.

```spl
-- BAD: no time bound, no index, filter after extraction
sourcetype=spring:json | where status >= 500 | stats count by endpoint

-- GOOD: time + index + indexed metadata + keyword prefilter, then field filter
index=app_prod sourcetype=spring:json earliest=-1h@m latest=@m
  ERROR
| where status >= 500
| stats count by endpoint
```

### 1.3 `TERM()` — the underused lever

Splunk's segmenter splits `_raw` at **major breakers** (space, tab, newline, `[]`, `<>`, `()`, `{}`, `|`, `!`, `;`, `,`, `'`, `"`, `&`, `?`) and then further at **minor breakers** (`.`, `/`, `:`, `=`, `@`, `-`, `#`, `$`, `%`, `\`, `_`).

Searching `trace_id=4f2a9b1c-8d3e-4a77-9f01-22b6cd1e0a3f` makes Splunk look up each hyphen-separated segment and intersect — many term lookups plus a raw-event verification pass. `TERM()` looks up the *whole* string as one dictionary entry:

```spl
index=app_prod earliest=-24h TERM(4f2a9b1c-8d3e-4a77-9f01-22b6cd1e0a3f)
```

**Critical constraint:** the string inside `TERM()` must be bounded by **major** breakers in the raw event. Splunk's own doc example: `TERM(127.0.0.1)` works against `127.0.0.1 - admin` (spaces around it) but **fails** against `ip=127.0.0.1 - user=admin`, because `=` is a minor breaker so the indexed major-breaker-bounded token is `ip=127.0.0.1`.

Practical implication for JSON logs: in `{"trace_id":"4f2a...","level":"ERROR"}`, the quotes and commas *are* major breakers, so the bare UUID **is** a major-breaker-bounded token. `TERM(<uuid>)` works. In logfmt (`trace_id=4f2a...`), it does not — use `TERM(trace_id=4f2a9b1c-8d3e-4a77-9f01-22b6cd1e0a3f)` instead.

Test it: run both forms and compare `scan_count` in the Job Inspector. If `TERM()` isn't helping, `scan_count` will be identical.

`CASE()` is the sibling: searches are case-insensitive by default; `CASE(ERROR)` forces exact case. Both support trailing wildcards: `TERM(%ASA-1*)`, `CASE(%ASA-1*)`.

### 1.4 `tstats` vs raw search

`tstats` reads only the tsidx files — no raw event decompression, no field extraction. Orders of magnitude faster, but only for **indexed fields**.

Always available as indexed fields: `index`, `sourcetype`, `source`, `host`, `_time`, `splunk_server`, `punct`, plus anything you explicitly made index-time (`INDEXED_EXTRACTIONS`, `fields.conf` `INDEXED=true`) and data model accelerations.

```spl
-- Volume/shape reconnaissance: which sourcetypes, which hosts, how much — seconds, not minutes
| tstats count WHERE index=app_prod earliest=-24h BY sourcetype, host

-- Event volume timeline across a wide window
| tstats count WHERE index=aws sourcetype=aws:elb:accesslogs earliest=-7d BY _time span=10m
| timechart span=10m sum(count) AS events

-- prestats=t hands internal format to timechart/chart/stats for multi-series
| tstats prestats=t count WHERE index=app_prod earliest=-24h BY _time span=5m, sourcetype
| timechart span=5m count BY sourcetype
```

`PREFIX()` (Splunk 8.0+) extends `tstats` to key=value pairs that survive segmentation — it aggregates by the value portion of an indexed token. Prefix must be lowercase inside the parens:

```spl
| tstats count WHERE index=app_prod TERM(level=ERROR) BY PREFIX(service=)
```

`tstats` restrictions worth memorizing:
- Search-time extracted fields are **not** allowed — anywhere, including `WHERE` and `BY`.
- No wildcards in field names (`BY host*` is invalid; wildcards in *values* are fine: `sourcetype=spring*`).
- No `count(eval(...))`, no nested `eval()` inside aggregates.
- Cannot handle multiple time ranges in one command.

**Workflow that works:** use `tstats` to find *where* and *when*, then a narrow raw search to find *what*.

### 1.5 `fields` early

`fields` is distributable streaming. Placing it right after the base search reduces the payload shipped from indexers to the search head, and in Fast/Smart mode limits which extractions must run.

```spl
index=app_prod sourcetype=spring:json earliest=-1h TERM(level=ERROR)
| fields _time trace_id service endpoint status duration_ms message
| stats count BY service, endpoint
```

- `| fields a b c` = keep only these (plus internal fields).
- `| fields - _raw` = drop the raw event once you've extracted what you need. Big win on verbose JSON.
- `| table` is **not** a substitute — `table` runs on the search head only. Use `fields` early, `table` last.

Splunk Lantern's guidance is explicit: avoid `table` mid-search; put it at the end so indexers can do map-reduce first.

### 1.6 `head` placement

`head` is centralized streaming — it short-circuits the pipeline once N results are produced.

```spl
-- GOOD: stops scanning after 100 matching events
index=app_prod TERM(level=ERROR) earliest=-24h | head 100 | table _time service message

-- POINTLESS for perf: stats already consumed every event
index=app_prod earliest=-24h | stats count BY service | head 100
```

Related: `| sort - count | head 20` scans everything twice on the search head. `| sort 20 - count` is the one-pass form (`sort <N>` limits during the sort). And `| sort 0 _time` is the incantation for **unlimited** sort — bare `sort` truncates at 10,000 by default.

### 1.7 Field extraction cost

- **Index-time fields** (`INDEXED_EXTRACTIONS=json`, `KV_MODE`, indexed fields in `fields.conf`): free at search time, usable by `tstats`, but bloat the index and can't be changed retroactively.
- **Search-time fields**: extracted per event, per search. `KV_MODE=json` on a fat Spring Boot JSON log means parsing the whole document even if you need one field.
- **`rex` in the pipeline**: a regex per event. Anchor it (`^`), avoid `.*` backtracking, and always run it *after* your filters, not before.
- **Search modes**: Fast mode disables field discovery (only fields you name). Smart is the default. Verbose returns everything — use it for 5 minutes while you learn the data shape, never in a saved search.

Diagnostic: **Job Inspector** (`Job` → `Inspect Job`). Look at `command.search.index` vs `command.search.rawdata` vs `command.search.kv` (extraction) durations, and the `scan_count` / `event_count` ratio. If `scan_count` >> `event_count`, your filters are running too late.

---

## 2. The high-ROI command set

### `stats` — the workhorse

```spl
index=app_prod sourcetype=spring:json earliest=-1h
| stats count AS total,
        count(eval(status>=500)) AS errors,
        dc(trace_id) AS traces,
        avg(duration_ms) AS avg_ms,
        max(duration_ms) AS max_ms,
        values(host) AS hosts,
        earliest(_time) AS first_seen,
        latest(_time) AS last_seen
  BY service, endpoint
| eval error_pct = round(100.0 * errors / total, 2)
| where total > 50
| sort - error_pct
```

`count(eval(<bool>))` is the documented conditional-count idiom — it counts only events where the expression is true. Caveat: if the field is a *string*, `status>=500` does lexicographic comparison. For ALB status codes and other string-typed fields use `count(eval(match(status,"^5")))` or `count(eval(tonumber(status)>=500))`.

Key functions: `count`, `dc`/`distinct_count`, `estdc` (cheap approximate), `sum`, `avg`, `median`, `min`/`max`, `range`, `stdev`, `values` (dedup'd multivalue), `list` (ordered, keeps dupes, capped at 100), `first`/`last` (input order), `earliest`/`latest` (by `_time`), `mode`, `rate`.

### `timechart` — stats with an implicit `BY _time`

```spl
index=app_prod sourcetype=spring:json earliest=-6h@h latest=@h
| timechart span=5m
    count AS requests,
    count(eval(status>=500)) AS errors,
    perc95(duration_ms) AS p95_ms
```

With a `BY` split you get one series per value (only one aggregate allowed alongside `BY`):

```spl
| timechart span=5m limit=10 useother=f count BY service
```

`limit=10` caps series count (default 10, `limit=0` = all), `useother=f` suppresses the `OTHER` bucket, `usenull=f` suppresses `NULL`. `cont=f` avoids filling empty buckets with zeros.

### `eval` — computed fields

```spl
| eval duration_s   = round(duration_ms/1000, 3),
       status_class = substr(tostring(status), 1, 1) . "xx",
       is_error     = if(status>=500, 1, 0),
       svc          = coalesce(service, app_name, 'k8s.container.name', "unknown"),
       endpoint_norm = replace(endpoint, "/\d+", "/{id}"),
       bucket       = case(duration_ms<100,"fast", duration_ms<1000,"ok",
                           duration_ms<5000,"slow", true(),"terrible")
```

Note `.` is string concatenation in eval — which is exactly why dotted field names (`k8s.pod.name`) **must** be single-quoted: `'k8s.pod.name'`.

Useful function families: `if`/`case`/`validate`, `coalesce`, `nullif`, `isnull`/`isnotnull`, `match`/`replace`/`substr`/`split`/`ltrim`, `mvindex`/`mvfilter`/`mvjoin`/`mvcount`/`mvdedup`, `strftime`/`strptime`/`relative_time`/`now`, `tonumber`/`tostring`/`printf`, `json_extract`.

### `where` vs `search`

- `search` (implicit at the start, explicit mid-pipeline) — term-based, supports wildcards in values, can push down to indexers.
- `where` — eval-expression based; required for field-to-field comparison and functions.

```spl
| where duration_ms > p95_baseline          -- field vs field: only `where` can do this
| where like(endpoint, "/api/v2/%")         -- SQL-ish LIKE
| where match(message, "(?i)timeout|refused")
| where isnotnull(trace_id) AND NOT cidrmatch("10.0.0.0/8", client_ip)
| search status=5* endpoint="/api/*"        -- wildcards: use `search`, not `where`
```

### `rex` — ad hoc extraction and normalization

```spl
-- named capture groups
| rex field=message "Order (?<order_id>\d+) failed for user (?<user_id>[\w-]+)"

-- multiple matches into a multivalue field
| rex field=_raw max_match=0 "\"(?<header>[Xx]-[\w-]+)\""

-- sed mode: in-place normalization (this is how you build error signatures)
| rex field=message mode=sed "s/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/<uuid>/g"
| rex field=message mode=sed "s/\b\d+\b/<n>/g"
```

`rex` silently does nothing if the regex misses — always check `| where isnull(order_id) | head 5` to find your parse failures.

### `spath` — JSON/XML navigation

```spl
-- auto-extract everything (first 5000 chars of input; tunable via extraction_cutoff in limits.conf)
| spath

-- targeted, much cheaper
| spath input=_raw path=mdc.traceId output=trace_id
| spath path=exception.stackTrace{0} output=top_frame

-- arrays: {} = all elements (multivalue), {n} = zero-based index for JSON
| spath path=errors{}.code output=error_codes
| spath path=spans{2}.name output=third_span
```

If `KV_MODE=json` or `INDEXED_EXTRACTIONS=json` is set on the sourcetype, top-level fields already exist and `spath` is redundant. `json_extract()` in eval is often faster for a single deep field:

```spl
| eval trace_id = json_extract(_raw, "mdc.traceId")
```

### `transaction` vs `stats` — prefer `stats`

`transaction` groups events into a single multivalue event, giving you `duration`, `eventcount`, `closed_txn`. It is expensive: `maxevents` defaults to 1000, and it holds open transactions in memory bounded by `maxopentxn`/`maxopenevents` in `limits.conf`. Exceeding them silently evicts transactions — you get *wrong answers*, not errors. It also requires events in descending time order when using `maxspan`/`maxpause`.

Use `transaction` only when you genuinely need **event ordering/nesting** or `startswith`/`endswith` boundary logic:

```spl
index=gateway earliest=-1h
| transaction session_id maxspan=30m maxpause=5m
    startswith="event=login" endswith="event=logout" keepevicted=t
| where closed_txn=0
| table session_id duration eventcount
```

For 95% of correlation work, `stats` is correct, distributable, and unbounded:

```spl
index=gateway earliest=-1h
| stats min(_time) AS start, max(_time) AS end, count AS events,
        values(event) AS event_types BY session_id
| eval duration = end - start
```

### `streamstats` — running/windowed calculations

Order-dependent, so control the sort explicitly.

```spl
-- running error total per service
| sort 0 _time
| streamstats count(eval(status>=500)) AS running_errors BY service

-- 10-point moving average per endpoint (global=f = independent window per group)
| streamstats window=10 global=f avg(duration_ms) AS ma10 BY endpoint

-- time-based window
| streamstats time_window=5m count AS req_last_5m BY service

-- gap detection between consecutive events of the same trace
| sort 0 trace_id _time
| streamstats current=f last(_time) AS prev_time BY trace_id
| eval gap_s = _time - prev_time
| where gap_s > 2

-- deploy-relative sequencing: reset the counter at each deploy marker
| streamstats reset_before="(event_type==\"deploy\")" count AS events_since_deploy BY service
```

Without `time_window`, the default window is all preceding events; `time_window` caps at 10,000 events regardless.

### `eventstats` — aggregate without collapsing

Computes a stat and *appends it to every event*. This is how you do "compare each row to its group's baseline."

```spl
index=app_prod sourcetype=spring:json earliest=-1h
| eventstats avg(duration_ms) AS avg_ms, stdev(duration_ms) AS sd_ms BY endpoint
| eval z = (duration_ms - avg_ms) / sd_ms
| where z > 3
| table _time trace_id endpoint duration_ms avg_ms z
```

Also the standard way to compute a percentage-of-total in one pass:

```spl
| stats count BY service
| eventstats sum(count) AS total
| eval pct = round(100.0*count/total, 2)
```

### `bin` (alias `bucket`) — explicit bucketing

`timechart` calls this implicitly. Use it directly when you need `_time` bucketing *plus* multiple `BY` fields (which `timechart` can't do).

```spl
index=app_prod earliest=-24h
| bin _time span=1h
| stats count AS requests, count(eval(status>=500)) AS errors BY _time, service, endpoint
| eval error_rate = round(100.0*errors/requests, 2)

-- align hourly buckets to local business day + 3h
| bin _time span=12h aligntime=@d+3h

-- non-time bucketing: latency histogram
| bin duration_ms bins=20 | stats count BY duration_ms
| bin duration_ms span=2log10 | stats count BY duration_ms   -- log-scaled buckets
```

### `top` / `rare`

```spl
| top limit=20 endpoint BY service showperc=t countfield=hits
| rare limit=10 useother=f error_code
```

`top` is `stats count | sort - count | head N` with percentages, and it's a transforming command — same cost. It's a convenience, not an optimization. `top` defaults to `limit=10`; always set it explicitly.

### `dedup`

```spl
| dedup trace_id                                    -- first event per trace (in current sort order)
| dedup 3 service                                   -- keep first 3 per service
| dedup service sortby - duration_ms                -- slowest request per service
| dedup trace_id keepempty=t                        -- keep events where trace_id is null
```

Gotchas: `dedup` respects the *current* order, so pair it with `sortby` or an explicit `sort` before it. It's memory-bound on cardinality. Deduping millions of trace IDs will be slower than `| stats first(*) AS * BY trace_id`.

### `table` / `fields`

`fields` early (distributable, prunes the wire payload), `table` last (search-head only, but preserves column order for output/export).

```spl
index=app_prod earliest=-1h TERM(level=ERROR)
| fields _time trace_id service endpoint status message
| ...
| table _time trace_id service endpoint status message
```

### `fillnull` / `coalesce`

```spl
| fillnull value=0 errors, timeouts          -- specific fields
| fillnull value="unknown"                   -- everything (default value is 0)
| eval svc = coalesce(service, 'k8s.container.name', app, sourcetype, "unknown")
```

`fillnull` after `stats`/`chart` is what makes zero-count buckets render correctly. `coalesce` is essential when the same logical field has different names across MFE / gateway / backend sourcetypes.

### `mvexpand` / `makemv` / `mvcombine`

```spl
| makemv delim="," tags                       -- string -> multivalue
| makemv tokenizer="(\w+)=(\w+)" kvpairs
| mvexpand tags limit=50                      -- one event per value
| eval tag_count = mvcount(tags)
| eval first_tag = mvindex(tags, 0)
| eval joined = mvjoin(tags, " | ")
| eval real = mvfilter(match(tags, "^env_"))
```

`mvexpand` is memory-bound: default `max_mem_usage_mb = 500`. Exceeding it **truncates the chunk with a warning**, not an error. Always `limit=` it, and expand as late as possible.

### `lookup` / `inputlookup` / `outputlookup`

```spl
| lookup service_owners.csv service OUTPUT owner_team, slack_channel, tier
| lookup service_owners.csv service AS svc OUTPUTNEW owner_team
| inputlookup deploys.csv WHERE service="checkout" | sort - deploy_time
| ... | outputlookup baseline_p95.csv          -- persist a computed baseline
```

`inputlookup append=t` inside a search is a cheap way to union reference data. Lookups are distributable streaming if the lookup file is replicated to indexers.

### `tstats` (see §1.4)

### `foreach` — loop over fields

```spl
-- convert every *_ms field to seconds
| foreach *_ms [ eval <<MATCHSTR>>_s = round('<<FIELD>>'/1000, 3) ]

-- zero-fill and total a wide timechart
| foreach 5* [ eval total = coalesce(total,0) + coalesce('<<FIELD>>',0) ]

-- multivalue mode
| foreach tags mode=multivalue [ eval joined = mvappend(joined, upper(<<ITEM>>)) ]
```

Tokens: `<<FIELD>>` (full name — single-quote it), `<<MATCHSTR>>` (the wildcard-matched part), `<<MATCHSEG1..3>>` (per-wildcard segments), `<<ITEM>>`/`<<ITER>>` in multivalue/json_array modes.

### Bonus: `cluster`, `convert`, `addinfo`, `appendpipe`, `untable`

```spl
| cluster field=message t=0.8 showcount=t labelonly=t   -- fuzzy message grouping
| convert ctime(first_seen) ctime(last_seen)            -- epoch -> human readable
| convert dur2sec(elapsed) AS elapsed_s
| addinfo                                               -- adds info_min_time/info_max_time
| appendpipe [ stats sum(count) AS count | eval service="TOTAL" ]
```

---

## 3. Correlation without `join`

### 3.1 The `stats values() BY correlation_id` idiom

This is the canonical multi-index correlation pattern. It's a single pass, fully distributable, and has no row limit.

```spl
(index=mfe_prod OR index=gateway_prod OR index=app_prod)
  earliest=-30m@m latest=@m
  (sourcetype=browser:json OR sourcetype=alb:access OR sourcetype=spring:json)
| eval trace_id = coalesce(trace_id, traceId, 'mdc.traceId', x_correlation_id, correlation_id)
| where isnotnull(trace_id)
| eval tier = case(index=="mfe_prod","1-browser",
                   index=="gateway_prod","2-gateway",
                   index=="app_prod","3-service",
                   true(),"9-other")
| fields _time trace_id tier index service endpoint status duration_ms message
| stats min(_time)            AS t_start,
        max(_time)            AS t_end,
        dc(tier)              AS tiers_seen,
        values(tier)          AS tiers,
        values(service)       AS services,
        values(endpoint)      AS endpoints,
        values(status)        AS statuses,
        max(duration_ms)      AS max_ms,
        count                 AS events,
        count(eval(status>=500)) AS server_errors,
        values(eval(if(status>=500, service."/".endpoint, null()))) AS failing_ops
  BY trace_id
| eval e2e_ms = round((t_end - t_start)*1000, 0)
| where server_errors > 0
| sort 20 - e2e_ms
| convert ctime(t_start)
| table t_start trace_id e2e_ms tiers services failing_ops statuses events
```

Why this beats `join`:
- One search job, not two. No subsearch row cap, no 60s subsearch timeout.
- `values(eval(...))` lets you conditionally collect — the `failing_ops` line is the whole investigation in one field.
- Filtering with `dc(tier)` finds traces that *didn't* reach a tier: `| where dc(tier)<3` = requests lost between gateway and service.

**Half-open detection** — the "request entered the gateway but no service log exists" case:

```spl
| stats values(tier) AS tiers, count AS events BY trace_id
| where mvfind(tiers, "2-gateway") >= 0 AND isnull(mvfind(tiers, "3-service"))
```

### 3.2 `transaction`-free session reconstruction

```spl
(index=mfe_prod OR index=app_prod) earliest=-1h session_id=*
| stats earliest(_time) AS first, latest(_time) AS last,
        list(eval(strftime(_time,"%H:%M:%S")." ".coalesce(event,message))) AS timeline
  BY session_id
| eval duration_s = last - first
```

`list()` preserves order and duplicates (capped at 100 values); `values()` sorts and dedups. For a chronological trace waterfall you want `list()` after an explicit `| sort 0 _time`.

### 3.3 When a subsearch is fine

Subsearches are acceptable when the result set is small and bounded — typically producing a filter term list:

```spl
-- Find all requests from users who hit a 500 in the last 15m
index=app_prod earliest=-1h
  [ search index=app_prod earliest=-15m status>=500
    | stats count BY user_id
    | where count >= 3
    | fields user_id
    | head 500 ]
| stats count BY user_id, endpoint, status
```

Rules:
- End the subsearch with `| fields <one_or_two_fields>` — otherwise every field becomes a search term and the expansion is garbage.
- `| head N` it explicitly so you never hit the silent truncation.
- `| format` if you need to control the generated boolean expression; `| format maxresults=<n>` caps it.
- Use `| return 100 $user_id` for a compact single-field return.

**Subsearch limits (`limits.conf [subsearch]`):**
| Setting | Default | Applies to |
|---|---|---|
| `maxout` | **10,000** | standard subsearches (search filter expansion) |
| `subsearch_maxout` | **50,000** | `join` |
| `maxtime` | **60 seconds** | all subsearches — results are *finalized*, i.e. silently truncated |
| `ttl` | 300s | subsearch result cache |

Truncation produces a warning banner in the UI and **nothing at all** via the REST API. This is the #1 source of silently-wrong Splunk answers.

### 3.4 `append` / `appendcols` alternatives

```spl
-- Union two differently-shaped datasets, then reconcile with stats
index=app_prod earliest=-1h | eval src="app" | fields src trace_id status
| append maxtime=120 [ search index=aws sourcetype=aws:elb:accesslogs earliest=-1h
                       | eval src="alb", trace_id=replace(trace_id,"^Root=","")
                       | fields src trace_id elb_status_code ]
| stats values(status) AS app_status, values(elb_status_code) AS alb_status,
        values(src) AS sources BY trace_id
| where mvcount(sources)=2
```

`append` runs as a subsearch → same 50k/60s caps. For large unions, prefer a single base search with `OR`ed index clauses.

### 3.5 `map` — avoid

`| map [search ...]` runs one search per input row (default `maxsearches=10`). It's a for-loop over search jobs. Almost always replaceable with `stats`. Mentioned only so you recognize it in inherited dashboards.

---

## 4. Investigation playbooks

### 4.1 Find the 5xx spike

**Step 1 — is it real, and when did it start?**

```spl
index=app_prod sourcetype=spring:json earliest=-24h@h latest=@h
| timechart span=10m
    count AS requests,
    count(eval(status>=500)) AS errors
| eval error_rate = round(100.0*errors/requests, 2)
| fillnull value=0 error_rate errors
```

**Step 2 — which service/endpoint owns it?**

```spl
index=app_prod sourcetype=spring:json earliest=-2h@m latest=@m
| fields _time service endpoint status
| stats count AS requests,
        count(eval(status>=500)) AS errors,
        count(eval(status>=400 AND status<500)) AS client_errors
  BY service, endpoint
| eval error_rate = round(100.0*errors/requests, 2)
| where requests >= 100 AND errors > 0
| sort 25 - errors
| table service endpoint requests errors error_rate client_errors
```

**Step 3 — is the spike new, or is this endpoint always broken?** Compare current window to the same window yesterday:

```spl
index=app_prod sourcetype=spring:json
  (earliest=-1h@h latest=@h) OR (earliest=-25h@h latest=-24h@h)
| eval window = if(_time >= relative_time(now(),"-1h@h"), "now", "yesterday")
| stats count AS requests, count(eval(status>=500)) AS errors BY window, service, endpoint
| eval rate = round(100.0*errors/requests, 2)
| stats first(eval(if(window=="now", rate, null())))      AS rate_now,
        first(eval(if(window=="yesterday", rate, null()))) AS rate_yday,
        sum(eval(if(window=="now", errors, 0)))            AS errors_now
  BY service, endpoint
| fillnull value=0 rate_now rate_yday
| eval delta = round(rate_now - rate_yday, 2)
| where errors_now >= 10
| sort 25 - delta
```

Note the `(earliest=... latest=...) OR (earliest=... latest=...)` construct — Splunk supports per-clause time modifiers in a single base search, which avoids `append` entirely.

**Step 4 — spike detection with a rolling baseline (no manual threshold):**

```spl
index=app_prod sourcetype=spring:json earliest=-24h@h latest=@h
| timechart span=5m count(eval(status>=500)) AS errors BY service limit=0
| untable _time service errors
| streamstats window=24 current=f global=f avg(errors) AS baseline, stdev(errors) AS sd BY service
| eval z = round((errors - baseline) / (sd + 0.5), 2)
| where z > 4 AND errors > 10
| sort 0 _time
| table _time service errors baseline z
```

### 4.2 Trace one request end-to-end (MFE → ALB/gateway → Spring Boot)

**Fast path — you have the trace ID:**

```spl
(index=mfe_prod OR index=gateway_prod OR index=app_prod OR index=aws)
  earliest=-2h
  TERM(9f1c4d2e8a3b47f6b0c5d9e2a1f38c74)
| eval tier = case(index=="mfe_prod","1-browser", index=="aws","2-alb",
                   index=="gateway_prod","3-gateway", index=="app_prod","4-service", true(),"9-other"),
       svc  = coalesce(service, 'k8s.container.name', elb, sourcetype),
       msg  = coalesce(message, request, _raw)
| sort 0 _time
| eval ts = strftime(_time, "%H:%M:%S.%3N")
| table ts tier svc host status elb_status_code target_status_code duration_ms target_processing_time msg
```

Use `sort 0 _time` (unlimited) — plain `sort _time` truncates at 10,000.

**Add relative offsets so you can see where the time went:**

```spl
| sort 0 _time
| streamstats current=f first(_time) AS t0
| eval t0 = coalesce(t0, _time)
| eventstats min(_time) AS trace_start
| eval offset_ms = round((_time - trace_start)*1000, 1)
| table offset_ms tier svc status duration_ms msg
```

**AWS X-Ray trace ID join:** ALB writes `trace_id` as `Root=1-63f5a1c2-1a2b3c4d5e6f708192a3b4c5`. Spring Boot with Micrometer Tracing writes a W3C 32-hex `traceId`. These are **different identifiers** — you cannot join them directly. Two options:

```spl
-- (a) Propagate your own header (X-Correlation-Id) end to end and key on that.
-- (b) If your app logs the incoming X-Amzn-Trace-Id, normalize both sides:
index=aws sourcetype=aws:elb:accesslogs earliest=-1h
| eval xray_id = replace(trace_id, "^\"?Root=", "")
| eval xray_id = replace(xray_id, "\"$", "")
| fields xray_id elb_status_code target_status_code target_processing_time request
| append [ search index=app_prod earliest=-1h amzn_trace_id=*
           | eval xray_id = replace(amzn_trace_id, "^Root=([^;]+).*", "\1")
           | fields xray_id service endpoint status duration_ms ]
| stats values(*) AS * BY xray_id
```

**Reverse lookup — you have a user complaint, not a trace ID:**

```spl
index=app_prod sourcetype=spring:json earliest=-2h user_id="u-88213" status>=500
| fields _time trace_id endpoint status message
| sort 0 - _time | head 20
```

### 4.3 Latency percentiles by endpoint

```spl
index=app_prod sourcetype=spring:json earliest=-4h@m latest=@m duration_ms=*
| fields service endpoint duration_ms status
| stats count AS n,
        avg(duration_ms)    AS avg_ms,
        perc50(duration_ms) AS p50,
        perc90(duration_ms) AS p90,
        perc95(duration_ms) AS p95,
        perc99(duration_ms) AS p99,
        max(duration_ms)    AS max_ms
  BY service, endpoint
| where n >= 100
| foreach avg_ms p50 p90 p95 p99 max_ms [ eval <<FIELD>> = round('<<FIELD>>', 0) ]
| eval tail_ratio = round(p99/p50, 1)
| sort 25 - p99
```

**Percentile accuracy — this matters for SLO reporting.** Splunk docs:

- `perc<n>()` / `p<n>()` — **approximate**. Above 1,000 distinct values Splunk uses a radix-tree digest, bounding error to **< 1% rank error** (a `perc95` result lands somewhere between the true p94 and p96). These functions are **nondeterministic** — rerunning the same search over the same data can give slightly different numbers.
- `upperperc<n>()` — approximate **upper bound** of the percentile.
- `exactperc<n>()` — exact, but "very resource expensive for high cardinality fields" and "can consume a large amount of memory."

Use `perc` for dashboards, `exactperc` only for a bounded final SLO calculation:

```spl
| stats exactperc99(duration_ms) AS p99_exact BY service   -- narrow window / few services only
```

**Percentiles over time:**

```spl
index=app_prod sourcetype=spring:json earliest=-12h@h latest=@h endpoint="/api/v2/checkout"
| timechart span=5m perc50(duration_ms) AS p50, perc95(duration_ms) AS p95, perc99(duration_ms) AS p99
```

**Latency histogram (better than percentiles for finding bimodality):**

```spl
index=app_prod sourcetype=spring:json earliest=-1h endpoint="/api/v2/checkout"
| bin duration_ms span=2log10
| stats count BY duration_ms
| sort 0 duration_ms
```

**Apdex-style bucketing:**

```spl
| eval bucket = case(duration_ms =< 300, "satisfied",
                     duration_ms =< 1200, "tolerating",
                     true(), "frustrated")
| stats count BY endpoint, bucket
| xyseries endpoint bucket count
| fillnull value=0
| eval apdex = round((satisfied + tolerating/2) / (satisfied+tolerating+frustrated), 3)
| sort 20 apdex
```

### 4.4 Correlate a deploy with error onset

**If deploys are in Splunk** (CI webhook → HEC, or a `deploys.csv` lookup):

```spl
index=app_prod sourcetype=spring:json earliest=-6h@h latest=@h
| timechart span=5m count(eval(status>=500)) AS errors, count AS requests BY service limit=0
```

overlay approach — annotate errors relative to the deploy:

```spl
index=ci sourcetype=deploy:event service="checkout" earliest=-24h
| stats latest(_time) AS deploy_time, latest(version) AS version BY service
| eval search_earliest = deploy_time - 3600, search_latest = deploy_time + 3600
| table service version deploy_time
```

**Before/after comparison, single search:**

```spl
index=app_prod sourcetype=spring:json service=checkout earliest=-2h latest=now
| eval deploy_time = strptime("2026-08-16 14:32:00", "%Y-%m-%d %H:%M:%S")
| eval phase = if(_time < deploy_time, "1-before", "2-after")
| stats count AS requests,
        count(eval(status>=500)) AS errors,
        perc95(duration_ms) AS p95,
        dc(eval(if(status>=500, message, null()))) AS distinct_errors
  BY phase, endpoint
| eval error_rate = round(100.0*errors/requests, 3)
| xyseries endpoint phase error_rate
| rename "1-before" AS rate_before, "2-after" AS rate_after
| fillnull value=0
| eval delta = round(rate_after - rate_before, 3)
| where delta > 0
| sort 20 - delta
```

**Change-point detection without knowing the deploy time** — find the first bucket where errors jump and stay up:

```spl
index=app_prod sourcetype=spring:json earliest=-12h@h latest=@h
| bin _time span=5m
| stats count AS requests, count(eval(status>=500)) AS errors BY _time, service
| eval rate = 100.0*errors/requests
| sort 0 service _time
| streamstats window=12 current=f global=f avg(rate) AS prior_avg, stdev(rate) AS prior_sd BY service
| eval jump = rate - prior_avg
| where prior_sd > 0 AND jump > 3*prior_sd AND errors >= 5
| stats min(_time) AS onset, values(service) AS services BY service
| convert ctime(onset)
```

**Deploy markers as a lookup join (small, bounded — a legitimate `inputlookup`):**

```spl
index=app_prod sourcetype=spring:json earliest=-7d@d
| bin _time span=1h
| stats count(eval(status>=500)) AS errors BY _time, service
| lookup deploys_hourly.csv _time service OUTPUT version, deployed_by
| where isnotnull(version)
| sort 0 - errors
```

Also useful: correlate error onset with new `version` values already present in the logs — no CI integration needed:

```spl
index=app_prod sourcetype=spring:json service=checkout earliest=-6h
| stats count AS requests, count(eval(status>=500)) AS errors,
        min(_time) AS first_seen BY app_version
| eval error_rate = round(100.0*errors/requests, 2)
| convert ctime(first_seen)
| sort 0 first_seen
```

### 4.5 Noisiest error signature

**Normalize with `rex mode=sed`, then count** (deterministic, reproducible, good for alerting):

```spl
index=app_prod sourcetype=spring:json earliest=-4h (level=ERROR OR level=FATAL)
| eval sig = coalesce('exception.class', message, _raw)
| rex field=sig mode=sed "s/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/<uuid>/g"
| rex field=sig mode=sed "s/0x[0-9a-fA-F]+/<hex>/g"
| rex field=sig mode=sed "s/\b\d{1,3}(\.\d{1,3}){3}\b/<ip>/g"
| rex field=sig mode=sed "s/\b[\w.+-]+@[\w-]+\.[\w.]+\b/<email>/g"
| rex field=sig mode=sed "s/\b\d+\b/<n>/g"
| rex field=sig mode=sed "s/'[^']*'/'<str>'/g"
| eval sig = substr(sig, 1, 200)
| stats count AS occurrences,
        dc(service)  AS services,
        dc(trace_id) AS traces,
        values(service) AS service_list,
        min(_time) AS first_seen,
        max(_time) AS last_seen,
        first(message) AS sample
  BY sig
| eval age_min = round((last_seen - first_seen)/60, 1)
| sort 20 - occurrences
| convert ctime(first_seen) ctime(last_seen)
| table occurrences services traces sig first_seen last_seen sample
```

**Or let `cluster` do fuzzy grouping** (better for unstructured logs where you can't guess the shape):

```spl
index=app_prod sourcetype=spring:json earliest=-2h level=ERROR
| fields _time service message
| cluster field=message t=0.8 showcount=t labelonly=t
| stats count AS occurrences,
        values(service) AS services,
        first(message)  AS representative
  BY cluster_label
| sort 20 - occurrences
```

`t` is the threshold (default `0.8`; **higher = stricter matching, more clusters**, range 0.0–1.0). `labelonly=t` keeps the original events annotated (so you can `stats` on them); `labelonly=f` outputs only cluster summaries. `match=termlist|termset|ngramset` controls the similarity metric — `ngramset` is more tolerant of word reordering.

**New-error detection** (signatures present now but absent in the prior baseline):

```spl
index=app_prod sourcetype=spring:json level=ERROR earliest=-7d@d latest=now
| rex field=message mode=sed "s/\b\d+\b/<n>/g"
| eval message = substr(message, 1, 150)
| eval window = if(_time >= relative_time(now(),"-1h"), "recent", "baseline")
| stats count AS n, values(window) AS windows, min(_time) AS first BY message
| where mvcount(windows)=1 AND mvfind(windows,"recent")>=0 AND n >= 5
| convert ctime(first)
| sort 0 - n
```

`punct` is a free, index-time signature field for the truly unstructured case:

```spl
| tstats count WHERE index=app_prod TERM(ERROR) earliest=-1h BY punct
| sort 20 - count
```

### 4.6 Kubernetes / EKS pod restarts and OOMKilled

Field names depend on your collector. With the **Splunk OpenTelemetry Collector for Kubernetes** (sck-otel), sourcetypes are `kube:container:<CONTAINER_NAME>` by default (overridable per-pod via the `splunk.com/sourcetype` annotation), and events are enriched with:

`k8s.pod.name`, `k8s.pod.uid`, `k8s.deployment.name`, `k8s.cluster.name`, `k8s.namespace.name`, `k8s.node.name`, `k8s.pod.start_time`, `container_name`, `run_id`, `stream`

Index routing is via the `splunk.com/index` annotation (pod annotation beats namespace annotation).

**Critical SPL gotcha:** dotted field names collide with eval's `.` concatenation operator. **Always single-quote them in `eval`/`where`:**

```spl
| eval pod = 'k8s.pod.name', ns = 'k8s.namespace.name'      -- correct
| eval pod = k8s.pod.name                                    -- WRONG: concatenates k8s . pod . name
| where 'k8s.namespace.name'="payments"                      -- correct
```

**OOMKilled from Kubernetes events:**

```spl
index=k8s_events earliest=-24h ("OOMKilled" OR "OutOfmemory")
| eval pod = coalesce('involvedObject.name', 'k8s.pod.name'),
       ns  = coalesce('involvedObject.namespace', 'k8s.namespace.name')
| stats count AS oom_kills,
        values(ns)   AS namespaces,
        values(reason) AS reasons,
        min(_time)   AS first, max(_time) AS last
  BY pod
| sort 0 - oom_kills
| convert ctime(first) ctime(last)
```

**OOMKilled via container exit code 137** (SIGKILL = 128+9) when you only have container/kubelet logs:

```spl
index=k8s_logs earliest=-24h ("exit code 137" OR "OOMKilled" OR "Killing container" OR "MemoryPressure")
| eval pod = 'k8s.pod.name', ns = 'k8s.namespace.name', node = 'k8s.node.name'
| stats count, values(node) AS nodes, values(ns) AS namespaces BY pod
| sort 20 - count
```

**Restart storms — detect pod identity churn per deployment:**

```spl
index=k8s_logs earliest=-6h
| eval deploy = 'k8s.deployment.name', ns = 'k8s.namespace.name', pod = 'k8s.pod.name'
| bin _time span=10m
| stats dc(pod) AS distinct_pods, count AS log_lines BY _time, ns, deploy
| streamstats window=6 current=f global=f avg(distinct_pods) AS baseline BY ns, deploy
| where distinct_pods > 2*baseline AND distinct_pods >= 3
| sort 0 - _time
```

**New pod appearances (a proxy for restarts) using `k8s.pod.start_time`:**

```spl
index=k8s_logs earliest=-6h 'k8s.pod.start_time'=*
| eval start_epoch = strptime('k8s.pod.start_time', "%Y-%m-%dT%H:%M:%S")
| stats values(start_epoch) AS starts, dc(start_epoch) AS start_count BY 'k8s.deployment.name'
| where start_count > 3
```

**Restart counts from kube-state-metrics** (if you ship metrics into a metrics index — much more reliable than log inference):

```spl
| mstats max(_value) AS restarts
    WHERE index=k8s_metrics
      metric_name="kube_pod_container_status_restarts_total"
      earliest=-6h
    BY pod, namespace, container span=5m
| streamstats current=f last(restarts) AS prev BY pod, container
| eval delta = restarts - prev
| where delta > 0
| stats sum(delta) AS new_restarts BY namespace, pod, container
| sort 20 - new_restarts
```

**Crash-loop signature — errors immediately before pod disappearance:**

```spl
index=k8s_logs 'k8s.namespace.name'="payments" earliest=-2h
| eval pod = 'k8s.pod.name'
| eventstats max(_time) AS pod_last_seen BY pod
| where (pod_last_seen - _time) < 30
| stats count, list(_raw) AS final_lines BY pod
| sort 10 - count
```

**Correlate app 5xx with a specific pod** — pinpoints "one bad replica":

```spl
index=app_prod sourcetype=spring:json earliest=-1h
| eval pod = coalesce('k8s.pod.name', host)
| stats count AS requests, count(eval(status>=500)) AS errors BY pod, service
| eval rate = round(100.0*errors/requests, 2)
| eventstats avg(rate) AS svc_avg_rate, count AS pod_count BY service
| where pod_count > 1 AND rate > 3*svc_avg_rate AND errors >= 10
| sort 0 - rate
```

**EKS control plane logs** land in CloudWatch log groups `/aws/eks/<cluster>/cluster` with streams `kube-apiserver-*`, `kube-controller-manager-*`, `kube-scheduler-*`, `authenticator-*`, `kube-apiserver-audit-*`. Forwarded via Firehose they arrive as `aws:cloudwatchlogs` (or `aws:firehose:json`). Note: the Splunk AWS add-on explicitly warns **not** to use the pull-based API input for `aws:cloudwatchlogs:*` due to CloudWatch API rate limits — use Kinesis Firehose push.

```spl
index=aws sourcetype=aws:cloudwatchlogs source="*/aws/eks/prod-cluster/cluster*" earliest=-2h
| spath
| search verb IN ("delete","patch") objectRef.resource="pods"
| stats count BY 'user.username', 'objectRef.namespace', verb
| sort 20 - count
```

### 4.7 ALB: `elb_status_code` vs `target_status_code`

**Field semantics (from AWS ALB access log spec):**

| Field | Meaning |
|---|---|
| `elb_status_code` | Status the **load balancer returned to the client** (may be LB-generated, a fixed-response rule, or a WAF block response) |
| `target_status_code` | Status **from the target**. Recorded **only if a connection was established and the target sent a response** — otherwise `-` |
| `request_processing_time` | LB received request → LB sent it to a target |
| `target_processing_time` | LB sent to target → target began sending response headers. **`-1` means: LB couldn't dispatch, target closed the connection before idle timeout, malformed client request, or target didn't respond before idle timeout** |
| `response_processing_time` | LB got response headers → LB began sending to client |
| `actions_executed` | `authenticate`, `fixed-response`, `forward`, `redirect`, `rewrite`, `waf`, `waf-failed`, or `-` |
| `error_reason` | Error code (auth actions / Lambda targets); `-` otherwise |
| `target_status_code_list` | Space-delimited list when multiple targets processed the request |
| `trace_id` | Contents of the `X-Amzn-Trace-Id` header |

**The core diagnostic:**

```spl
index=aws sourcetype=aws:elb:accesslogs earliest=-2h@m latest=@m
| eval alb_5xx     = if(match(elb_status_code, "^5"), 1, 0),
       tgt_5xx     = if(match(target_status_code, "^5"), 1, 0),
       no_response = if(target_status_code="-" OR isnull(target_status_code), 1, 0),
       lb_generated = if(match(elb_status_code,"^5") AND (target_status_code="-" OR isnull(target_status_code)), 1, 0),
       target_originated = if(match(elb_status_code,"^5") AND match(target_status_code,"^5"), 1, 0)
| timechart span=5m
    count                    AS requests,
    sum(alb_5xx)             AS elb_5xx,
    sum(target_originated)   AS app_5xx,
    sum(lb_generated)        AS infra_5xx
```

**Interpretation table** — this is the whole point of the distinction:

| `elb_status_code` | `target_status_code` | `target_processing_time` | Meaning |
|---|---|---|---|
| `502` | `-` | `-1` | Target closed connection / sent a malformed response. **Infra/app crash, not app logic.** |
| `503` | `-` | `-1` | No healthy targets in the target group. **Scaling / health check failure.** |
| `504` | `-` | `-1` | Target didn't respond before the idle timeout. **App hung — check GC pauses, DB pool exhaustion, downstream timeouts.** |
| `500` | `500` | `> 0` | **Your Spring Boot code threw.** Go find the trace ID in the app index. |
| `5xx` | `2xx` | `> 0` | Target succeeded; LB failed on the response path (rare — check `error_reason`). |
| `460`/`463`/`464` | `-` | — | Client closed early / bad `X-Forwarded-For` / protocol mismatch. Not a server bug. |

`elb_status_code` is a string field after extraction — use `match(elb_status_code,"^5")` or `elb_status_code IN ("500","502","503","504")` rather than `elb_status_code>=500`, so you don't depend on implicit type coercion.

**Break down by target and cause:**

```spl
index=aws sourcetype=aws:elb:accesslogs earliest=-1h match(elb_status_code,"^5")
| rex field=request "^(?<http_method>\w+)\s+\w+://[^/]+(?<path>/[^?\s]*)"
| eval path_norm = replace(path, "/\d+", "/{id}"),
       cause = case(
         elb_status_code="502" AND target_status_code="-", "502 target closed/malformed",
         elb_status_code="503" AND target_status_code="-", "503 no healthy targets",
         elb_status_code="504" AND target_status_code="-", "504 target timeout",
         target_status_code!="-", "app returned ".target_status_code,
         true(), "other ".elb_status_code)
| stats count AS errors,
        dc(target) AS distinct_targets,
        values(target) AS targets,
        avg(target_processing_time) AS avg_tpt
  BY cause, path_norm
| sort 25 - errors
```

**Is it one bad task/pod behind the ALB?**

```spl
index=aws sourcetype=aws:elb:accesslogs earliest=-1h
| rex field=target "^(?<target_ip>[\d.]+):(?<target_port>\d+)$"
| stats count AS requests, count(eval(match(elb_status_code,"^5"))) AS errors BY target_ip
| eval rate = round(100.0*errors/requests, 2)
| eventstats avg(rate) AS fleet_avg
| where requests > 100 AND rate > 3*fleet_avg
| sort 0 - rate
```

**Timeouts specifically (`target_processing_time = -1`):**

```spl
index=aws sourcetype=aws:elb:accesslogs earliest=-2h target_processing_time=-1
| timechart span=5m count BY elb_status_code limit=0
```

**ALB latency percentiles (independent of app instrumentation):**

```spl
index=aws sourcetype=aws:elb:accesslogs earliest=-1h target_processing_time>=0
| rex field=request "^(?<http_method>\w+)\s+\w+://[^/]+(?<path>/[^?\s]*)"
| eval path_norm = replace(path, "/\d+", "/{id}"),
       total_ms  = round((request_processing_time + target_processing_time + response_processing_time)*1000, 1),
       target_ms = round(target_processing_time*1000, 1)
| stats count AS n, perc50(target_ms) AS p50, perc95(target_ms) AS p95, perc99(target_ms) AS p99,
        perc95(total_ms) AS p95_total
  BY path_norm
| where n >= 100
| sort 25 - p99
```

The `p95_total` vs `p95` gap isolates LB/queueing overhead from actual app time.

**Sourcetype caveat:** the Splunk Add-on for AWS ships `aws:elb:accesslogs`, but its extractions were originally written for **Classic** ELB and its ALB extraction is keyed on the `source` pattern (`source::...elasticloadbalancing**.log.gz`), not the sourcetype. Older add-on versions mis-parse ALB lines. Verify before trusting field names:

```spl
| tstats count WHERE index=aws sourcetype=aws:elb:accesslogs* earliest=-1h BY sourcetype, source
```

If fields are missing, an `EXTRACT-` in `props.conf` matching the ALB field order (see §8) is the standard fix. Community-recommended ALB extraction captures, in order: `type`, `timestamp`, `elb`, `client_ip`, `client_port`, `target`, `request_processing_time`, `target_processing_time`, `response_processing_time`, `elb_status_code`, `target_status_code`, `received_bytes`, `sent_bytes`, `request`, `user_agent`, `ssl_cipher`, `ssl_protocol`, `target_group_arn`, `trace_id`.

---

## 5. Operational tooling

### 5.1 Time modifiers

Units: `s|sec|secs|second|seconds`, `m|min|mins|minute|minutes`, `h|hr|hrs|hour|hours`, `d|day|days`, `w|week|weeks`, `mon|month|months`, `q|qtr|qtrs|quarter|quarters`, `y|yr|yrs|year|years`.

Syntax: `[+|-]<integer><unit>@<snap_unit>`, and you can chain further offsets after the snap.

```spl
earliest=-15m              latest=now
earliest=-1h@h             latest=@h        -- previous complete hour (stable, cacheable)
earliest=-24h@h            latest=@h
earliest=-7d@d             latest=@d        -- last 7 complete days
earliest=@d                latest=now       -- today so far
earliest=-1d@d             latest=@d        -- yesterday
earliest=@w0               latest=now       -- week to date, Sunday start (@w0..@w7; Sun=0 or 7, Mon=1)
earliest=-mon@mon          latest=@mon      -- last complete calendar month
earliest=@q                latest=now       -- quarter to date (snaps to Jan 1/Apr 1/Jul 1/Oct 1)
earliest=@d-2h             latest=@d+6h     -- chained offsets after snap
earliest=-1h@h-1d          latest=@h-1d     -- same hour, yesterday
earliest="08/16/2026:14:00:00" latest="08/16/2026:15:00:00"   -- absolute: %m/%d/%Y:%H:%M:%S
earliest=1755354000        latest=1755357600                  -- epoch
```

**Snapping always rounds *down*** ("snaps backwards to the latest time that is not after the specified time"). `-7d@d` at 14:30 Sunday means midnight *seven days ago*, so the window is 7 days + 14.5 hours. Use `earliest=-7d@d latest=@d` for exactly 7 complete days.

**`_index_earliest` / `_index_latest`** filter by **index time**, not event time. Essential for late-arriving data and for alerts that must not miss backfilled events:

```spl
index=app_prod earliest=-24h latest=now _index_earliest=-15m _index_latest=now
```

**In eval:**

```spl
| eval yesterday_same_hour = relative_time(now(), "-1d@h")
| eval day_bucket = strftime(_time, "%Y-%m-%d")
| eval hour_of_day = strftime(_time, "%H")
| eval epoch = strptime(log_timestamp, "%Y-%m-%dT%H:%M:%S.%3N%z")
| eval _time = epoch                                   -- retime events for charting
| eval age_min = round((now() - _time)/60, 1)
```

Reindexing `_time` mid-search is legitimate and common — e.g. plotting by a business timestamp rather than ingest time.

### 5.2 `| makeresults` for testing SPL without data

```spl
-- 1 row, one field
| makeresults | eval status=500, service="checkout", duration_ms=1234

-- N synthetic rows, one per day, backwards
| makeresults count=10
| streamstats count AS n
| eval _time = _time - (n*86400),
       service = mvindex(split("checkout,cart,search,auth", ","), n%4),
       status  = if(n%3=0, 500, 200),
       duration_ms = 100 + (n*37)%2000
| fields - n
| sort 0 _time

-- inline CSV (Splunk 9.3+ for the format/data args; max 29,999 chars)
| makeresults format=csv data="service,endpoint,p95
checkout,/api/checkout,1420
cart,/api/cart,310"

-- inline JSON
| makeresults format=json data="[{\"service\":\"checkout\",\"status\":500},{\"service\":\"cart\",\"status\":200}]"

-- annotate=true adds _raw, host, source, sourcetype, splunk_server
| makeresults count=3 annotate=true
```

This is the fastest way to debug a `foreach`, `mvexpand`, `streamstats window=` boundary, or a regex — no index scan, instant feedback.

### 5.3 Search macros

Definition (Settings → Advanced search → Search macros, or `macros.conf`). Name encodes arity: a two-argument macro is named `mymacro(2)`. Arguments are `$name$` tokens.

```ini
# $SPLUNK_HOME/etc/apps/<app>/local/macros.conf

[app_base]
definition = index=app_prod sourcetype=spring:json
iseval = 0

[app_errors]
definition = `app_base` (level=ERROR OR level=FATAL OR status>=500)

[svc_errors(2)]
args = svc, window
definition = `app_base` service="$svc$" earliest=-$window$ status>=500 \
  | stats count AS errors, dc(trace_id) AS traces BY endpoint \
  | sort 20 - errors
validation = isnum(replace($window$, "[a-z]+$", ""))
errormsg = window must look like 15m, 2h, 1d

[error_rate(1)]
args = span
definition = timechart span=$span$ count AS requests, count(eval(status>=500)) AS errors \
  | eval error_rate = round(100.0*errors/requests, 2)
```

Invocation uses backticks:

```spl
`app_errors` earliest=-1h | `error_rate(5m)`
`svc_errors(checkout, 2h)`
```

Rules that trip people up:
- A macro containing a **generating command** (`tstats`, `inputlookup`, `makeresults`) must omit the leading `|` in the definition; put the pipe before the backtick in the search: `| \`my_tstats_macro\``.
- `iseval = 1` ("Use eval-based definition") means the definition string is itself an eval expression that *returns* the SPL to splice in — useful for conditional search construction.
- Macros expand textually before parsing, so they compose with `fields`/`where` naturally, but a macro's internal pipes will break if you splice it mid-expression.

### 5.4 Saved searches / alerts

`savedsearches.conf`:

```ini
[Prod 5xx rate by service]
search = index=app_prod sourcetype=spring:json \
  | stats count AS requests, count(eval(status>=500)) AS errors BY service \
  | eval error_rate = round(100.0*errors/requests, 2) \
  | where requests > 100 AND error_rate > 2
dispatch.earliest_time = -15m@m
dispatch.latest_time   = @m
cron_schedule = */5 * * * *
enableSched = 1
counttype = number of events
relation = greater than
quantity = 0
alert.severity = 4
alert.suppress = 1
alert.suppress.period = 30m
alert.suppress.fields = service
action.webhook = 1
action.webhook.param.url = https://hooks.example.com/splunk
```

Notes:
- Snap-to (`-15m@m latest=@m`) makes the window deterministic and lets Splunk reuse cached results across runs. Unsnapped ranges defeat caching.
- `alert.suppress.fields` = throttle per-entity, so one broken service doesn't suppress alerts for others.
- Reference from a search: `| savedsearch "Prod 5xx rate by service"` (re-runs it), or `| loadjob savedsearch="admin:search:Prod 5xx rate by service"` (loads the last scheduled run's artifacts — instant, no re-scan). `loadjob` is enormously useful for building on expensive scheduled searches.

**Summary indexing** for expensive recurring aggregations:

```spl
index=app_prod sourcetype=spring:json earliest=-1h@h latest=@h
| bin _time span=5m
| stats count AS requests, count(eval(status>=500)) AS errors,
        perc95(duration_ms) AS p95 BY _time, service, endpoint
| collect index=summary_app marker="report=svc_5m"
```

then query the summary instead of raw:

```spl
index=summary_app report=svc_5m earliest=-30d@d
| timechart span=1h sum(errors) AS errors BY service
```

---

## 6. Splunk REST API from the terminal

Management port is **8089** (not 8000). Endpoints below assume Splunk Enterprise; Splunk Cloud requires a support ticket to open REST access, and the hostname is typically `https://<stack>.splunkcloud.com:8089`.

### 6.1 Authentication

```bash
export SPLUNK_HOST="https://splunk.example.com:8089"

# (a) Authentication token (JWT) — Settings > Tokens. Preferred for scripting.
export SPLUNK_TOKEN="eyJraWQiOiJz..."
AUTH=(-H "Authorization: Bearer $SPLUNK_TOKEN")

# (b) Session key from username/password
SESSION_KEY=$(curl -s -k -u "$USER:$PASS" \
  "$SPLUNK_HOST/services/auth/login" -d output_mode=json | jq -r .sessionKey)
AUTH=(-H "Authorization: Splunk $SESSION_KEY")

# (c) Basic auth (fine for interactive one-offs)
AUTH=(-u "$USER:$PASS")
```

### 6.2 One-shot: `search/jobs/export` (streaming, no SID)

Best for CLI investigation and for piping into an AI agent — results stream as they're produced and there's no job to poll or clean up.

```bash
curl -s -k "${AUTH[@]}" \
  "$SPLUNK_HOST/services/search/jobs/export" \
  --data-urlencode 'search=search index=app_prod sourcetype=spring:json status>=500
                           | stats count AS errors, dc(trace_id) AS traces BY service, endpoint
                           | sort 25 - errors' \
  -d earliest_time="-1h@m" \
  -d latest_time="@m" \
  -d output_mode=csv
```

JSON Lines (one JSON object per result — ideal for streaming into a script):

```bash
curl -s -k "${AUTH[@]}" \
  "$SPLUNK_HOST/services/search/jobs/export" \
  --data-urlencode 'search=search index=aws sourcetype=aws:elb:accesslogs elb_status_code=50*
                           | stats count BY elb_status_code, target_status_code' \
  -d earliest_time="-30m" -d latest_time="now" \
  -d output_mode=json \
  | jq -c '.result'
```

`output_mode` accepts (lowercase required): `atom`, `csv`, `json`, `json_cols`, `json_rows`, `raw`, `xml`.

### 6.3 One-shot blocking: `exec_mode=oneshot`

```bash
curl -s -k "${AUTH[@]}" \
  "$SPLUNK_HOST/services/search/jobs" \
  -d exec_mode=oneshot \
  -d output_mode=json \
  -d earliest_time="-15m" -d latest_time="now" \
  -d count=0 \
  --data-urlencode 'search=| tstats count WHERE index=app_prod BY sourcetype, host'
```

Returns the full result set in the response body. Blocks until done — set a client timeout.

### 6.4 Async: create job → poll → fetch (for long searches)

```bash
# 1. Dispatch
SID=$(curl -s -k "${AUTH[@]}" \
  "$SPLUNK_HOST/services/search/jobs" \
  -d output_mode=json \
  -d earliest_time="-24h@h" -d latest_time="@h" \
  -d adhoc_search_level=fast \
  --data-urlencode 'search=search index=app_prod status>=500 | stats count BY service' \
  | jq -r .sid)

# 2. Poll
while true; do
  read -r DONE STATE <<<"$(curl -s -k "${AUTH[@]}" \
    "$SPLUNK_HOST/services/search/jobs/$SID" -d output_mode=json \
    | jq -r '.entry[0].content | "\(.isDone) \(.dispatchState)"')"
  [ "$DONE" = "true" ] && break
  echo "state=$STATE" >&2
  sleep 2
done

# 3. Fetch (count=0 = all; default is 100!)
curl -s -k "${AUTH[@]}" \
  "$SPLUNK_HOST/services/search/jobs/$SID/results" --get \
  -d output_mode=json -d count=0

# 4. Clean up
curl -s -k -X DELETE "${AUTH[@]}" "$SPLUNK_HOST/services/search/jobs/$SID"
```

`dispatchState` progresses `QUEUED → PARSING → RUNNING → FINALIZING → DONE` (or `FAILED`).

### 6.5 Parameters worth knowing

| Parameter | Notes |
|---|---|
| `search` | **Must start with `search ` or a leading `\|`.** A bare `index=foo` is a syntax error over REST. |
| `earliest_time` / `latest_time` | Accept the same modifiers as SPL (`-1h@h`, `@d`, epoch, `%m/%d/%Y:%H:%M:%S`). |
| `output_mode` | `csv`, `json`, `json_rows`, `json_cols`, `raw`, `xml`, `atom`. |
| `count` | On `/results`: **defaults to 100.** Set `count=0` for all. |
| `offset` | Pagination on `/results`. |
| `exec_mode` | `normal` (default, async), `blocking`, `oneshot`. |
| `adhoc_search_level` | `verbose` \| `fast` \| `smart`. `fast` skips field discovery. |
| `rf` | Required fields — pushes `fields` optimization into the job. Repeatable. |
| `max_count` | Max events an event-returning search retains (default 10000). |
| `max_time` | Server-side job time limit in seconds. |
| `namespace` / `/servicesNS/<user>/<app>/...` | App context. Needed for app-scoped macros and lookups to resolve. |
| `-k` | Skips TLS verification. Drop it in production; use `--cacert`. |

### 6.6 A reusable wrapper

```bash
#!/usr/bin/env bash
# splunkq — run SPL from the CLI, emit CSV or JSON
set -euo pipefail

: "${SPLUNK_HOST:?set SPLUNK_HOST}"
: "${SPLUNK_TOKEN:?set SPLUNK_TOKEN}"

EARLIEST="${EARLIEST:--1h@m}"
LATEST="${LATEST:-@m}"
MODE="${MODE:-csv}"
APP="${APP:-search}"
USER_CTX="${USER_CTX:-nobody}"

SPL="$(cat)"                              # SPL on stdin
case "$SPL" in
  \|*|search\ *) ;;                       # already valid
  *) SPL="search $SPL" ;;                 # auto-prefix
esac

curl -sS --fail-with-body \
  -H "Authorization: Bearer $SPLUNK_TOKEN" \
  "$SPLUNK_HOST/servicesNS/$USER_CTX/$APP/search/jobs/export" \
  --data-urlencode "search=$SPL" \
  -d earliest_time="$EARLIEST" \
  -d latest_time="$LATEST" \
  -d adhoc_search_level=fast \
  -d output_mode="$MODE"
```

Usage:

```bash
EARLIEST=-4h MODE=json ./splunkq <<'SPL'
index=app_prod sourcetype=spring:json
| stats count AS requests, count(eval(status>=500)) AS errors BY service
| eval error_rate=round(100.0*errors/requests,2)
| where requests>100
| sort 20 - error_rate
SPL
```

Feeding an agent: `MODE=csv` keeps token usage low and is trivially tabular. `MODE=json | jq -c '.result'` gives one compact object per line. **Always `| head N` and `| fields ...` before exporting** — an unbounded `index=app_prod earliest=-24h` export will happily stream gigabytes.

### 6.7 Other useful endpoints

```bash
# List saved searches
curl -s -k "${AUTH[@]}" "$SPLUNK_HOST/servicesNS/-/-/saved/searches" \
  --get -d output_mode=json -d count=0 | jq -r '.entry[].name'

# Run a saved search
curl -s -k "${AUTH[@]}" \
  "$SPLUNK_HOST/servicesNS/nobody/search/saved/searches/Prod%205xx%20rate/dispatch" \
  -d output_mode=json

# Fetch the last scheduled run's results without re-running (huge time saver)
curl -s -k "${AUTH[@]}" "$SPLUNK_HOST/services/search/jobs/export" \
  --data-urlencode 'search=| loadjob savedsearch="nobody:search:Prod 5xx rate"' \
  -d output_mode=csv

# Enumerate indexes and their time ranges
curl -s -k "${AUTH[@]}" "$SPLUNK_HOST/services/data/indexes" \
  --get -d output_mode=json -d count=0 \
  | jq -r '.entry[] | "\(.name)\t\(.content.totalEventCount)\t\(.content.minTime)\t\(.content.maxTime)"'

# Send test data via HEC (port 8088, different token)
curl -k "https://splunk.example.com:8088/services/collector/event" \
  -H "Authorization: Splunk $HEC_TOKEN" \
  -d '{"sourcetype":"spring:json","index":"app_dev","event":{"level":"ERROR","service":"checkout","trace_id":"abc123","message":"test"}}'
```

---

## 7. Gotchas

**Subsearch truncation is silent.** `maxout` = 10,000 for standard subsearches, `subsearch_maxout` = 50,000 for `join`, `maxtime` = 60s for all. Over the limit, Splunk *finalizes* the subsearch and continues with partial results — a warning in the UI, **nothing** via REST. Never build a subsearch whose result count you can't bound. Always add `| head N`.

**`join` is a trap.** Default `max=1` means each left row joins at most one right row — a one-to-many relationship silently drops matches. Docs: "A maximum of 50,000 rows in the right-side dataset can be joined... over a maximum runtime of 60 seconds." Use `stats ... BY <key>` instead. If you must join, set `max=0` and verify counts before and after.

**Case sensitivity is inconsistent, and you will get burned:**

| Thing | Case-sensitive? |
|---|---|
| Search terms and field *values* | **No** — `error` matches `ERROR` |
| Field *names* | **Yes** — `Status` ≠ `status` |
| Command names | No — `STATS` works |
| Boolean operators (`AND`, `OR`, `NOT`) | **Yes** — must be uppercase; lowercase `and` is a literal search term |
| `where`/`eval` string comparison with `=` / `!=` | **Yes** — `where status="Error"` won't match `"error"` |
| `where like()` | Yes |
| `IN()` in `search` | No; in `where` — yes |
| Regex in `rex`/`match()` | Yes (use `(?i)`) |
| Lookup matching | Configurable (`case_sensitive_match` in `transforms.conf`, default true) |

Normalize defensively: `| eval status_lc = lower(status)`.

**Leading wildcards defeat the term index.** `*Exception` or `*checkout*` cannot use the tsidx dictionary — Splunk falls back to scanning and matching every raw event in the time range. Trailing wildcards (`Null*`) are fine. Rewrite `*Exception` as `TERM(*Exception)`… which still doesn't help — instead, narrow the time range and use a positive term you *do* know, then filter with `where match(...)`.

**`NOT` vs `!=`:**

```spl
index=app_prod NOT status=200      -- includes events where `status` does not exist
index=app_prod status!=200         -- requires `status` to exist AND not equal 200
```

Same divergence in `where`: `where NOT status=200` vs `where status!=200` (the latter is false when `status` is null, since `null != 200` is null, not true).

**Index-time vs search-time fields.** Index-time fields are usable by `tstats`, cost nothing at search time, but only apply to data indexed *after* the config change — they are not retroactive. Search-time fields are retroactive and free to change but cost CPU on every search and are invisible to `tstats`. Also: `<field>::<value>` syntax explicitly targets an indexed field; `<field>=<value>` will match either. Use `::` when you know it's indexed and want to guarantee the fast path.

**`_time` vs index time.** Events with bad timestamp parsing land in the wrong `_time` bucket and your search window misses them. Cross-check with `_index_earliest`, or `| eval lag = _indextime - _time | stats max(lag) avg(lag) BY sourcetype`.

**Approximate percentiles are nondeterministic.** `perc`/`upperperc` above 1000 distinct values use a digest with <1% rank error and *can return different values on reruns of identical data*. Don't put them in a contract-grade SLO report without `exactperc`. Don't file a bug when a dashboard number wobbles by 3ms.

**`mvexpand` truncates at `max_mem_usage_mb` (default 500MB) with a warning, not an error.** Always set `limit=`.

**`sort` truncates at 10,000 by default.** `| sort 0 <field>` for unlimited. Same for `sort` inside `dedup ... sortby`.

**`transaction` evicts silently.** `maxevents` defaults to 1000; `maxopentxn`/`maxopenevents` from `limits.conf` bound memory. Exceeding them drops transactions. Use `keepevicted=t` and check `closed_txn=0` if you must use it.

**`stats` and `dedup` are memory-bound on cardinality.** `stats count BY trace_id` over 50M unique trace IDs will hit `max_mem_usage_mb` and spill or truncate. Bound it: filter first, or aggregate at a coarser key.

**`spath` auto-extract stops at 5,000 characters** (`extraction_cutoff` in `limits.conf`). Deep fields in a fat JSON log will silently be missing. Use `spath path=...` explicitly, or `json_extract()`.

**`list()` caps at 100 values**, silently. `values()` dedups and sorts (so it loses order). Neither is a safe "give me everything."

**Dotted field names need single quotes in `eval`/`where`** (`'k8s.pod.name'`), because `.` is the string concatenation operator. Unquoted, you get a confusing concatenation of three nonexistent fields rather than an error.

**`timechart` defaults to `limit=10` series** plus an `OTHER` bucket. If a service is missing from your chart, that's why. Set `limit=0 useother=f`.

**Splunk Cloud REST access** is off by default and requires a support ticket; free trial accounts can't use it at all. Also, Splunk Cloud can't edit `limits.conf` directly — use the ACS API or a support ticket.

**`aws:cloudwatchlogs:*` pull-based inputs are explicitly discouraged** by the Splunk AWS add-on docs due to CloudWatch API rate limits. Use Kinesis Data Firehose push. If your CloudWatch data has gaps, this is the first thing to check.

**Verify field extraction before trusting a playbook.** One command tells you what actually exists:

```spl
index=aws sourcetype=aws:elb:accesslogs earliest=-15m
| head 1000
| fieldsummary maxvals=5
| table field count distinct_count values
```

---

## 8. Sources

**Search performance and optimization**
- [Write better searches — Splunk Enterprise 9.4](https://help.splunk.com/en/splunk-enterprise/search/search-manual/9.4/optimizing-searches/write-better-searches)
- [Optimizing search — Splunk Lantern](https://lantern.splunk.com/Platform_Data_Management/Transform_Data/Optimizing_search)
- [Super Optimize your Splunk Stats Searches: tstats, TERM, and PREFIX — Splunk Community Blog](https://community.splunk.com/t5/Community-Blog/Super-Optimize-your-Splunk-Stats-Searches-Unlocking-the-Power-of/ba-p/753778)
- [Use CASE() and TERM() to match phrases](https://help.splunk.com/en/splunk-enterprise/search/search-manual/9.2/search-primer/use-case-and-term-to-match-phrases)

**Command references (Splunk 9.4 SPL Search Reference)**
- [tstats](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/tstats)
- [streamstats](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/streamstats)
- [eventstats](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/eventstats)
- [transaction](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/transaction)
- [join](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/join)
- [cluster](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/cluster)
- [bin](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/bin)
- [rex](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/rex)
- [spath](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/spath)
- [mvexpand](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/mvexpand)
- [foreach](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/foreach)
- [makeresults](https://help.splunk.com/en/splunk-enterprise/spl-search-reference/9.4/search-commands/makeresults)
- [Aggregate functions (percentiles: perc / exactperc / upperperc)](https://docs.splunk.com/Documentation/Splunk/9.3.2/SearchReference/Aggregatefunctions)

**Subsearches and limits**
- [About subsearches — Splunk Enterprise 9.3](https://help.splunk.com/en/splunk-enterprise/search/search-manual/9.3/subsearches/about-subsearches)
- [Subsearch produced 50000 results, truncating to maxout — Splunk KB](https://splunk.my.site.com/customer/s/article/subsearch-Subsearch-produced-50000-results-truncating-to-maxout-maxResultRows-50000)

**Time modifiers, macros, saved searches**
- [Specify time modifiers in your search — Splunk Enterprise 9.4](https://help.splunk.com/en/splunk-enterprise/search/search-manual/9.4/specify-time-ranges/specify-time-modifiers-in-your-search)
- [Define search macros in Settings — Splunk Enterprise 9.4](https://help.splunk.com/en/splunk-enterprise/manage-knowledge-objects/knowledge-management-manual/9.4/search-macros/define-search-macros-in-settings)

**REST API**
- [Export data using the Splunk REST API](https://help.splunk.com/en/splunk-enterprise/search/search-manual/10.4/export-search-results/export-data-using-the-splunk-rest-api)
- [Creating searches using the REST API](https://docs.splunk.com/Documentation/SplunkCloud/latest/RESTTUT/RESTsearches)

**AWS**
- [Source types — Splunk Add-on for Amazon Web Services](https://splunk.github.io/splunk-add-on-for-amazon-web-services/DataTypes/)
- [CloudWatch Logs input — Splunk Add-on for AWS](https://splunk.github.io/splunk-add-on-for-amazon-web-services/CloudWatchLogs/)
- [ALB Access Log entry fields — AWS documentation](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/load-balancer-access-logs.html)
- [Why are ALB Access logs not getting indexed or parsed correctly? — Splunk Community (ALB props.conf EXTRACT)](https://community.splunk.com/t5/All-Apps-and-Add-ons/Splunk-Add-on-for-Amazon-Web-Services-Why-are-ALB-Access-logs/m-p/231895)
- [ALB logs show target_status_code=502 and elb_status_code=202 — AWS re:Post](https://repost.aws/questions/QUuf0HVbizQv2LxaSz4YTZcQ/alb-logs-show-target-status-code-502-and-elb-status-code-202)

**Kubernetes / EKS**
- [Splunk Connect for Kubernetes — OpenTelemetry (sourcetypes and k8s.* metadata fields)](https://splunk.github.io/sck-otel/)
- [Splunk OpenTelemetry Collector for Kubernetes — Splunk Validated Architectures](https://help.splunk.com/en/splunk-enterprise/splunk-validated-architectures/getting-data-in-forwarding-and-preprocessing/splunk-opentelemetry-collector-for-kubernetes)
- [(Optional) Set up Amazon EKS control plane logging — AWS](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/Container-Insights-setup-control-plane-logging.html)

---

**Verification notes.** Three things I'd flag as environment-dependent rather than doc-certain: (1) ALB field extraction under `aws:elb:accesslogs` is keyed on the `source` pattern rather than sourcetype in the shipped add-on, and older add-on versions parse ALB lines incorrectly — run the `fieldsummary` check in §7 before trusting §4.7. (2) Kubernetes metadata field names depend entirely on your collector (sck-otel `k8s.pod.name` vs. the older Splunk Connect for Kubernetes `kubernetes.pod_name` vs. Fluent Bit conventions) — §4.6 uses sck-otel names. (3) `makeresults format=`/`data=` args require Splunk 9.3+; the rest of the SPL is valid across 9.x.agentId: a98ad00a9d1be61ac (use SendMessage with to: 'a98ad00a9d1be61ac', summary: '<5-10 word recap>' to continue this agent)
<usage>subagent_tokens: 99601
tool_uses: 54
