# staff-dev-env

A deliberately small terminal setup for a Staff/Lead Frontend Engineer on a
corporate-managed Mac with no Homebrew.

Built around what you actually do all day: **git log · ripgrep · zsh aliases and
themes · vim motions · tmux · directory shortcuts.** Everything else is opt-in
and off by default.

**Three tools required:** `ripgrep`, `fzf`, `tmux`. That's it.

---

## Install

```bash
./install.sh --preflight     # 1. read-only audit. Writes nothing. Always first.
./install.sh --no-tools      # 2. config only — your portal supplies the binaries
exec zsh
sde-doctor                   # 3. what's present, what's missing, what's hidden
sde-help                     # every command this adds
```

`--no-tools` installs no package manager and downloads nothing. Every module
checks for its tools at load time, so a partial set is fine — no `delta` means
git uses the default pager, no `fd` means fzf lists files with ripgrep instead.

Every run snapshots your config first and prints the path to a `restore.sh` that
puts everything back byte-for-byte.

### What touches what

| File | Action |
|---|---|
| `~/.zshrc` | **append** one marked block at the end |
| `~/.gitconfig` | **append** one `include.path` line |
| `~/.ideavimrc`, `~/.config/tmux/tmux.conf`, `~/.config/git/ignore` | **replace** with a symlink (backed up twice first) |
| `~/.vimrc`, `~/.config/nvim`, VS Code `settings.json` | **never touched** |
| `/etc/*`, `/usr/bin`, anything company-managed | **never touched** |

### Uninstall

```bash
~/.config/staff-dev-env-backups/<timestamp>/restore.sh
```

---

## What's in the core (always on)

Eight files. That's the whole default surface.

```
zsh/00-path.zsh        PATH, EDITOR, pagers
zsh/10-history.zsh     ★ 200k shared history — biggest win per line of config
zsh/20-completion.zsh  native zsh completion, cached (no oh-my-zsh)
zsh/30-vi-mode.zsh     vim motions in the shell + text objects
zsh/40-tools.zsh       fzf / bat / zoxide wiring, all optional-safe
zsh/50-nav.zsh         ★ directory shortcuts + search (j, f, s)
zsh/60-git.zsh         ★ fuzzy git: glf, gco, gfix, gwt, greflog
zsh/90-prompt.zsh      three themes, no forks in the hot path
```

## What's opt-in (off until you ask)

```bash
export SDE_ENABLE="aws"            # in ~/.zshrc, above the staff-dev-env block
```

| Module | Contains |
|---|---|
| `aws` | ECS: `ecs` `ecsps` `ecslog` `ecsdeploy` `ecsx`, profile switching, CloudWatch tail, secrets |
| `terraform` | saved-plan discipline (`tfp`/`tfa`), `tfs`, `tfd` |
| `splunk` | `spl`, saved query library, `splunkq` CLI |
| `frontend` | pnpm workspace + single-spa helpers |

There is **no Kubernetes module** — removed, not disabled, since you're moving
to ECS. Say the word if that changes.

---

## The four commands to remember

```bash
sde-help            # every command, with descriptions
sde-doctor          # tool inventory + shadowing warnings
sde-theme compact   # switch prompt theme
jl                  # your directory shortcuts
```

## Directory shortcuts

One file, `~/.config/staff-dev-env/dirs.conf`:

```
work  = ~/work
repos = ~/work/repos/*
```

gives you all four of these:

```bash
j work           # explicit jump, tab-completes
cd ~work         # zsh named directory (and the prompt prints ~work)
j                # fzf picker
cd orders-mfe    # from anywhere — /* puts the parent on CDPATH
```

`jl` list · `ja <name>` register current dir · `je` edit · `jr` reload.

---

## Docs

**→ [docs/00-GUIDE.md](docs/00-GUIDE.md)** — start here: what to learn, in what
order, over four weeks.

| | |
|---|---|
| [01-GIT-MASTERY.md](docs/01-GIT-MASTERY.md) | object model, `git log` as a query language, rebase without fear, worktrees, bisect |
| [03-VIM-MOTIONS.md](docs/03-VIM-MOTIONS.md) | motions in IntelliJ + VS Code + zsh, without a third editor |
| [04-TMUX.md](docs/04-TMUX.md) | six bindings, the sessionizer, nothing else |
| [06-TOOL-REQUEST-LIST.md](docs/06-TOOL-REQUEST-LIST.md) | what to ask your portal for |
| [05-AI-AGENTS.md](docs/05-AI-AGENTS.md) | Copilot instructions, agents, safe terminal access *(reference)* |
| [02-SPLUNK-SPL.md](docs/02-SPLUNK-SPL.md) | SPL field guide *(only if you enable the splunk module)* |
