# 50 :: navigation, directory shortcuts, and search
#
# This module covers two of your three most-used things: jumping to a directory,
# and searching. (Git is module 60.)
#
# THE DIRECTORY SHORTCUT PROBLEM
# You want `cd <something short>` to land in a folder you use constantly. There
# are four ways to do that in zsh and they stack — you get all four here:
#
#   1. NAMED DIRECTORIES   `cd ~work` — and, crucially, zsh *displays* the path
#                          as `~work` in your prompt. Native, zero dependencies.
#   2. CDPATH              `cd orders-mfe` from anywhere, if its parent is
#                          registered. Native. Almost nobody knows about it.
#   3. `j <name>`          explicit jump with tab-completion.
#   4. `j` with no args    fzf picker over everything registered.
#
# All four read ONE file: ~/.config/staff-dev-env/dirs.conf
# Register a directory once and every mechanism knows about it.

# ===========================================================================
#  DIRECTORY REGISTRY
# ===========================================================================
: ${SDE_DIRS_FILE:="$STAFF_DEV_ENV_HOME/dirs.conf"}

# Create the file with a worked example the first time.
if [[ ! -f "$SDE_DIRS_FILE" ]]; then
  mkdir -p "${SDE_DIRS_FILE:h}"
  cat > "$SDE_DIRS_FILE" <<'EOF'
# staff-dev-env :: directory shortcuts
#
#   <name> = <path>          ~ is expanded. Lines starting with # are ignored.
#
# Each entry gives you all of these at once:
#   cd ~<name>               zsh named directory (and the prompt shows ~<name>)
#   j <name>                 explicit jump, with tab completion
#   j                        fzf picker over every entry
#
# A trailing /* means "register the CHILDREN of this directory", which is what
# you want for a folder full of repos — it adds them to CDPATH so you can type
# `cd <repo-name>` from anywhere.
#
# Examples — edit these:
# work    = ~/work
# repos   = ~/work/repos/*
# dl      = ~/Downloads
# conf    = ~/.config/staff-dev-env
EOF
fi

typeset -gA SDE_DIRS

_sde_load_dirs() {
  SDE_DIRS=()
  cdpath=()
  [[ -r "$SDE_DIRS_FILE" ]] || return
  local line name path
  while IFS= read -r line; do
    # NOTE the backslash: module 10 turns on EXTENDED_GLOB, which makes bare `#`
    # a glob operator. `${line%%#*}` is then a *syntax error* ("bad pattern")
    # that aborts this whole file. Escaping it is not optional here.
    line="${line%%\#*}"                      # strip comments
    [[ "$line" != *=* ]] && continue
    name="${line%%=*}"; path="${line#*=}"
    name="${name//[[:space:]]/}"
    # trim surrounding whitespace without globbing (paths may contain spaces)
    path="${path#"${path%%[![:space:]]*}"}"
    path="${path%"${path##*[![:space:]]}"}"
    [[ -z "$name" || -z "$path" ]] && continue

    if [[ "$path" == */\* ]]; then
      # `repos = ~/work/repos/*` — put the PARENT on CDPATH so that
      # `cd any-child` works from anywhere. This is the cheapest possible
      # "fuzzy cd" and it costs zero external tools.
      path="${path%/\*}"
      path="${path/#\~/$HOME}"
      [[ -d "$path" ]] && cdpath+=("$path")
      SDE_DIRS[$name]="$path"
      hash -d "$name"="$path" 2>/dev/null
    else
      path="${path/#\~/$HOME}"
      [[ -d "$path" ]] || continue
      SDE_DIRS[$name]="$path"
      # named directory: enables `cd ~name` AND makes the prompt print ~name
      hash -d "$name"="$path" 2>/dev/null
    fi
  done < "$SDE_DIRS_FILE"
  typeset -gU cdpath
}
_sde_load_dirs

#@ j	jump to a registered directory: `j work`, or bare `j` for a picker
j() {
  local target
  if [[ -n "$1" ]]; then
    target="${SDE_DIRS[$1]}"
    if [[ -z "$target" ]]; then
      # not registered — fall back to a fuzzy match on the names
      local match
      match=$(print -l ${(k)SDE_DIRS} | grep -i -- "$1" | head -1)
      target="${SDE_DIRS[$match]}"
    fi
    [[ -z "$target" ]] && { echo "j: no shortcut matching '$1'. see: jl"; return 1 }
  else
    local pick
    pick=$(
      for k in ${(ko)SDE_DIRS}; do printf '%-14s %s\n' "$k" "${SDE_DIRS[$k]/#$HOME/~}"; done \
      | fzf --header 'jump to' --preview 'ls -la $(echo {} | awk "{print \$2}" | sed "s|^~|$HOME|") 2>/dev/null'
    ) || return
    target="${SDE_DIRS[${pick%% *}]}"
  fi
  cd "$target"
}

#@ jl	list your directory shortcuts
jl() {
  print -P "%B  shortcuts%b  (edit: $SDE_DIRS_FILE)"
  for k in ${(ko)SDE_DIRS}; do
    printf '  %-14s %s\n' "$k" "${SDE_DIRS[$k]/#$HOME/~}"
  done
  print -P "\n  use: %Bj <name>%b   or   %Bcd ~<name>%b   or bare %Bj%b for a picker"
  [[ ${#cdpath} -gt 0 ]] && print "  CDPATH: ${(j:, :)${cdpath/#$HOME/~}}  (cd <child-name> works from anywhere)"
}

#@ ja	register the CURRENT directory as a shortcut: ja work
ja() {
  local name="${1:-${PWD:t}}"
  name="${name//[^a-zA-Z0-9_-]/}"
  if [[ -n "${SDE_DIRS[$name]}" ]]; then
    echo "'$name' already points at ${SDE_DIRS[$name]}"; return 1
  fi
  printf '%-8s = %s\n' "$name" "${PWD/#$HOME/~}" >> "$SDE_DIRS_FILE"
  _sde_load_dirs
  echo "added: $name -> ${PWD/#$HOME/~}   (use: j $name)"
}

#@ jr	reload dirs.conf after editing it by hand
jr() { _sde_load_dirs && jl; }

#@ je	open dirs.conf in your editor, then reload
je() { ${EDITOR:-vim} "$SDE_DIRS_FILE" && _sde_load_dirs && echo "reloaded"; }

# tab-completion for j
_sde_j_complete() { compadd -- ${(k)SDE_DIRS} }
compdef _sde_j_complete j 2>/dev/null

# ===========================================================================
#  PLAIN NAVIGATION
# ===========================================================================
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'
#@ -	cd back to the previous directory
alias -- -='cd -'
#@ d	recent directories; then `1`..`9` to jump to one
alias d='dirs -v | head -10'
for i in {1..9}; do alias "$i"="cd +$i"; done

#@ mkcd	mkdir then cd into it
mkcd() { mkdir -p "$1" && cd "$1"; }

# ===========================================================================
#  SAFETY + SMALL THINGS
# ===========================================================================
alias cp='cp -i'
alias mv='mv -i'
alias rm='rm -i'            # `\rm` bypasses when you mean it
alias mkdir='mkdir -p'
alias reload='exec zsh'
alias path='print -l $path'

#@ ports	what is listening locally (the dev-server port hunt)
alias ports='lsof -nP -iTCP -sTCP:LISTEN | sort -k9'

#@ killport	kill whatever owns a local port: killport 4200
killport() {
  local p="${1:?usage: killport <port>}" pids
  pids=$(lsof -ti tcp:"$p") || { echo "nothing listening on $p"; return 1 }
  echo "$pids" | xargs ps -o pid=,comm= -p
  echo "$pids" | xargs kill -9 && echo "killed"
}

# ===========================================================================
#  SEARCH  — your other core use case.
#  The pattern is always: producer (rg/fd) -> fzf (choose) -> consumer (editor).
# ===========================================================================

#@ f	fuzzy-find a file with preview, open it in $EDITOR
f() {
  local file
  file=$(eval "${FZF_DEFAULT_COMMAND:-fd --type f --hidden --exclude .git}" \
         | fzf --preview 'bat --color=always --style=numbers --line-range :400 {} 2>/dev/null || head -400 {}') || return
  [[ -n "$file" ]] && ${EDITOR:-vim} "$file"
}

#@ s	live ripgrep: type a query, see results as you type, Enter opens at the line
s() {
  local initial="${*:-}" rg_cmd out file line
  rg_cmd="rg --column --line-number --no-heading --color=always --smart-case"
  out=$(
    FZF_DEFAULT_COMMAND="$rg_cmd $(printf '%q' "$initial") || true" \
    fzf --ansi --disabled --query "$initial" \
        --bind "change:reload:$rg_cmd {q} || true" \
        --delimiter : \
        --preview 'bat --color=always --style=numbers --highlight-line {2} {1} 2>/dev/null || sed -n "{2}p" {1}' \
        --preview-window 'up,60%,border-bottom,+{2}+3/3,~3' \
        --header 'live grep — Enter opens at the line'
  ) || return
  file=${out%%:*}; line=$(echo "$out" | cut -d: -f2)
  [[ -n "$file" ]] || return
  case "$EDITOR" in
    code*)    code -g "$file:$line" ;;
    vim|nvim) $EDITOR "+$line" "$file" ;;
    *)        ${EDITOR:-vim} "$file" ;;
  esac
}
#@ rgf	alias of `s` (muscle memory)
alias rgf='s'

#@ sl	ripgrep, filenames only, multi-select with fzf
sl() { rg --files-with-matches --smart-case "$@" | fzf -m --preview 'bat --color=always {} 2>/dev/null || cat {}'; }

#@ sr	search & replace across the repo, with a confirmation step
sr() {
  local from="${1:?usage: sr <search> <replace> [rg args...]}" to="${2?}"
  shift 2
  echo "--- files that would change ---"
  rg -l --smart-case "$from" "$@" || { echo "no matches"; return 1 }
  echo
  read -q "REPLY?rewrite these files? [y/N] " || { echo; return 1 }
  echo
  rg -l --smart-case "$from" "$@" | xargs sed -i '' "s|${from}|${to}|g"
  echo "done — review with: git diff"
}

#@ todo	every TODO/FIXME/HACK in the repo
todo() { rg -n --smart-case '(TODO|FIXME|HACK|XXX)' "$@"; }
