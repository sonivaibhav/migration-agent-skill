# 60 :: git
#
# The aliases live in git/gitconfig.include (so they work from any tool, including
# IntelliJ's terminal and CI). This file holds the things that need a *shell*:
# fzf pickers, worktree management, and multi-step workflows.

alias g='git'
alias lg='lazygit'

# ===========================================================================
#  BRANCHES
# ===========================================================================

#@ gco	fuzzy checkout: local branches first, sorted by recency, with a log preview
gco() {
  local branch
  branch=$(
    git for-each-ref --sort=-committerdate refs/heads/ \
      --format='%(refname:short)%09%(committerdate:relative)%09%(authorname)' \
    | column -t -s $'\t' \
    | fzf --preview 'git log --oneline --graph --color=always -20 {1}' \
          --preview-window 'right,60%' --header 'local branches (recent first)'
  ) || return
  git checkout "${branch%% *}"
}

#@ gcor	fuzzy checkout a REMOTE branch (creates a local tracking branch)
gcor() {
  local branch
  branch=$(
    git for-each-ref --sort=-committerdate refs/remotes/ \
      --format='%(refname:short)%09%(committerdate:relative)' \
    | grep -v 'HEAD' | column -t -s $'\t' \
    | fzf --preview 'git log --oneline --graph --color=always -20 {1}' --header 'remote branches'
  ) || return
  local full="${branch%% *}"
  git checkout --track "$full" 2>/dev/null || git checkout "${full#*/}"
}

#@ gbd	fuzzy multi-select branch delete (safe -d; asks before force)
gbd() {
  local branches
  branches=$(git branch | grep -v '^\*' | sed 's/^ *//' \
    | fzf -m --preview 'git log --oneline --color=always -10 {1}' --header 'TAB to multi-select, Enter to delete') || return
  echo "$branches" | xargs -n1 git branch -d 2>&1 | while read -r line; do
    echo "$line"
    if [[ "$line" == *"not fully merged"* ]]; then
      echo "  → unmerged. force with: git branch -D <name>   (recoverable via git reflog)"
    fi
  done
}

#@ gclean	delete every local branch whose remote is gone (post-squash-merge cleanup)
gclean() {
  git fetch --prune
  local gone
  gone=$(git for-each-ref --format='%(refname:short) %(upstream:track)' refs/heads/ \
         | awk '$2 == "[gone]" { print $1 }')
  [[ -z "$gone" ]] && { echo "nothing to clean"; return }
  echo "$gone"
  read -q "REPLY?delete these ${#${(f)gone}} branches? [y/N] " || { echo; return 1 }
  echo; echo "$gone" | xargs -n1 git branch -D
}

# ===========================================================================
#  HISTORY ARCHAEOLOGY  — `git log` is a query language, not a wall of text
# ===========================================================================

#@ glf	interactive log browser: fuzzy the subject, preview the full diff
glf() {
  git log --color=always --format='%C(auto)%h %C(blue)%ad%C(auto)%d %s %C(black)%C(bold)%an' --date=short "$@" \
  | fzf --ansi --no-sort --reverse --tiebreak=index \
        --preview 'grep -o "[a-f0-9]\{7,\}" <<< {} | head -1 | xargs -I% git show --color=always --stat --patch %' \
        --preview-window 'right,60%' \
        --bind 'enter:execute(grep -o "[a-f0-9]\{7,\}" <<< {} | head -1 | xargs -I% git show --color=always % | less -R)' \
        --bind 'ctrl-y:execute-silent(grep -o "[a-f0-9]\{7,\}" <<< {} | head -1 | tr -d "\n" | pbcopy)+abort' \
        --header 'Enter=show  Ctrl-Y=copy sha  Ctrl-/=toggle preview'
}

#@ gwho	who last touched each line of a file, fuzzy-navigable (blame, humanised)
gwho() {
  local file="${1:?usage: gwho <file>}"
  git blame --date=short -w -C "$file" | fzf --preview "echo {} | grep -o '^[a-f0-9]\{7,\}' | xargs -I% git show --color=always % | head -200"
}

#@ gpick	fuzzy cherry-pick a commit from another branch
gpick() {
  local br sha
  br=$(git branch -a --format='%(refname:short)' | fzf --header 'source branch') || return
  sha=$(git log --oneline --color=always -50 "$br" | fzf --ansi --header "commit from $br" | awk '{print $1}') || return
  [[ -n "$sha" ]] && git cherry-pick "$sha"
}

#@ gundo	undo the last commit but KEEP the changes staged (the safe undo)
gundo() { git reset --soft HEAD~1 && git status --short; }

#@ gfix	pick a commit, create a fixup for it, then autosquash — the review-feedback loop
gfix() {
  git diff --cached --quiet && { echo "nothing staged. stage your fix first (git add -p)"; return 1 }
  local sha
  sha=$(git log --oneline --color=always -30 | fzf --ansi --header 'fixup which commit?' | awk '{print $1}') || return
  [[ -z "$sha" ]] && return
  git commit --fixup="$sha" && \
  GIT_SEQUENCE_EDITOR=: git rebase --autosquash --autostash -i "$sha~1"
}

#@ greflog	fuzzy reflog — your undo history for EVERYTHING, including "lost" commits
greflog() {
  git reflog --color=always --date=relative -100 \
  | fzf --ansi --no-sort --preview 'echo {1} | xargs -I% git show --color=always --stat %' \
        --header 'reflog: nothing in git is really gone for ~90 days' \
  | awk '{print $1}' | tr -d '\n' | pbcopy 2>/dev/null
  echo "sha copied to clipboard — recover with: git checkout -b rescue <sha>"
}

# ===========================================================================
#  WORKTREES  — the single biggest workflow win for a microfrontend monorepo.
#  A worktree is a second checkout sharing ONE .git dir. Meaning: no stashing,
#  no re-running `pnpm install` from scratch, and you can run the Angular host
#  from main while fixing a React MFE on a branch, simultaneously.
# ===========================================================================

# Worktrees live as siblings: ~/code/myrepo and ~/code/myrepo.wt/<branch>
_sde_wt_root() {
  local root; root=$(git rev-parse --show-toplevel 2>/dev/null) || return 1
  # if we're already inside a worktree, resolve back to the main checkout
  local common; common=$(git rev-parse --git-common-dir)
  echo "${common:h}"
}

#@ gwt	create (or reuse) a worktree for a branch and cd into it
gwt() {
  local branch="${1:?usage: gwt <branch-name>  (created from origin/HEAD if new)}"
  local main; main=$(_sde_wt_root) || { echo "not in a git repo"; return 1 }
  local dir="${main}.wt/${branch//\//-}"

  if [[ -d "$dir" ]]; then
    cd "$dir" && echo "→ existing worktree $dir"; return
  fi
  mkdir -p "${main}.wt"
  if git show-ref --verify --quiet "refs/heads/$branch"; then
    git worktree add "$dir" "$branch"
  else
    git worktree add -b "$branch" "$dir" "$(git base)"
  fi
  cd "$dir"
  cat <<EOF

  worktree ready: $dir
  it shares .git with the main checkout, so fetches/branches are instantly visible.
  node_modules is NOT shared — run \`pnpm install\` here once (pnpm's content-
  addressable store makes this fast; it hardlinks from ~/Library/pnpm/store).
EOF
}

#@ gwts	fuzzy-switch between worktrees
gwts() {
  local sel
  sel=$(git worktree list | fzf --header 'worktrees') || return
  cd "$(echo "$sel" | awk '{print $1}')"
}

#@ gwtrm	fuzzy-remove a worktree (and prune the admin files)
gwtrm() {
  local sel
  sel=$(git worktree list | grep -v '\[.*\]$' --color=never | fzf --header 'remove which worktree?') || return
  local dir; dir=$(echo "$sel" | awk '{print $1}')
  [[ "$dir" == "$(_sde_wt_root)" ]] && { echo "refusing to remove the main checkout"; return 1 }
  git worktree remove "$dir" && git worktree prune && echo "removed $dir"
}

# ===========================================================================
#  CONFLICT RESOLUTION
# ===========================================================================

#@ gconf	list conflicted files and open them one at a time
gconf() {
  local files; files=$(git diff --name-only --diff-filter=U)
  [[ -z "$files" ]] && { echo "no conflicts"; return }
  echo "$files" | fzf -m --preview 'git diff --color=always -- {}' --header 'conflicted files' \
    | while read -r f; do ${EDITOR:-vim} "$f"; done
}

#@ gours / gtheirs	resolve a conflicted file entirely one way (fuzzy-picked)
gours()   { git diff --name-only --diff-filter=U | fzf -m | xargs -r git checkout --ours   && git add -u; }
gtheirs() { git diff --name-only --diff-filter=U | fzf -m | xargs -r git checkout --theirs && git add -u; }

# ===========================================================================
#  PR / REVIEW  (needs `gh`)
# ===========================================================================

#@ gpr	fuzzy-pick an open PR and check it out locally
gpr() {
  command -v gh >/dev/null || { echo "needs the gh CLI"; return 1 }
  local n
  n=$(gh pr list --limit 60 --json number,title,author,headRefName \
      --template '{{range .}}{{printf "%v\t%s\t%s\t%s\n" .number .title .author.login .headRefName}}{{end}}' \
      | column -t -s $'\t' | fzf --preview 'gh pr view {1}' --preview-window 'right,55%' | awk '{print $1}') || return
  [[ -n "$n" ]] && gh pr checkout "$n"
}

#@ gdm	diff your branch against the merge-base with main — what review will actually see
gdm() { git dm "$@"; }

#@ gsm	files changed vs main, with churn — the "what did I actually touch" view
gsm() { git dm --stat "$@"; }
