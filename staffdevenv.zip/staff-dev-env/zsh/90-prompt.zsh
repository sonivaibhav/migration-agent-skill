# 90 :: prompt / theme
#
# Pick one:
#     export SDE_THEME=minimal    two lines, quiet, default
#     export SDE_THEME=compact    one line — best inside tmux splits
#     export SDE_THEME=verbose    adds AWS profile + command duration
#     export SDE_THEME=off        keep whatever prompt you already have
# Put it BEFORE the staff-dev-env block in ~/.zshrc, then `exec zsh`.
# Or just try one now:  SDE_THEME=compact exec zsh
#
# WHY NOT POWERLEVEL10K / STARSHIP / OH-MY-ZSH THEMES
# They are good, and if you already run one, set SDE_THEME=off and keep it.
# The reason this file exists is cost: a prompt runs on every single Enter, and
# the common failure is a theme that shells out to `git status` each time. In a
# large repo that walks the whole worktree and adds 200-400ms to every prompt —
# which reads as "my machine is slow" and is really "my prompt is slow".
# Everything below is a file read or a shell builtin. No forks in the hot path.

: ${SDE_THEME:=minimal}
[[ "$SDE_THEME" == "off" ]] && return

setopt PROMPT_SUBST
autoload -Uz add-zsh-hook
zmodload zsh/datetime

# ===========================================================================
#  SEGMENTS
# ===========================================================================

# --- git: branch + state, WITHOUT running `git status` --------------------
# `git symbolic-ref` is one small file read. The in-progress markers below are
# plain file-existence checks. Together they cost well under a millisecond, and
# they tell you the thing that actually matters: am I mid-rebase right now?
_sde_git() {
  local gd ref extra=""
  gd=$(command git rev-parse --git-dir 2>/dev/null) || return
  ref=$(command git symbolic-ref --quiet --short HEAD 2>/dev/null) \
    || ref=$(command git rev-parse --short HEAD 2>/dev/null) \
    || return

  [[ -d "$gd/rebase-merge" || -d "$gd/rebase-apply" ]] && extra=" %F{red}REBASE%f"
  [[ -f "$gd/MERGE_HEAD" ]]        && extra=" %F{red}MERGE%f"
  [[ -f "$gd/CHERRY_PICK_HEAD" ]]  && extra=" %F{red}CHERRY-PICK%f"
  [[ -f "$gd/BISECT_LOG" ]]        && extra=" %F{yellow}BISECT%f"
  [[ "$gd" == */worktrees/* ]]     && extra="$extra %F{magenta}⑂wt%f"

  print -n " %F{green}${ref}%f${extra}"
}

# --- aws profile (only rendered by the verbose theme) ----------------------
_sde_aws() {
  [[ -z "$AWS_PROFILE" ]] && return
  local colour=blue
  [[ "$AWS_PROFILE" == *(prod|prd|production)* ]] && colour=red
  print -n " %F{$colour}☁${AWS_PROFILE}%f"
}

# --- how long the last command took ---------------------------------------
typeset -g _SDE_T0 _SDE_DUR
_sde_timer_start() { _SDE_T0=$EPOCHREALTIME }
_sde_timer_stop() {
  _SDE_DUR=""
  [[ -z "$_SDE_T0" ]] && return
  local d=$(( EPOCHREALTIME - _SDE_T0 )); _SDE_T0=""
  (( d < 3 )) && return
  if (( d > 60 )); then _SDE_DUR=$(printf ' %%F{yellow}%dm%02ds%%f' $((d/60)) $((d%60)))
  else                  _SDE_DUR=$(printf ' %%F{yellow}%.1fs%%f' $d); fi
}
add-zsh-hook preexec _sde_timer_start
add-zsh-hook precmd  _sde_timer_stop

# ===========================================================================
#  THEMES
#  %~ prints your directory — and because module 50 registers named
#  directories, a registered folder shows as `~work` instead of a long path.
#  That is the cheapest readability win available in a prompt.
# ===========================================================================
case "$SDE_THEME" in
  compact)
    # One line. Use this inside tmux, where vertical space is the scarce thing.
    PROMPT='%F{240}%1~%f$(_sde_git) %(?.%F{blue}.%F{red})❯%f '
    ;;
  verbose)
    PROMPT='
%F{240}%~%f$(_sde_git)$(_sde_aws)${_SDE_DUR}
%(?.%F{blue}.%F{red})❯%f '
    ;;
  minimal|*)
    # Two lines on purpose: context on top, a short clean line to type on.
    # When you paste a command into a ticket you don't drag the context with it.
    PROMPT='
%F{240}%~%f$(_sde_git)${_SDE_DUR}
%(?.%F{blue}.%F{red})❯%f '
    ;;
esac

# Right side: exit code when non-zero, and NORMAL when you're in vi normal mode.
# INSERT is deliberately not shown — the absence of the marker is the signal,
# and it keeps the line quiet in the state you're in 95% of the time.
RPROMPT='%(?..%F{red}✗%?%f )${${KEYMAP/vicmd/%F{yellow\}NORMAL%f}/(main|viins)/}'

# repaint the mode indicator the instant you press Esc
if (( ${+functions[zle-keymap-select]} )); then
  functions[zle-keymap-select]="${functions[zle-keymap-select]}
  zle reset-prompt"
fi

#@ sde-theme	preview and switch prompt theme: sde-theme compact
sde-theme() {
  if [[ -z "$1" ]]; then
    print "current: $SDE_THEME"
    print "themes:  minimal | compact | verbose | off"
    print "\ntry one now:   SDE_THEME=compact exec zsh"
    print "keep it:       add 'export SDE_THEME=compact' to ~/.zshrc"
    print "               ABOVE the staff-dev-env block"
    return
  fi
  export SDE_THEME="$1"
  source "$STAFF_DEV_ENV_HOME/zsh/90-prompt.zsh"
  print "theme -> $1  (add 'export SDE_THEME=$1' to ~/.zshrc to keep it)"
}
