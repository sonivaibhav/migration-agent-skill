# optional :: frontend monorepo  —  enable with: export SDE_ENABLE="frontend"
#
# The pain in a 40-package pnpm workspace is not running commands, it is
# *targeting* them. Almost everything here is "pick a package with fzf, then
# run the thing".

alias p='pnpm'
alias pi='pnpm install'
alias pif='pnpm install --frozen-lockfile'
alias pd='pnpm dev'
alias pb='pnpm build'
alias pt='pnpm test'

# --- workspace targeting ----------------------------------------------------
_sde_ws_names() {
  # pnpm's own list is authoritative and handles nested workspaces correctly
  pnpm -r list --depth -1 --json 2>/dev/null | jq -r '.[].name // empty' | grep -v '^$' | sort
}

#@ pw	fuzzy-pick a workspace package, then run a pnpm command in it: pw build
pw() {
  local pkg
  pkg=$(_sde_ws_names | fzf --header 'workspace package' \
        --preview 'pnpm -r list --depth -1 --json | jq -r ".[] | select(.name==\"{}\") | .path"') || return
  [[ -z "$pkg" ]] && return
  if [[ $# -eq 0 ]]; then
    # no command given: show the package's scripts and let you pick one
    local dir script
    dir=$(pnpm -r list --depth -1 --json | jq -r --arg n "$pkg" '.[] | select(.name==$n) | .path')
    script=$(jq -r '.scripts | keys[]' "$dir/package.json" | fzf --header "script in $pkg" \
             --preview "jq -r '.scripts[\"{}\"]' $(printf '%q' "$dir/package.json")") || return
    pnpm --filter "$pkg" run "$script"
  else
    pnpm --filter "$pkg" "$@"
  fi
}

#@ pcd	fuzzy-pick a workspace package and cd into its directory
pcd() {
  local pkg dir
  pkg=$(_sde_ws_names | fzf --header 'cd to package') || return
  dir=$(pnpm -r list --depth -1 --json | jq -r --arg n "$pkg" '.[] | select(.name==$n) | .path')
  [[ -d "$dir" ]] && cd "$dir"
}

#@ pr	pick and run a script from the package.json in the CURRENT directory
pr() {
  [[ -f package.json ]] || { echo "no package.json here (try pw)"; return 1 }
  local script
  script=$(jq -r '.scripts | keys[]' package.json \
    | fzf --header "scripts in $(jq -r .name package.json)" \
          --preview 'jq -r ".scripts[\"{}\"]" package.json') || return
  [[ -n "$script" ]] && pnpm run "$script"
}

#@ pwhy	why is this package installed / who depends on it
pwhy() { pnpm why "${1:?usage: pwhy <package>}" -r; }

#@ pdup	find duplicate versions of the same dep across the workspace (MFE bundle-bloat hunt)
pdup() {
  pnpm -r list --depth 0 --json 2>/dev/null \
  | jq -r '.[] | .name as $pkg | (.dependencies // {}) + (.devDependencies // {})
      | to_entries[] | [.key, (.value.version // .value)] | @tsv' \
  | sort -u | awk -F'\t' '{c[$1]=c[$1]" "$2} END {for (d in c) { n=split(c[d],a," "); if (n>1) print d ":" c[d] }}' \
  | sort
}

#@ nuke	remove node_modules everywhere below here, then reinstall
nuke() {
  echo "removing node_modules trees under $PWD…"
  fd -H -t d '^node_modules$' -E node_modules/\* -x rm -rf {} \; 2>/dev/null
  rm -rf .angular .nx/cache .turbo node_modules/.vite 2>/dev/null
  echo "reinstalling…"
  pnpm install
}

#@ cachebust	clear the caches that lie to you (vite, jest, angular, ts build info)
cachebust() {
  rm -rf node_modules/.vite node_modules/.cache .angular/cache .nx/cache .turbo 2>/dev/null
  fd -H -t f 'tsconfig.tsbuildinfo' -x rm -f {} \; 2>/dev/null
  pnpm exec jest --clearCache >/dev/null 2>&1
  echo "caches cleared"
}

# --- testing ----------------------------------------------------------------
#@ tw	run the test file matching a fuzzy-picked spec, in watch mode
tw() {
  local spec
  spec=$(fd -e spec.ts -e spec.tsx -e test.ts -e test.tsx -e spec.js \
        | fzf --preview 'bat --color=always {}') || return
  [[ -z "$spec" ]] && return
  if [[ -f vitest.config.ts || -f vite.config.ts ]]; then
    pnpm exec vitest --watch "$spec"
  else
    pnpm exec jest --watch "$spec"
  fi
}

#@ tcov	open the coverage report for the current package in a browser
tcov() {
  local f=coverage/lcov-report/index.html
  [[ -f $f ]] || f=$(fd -p 'coverage/.*index\.html$' | head -1)
  [[ -f "$f" ]] && open "$f" || echo "no coverage report — run your tests with --coverage first"
}

# --- single-spa / microfrontends -------------------------------------------
# The #1 debugging question in single-spa is "which build of which MFE is the
# browser actually loading?" These print the answer instead of guessing.

#@ mfemap	fetch and pretty-print the import map an environment is serving
mfemap() {
  local url="${1:?usage: mfemap <import-map-url or app url>}"
  curl -fsSL "$url" \
  | { grep -o '<script[^>]*type="systemjs-importmap"[^>]*>.*</script>' || cat; } \
  | sed -e 's/.*<script[^>]*>//' -e 's|</script>.*||' \
  | jq '.imports' 2>/dev/null || echo "no inline importmap found; try the /importmap.json endpoint directly"
}

#@ mfeoverride	print the browser snippet that pins one MFE to your localhost build
mfeoverride() {
  local name="${1:?usage: mfeoverride <@org/mfe-name> [port=8080]}" port="${2:-8080}"
  cat <<EOF
Paste in the browser console on the host app, then reload:

  localStorage.setItem('import-map-override:$name', 'http://localhost:$port/$(basename "$name").js');
  location.reload();

Remove it with:
  localStorage.removeItem('import-map-override:$name'); location.reload();

(import-map-overrides must be loaded by the host — it usually is in non-prod.)
EOF
}

#@ mfeports	which of your MFE dev servers are currently up
mfeports() {
  lsof -nP -iTCP -sTCP:LISTEN 2>/dev/null \
  | awk 'NR>1 {split($9,a,":"); print a[length(a)] "\t" $1 "\t" $2}' \
  | sort -un | { echo -e "PORT\tPROC\tPID"; cat; } | column -t -s $'\t'
}

# --- crossing the frontend/backend boundary --------------------------------
#@ apidiff	pretty-diff two JSON API responses (prod vs local, before vs after)
apidiff() {
  local a="${1:?usage: apidiff <url-or-file-a> <url-or-file-b>}" b="${2:?}"
  _get() { [[ -f "$1" ]] && cat "$1" || curl -fsSL "$1"; }
  diff <(_get "$a" | jq -S .) <(_get "$b" | jq -S .) | ${PAGER:-less}
  unfunction _get
}

#@ timed	time an HTTP request with a full latency breakdown (dns/tcp/tls/ttfb)
timed() {
  curl -o /dev/null -sS -w '
  dns      %{time_namelookup}s
  tcp      %{time_connect}s
  tls      %{time_appconnect}s
  ttfb     %{time_starttransfer}s
  total    %{time_total}s
  status   %{http_code}
  size     %{size_download} bytes
' "${1:?usage: timed <url>}"
}
