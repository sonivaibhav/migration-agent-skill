# optional :: Terraform  —  enable with: export SDE_ENABLE="terraform"
#
# The two things that actually save time: (1) never run `apply` against a plan
# you didn't save, and (2) read plans as *data* (jq over `terraform show -json`)
# instead of scrolling 4000 lines of coloured text.

alias tf='terraform'
alias tfi='terraform init'
alias tff='terraform fmt -recursive'
alias tfv='terraform validate'

#@ tfp	plan into a saved plan file (.tfplan) — the only plan worth applying
tfp() { terraform plan -out=.tfplan "$@"; }

#@ tfa	apply the SAVED plan. Refuses if there isn't one. No surprise re-plan.
tfa() {
  [[ -f .tfplan ]] || { echo "no .tfplan — run tfp first (never apply an unsaved plan)"; return 1 }
  echo "applying .tfplan created $(date -r .tfplan '+%H:%M:%S')"
  terraform apply .tfplan && rm -f .tfplan
}

#@ tfs	read the last plan as a table: action, type, address. Scan 200 changes in 5s.
tfs() {
  [[ -f .tfplan ]] || { echo "no .tfplan — run tfp first"; return 1 }
  terraform show -json .tfplan \
  | jq -r '.resource_changes[]
      | select(.change.actions != ["no-op"])
      | [(.change.actions | join("+")), .type, .address] | @tsv' \
  | sort | { echo -e "ACTION\tTYPE\tADDRESS"; cat; } | column -t -s $'\t'
}

#@ tfd	show ONLY the destroys and replaces from the last plan. Read this every time.
tfd() {
  [[ -f .tfplan ]] || { echo "no .tfplan"; return 1 }
  local out
  out=$(terraform show -json .tfplan \
    | jq -r '.resource_changes[]
        | select(.change.actions | inside(["delete","create"]) | not)
        | select(.change.actions[] | . == "delete")
        | .address')
  if [[ -z "$out" ]]; then
    print -P "%F{green}  no destroys or replacements%f"
  else
    print -P "%F{red}%B  DESTRUCTIVE CHANGES%b%f"; echo "$out"
  fi
}

#@ tfws	fuzzy-switch terraform workspace
tfws() {
  local ws
  ws=$(terraform workspace list | sed 's/^[* ]*//' | grep -v '^$' | fzf --header 'workspace') || return
  terraform workspace select "$ws"
}

#@ tfsl	fuzzy-browse the state: pick a resource, see its attributes
tfsl() {
  terraform state list \
  | fzf --preview 'terraform state show {}' --preview-window 'right,65%' \
        --bind 'ctrl-y:execute-silent(printf %s {} | pbcopy)+abort' \
        --header 'Enter=nothing  Ctrl-Y=copy address'
}

#@ tfimp	print the import command for a resource address you pick (you fill in the id)
tfimp() {
  local addr; addr=$(terraform state list | fzf --header 'address to model the import on') || return
  echo "terraform import '$addr' <REMOTE_ID>"
}

#@ tfgraph	which resources depend on the one you pick (dependency blast radius)
tfgraph() {
  local addr; addr=$(terraform state list | fzf) || return
  terraform graph | grep -F "$addr" | sed 's/^\s*//'
}

#@ tfclean	remove .terraform dirs and lock files below here (fixes 80% of init weirdness)
tfclean() {
  fd -H -t d '^\.terraform$' -x rm -rf {} \; 2>/dev/null
  fd -H -t f '^\.terraform\.lock\.hcl$' -x rm -f {} \; 2>/dev/null
  echo "cleaned. run tfi again."
}

# A note you will want in six months:
#   `terraform plan` exit codes with -detailed-exitcode: 0 = no changes,
#   1 = error, 2 = changes present. That is how you gate a CI job on drift:
#     terraform plan -detailed-exitcode -out=.tfplan || [ $? -eq 2 ]
#@ tfdrift	detect drift with a proper exit code (0 = clean, 2 = drifted)
tfdrift() { terraform plan -detailed-exitcode -out=.tfplan "$@"; }
