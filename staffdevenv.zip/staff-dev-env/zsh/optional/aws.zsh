# optional :: AWS (ECS)
#
#   enable with:  export SDE_ENABLE="aws"
#
# ECS-focused. There is no EKS/kubectl support here by design — if you move
# back to Kubernetes, say so and it comes back as its own optional module.
#
# The core problem with multi-account AWS work is not typing — it is *knowing
# which account you are in*. Every function below either shows you, or refuses
# to run until you've picked. The prompt module (90) puts it on screen always.
#
# Assumes AWS CLI v2 with SSO profiles in ~/.aws/config. If your company uses
# saml2aws / aws-vault / an internal wrapper, replace `_sde_aws_login` only —
# everything else keys off $AWS_PROFILE and will keep working.

#@ awsp	fuzzy-switch AWS profile (reads ~/.aws/config), verifies the session
awsp() {
  local profile
  if [[ -n "$1" ]]; then
    profile="$1"
  else
    profile=$(
      grep -E '^\[profile |^\[default\]' ~/.aws/config 2>/dev/null \
      | sed -E 's/^\[profile //; s/^\[//; s/\]$//' | sort -u \
      | fzf --header 'AWS profile' \
            --preview 'aws configure list --profile {} 2>/dev/null; echo; sed -n "/^\[profile {}\]/,/^\[/p" ~/.aws/config'
    ) || return
  fi
  [[ -z "$profile" ]] && return 1
  export AWS_PROFILE="$profile"
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN  # kill stale static creds
  local region
  region=$(aws configure get region --profile "$profile" 2>/dev/null)
  [[ -n "$region" ]] && export AWS_REGION="$region" AWS_DEFAULT_REGION="$region"
  awsauth
}

#@ awsr	switch region for the current shell only
awsr() {
  local r="${1:-$(printf '%s\n' us-east-1 us-east-2 us-west-2 eu-west-1 eu-central-1 ap-south-1 ap-southeast-2 | fzf --header region)}"
  [[ -z "$r" ]] && return 1
  export AWS_REGION="$r" AWS_DEFAULT_REGION="$r"
  echo "region → $r"
}

# internal: how this org logs in. Change ONLY this if you use saml2aws/aws-vault.
_sde_aws_login() { aws sso login --profile "${AWS_PROFILE:?set AWS_PROFILE first}"; }

#@ awsauth	ensure the current profile has a live session; log in if not
awsauth() {
  [[ -z "$AWS_PROFILE" ]] && { echo "no AWS_PROFILE set — run awsp"; return 1 }
  if aws sts get-caller-identity --output json >/dev/null 2>&1; then
    awswho
  else
    echo "session for '$AWS_PROFILE' is expired or missing — logging in…"
    _sde_aws_login && awswho
  fi
}

#@ awswho	who am I, in which account, with what role — run this before anything scary
awswho() {
  local id
  id=$(aws sts get-caller-identity --output json 2>/dev/null) || { echo "not authenticated"; return 1 }
  local acct arn
  acct=$(jq -r .Account <<<"$id"); arn=$(jq -r .Arn <<<"$id")
  local alias_name
  alias_name=$(aws iam list-account-aliases --query 'AccountAliases[0]' --output text 2>/dev/null)
  [[ "$alias_name" == "None" || -z "$alias_name" ]] && alias_name="(no alias)"
  printf '  profile  %s\n  account  %s  %s\n  region   %s\n  identity %s\n' \
    "$AWS_PROFILE" "$acct" "$alias_name" "${AWS_REGION:-?}" "${arn##*/}"
  # loud warning if this looks like production
  if [[ "$AWS_PROFILE" == *(prod|prd|production)* ]]; then
    print -P "%F{red}%B  ⚠  PRODUCTION PROFILE%b%f"
  fi
}

#@ awsexp	how many minutes until the current SSO session expires
awsexp() {
  local f newest exp
  newest=$(ls -t ~/.aws/sso/cache/*.json 2>/dev/null | head -1) || return 1
  exp=$(jq -r '.expiresAt // empty' "$newest")
  [[ -z "$exp" ]] && { echo "unknown"; return 1 }
  local secs=$(( $(date -jf '%Y-%m-%dT%H:%M:%SZ' "${exp%%.*}Z" +%s 2>/dev/null || echo 0) - $(date +%s) ))
  (( secs > 0 )) && echo "$(( secs / 60 )) min left" || echo "expired"
}

# ===========================================================================
#  SECRETS / CREDENTIALS  — never echo a password into your scrollback.
#  These copy to the clipboard instead. Your terminal history and any screen
#  share stay clean, and the value doesn't end up in a tmux buffer.
# ===========================================================================

#@ sec	fuzzy-pick a Secrets Manager secret; JSON goes to stdout, keys are listed
sec() {
  local name="${1:-$(aws secretsmanager list-secrets --query 'SecretList[].Name' --output text | tr '\t' '\n' | fzf --header 'secret')}"
  [[ -z "$name" ]] && return 1
  aws secretsmanager get-secret-value --secret-id "$name" --query SecretString --output text | jq .
}

#@ dbcreds	pull a DB secret, print host/port/user, copy ONLY the password to the clipboard
dbcreds() {
  local name="${1:-$(aws secretsmanager list-secrets --query 'SecretList[].Name' --output text | tr '\t' '\n' | fzf --header 'db secret')}"
  [[ -z "$name" ]] && return 1
  local json
  json=$(aws secretsmanager get-secret-value --secret-id "$name" --query SecretString --output text) || return 1
  jq -r '{host,port,dbname,username,engine} | to_entries[] | "  \(.key)\t\(.value)"' <<<"$json" 2>/dev/null | column -t -s $'\t'
  jq -r '.password' <<<"$json" | tr -d '\n' | pbcopy
  echo "  password → clipboard (not printed, not in history)"
  # a ready-to-paste psql line, without the password in it
  local h p d u
  h=$(jq -r .host <<<"$json"); p=$(jq -r .port <<<"$json")
  d=$(jq -r .dbname <<<"$json"); u=$(jq -r .username <<<"$json")
  [[ "$h" != "null" ]] && echo "  psql -h $h -p $p -U $u -d $d      # paste password when prompted"
}

#@ ssm	fuzzy-pick and read an SSM parameter (decrypted)
ssm() {
  local name="${1:-$(aws ssm describe-parameters --query 'Parameters[].Name' --output text | tr '\t' '\n' | sort | fzf --header 'SSM parameter')}"
  [[ -z "$name" ]] && return 1
  aws ssm get-parameter --name "$name" --with-decryption --query 'Parameter.Value' --output text
}

# ===========================================================================
#  ECS
# ===========================================================================

#@ ecs	fuzzy-drill: cluster → service → show deployments, events and task health
ecs() {
  local cluster svc
  cluster=$(aws ecs list-clusters --query 'clusterArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' | fzf --header cluster) || return
  svc=$(aws ecs list-services --cluster "$cluster" --query 'serviceArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' \
        | fzf --header "service in $cluster" \
              --preview "aws ecs describe-services --cluster $cluster --services {} --query 'services[0].{desired:desiredCount,running:runningCount,pending:pendingCount,status:status}' --output table") || return
  echo "── deployments ──"
  aws ecs describe-services --cluster "$cluster" --services "$svc" \
    --query 'services[0].deployments[].{status:status,taskDef:taskDefinition,desired:desiredCount,running:runningCount,failed:failedTasks,rollout:rolloutState}' --output table
  echo "── recent events ──"
  aws ecs describe-services --cluster "$cluster" --services "$svc" \
    --query 'services[0].events[:12].[createdAt,message]' --output text
}

#@ ecsx	exec a shell into a running ECS task (requires enableExecuteCommand on the service)
ecsx() {
  local cluster task
  cluster=$(aws ecs list-clusters --query 'clusterArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' | fzf --header cluster) || return
  task=$(aws ecs list-tasks --cluster "$cluster" --query 'taskArns[]' --output text | tr '\t' '\n' | fzf --header task) || return
  local container
  container=$(aws ecs describe-tasks --cluster "$cluster" --tasks "$task" \
    --query 'tasks[0].containers[].name' --output text | tr '\t' '\n' | fzf --select-1 --header container) || return
  aws ecs execute-command --cluster "$cluster" --task "$task" --container "$container" --interactive --command "/bin/sh"
}

# ===========================================================================
#  CLOUDWATCH LOGS
#  `aws logs tail` is criminally underused. It does live follow, relative time
#  ranges, and filter patterns — no console tab required.
# ===========================================================================

#@ cwt	fuzzy-pick a log group and tail it live
cwt() {
  local group
  group=$(aws logs describe-log-groups --query 'logGroups[].logGroupName' --output text | tr '\t' '\n' | fzf --header 'log group') || return
  shift 2>/dev/null
  aws logs tail "$group" --follow --format short "$@"
}

#@ cwg	fuzzy log group, then grep it over a time window: cwg 2h ERROR
cwg() {
  local since="${1:-1h}" pattern="${2:-}"
  local group
  group=$(aws logs describe-log-groups --query 'logGroups[].logGroupName' --output text | tr '\t' '\n' | fzf --header 'log group') || return
  aws logs tail "$group" --since "$since" --format short ${pattern:+--filter-pattern "$pattern"}
}

#@ cwi	CloudWatch Logs Insights from the terminal: cwi <group> '<query>' [since]
cwi() {
  local group="${1:?usage: cwi <log-group> <query> [since-minutes, default 60]}"
  local query="${2:?}" mins="${3:-60}"
  local end=$(date +%s) start=$(( $(date +%s) - mins * 60 ))
  local qid
  qid=$(aws logs start-query --log-group-name "$group" --start-time "$start" --end-time "$end" \
        --query-string "$query" --query queryId --output text) || return 1
  printf 'query %s running' "$qid"
  local status
  while :; do
    sleep 1; printf '.'
    status=$(aws logs get-query-results --query-id "$qid" --query status --output text)
    [[ "$status" != "Running" && "$status" != "Scheduled" ]] && break
  done
  echo
  aws logs get-query-results --query-id "$qid" --output json \
    | jq -r '.results[] | map({(.field): .value}) | add'
}

# --- everyday shorthands ----------------------------------------------------
#@ awsid	just the account id
alias awsid='aws sts get-caller-identity --query Account --output text'
#@ awsregions	list enabled regions
alias awsregions='aws ec2 describe-regions --query "Regions[].RegionName" --output text | tr "\t" "\n" | sort'

# ===========================================================================
#  ECS — the bits you need weekly once you are off EKS
# ===========================================================================

#@ ecsps	running tasks for a fuzzy-picked service, with health and age
ecsps() {
  local cluster svc
  cluster=$(aws ecs list-clusters --query 'clusterArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' | fzf --header cluster) || return
  svc=$(aws ecs list-services --cluster "$cluster" --query 'serviceArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' | fzf --header service) || return
  local tasks
  tasks=$(aws ecs list-tasks --cluster "$cluster" --service-name "$svc" --query 'taskArns[]' --output text)
  [[ -z "$tasks" ]] && { echo "no running tasks"; return 1 }
  aws ecs describe-tasks --cluster "$cluster" --tasks ${=tasks} \
    --query 'tasks[].{task:taskArn,status:lastStatus,health:healthStatus,started:startedAt,cpu:cpu,mem:memory}' \
    --output table
}

#@ ecslog	tail the CloudWatch logs of a fuzzy-picked ECS service
ecslog() {
  local cluster svc group
  cluster=$(aws ecs list-clusters --query 'clusterArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' | fzf --header cluster) || return
  svc=$(aws ecs list-services --cluster "$cluster" --query 'serviceArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' | fzf --header service) || return
  # resolve the task definition -> log group, rather than making you guess it
  local td
  td=$(aws ecs describe-services --cluster "$cluster" --services "$svc" --query 'services[0].taskDefinition' --output text)
  group=$(aws ecs describe-task-definition --task-definition "$td" \
          --query 'taskDefinition.containerDefinitions[0].logConfiguration.options."awslogs-group"' --output text)
  [[ -z "$group" || "$group" == "None" ]] && { echo "no awslogs group on $td"; return 1 }
  echo "tailing $group  (Ctrl-C to stop)"
  aws logs tail "$group" --follow --format short "$@"
}

#@ ecsdeploy	is the rollout finished? deployments + failed tasks + recent events
ecsdeploy() {
  local cluster svc
  cluster=$(aws ecs list-clusters --query 'clusterArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' | fzf --header cluster) || return
  svc=$(aws ecs list-services --cluster "$cluster" --query 'serviceArns[]' --output text | tr '\t' '\n' | sed 's|.*/||' | fzf --header service) || return
  echo "── deployments (rolloutState is the answer to 'did it go out?') ──"
  aws ecs describe-services --cluster "$cluster" --services "$svc" \
    --query 'services[0].deployments[].{state:rolloutState,status:status,desired:desiredCount,running:runningCount,pending:pendingCount,failed:failedTasks,taskDef:taskDefinition}' \
    --output table
  echo "── last 10 events ──"
  aws ecs describe-services --cluster "$cluster" --services "$svc" \
    --query 'services[:1].events[:10].[createdAt,message]' --output text
}
