# optional :: Splunk  —  enable with: export SDE_ENABLE="splunk"
#
# Why bother when the web UI exists? Three reasons:
#   1. Your searches become files you can version, review and reuse.
#   2. Results become JSON you can pipe into jq, into a diff, into a ticket.
#   3. An AI agent can run a *script* safely. It cannot click your Splunk UI.
#
# Setup (once) — put these in ~/.config/staff-dev-env/splunk.env, chmod 600:
#     SPLUNK_HOST=https://splunk.yourcorp.com:8089
#     SPLUNK_TOKEN=eyJ...            # Settings → Tokens → New Token
# The wrapper script `splunkq` (in bin/) reads that file.

: ${SPLUNK_ENV_FILE:="$STAFF_DEV_ENV_HOME/splunk.env"}
export SPLUNK_ENV_FILE

#@ spl	run SPL and get a table: spl 'index=app_prod error | stats count by service'
spl() { splunkq -f table "$@"; }

#@ splj	run SPL and get JSON — pipe this into jq, or into an agent
splj() { splunkq -f json "$@"; }

#@ splc	run SPL and get CSV — for spreadsheets and for diffing two runs
splc() { splunkq -f csv "$@"; }

#@ spls	save the SPL you just ran into a versioned file: spls <name>
spls() {
  local name="${1:?usage: spls <query-name>}"
  local dir="$STAFF_DEV_ENV_HOME/splunk/queries"; mkdir -p "$dir"
  fc -ln -1 | sed "s/^ *spl[jc]* *//" > "$dir/$name.spl"
  echo "saved → $dir/$name.spl"
}

#@ splr	fuzzy-pick a saved query, preview it, run it
splr() {
  local dir="$STAFF_DEV_ENV_HOME/splunk/queries"
  local f; f=$(fd -e spl . "$dir" 2>/dev/null | fzf --preview 'bat --color=always -l sql {}') || return
  echo "── $f ──"; cat "$f"; echo "──"
  splunkq -f table "$(cat "$f")"
}

# ---------------------------------------------------------------------------
# Time helpers. Splunk time modifiers are the thing everyone gets wrong.
#   -15m      relative
#   -1d@d     one day ago, SNAPPED to midnight  ← @ is the snap operator
#   @w0       start of this week (Sunday)
#   -60m@m    60 minutes ago, snapped to the minute (stable bucket boundaries)
# Snapping matters: without @, every re-run shifts your buckets and your
# timechart looks different each time you press enter.
# ---------------------------------------------------------------------------
#@ spltime	print a cheat sheet of Splunk time modifiers
spltime() {
  cat <<'EOF'
  earliest=-15m  latest=now          last 15 minutes
  earliest=-1h@h latest=@h           the previous full clock hour  (stable buckets)
  earliest=-1d@d latest=@d           all of yesterday
  earliest=@d                        since midnight today
  earliest=-7d@d latest=@d           the last 7 full days
  earliest=@w0                       since the start of this week (Sunday)
  earliest=-30d@d latest=-1d@d       last 30 days, excluding today (no partial day)

  snap units: @s @m @h @d @w @mon @q @y      offsets: s m h d w mon q y
  RULE: always snap when comparing time ranges, never snap when tailing live.
EOF
}

# ---------------------------------------------------------------------------
# Query fragments you will reuse. These are *starting points* — the full
# playbooks are in docs/02-SPLUNK-SPL.md.
# ---------------------------------------------------------------------------
#@ spl5xx	5xx rate over time by service: spl5xx <index> [minutes]
spl5xx() {
  local idx="${1:?usage: spl5xx <index> [minutes=60]}" mins="${2:-60}"
  spl "search index=$idx earliest=-${mins}m@m latest=@m status>=500
       | timechart span=1m count by service limit=10 useother=f"
}

#@ spltrace	follow one correlation id across every index: spltrace <id>
spltrace() {
  local id="${1:?usage: spltrace <correlation-or-trace-id> [hours=4]}" hrs="${2:-4}"
  spl "search index=* earliest=-${hrs}h \"$id\"
       | eval svc=coalesce(service,application,sourcetype)
       | sort 0 _time
       | table _time index svc level status message
       | head 500"
}

#@ splp95	latency percentiles by endpoint: splp95 <index> [minutes]
splp95() {
  local idx="${1:?usage: splp95 <index> [minutes=60]}" mins="${2:-60}"
  spl "search index=$idx earliest=-${mins}m@m latest=@m duration=*
       | stats count, avg(duration) as avg, perc50(duration) as p50,
               perc95(duration) as p95, perc99(duration) as p99 by endpoint
       | sort - p95 | head 25 | fieldformat avg=round(avg,1)"
}
