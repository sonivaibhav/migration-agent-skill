# 00 :: PATH and environment
#
# Rule for a managed Mac: prepend YOUR bin dirs, never remove the company's.
# typeset -U keeps PATH deduplicated, which matters because corporate shell
# profiles love to append the same entry three times.

# -g forces global scope. Without it, if this file is ever sourced from inside a
# function, `path` becomes function-local, PATH is silently emptied for the rest
# of the load, and you get baffling "command not found: mkdir" errors.
typeset -gU path PATH

path=(
  "$HOME/.local/bin"                      # our tools land here
  "$HOME/.local/share/mise/shims"         # mise-managed binaries
  $path                                   # <-- everything the company set up
)
export PATH

# --- editor -----------------------------------------------------------------
# `code -w` is a good $EDITOR because git/tmux/fzf will block until you close
# the tab. If the `code` shim is not installed: VS Code -> Cmd+Shift+P ->
# "Shell Command: Install 'code' command in PATH".
if command -v code >/dev/null 2>&1; then
  export EDITOR="code -w"
  export VISUAL="code -w"
else
  export EDITOR="vim"
  export VISUAL="vim"
fi
# Deliberately keep a terminal editor for git rebase todo lists — waiting on a
# GUI window for a 4-line rebase todo is friction you will feel every day.
export GIT_SEQUENCE_EDITOR="${GIT_SEQUENCE_EDITOR:-vim}"

# --- pagers -----------------------------------------------------------------
export PAGER="less"
# -F quit if one screen, -R keep colors, -X don't clear screen, -i smart case
export LESS="-FRXi"
if command -v bat >/dev/null 2>&1; then
  export MANPAGER="sh -c 'sed -e s/.\\\\x08//g | bat -l man -p'"
  export BAT_THEME="${BAT_THEME:-ansi}"
fi

# --- language toolchains ----------------------------------------------------
export NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=8192}"  # big monorepo builds
export PNPM_HOME="${PNPM_HOME:-$HOME/Library/pnpm}"
path=("$PNPM_HOME" $path)

# --- misc -------------------------------------------------------------------
export LANG="${LANG:-en_US.UTF-8}"
export AWS_PAGER=""            # stop aws cli from opening less on every command
export AWS_CLI_AUTO_PROMPT="off"

# mise activation (no-op if mise isn't installed)
command -v mise >/dev/null 2>&1 && eval "$(mise activate zsh)"
