# staff-dev-env :: loader
#
# The ONLY line appended to your ~/.zshrc points here.
#
# TWO TIERS, on purpose:
#
#   zsh/*.zsh           CORE. Always loads. 8 files. This is the minimal set:
#                       path, history, completion, vi-mode, tools, navigation,
#                       git, prompt.
#
#   zsh/optional/*.zsh  OPT-IN. Loads only if you name it. Nothing here runs
#                       until you ask for it, so you are never carrying weight
#                       you don't use:
#                           export SDE_ENABLE="aws frontend"
#
# Turn a CORE module off by its number:
#                           export SDE_DISABLE="90"      # keep your own prompt
#
# Both go in ~/.zshrc ABOVE the staff-dev-env block.

: ${STAFF_DEV_ENV_HOME:="$HOME/.config/staff-dev-env"}
export STAFF_DEV_ENV_HOME
: ${SDE_DISABLE:=""}
: ${SDE_ENABLE:=""}

# Track functions and aliases separately. A name that already existed as YOUR
# alias and now also exists as OUR function is the case we care about — a merged
# set would miss it, because the name isn't new.
typeset -ga SDE_OWNED SDE_FUNCS SDE_ALIASES
_sde_fn_before=(${(k)functions})
_sde_al_before=(${(k)aliases})

# ---------------------------------------------------------------------------
# CRITICAL: disable alias EXPANSION while sourcing.
#
# If you already have `alias gco='git checkout'` (oh-my-zsh ships exactly that),
# zsh cannot even parse our `gco() { ... }` — it expands the alias inside the
# function name and dies with:
#     defining function based on alias `gco'
#     parse error near `()'
# ...which aborts the REST OF THAT FILE. You would lose every function defined
# after it, silently, with two lines of warning at startup.
#
# `unsetopt aliases` stops expansion during parsing. Defining aliases still
# works, so our own `alias cat='bat …'` lines are unaffected. Restored after.
# ---------------------------------------------------------------------------
_sde_aliases_were=${options[aliases]}
unsetopt aliases

# --- core -------------------------------------------------------------------
for _sde_f in "$STAFF_DEV_ENV_HOME"/zsh/[0-9]*.zsh(N); do
  _sde_base="${_sde_f:t}"
  [[ " $SDE_DISABLE " == *" ${_sde_base%%-*} "* ]] && continue
  source "$_sde_f"
done

# --- opt-in -----------------------------------------------------------------
for _sde_name in ${=SDE_ENABLE}; do
  _sde_f="$STAFF_DEV_ENV_HOME/zsh/optional/${_sde_name}.zsh"
  if [[ -r "$_sde_f" ]]; then
    source "$_sde_f"
  else
    print -u2 "staff-dev-env: no optional module '${_sde_name}' (available: ${$(print -l "$STAFF_DEV_ENV_HOME"/zsh/optional/*.zsh(N:t:r))//$'\n'/ })"
  fi
done

[[ "$_sde_aliases_were" == on ]] && setopt aliases

SDE_FUNCS=(${${${(k)functions}:|_sde_fn_before}:#_*})
SDE_ALIASES=(${${${(k)aliases}:|_sde_al_before}:#_*})
SDE_OWNED=(${(u)SDE_FUNCS} ${(u)SDE_ALIASES})
unset _sde_f _sde_base _sde_name _sde_fn_before _sde_al_before _sde_aliases_were

# ---------------------------------------------------------------------------
# sde-help : you will forget these. This is how you find them again.
# ---------------------------------------------------------------------------
sde-help() {
  local filter="${1:-}"
  print -P "%B staff-dev-env %b  (usage: sde-help [filter])\n"
  grep -h '^#@ ' "$STAFF_DEV_ENV_HOME"/zsh/*.zsh "$STAFF_DEV_ENV_HOME"/zsh/optional/*.zsh 2>/dev/null \
    | sed 's/^#@ //' \
    | { [[ -n "$filter" ]] && grep -i -- "$filter" || cat; } \
    | awk -F'\t+' '{ printf "  \033[36m%-16s\033[0m %s\n", $1, $2 }'
  if [[ -z "$filter" ]]; then
    print -P "\n%B optional modules %b  (enable with: export SDE_ENABLE=\"aws terraform\")"
    local m
    for m in "$STAFF_DEV_ENV_HOME"/zsh/optional/*.zsh(N); do
      if [[ " ${SDE_ENABLE} " == *" ${m:t:r} "* ]]; then
        printf "  \033[32m● %-14s\033[0m enabled\n" "${m:t:r}"
      else
        printf "  \033[90m○ %-14s\033[0m off\n" "${m:t:r}"
      fi
    done
  fi
}

# ---------------------------------------------------------------------------
# sde-unshadow : our functions that a pre-existing alias is silently hiding.
#
# zsh expands aliases BEFORE it resolves functions. So if you already had
# `alias gco='git checkout'`, our richer `gco` is unreachable — with no error.
# Load order does not help. We do NOT unalias anything automatically; deleting
# a name you rely on without asking is not our call.
# ---------------------------------------------------------------------------
sde-unshadow() {
  local fix=0 name shadowed=()
  [[ "${1:-}" == "--fix" ]] && fix=1
  for name in $SDE_FUNCS; do
    (( ${+aliases[$name]} )) && shadowed+=("$name")
  done

  if (( ${#shadowed} == 0 )); then
    print -P "%F{green}nothing shadowed%f — every staff-dev-env function is reachable"
    return 0
  fi

  print -P "%B${#shadowed} of our functions are hidden by an alias you already had:%b\n"
  for name in $shadowed; do
    printf '  %-14s alias %s=%s\n' "$name" "$name" "${(qqq)aliases[$name]}"
  done

  if (( fix )); then
    for name in $shadowed; do unalias "$name"; done
    print -P "\n%F{green}unaliased for THIS shell.%f To keep it, add to ~/.zshrc"
    print    "AFTER the staff-dev-env block:\n"
    print    "  unalias ${shadowed} 2>/dev/null"
  else
    print -P "\n%F{yellow}run 'sde-unshadow --fix'%f to unalias them here,"
    print    "or keep yours — nothing is broken, ours are just unreachable."
  fi
}

# ---------------------------------------------------------------------------
# sde-doctor : what's installed, what isn't, and whether anything is hidden
# ---------------------------------------------------------------------------
sde-doctor() {
  local t
  print -P "%B core tools %b  (the minimal set — everything else is optional)"
  for t in git zsh rg fzf tmux; do
    if command -v $t >/dev/null 2>&1; then
      printf '  \033[32m✓\033[0m %-8s %s\n' "$t" "$(command -v $t)"
    else
      printf '  \033[31m✗\033[0m %-8s MISSING — request this one\n' "$t"
    fi
  done

  print -P "\n%B nice to have %b"
  for t in fd bat delta lazygit zoxide; do
    if command -v $t >/dev/null 2>&1; then
      printf '  \033[32m✓\033[0m %-8s %s\n' "$t" "$(command -v $t)"
    else
      printf '  \033[90m·\033[0m %-8s not installed (degrades gracefully)\n' "$t"
    fi
  done

  print -P "\n%B context %b"
  printf '  theme          %s\n' "${SDE_THEME:-minimal}"
  printf '  core disabled  %s\n' "${SDE_DISABLE:-<none>}"
  printf '  optional on    %s\n' "${SDE_ENABLE:-<none>}"
  printf '  shortcuts      %s registered  (jl to list)\n' "${#SDE_DIRS}"
  printf '  names added    %s\n' "${#SDE_OWNED}"

  local -a shadowed
  local n
  for n in $SDE_FUNCS; do (( ${+aliases[$n]} )) && shadowed+=("$n"); done
  if (( ${#shadowed} )); then
    print -P "\n%F{yellow}  ⚠ ${#shadowed} of our functions are hidden by your own aliases:%f"
    printf '    %s\n' "${shadowed[*]}"
    print    "    they will silently do the OLD thing. run: sde-unshadow --fix"
  fi
}
