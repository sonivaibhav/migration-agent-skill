# 20 :: completion
#
# No oh-my-zsh. It is ~3000 lines of framework to get things zsh does natively
# in 30. On a monorepo machine the startup cost is real and the abstraction
# actively hides what your shell is doing. This module is the whole benefit.

autoload -Uz compinit

# compinit does a security audit of every file in fpath on every shell start.
# That's ~200ms you pay 40 times a day. Cache it: full check once per day.
_sde_zcompdump="${XDG_CACHE_HOME:-$HOME/.cache}/zsh/zcompdump-${ZSH_VERSION}"
mkdir -p "${_sde_zcompdump:h}"
if [[ -n "$_sde_zcompdump"(#qN.mh+24) ]]; then
  compinit -d "$_sde_zcompdump"
else
  compinit -C -d "$_sde_zcompdump"     # -C = trust the cache, skip the audit
fi
unset _sde_zcompdump

zmodload -i zsh/complist

# --- behaviour --------------------------------------------------------------
zstyle ':completion:*' menu select                      # arrow-key menu
zstyle ':completion:*' matcher-list \
  'm:{a-zA-Z}={A-Za-z}' \
  'r:|[._-]=* r:|=*' \
  'l:|=* r:|=*'                                         # case-insensitive + fuzzy-ish
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*' group-name ''
zstyle ':completion:*:descriptions' format '%F{yellow}%B%d%b%f'
zstyle ':completion:*:warnings'     format '%F{red}no matches%f'
zstyle ':completion:*' use-cache on
zstyle ':completion:*' cache-path "${XDG_CACHE_HOME:-$HOME/.cache}/zsh/zcompcache"

# Don't offer the argument you just used (huge for `git checkout`, long aws commands)
zstyle ':completion:*:*:*:*:*' ignore-line other

# kill/ps completion that's actually usable
zstyle ':completion:*:*:kill:*:processes' \
  list-colors '=(#b) #([0-9]#)*=0=01;31'
zstyle ':completion:*:kill:*' command 'ps -u $USER -o pid,%cpu,tty,cputime,cmd'

# In the completion menu, hjkl navigates (vim muscle memory pays off here too)
bindkey -M menuselect 'h' vi-backward-char
bindkey -M menuselect 'j' vi-down-line-or-history
bindkey -M menuselect 'k' vi-up-line-or-history
bindkey -M menuselect 'l' vi-forward-char
bindkey -M menuselect '^[' undo

# --- tool-provided completions ---------------------------------------------
# Generate these once into a cached fpath dir rather than eval-ing on every start.
_sde_compdir="${XDG_CACHE_HOME:-$HOME/.cache}/zsh/completions"
mkdir -p "$_sde_compdir"
fpath=("$_sde_compdir" $fpath)

_sde_gen_completion() {   # _sde_gen_completion <cmd> <file> <generator...>
  local cmd="$1" out="$_sde_compdir/$2"; shift 2
  command -v "$cmd" >/dev/null 2>&1 || return 0
  [[ -s "$out" ]] && return 0
  "$@" > "$out" 2>/dev/null || rm -f "$out"
}
_sde_gen_completion gh      _gh      gh completion -s zsh
_sde_gen_completion pnpm    _pnpm    pnpm completion zsh
_sde_gen_completion mise    _mise    mise completion zsh
unfunction _sde_gen_completion
unset _sde_compdir

# terraform ships its own completion registration
command -v terraform >/dev/null 2>&1 && complete -o nospace -C "$(command -v terraform)" terraform

# aws-cli v2 completer, if the company image has it
[[ -x /usr/local/bin/aws_completer ]] && complete -C /usr/local/bin/aws_completer aws
command -v aws_completer >/dev/null 2>&1 && complete -C "$(command -v aws_completer)" aws
