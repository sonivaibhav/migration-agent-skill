# 10 :: history + shell options
#
# This module is the single highest-ROI thing in the whole repo and it is
# 20 lines of config. Default zsh history is 1000 lines, not shared between
# panes, and loses everything if a shell crashes. Fix that once, forever.

HISTFILE="$HOME/.zsh_history"
HISTSIZE=200000          # in-memory
SAVEHIST=200000          # on-disk

setopt EXTENDED_HISTORY        # record timestamp + duration
setopt INC_APPEND_HISTORY      # write as you go, not on exit (tmux-safe)
setopt SHARE_HISTORY           # every pane sees every other pane's history
setopt HIST_IGNORE_DUPS        # don't log an immediately repeated command
setopt HIST_IGNORE_ALL_DUPS    # drop older duplicates entirely
setopt HIST_IGNORE_SPACE       # ` command` (leading space) stays out of history
setopt HIST_REDUCE_BLANKS
setopt HIST_VERIFY             # expand !! and let you edit before running
setopt HIST_FIND_NO_DUPS

# Never record these — they are noise, or they leak.
HISTORY_IGNORE='(ls|ll|cd|cd ..|pwd|exit|clear|c)'
zshaddhistory() {
  # Also drop anything that smells like a credential on the command line.
  [[ "$1" != *(AWS_SECRET|--password|--token|PGPASSWORD)* ]]
}

# --- directory navigation ---------------------------------------------------
setopt AUTO_CD                 # `src/` instead of `cd src/`
setopt AUTO_PUSHD              # every cd pushes to the dir stack
setopt PUSHD_IGNORE_DUPS
setopt PUSHD_SILENT
DIRSTACKSIZE=20
#@ d	list recent directories; `1`..`9` jumps to one (AUTO_PUSHD)
alias d='dirs -v | head -10'
for i in {1..9}; do alias "$i"="cd +$i"; done

# --- globbing ---------------------------------------------------------------
setopt EXTENDED_GLOB           # ^, ~, # in globs. `ls ^*.ts` = everything but .ts
setopt NO_CASE_GLOB
setopt NUMERIC_GLOB_SORT
unsetopt NOMATCH               # a non-matching glob is passed through, not fatal

# --- correction / safety ----------------------------------------------------
setopt INTERACTIVE_COMMENTS    # `#` comments work interactively (great for notes)
setopt NO_BEEP
setopt NO_FLOW_CONTROL         # frees Ctrl-S / Ctrl-Q for real keybindings
unsetopt CORRECT_ALL           # zsh "did you mean" is more annoying than useful
