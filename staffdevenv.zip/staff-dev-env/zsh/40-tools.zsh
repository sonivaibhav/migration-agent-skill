# 40 :: fzf and friends
#
# Only two tools here are load-bearing: ripgrep and fzf. Everything else is
# guarded by `command -v`, so this file works fine on a machine where nothing
# else has been approved yet. Nothing breaks; you just get less.
#
# fzf is worth understanding rather than just installing. On its own it is a
# fuzzy filter. The value is the PATTERN: pipe your own data in, act on what
# comes out. `j`, `f`, `s` and every git picker in module 60 are the same three
# lines with a different producer. Learn it once, apply it forever.

export RIPGREP_CONFIG_PATH="${STAFF_DEV_ENV_HOME}/zsh/ripgreprc"
_SDE_IGNORE="${STAFF_DEV_ENV_HOME}/zsh/fdignore"

# ------------------------------------------------------------------- fzf ----
if command -v fzf >/dev/null 2>&1; then

  if command -v fd >/dev/null 2>&1; then
    export FZF_DEFAULT_COMMAND="fd --type f --hidden --follow --exclude .git --ignore-file $_SDE_IGNORE"
    export FZF_ALT_C_COMMAND="fd --type d --hidden --follow --exclude .git --ignore-file $_SDE_IGNORE"
  else
    # fd not approved yet — ripgrep can list files too, and it honours .gitignore
    export FZF_DEFAULT_COMMAND="rg --files --hidden --glob '!.git'"
  fi
  export FZF_CTRL_T_COMMAND="$FZF_DEFAULT_COMMAND"

  export FZF_DEFAULT_OPTS="
    --height=60%
    --layout=reverse
    --border=rounded
    --info=inline
    --cycle
    --pointer='▶'
    --marker='✓'
    --bind='ctrl-/:toggle-preview'
    --bind='ctrl-u:preview-half-page-up'
    --bind='ctrl-d:preview-half-page-down'
    --bind='ctrl-y:execute-silent(printf %s {+} | pbcopy)+abort'
    --bind='alt-a:toggle-all'
  "
  # ctrl-y copies the highlighted line to the clipboard and quits. You will use
  # this constantly — branch names, file paths, container IDs, ARNs.

  if command -v bat >/dev/null 2>&1; then
    export FZF_CTRL_T_OPTS="--preview 'bat --style=numbers --color=always --line-range :300 {}'"
  fi

  # Shell integration: Ctrl-R history, Ctrl-T file, Alt-C cd.
  # fzf >= 0.48 exposes `fzf --zsh`; older builds ship files.
  if fzf --zsh >/dev/null 2>&1; then
    source <(fzf --zsh)
  else
    for _p in /usr/share/fzf ~/.fzf/shell /opt/fzf/shell \
              "$HOME/.local/share/mise/installs/fzf"/*/shell; do
      [[ -f "$_p/key-bindings.zsh" ]] && source "$_p/key-bindings.zsh" && break
    done
    unset _p
  fi
fi
#@ Ctrl-R	fuzzy search your shell history
#@ Ctrl-T	insert a file path into the current command
#@ Alt-C	cd into a subdirectory, fuzzy-picked

# ------------------------------------------------------------------- bat ----
if command -v bat >/dev/null 2>&1; then
  #@ cat	bat — syntax highlighting, no pager, still pipes correctly
  alias cat='bat --paging=never --style=plain'
  #@ catn	bat with line numbers and the git change gutter
  alias catn='bat --style=numbers,changes'
  export BAT_THEME="${BAT_THEME:-ansi}"
  export MANPAGER="sh -c 'sed -e s/.\\\\x08//g | bat -l man -p'"
fi

# ------------------------------------------------------------------- ls -----
if command -v eza >/dev/null 2>&1; then
  alias ls='eza --group-directories-first --icons=never'
  alias ll='eza -l --group-directories-first --git --time-style=relative'
  alias la='eza -la --group-directories-first --git --time-style=relative'
  #@ lt	tree view, 2 levels, respects .gitignore
  alias lt='eza --tree --level=2 --git-ignore'
else
  alias ll='ls -lh'
  alias la='ls -lah'
fi

# ---------------------------------------------------------------- zoxide ----
# Optional, and it overlaps with module 50's `j`. The difference:
#   j       explicit — you registered the folder, it always goes there
#   cd      learned  — zoxide ranks by how often you actually visit
# Having both is fine; `j` is predictable, zoxide is convenient.
if command -v zoxide >/dev/null 2>&1; then
  eval "$(zoxide init zsh --cmd cd)"
fi
#@ cd <bit>	with zoxide installed: jump to the best-matching visited directory
