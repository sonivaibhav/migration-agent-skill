# 30 :: vi mode in the shell
#
# WHY THIS MODULE EXISTS: you asked to learn Vim motions without abandoning
# IntelliJ/VS Code. The shell is the best practice ground, because every command
# you type is a tiny editing exercise with instant feedback and zero stakes.
# Twenty times a day you will want to fix the middle of a long aws or git command.
# That is where motions become muscle memory.
#
# The escape hatch: the emacs-style keys you already know (Ctrl-A, Ctrl-E,
# Ctrl-W, Ctrl-K) are explicitly kept below, so you are never stuck.

bindkey -v
export KEYTIMEOUT=15        # 150ms is the default and feels laggy after `Esc`

# --- text objects (zsh 5.0.8+) ---------------------------------------------
# Gives you ci" ci' ci( ca{ di[ etc. — exactly like vim. This is the single
# most useful vim skill for shell work: `ci"` to replace a quoted argument.
autoload -Uz select-bracketed select-quoted
zle -N select-quoted
zle -N select-bracketed
for m in visual viopp; do
  for c in {a,i}${(s..)^:-\'\"\`\|,./:;=+@}; do bindkey -M $m $c select-quoted; done
  for c in {a,i}${(s..)^:-'()[]{}<>bB'}; do bindkey -M $m $c select-bracketed; done
done
autoload -Uz surround
zle -N delete-surround surround
zle -N add-surround surround
zle -N change-surround surround
bindkey -M vicmd cs change-surround
bindkey -M vicmd ds delete-surround
bindkey -M vicmd ys add-surround
bindkey -M visual S add-surround

# --- edit the current command line in $EDITOR -------------------------------
# Normal mode `v`, or Ctrl-X Ctrl-E from insert mode. When a one-liner grows
# into a five-line loop, this is how you escape the single-line prison.
autoload -Uz edit-command-line
zle -N edit-command-line
bindkey -M vicmd 'v' edit-command-line
bindkey '^X^E' edit-command-line

# --- history search that respects what you already typed --------------------
autoload -Uz up-line-or-beginning-search down-line-or-beginning-search
zle -N up-line-or-beginning-search
zle -N down-line-or-beginning-search
bindkey -M vicmd 'k' up-line-or-beginning-search
bindkey -M vicmd 'j' down-line-or-beginning-search
bindkey '^[[A' up-line-or-beginning-search      # up arrow
bindkey '^[[B' down-line-or-beginning-search    # down arrow

# --- the emacs keys you keep, because muscle memory is a sunk cost ---------
bindkey -M viins '^A' beginning-of-line
bindkey -M viins '^E' end-of-line
bindkey -M viins '^K' kill-line
bindkey -M viins '^U' backward-kill-line
bindkey -M viins '^W' backward-kill-word
bindkey -M viins '^Y' yank
bindkey -M viins '^?' backward-delete-char       # backspace over the insert point
bindkey -M viins '^H' backward-delete-char
bindkey -M viins '^[[3~' delete-char

# --- mode indicator via cursor shape ---------------------------------------
# Block = normal mode, beam = insert. Without this you will constantly be unsure
# which mode you're in, which is the #1 reason people abandon shell vi-mode.
_sde_cursor() {
  case "${KEYMAP:-viins}" in
    vicmd)             printf '\e[2 q' ;;   # steady block
    viins|main|*)      printf '\e[6 q' ;;   # steady beam
  esac
}
zle-keymap-select() { _sde_cursor; }
zle-line-init()     { _sde_cursor; }
zle -N zle-keymap-select
zle -N zle-line-init
precmd_functions+=(_sde_cursor)

# --- yank to the macOS clipboard from vicmd ---------------------------------
# `yy` copies the whole command line to the system clipboard. Useful constantly:
# build a command interactively, then paste it into a runbook or a PR comment.
_sde_vi_yank_clip() {
  zle vi-yank-whole-line
  printf '%s' "$CUTBUFFER" | pbcopy 2>/dev/null
}
zle -N _sde_vi_yank_clip
bindkey -M vicmd 'yy' _sde_vi_yank_clip

#@ Esc then ...	shell vi-mode: ciw cw ci" f<char> 0 $ A I b w — same as IntelliJ
#@ v (normal)	open the current command line in $EDITOR, save+quit to run it
